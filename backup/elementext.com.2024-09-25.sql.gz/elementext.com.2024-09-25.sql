--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.11
-- Dumped by pg_dump version 9.6.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: about_aboutblock; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.about_aboutblock (
    attachableblock_ptr_id integer NOT NULL,
    header character varying(128) NOT NULL,
    description text NOT NULL,
    link_text character varying(128) NOT NULL
);


--
-- Name: about_aboutpageconfig; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.about_aboutpageconfig (
    id integer NOT NULL,
    title character varying(128) NOT NULL,
    header text,
    description text NOT NULL,
    background character varying(100) NOT NULL,
    visible boolean NOT NULL,
    updated timestamp with time zone NOT NULL,
    text text NOT NULL
);


--
-- Name: about_aboutpageconfig_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.about_aboutpageconfig_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: about_aboutpageconfig_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.about_aboutpageconfig_id_seq OWNED BY public.about_aboutpageconfig.id;


--
-- Name: attachable_blocks_attachableblock; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.attachable_blocks_attachableblock (
    id integer NOT NULL,
    label character varying(128) NOT NULL,
    visible boolean NOT NULL,
    created timestamp with time zone NOT NULL,
    updated timestamp with time zone NOT NULL,
    content_type_id integer
);


--
-- Name: attachable_blocks_attachableblock_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.attachable_blocks_attachableblock_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: attachable_blocks_attachableblock_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.attachable_blocks_attachableblock_id_seq OWNED BY public.attachable_blocks_attachableblock.id;


--
-- Name: attachable_blocks_attachablereference; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.attachable_blocks_attachablereference (
    id integer NOT NULL,
    object_id integer NOT NULL,
    ajax boolean NOT NULL,
    set_name character varying(32) NOT NULL,
    sort_order integer NOT NULL,
    block_id integer NOT NULL,
    block_ct_id integer,
    content_type_id integer NOT NULL
);


--
-- Name: attachable_blocks_attachablereference_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.attachable_blocks_attachablereference_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: attachable_blocks_attachablereference_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.attachable_blocks_attachablereference_id_seq OWNED BY public.attachable_blocks_attachablereference.id;


--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(80) NOT NULL
);


--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.auth_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.auth_group_id_seq OWNED BY public.auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.auth_group_permissions_id_seq OWNED BY public.auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.auth_permission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.auth_permission_id_seq OWNED BY public.auth_permission.id;


--
-- Name: ckeditor_pagefile; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ckeditor_pagefile (
    id integer NOT NULL,
    app_name character varying(30) NOT NULL,
    model_name character varying(30) NOT NULL,
    instance_id integer NOT NULL,
    file character varying(100) NOT NULL
);


--
-- Name: ckeditor_pagefile_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ckeditor_pagefile_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ckeditor_pagefile_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ckeditor_pagefile_id_seq OWNED BY public.ckeditor_pagefile.id;


--
-- Name: ckeditor_pagephoto; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ckeditor_pagephoto (
    id integer NOT NULL,
    app_name character varying(30) NOT NULL,
    model_name character varying(30) NOT NULL,
    instance_id integer NOT NULL,
    photo character varying(100) NOT NULL,
    photo_crop character varying(32) NOT NULL
);


--
-- Name: ckeditor_pagephoto_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ckeditor_pagephoto_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ckeditor_pagephoto_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ckeditor_pagephoto_id_seq OWNED BY public.ckeditor_pagephoto.id;


--
-- Name: ckeditor_simplephoto; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ckeditor_simplephoto (
    id integer NOT NULL,
    app_name character varying(30) NOT NULL,
    model_name character varying(30) NOT NULL,
    instance_id integer NOT NULL,
    photo character varying(100) NOT NULL
);


--
-- Name: ckeditor_simplephoto_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ckeditor_simplephoto_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ckeditor_simplephoto_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ckeditor_simplephoto_id_seq OWNED BY public.ckeditor_simplephoto.id;


--
-- Name: config_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.config_config (
    id integer NOT NULL,
    updated timestamp with time zone NOT NULL
);


--
-- Name: config_config_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.config_config_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: config_config_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.config_config_id_seq OWNED BY public.config_config.id;


--
-- Name: contacts_address; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contacts_address (
    id integer NOT NULL,
    address character varying(255) NOT NULL,
    city character varying(255) NOT NULL,
    region character varying(64) NOT NULL,
    zip character varying(32) NOT NULL,
    coords character varying(32) NOT NULL,
    sort_order integer NOT NULL,
    updated timestamp with time zone NOT NULL,
    url character varying(200) NOT NULL,
    CONSTRAINT contacts_address_sort_order_check CHECK ((sort_order >= 0))
);


--
-- Name: contacts_address_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.contacts_address_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: contacts_address_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.contacts_address_id_seq OWNED BY public.contacts_address.id;


--
-- Name: contacts_contactblock; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contacts_contactblock (
    attachableblock_ptr_id integer NOT NULL,
    header character varying(128) NOT NULL,
    description text NOT NULL,
    background character varying(100) NOT NULL
);


--
-- Name: contacts_contactsconfig; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contacts_contactsconfig (
    id integer NOT NULL,
    header_index character varying(128) NOT NULL,
    updated timestamp with time zone NOT NULL,
    title_index character varying(75) NOT NULL,
    form_description text NOT NULL,
    form_background character varying(100) NOT NULL,
    header_form character varying(128) NOT NULL,
    title_form character varying(75) NOT NULL
);


--
-- Name: contacts_contactsconfig_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.contacts_contactsconfig_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: contacts_contactsconfig_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.contacts_contactsconfig_id_seq OWNED BY public.contacts_contactsconfig.id;


--
-- Name: contacts_estimateblock; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contacts_estimateblock (
    attachableblock_ptr_id integer NOT NULL,
    header character varying(128) NOT NULL,
    description text NOT NULL,
    background character varying(100) NOT NULL
);


--
-- Name: contacts_message; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contacts_message (
    id integer NOT NULL,
    name character varying(128) NOT NULL,
    phone character varying(32) NOT NULL,
    email character varying(254) NOT NULL,
    message text NOT NULL,
    date timestamp with time zone NOT NULL,
    referer character varying(512) NOT NULL
);


--
-- Name: contacts_message_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.contacts_message_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: contacts_message_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.contacts_message_id_seq OWNED BY public.contacts_message.id;


--
-- Name: contacts_notificationreceiver; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contacts_notificationreceiver (
    id integer NOT NULL,
    email character varying(254) NOT NULL,
    config_id integer NOT NULL
);


--
-- Name: contacts_notificationreceiver_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.contacts_notificationreceiver_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: contacts_notificationreceiver_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.contacts_notificationreceiver_id_seq OWNED BY public.contacts_notificationreceiver.id;


--
-- Name: contacts_openinghours; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contacts_openinghours (
    id integer NOT NULL,
    weekdays character varying(255) NOT NULL,
    start_time time without time zone,
    end_time time without time zone,
    address_id integer NOT NULL
);


--
-- Name: contacts_openinghours_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.contacts_openinghours_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: contacts_openinghours_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.contacts_openinghours_id_seq OWNED BY public.contacts_openinghours.id;


--
-- Name: contacts_phonenumber; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contacts_phonenumber (
    id integer NOT NULL,
    number character varying(255) NOT NULL,
    sort_order integer NOT NULL,
    address_id integer NOT NULL,
    CONSTRAINT contacts_phonenumber_sort_order_check CHECK ((sort_order >= 0))
);


--
-- Name: contacts_phonenumber_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.contacts_phonenumber_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: contacts_phonenumber_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.contacts_phonenumber_id_seq OWNED BY public.contacts_phonenumber.id;


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.django_admin_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.django_admin_log_id_seq OWNED BY public.django_admin_log.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.django_content_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.django_content_type_id_seq OWNED BY public.django_content_type.id;


--
-- Name: django_cron_cronjoblog; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.django_cron_cronjoblog (
    id integer NOT NULL,
    code character varying(64) NOT NULL,
    start_time timestamp with time zone NOT NULL,
    end_time timestamp with time zone NOT NULL,
    is_success boolean NOT NULL,
    message text NOT NULL,
    ran_at_time time without time zone
);


--
-- Name: django_cron_cronjoblog_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.django_cron_cronjoblog_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: django_cron_cronjoblog_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.django_cron_cronjoblog_id_seq OWNED BY public.django_cron_cronjoblog.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.django_migrations (
    id integer NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.django_migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.django_migrations_id_seq OWNED BY public.django_migrations.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


--
-- Name: django_site; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.django_site (
    id integer NOT NULL,
    domain character varying(100) NOT NULL,
    name character varying(50) NOT NULL
);


--
-- Name: django_site_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.django_site_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: django_site_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.django_site_id_seq OWNED BY public.django_site.id;


--
-- Name: gallery_galleryitembase; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.gallery_galleryitembase (
    id integer NOT NULL,
    object_id integer NOT NULL,
    description text NOT NULL,
    sort_order integer NOT NULL,
    created timestamp with time zone NOT NULL,
    changed timestamp with time zone NOT NULL,
    content_type_id integer NOT NULL,
    self_type_id integer NOT NULL,
    CONSTRAINT gallery_galleryitembase_sort_order_check CHECK ((sort_order >= 0))
);


--
-- Name: gallery_galleryitembase_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.gallery_galleryitembase_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: gallery_galleryitembase_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.gallery_galleryitembase_id_seq OWNED BY public.gallery_galleryitembase.id;


--
-- Name: google_maps_mapandaddress; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.google_maps_mapandaddress (
    id integer NOT NULL,
    address character varying(255) NOT NULL,
    longitude double precision NOT NULL,
    latitude double precision NOT NULL
);


--
-- Name: google_maps_mapandaddress_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.google_maps_mapandaddress_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: google_maps_mapandaddress_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.google_maps_mapandaddress_id_seq OWNED BY public.google_maps_mapandaddress.id;


--
-- Name: insurance_insuranceblock; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.insurance_insuranceblock (
    attachableblock_ptr_id integer NOT NULL,
    header character varying(128) NOT NULL,
    description text NOT NULL
);


--
-- Name: insurance_insurancepageconfig; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.insurance_insurancepageconfig (
    id integer NOT NULL,
    title character varying(128) NOT NULL,
    header text,
    description text NOT NULL,
    background character varying(100) NOT NULL,
    visible boolean NOT NULL,
    updated timestamp with time zone NOT NULL
);


--
-- Name: insurance_insurancepageconfig_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.insurance_insurancepageconfig_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: insurance_insurancepageconfig_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.insurance_insurancepageconfig_id_seq OWNED BY public.insurance_insurancepageconfig.id;


--
-- Name: insurance_insurancestep; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.insurance_insurancestep (
    id integer NOT NULL,
    header character varying(128) NOT NULL,
    description text NOT NULL,
    image character varying(100) NOT NULL,
    config_id integer NOT NULL,
    number integer NOT NULL,
    sort_order integer NOT NULL,
    CONSTRAINT insurance_insurancestep_number_check CHECK ((number >= 0))
);


--
-- Name: insurance_insurancestep_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.insurance_insurancestep_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: insurance_insurancestep_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.insurance_insurancestep_id_seq OWNED BY public.insurance_insurancestep.id;


--
-- Name: licenses_license; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.licenses_license (
    id integer NOT NULL,
    title character varying(128) NOT NULL,
    slug character varying(64) NOT NULL,
    text text NOT NULL,
    visible boolean NOT NULL,
    sort_order integer NOT NULL,
    updated timestamp with time zone NOT NULL
);


--
-- Name: licenses_license_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.licenses_license_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: licenses_license_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.licenses_license_id_seq OWNED BY public.licenses_license.id;


--
-- Name: licenses_licensesblock; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.licenses_licensesblock (
    attachableblock_ptr_id integer NOT NULL,
    header character varying(128) NOT NULL
);


--
-- Name: licenses_licensespageconfig; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.licenses_licensespageconfig (
    id integer NOT NULL,
    title character varying(128) NOT NULL,
    header text,
    description text NOT NULL,
    background character varying(100) NOT NULL,
    visible boolean NOT NULL,
    updated timestamp with time zone NOT NULL
);


--
-- Name: licenses_licensespageconfig_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.licenses_licensespageconfig_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: licenses_licensespageconfig_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.licenses_licensespageconfig_id_seq OWNED BY public.licenses_licensespageconfig.id;


--
-- Name: main_advantage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.main_advantage (
    id integer NOT NULL,
    title character varying(128) NOT NULL,
    description text NOT NULL,
    updated timestamp with time zone NOT NULL,
    sort_order integer NOT NULL,
    icon character varying(100) NOT NULL,
    config_id integer NOT NULL
);


--
-- Name: main_advantage_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.main_advantage_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: main_advantage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.main_advantage_id_seq OWNED BY public.main_advantage.id;


--
-- Name: main_advantagesblock; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.main_advantagesblock (
    attachableblock_ptr_id integer NOT NULL,
    header character varying(128) NOT NULL
);


--
-- Name: main_mainpageconfig; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.main_mainpageconfig (
    id integer NOT NULL,
    updated timestamp with time zone NOT NULL,
    background character varying(100) NOT NULL,
    description character varying(128) NOT NULL,
    text text NOT NULL,
    title character varying(128) NOT NULL,
    coupon_discount integer NOT NULL,
    coupon_visible boolean NOT NULL,
    CONSTRAINT main_mainpageconfig_coupon_discount_check CHECK ((coupon_discount >= 0))
);


--
-- Name: main_mainpageconfig_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.main_mainpageconfig_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: main_mainpageconfig_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.main_mainpageconfig_id_seq OWNED BY public.main_mainpageconfig.id;


--
-- Name: main_member; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.main_member (
    id integer NOT NULL,
    logo character varying(100),
    link character varying(200) NOT NULL,
    visible boolean NOT NULL,
    updated timestamp with time zone NOT NULL,
    sort_order integer NOT NULL,
    config_id integer NOT NULL
);


--
-- Name: main_member_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.main_member_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: main_member_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.main_member_id_seq OWNED BY public.main_member.id;


--
-- Name: main_membersblock; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.main_membersblock (
    attachableblock_ptr_id integer NOT NULL,
    header character varying(128) NOT NULL
);


--
-- Name: main_recoveryblock; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.main_recoveryblock (
    attachableblock_ptr_id integer NOT NULL,
    header character varying(128) NOT NULL
);


--
-- Name: main_step; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.main_step (
    id integer NOT NULL,
    number smallint NOT NULL,
    header character varying(128) NOT NULL,
    description text NOT NULL,
    icon character varying(100) NOT NULL,
    updated timestamp with time zone NOT NULL,
    sort_order integer NOT NULL,
    config_id integer NOT NULL,
    CONSTRAINT main_step_number_check CHECK ((number >= 0))
);


--
-- Name: main_step_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.main_step_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: main_step_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.main_step_id_seq OWNED BY public.main_step.id;


--
-- Name: main_stepsblock; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.main_stepsblock (
    attachableblock_ptr_id integer NOT NULL
);


--
-- Name: offers_offer; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.offers_offer (
    id integer NOT NULL,
    delay smallint NOT NULL,
    header character varying(128) NOT NULL,
    text text NOT NULL,
    date_start date NOT NULL,
    date_end date,
    visible boolean NOT NULL,
    url character varying(200) NOT NULL,
    text_for_link character varying(64) NOT NULL,
    updated timestamp with time zone NOT NULL,
    email character varying(254) NOT NULL,
    name character varying(64) NOT NULL,
    number character varying(255) NOT NULL,
    status character varying(64) NOT NULL
);


--
-- Name: offers_offer_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.offers_offer_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: offers_offer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.offers_offer_id_seq OWNED BY public.offers_offer.id;


--
-- Name: rating_ratingvote; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rating_ratingvote (
    id integer NOT NULL,
    ip inet NOT NULL,
    rating integer NOT NULL,
    date timestamp with time zone NOT NULL
);


--
-- Name: rating_ratingvote_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.rating_ratingvote_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: rating_ratingvote_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.rating_ratingvote_id_seq OWNED BY public.rating_ratingvote.id;


--
-- Name: seo_counter; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.seo_counter (
    id integer NOT NULL,
    label character varying(128) NOT NULL,
    "position" character varying(12) NOT NULL,
    content text NOT NULL,
    sort_order integer NOT NULL
);


--
-- Name: seo_counter_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.seo_counter_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: seo_counter_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.seo_counter_id_seq OWNED BY public.seo_counter.id;


--
-- Name: seo_redirect; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.seo_redirect (
    id integer NOT NULL,
    old_path character varying(200) NOT NULL,
    new_path character varying(200) NOT NULL,
    permanent boolean NOT NULL,
    note text NOT NULL,
    created date NOT NULL,
    last_usage date
);


--
-- Name: seo_redirect_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.seo_redirect_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: seo_redirect_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.seo_redirect_id_seq OWNED BY public.seo_redirect.id;


--
-- Name: seo_seoconfig; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.seo_seoconfig (
    id integer NOT NULL,
    title character varying(128) NOT NULL,
    keywords text NOT NULL,
    description text NOT NULL
);


--
-- Name: seo_seoconfig_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.seo_seoconfig_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: seo_seoconfig_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.seo_seoconfig_id_seq OWNED BY public.seo_seoconfig.id;


--
-- Name: seo_seodata; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.seo_seodata (
    id integer NOT NULL,
    object_id integer NOT NULL,
    title character varying(128) NOT NULL,
    keywords text NOT NULL,
    description text NOT NULL,
    canonical character varying(200) NOT NULL,
    noindex boolean NOT NULL,
    og_title character varying(255) NOT NULL,
    og_image character varying(100) NOT NULL,
    og_description text NOT NULL,
    content_type_id integer NOT NULL,
    CONSTRAINT seo_seodata_object_id_check CHECK ((object_id >= 0))
);


--
-- Name: seo_seodata_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.seo_seodata_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: seo_seodata_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.seo_seodata_id_seq OWNED BY public.seo_seodata.id;


--
-- Name: services_service; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.services_service (
    id integer NOT NULL,
    title character varying(128) NOT NULL,
    slug character varying(64) NOT NULL,
    description text NOT NULL,
    text text NOT NULL,
    sort_order integer NOT NULL,
    updated timestamp with time zone NOT NULL,
    background character varying(100) NOT NULL,
    header text,
    icon character varying(100) NOT NULL,
    level integer NOT NULL,
    lft integer NOT NULL,
    parent_id integer,
    rght integer NOT NULL,
    tree_id integer NOT NULL,
    visible boolean NOT NULL,
    CONSTRAINT services_service_level_check CHECK ((level >= 0)),
    CONSTRAINT services_service_lft_check CHECK ((lft >= 0)),
    CONSTRAINT services_service_rght_check CHECK ((rght >= 0)),
    CONSTRAINT services_service_sort_order_check CHECK ((sort_order >= 0)),
    CONSTRAINT services_service_tree_id_check CHECK ((tree_id >= 0))
);


--
-- Name: services_service_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.services_service_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: services_service_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.services_service_id_seq OWNED BY public.services_service.id;


--
-- Name: services_servicesblock; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.services_servicesblock (
    attachableblock_ptr_id integer NOT NULL,
    header character varying(128) NOT NULL
);


--
-- Name: services_servicesconfig; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.services_servicesconfig (
    id integer NOT NULL,
    header text,
    updated timestamp with time zone NOT NULL,
    background character varying(100) NOT NULL,
    description text NOT NULL,
    text text NOT NULL,
    title character varying(128) NOT NULL,
    visible boolean NOT NULL
);


--
-- Name: services_servicesconfig_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.services_servicesconfig_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: services_servicesconfig_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.services_servicesconfig_id_seq OWNED BY public.services_servicesconfig.id;


--
-- Name: social_networks_feedpost; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.social_networks_feedpost (
    id integer NOT NULL,
    network character varying(32) NOT NULL,
    text text NOT NULL,
    url character varying(200) NOT NULL,
    scheduled boolean NOT NULL,
    object_id integer,
    created timestamp with time zone NOT NULL,
    posted timestamp with time zone,
    content_type_id integer,
    CONSTRAINT social_networks_feedpost_object_id_check CHECK ((object_id >= 0))
);


--
-- Name: social_networks_feedpost_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.social_networks_feedpost_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: social_networks_feedpost_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.social_networks_feedpost_id_seq OWNED BY public.social_networks_feedpost.id;


--
-- Name: social_networks_socialconfig; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.social_networks_socialconfig (
    id integer NOT NULL,
    google_apikey character varying(48) NOT NULL,
    twitter_client_id character varying(48) NOT NULL,
    twitter_client_secret character varying(64) NOT NULL,
    twitter_access_token character varying(64) NOT NULL,
    twitter_access_token_secret character varying(64) NOT NULL,
    facebook_access_token text NOT NULL,
    linkedin_access_token text NOT NULL,
    instagram_client_id character varying(48) NOT NULL,
    instagram_client_secret character varying(48) NOT NULL,
    instagram_access_token character varying(64) NOT NULL,
    updated timestamp with time zone NOT NULL,
    linkedin_client_secret character varying(48) NOT NULL,
    linkedin_client_id character varying(48) NOT NULL,
    facebook_client_id character varying(48) NOT NULL,
    facebook_client_secret character varying(64) NOT NULL
);


--
-- Name: social_networks_socialconfig_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.social_networks_socialconfig_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: social_networks_socialconfig_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.social_networks_socialconfig_id_seq OWNED BY public.social_networks_socialconfig.id;


--
-- Name: social_networks_sociallinks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.social_networks_sociallinks (
    id integer NOT NULL,
    social_facebook character varying(255) NOT NULL,
    social_twitter character varying(255) NOT NULL,
    social_google character varying(255) NOT NULL,
    updated timestamp with time zone NOT NULL,
    social_instagram character varying(255) NOT NULL,
    social_linkedin character varying(255) NOT NULL,
    social_yelp character varying(255) NOT NULL,
    social_youtube character varying(255) NOT NULL
);


--
-- Name: social_networks_sociallinks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.social_networks_sociallinks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: social_networks_sociallinks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.social_networks_sociallinks_id_seq OWNED BY public.social_networks_sociallinks.id;


--
-- Name: testimonials_testimonial; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.testimonials_testimonial (
    id integer NOT NULL,
    rating smallint NOT NULL,
    author character varying(50) NOT NULL,
    text text NOT NULL,
    visible boolean NOT NULL,
    sort_order integer NOT NULL,
    CONSTRAINT testimonials_testimonial_rating_check CHECK ((rating >= 0)),
    CONSTRAINT testimonials_testimonial_sort_order_check CHECK ((sort_order >= 0))
);


--
-- Name: testimonials_testimonial_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.testimonials_testimonial_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: testimonials_testimonial_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.testimonials_testimonial_id_seq OWNED BY public.testimonials_testimonial.id;


--
-- Name: testimonials_testimonialsblock; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.testimonials_testimonialsblock (
    attachableblock_ptr_id integer NOT NULL,
    header character varying(128) NOT NULL
);


--
-- Name: users_customuser; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users_customuser (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(30) NOT NULL,
    first_name character varying(30) NOT NULL,
    last_name character varying(30) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL,
    avatar character varying(100) NOT NULL,
    avatar_crop character varying(32) NOT NULL
);


--
-- Name: users_customuser_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users_customuser_groups (
    id integer NOT NULL,
    customuser_id integer NOT NULL,
    group_id integer NOT NULL
);


--
-- Name: users_customuser_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_customuser_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_customuser_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_customuser_groups_id_seq OWNED BY public.users_customuser_groups.id;


--
-- Name: users_customuser_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_customuser_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_customuser_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_customuser_id_seq OWNED BY public.users_customuser.id;


--
-- Name: users_customuser_user_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users_customuser_user_permissions (
    id integer NOT NULL,
    customuser_id integer NOT NULL,
    permission_id integer NOT NULL
);


--
-- Name: users_customuser_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_customuser_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_customuser_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_customuser_user_permissions_id_seq OWNED BY public.users_customuser_user_permissions.id;


--
-- Name: work_galleryimageservice; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.work_galleryimageservice (
    galleryitembase_ptr_id integer NOT NULL,
    image character varying(100) NOT NULL,
    image_crop character varying(32) NOT NULL,
    image_alt character varying(255) NOT NULL
);


--
-- Name: work_galleryservice; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.work_galleryservice (
    id integer NOT NULL
);


--
-- Name: work_galleryservice_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.work_galleryservice_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: work_galleryservice_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.work_galleryservice_id_seq OWNED BY public.work_galleryservice.id;


--
-- Name: work_workpageconfig; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.work_workpageconfig (
    id integer NOT NULL,
    title character varying(128) NOT NULL,
    header text,
    description text NOT NULL,
    background character varying(100) NOT NULL,
    visible boolean NOT NULL,
    updated timestamp with time zone NOT NULL,
    text text NOT NULL,
    gallery_id integer
);


--
-- Name: work_workpageconfig_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.work_workpageconfig_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: work_workpageconfig_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.work_workpageconfig_id_seq OWNED BY public.work_workpageconfig.id;


--
-- Name: about_aboutpageconfig id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.about_aboutpageconfig ALTER COLUMN id SET DEFAULT nextval('public.about_aboutpageconfig_id_seq'::regclass);


--
-- Name: attachable_blocks_attachableblock id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attachable_blocks_attachableblock ALTER COLUMN id SET DEFAULT nextval('public.attachable_blocks_attachableblock_id_seq'::regclass);


--
-- Name: attachable_blocks_attachablereference id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attachable_blocks_attachablereference ALTER COLUMN id SET DEFAULT nextval('public.attachable_blocks_attachablereference_id_seq'::regclass);


--
-- Name: auth_group id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_group ALTER COLUMN id SET DEFAULT nextval('public.auth_group_id_seq'::regclass);


--
-- Name: auth_group_permissions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_group_permissions_id_seq'::regclass);


--
-- Name: auth_permission id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_permission ALTER COLUMN id SET DEFAULT nextval('public.auth_permission_id_seq'::regclass);


--
-- Name: ckeditor_pagefile id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ckeditor_pagefile ALTER COLUMN id SET DEFAULT nextval('public.ckeditor_pagefile_id_seq'::regclass);


--
-- Name: ckeditor_pagephoto id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ckeditor_pagephoto ALTER COLUMN id SET DEFAULT nextval('public.ckeditor_pagephoto_id_seq'::regclass);


--
-- Name: ckeditor_simplephoto id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ckeditor_simplephoto ALTER COLUMN id SET DEFAULT nextval('public.ckeditor_simplephoto_id_seq'::regclass);


--
-- Name: config_config id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_config ALTER COLUMN id SET DEFAULT nextval('public.config_config_id_seq'::regclass);


--
-- Name: contacts_address id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contacts_address ALTER COLUMN id SET DEFAULT nextval('public.contacts_address_id_seq'::regclass);


--
-- Name: contacts_contactsconfig id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contacts_contactsconfig ALTER COLUMN id SET DEFAULT nextval('public.contacts_contactsconfig_id_seq'::regclass);


--
-- Name: contacts_message id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contacts_message ALTER COLUMN id SET DEFAULT nextval('public.contacts_message_id_seq'::regclass);


--
-- Name: contacts_notificationreceiver id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contacts_notificationreceiver ALTER COLUMN id SET DEFAULT nextval('public.contacts_notificationreceiver_id_seq'::regclass);


--
-- Name: contacts_openinghours id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contacts_openinghours ALTER COLUMN id SET DEFAULT nextval('public.contacts_openinghours_id_seq'::regclass);


--
-- Name: contacts_phonenumber id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contacts_phonenumber ALTER COLUMN id SET DEFAULT nextval('public.contacts_phonenumber_id_seq'::regclass);


--
-- Name: django_admin_log id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_admin_log ALTER COLUMN id SET DEFAULT nextval('public.django_admin_log_id_seq'::regclass);


--
-- Name: django_content_type id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_content_type ALTER COLUMN id SET DEFAULT nextval('public.django_content_type_id_seq'::regclass);


--
-- Name: django_cron_cronjoblog id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_cron_cronjoblog ALTER COLUMN id SET DEFAULT nextval('public.django_cron_cronjoblog_id_seq'::regclass);


--
-- Name: django_migrations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_migrations ALTER COLUMN id SET DEFAULT nextval('public.django_migrations_id_seq'::regclass);


--
-- Name: django_site id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_site ALTER COLUMN id SET DEFAULT nextval('public.django_site_id_seq'::regclass);


--
-- Name: gallery_galleryitembase id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gallery_galleryitembase ALTER COLUMN id SET DEFAULT nextval('public.gallery_galleryitembase_id_seq'::regclass);


--
-- Name: google_maps_mapandaddress id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.google_maps_mapandaddress ALTER COLUMN id SET DEFAULT nextval('public.google_maps_mapandaddress_id_seq'::regclass);


--
-- Name: insurance_insurancepageconfig id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.insurance_insurancepageconfig ALTER COLUMN id SET DEFAULT nextval('public.insurance_insurancepageconfig_id_seq'::regclass);


--
-- Name: insurance_insurancestep id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.insurance_insurancestep ALTER COLUMN id SET DEFAULT nextval('public.insurance_insurancestep_id_seq'::regclass);


--
-- Name: licenses_license id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.licenses_license ALTER COLUMN id SET DEFAULT nextval('public.licenses_license_id_seq'::regclass);


--
-- Name: licenses_licensespageconfig id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.licenses_licensespageconfig ALTER COLUMN id SET DEFAULT nextval('public.licenses_licensespageconfig_id_seq'::regclass);


--
-- Name: main_advantage id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.main_advantage ALTER COLUMN id SET DEFAULT nextval('public.main_advantage_id_seq'::regclass);


--
-- Name: main_mainpageconfig id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.main_mainpageconfig ALTER COLUMN id SET DEFAULT nextval('public.main_mainpageconfig_id_seq'::regclass);


--
-- Name: main_member id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.main_member ALTER COLUMN id SET DEFAULT nextval('public.main_member_id_seq'::regclass);


--
-- Name: main_step id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.main_step ALTER COLUMN id SET DEFAULT nextval('public.main_step_id_seq'::regclass);


--
-- Name: offers_offer id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offers_offer ALTER COLUMN id SET DEFAULT nextval('public.offers_offer_id_seq'::regclass);


--
-- Name: rating_ratingvote id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rating_ratingvote ALTER COLUMN id SET DEFAULT nextval('public.rating_ratingvote_id_seq'::regclass);


--
-- Name: seo_counter id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.seo_counter ALTER COLUMN id SET DEFAULT nextval('public.seo_counter_id_seq'::regclass);


--
-- Name: seo_redirect id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.seo_redirect ALTER COLUMN id SET DEFAULT nextval('public.seo_redirect_id_seq'::regclass);


--
-- Name: seo_seoconfig id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.seo_seoconfig ALTER COLUMN id SET DEFAULT nextval('public.seo_seoconfig_id_seq'::regclass);


--
-- Name: seo_seodata id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.seo_seodata ALTER COLUMN id SET DEFAULT nextval('public.seo_seodata_id_seq'::regclass);


--
-- Name: services_service id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.services_service ALTER COLUMN id SET DEFAULT nextval('public.services_service_id_seq'::regclass);


--
-- Name: services_servicesconfig id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.services_servicesconfig ALTER COLUMN id SET DEFAULT nextval('public.services_servicesconfig_id_seq'::regclass);


--
-- Name: social_networks_feedpost id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_networks_feedpost ALTER COLUMN id SET DEFAULT nextval('public.social_networks_feedpost_id_seq'::regclass);


--
-- Name: social_networks_socialconfig id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_networks_socialconfig ALTER COLUMN id SET DEFAULT nextval('public.social_networks_socialconfig_id_seq'::regclass);


--
-- Name: social_networks_sociallinks id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_networks_sociallinks ALTER COLUMN id SET DEFAULT nextval('public.social_networks_sociallinks_id_seq'::regclass);


--
-- Name: testimonials_testimonial id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.testimonials_testimonial ALTER COLUMN id SET DEFAULT nextval('public.testimonials_testimonial_id_seq'::regclass);


--
-- Name: users_customuser id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_customuser ALTER COLUMN id SET DEFAULT nextval('public.users_customuser_id_seq'::regclass);


--
-- Name: users_customuser_groups id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_customuser_groups ALTER COLUMN id SET DEFAULT nextval('public.users_customuser_groups_id_seq'::regclass);


--
-- Name: users_customuser_user_permissions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_customuser_user_permissions ALTER COLUMN id SET DEFAULT nextval('public.users_customuser_user_permissions_id_seq'::regclass);


--
-- Name: work_galleryservice id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_galleryservice ALTER COLUMN id SET DEFAULT nextval('public.work_galleryservice_id_seq'::regclass);


--
-- Name: work_workpageconfig id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_workpageconfig ALTER COLUMN id SET DEFAULT nextval('public.work_workpageconfig_id_seq'::regclass);


--
-- Data for Name: about_aboutblock; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.about_aboutblock (attachableblock_ptr_id, header, description, link_text) FROM stdin;
\.


--
-- Data for Name: about_aboutpageconfig; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.about_aboutpageconfig (id, title, header, description, background, visible, updated, text) FROM stdin;
1	About Us	Element Exteriors - Colorado’s First Choice for Storm Damage Restoration.	We put the same emphasis on quality work and customer satisfaction in our jobs. 	./background_1.jpg	t	2019-10-28 04:53:09.263377+00	<p>\r\n  Element Exteriors comes from humble beginnings.&nbsp;In 2009, when the housing market began to taper off, and new construction was no longer at a premium, I shifted my focus and began working directly with homeowners. I moved from providing services for new homes to re-roofing and roofing repair, and we&rsquo;ve never looked back.\r\n</p>\r\n\r\n<p>\r\n  Today we are proudly headquartered in Centennial, CO and primarily deal with storm restoration and weather-related insurance claims.&nbsp;We bring the same guaranteed quality service, completed in a timely manner, to every job, big or small, and we use only top of the line materials to ensure the best quality finished product.\r\n</p>\r\n\r\n<p>\r\n  We put the same emphasis on quality work and customer satisfaction in our jobs.&nbsp;In an industry where it can be easy to feel as if roofing companies are taking advantage of you, we go out of our way to make sure that every customer has our complete attention and every job is done right from start to finish - satisfaction guaranteed. We take those last two words very seriously because the last thing we want is an unhappy customer.\r\n</p>\r\n\r\n<p>\r\n  To that end, we start from the minute you contact us to prove that we&rsquo;re not just your average contractor. We have trained staff who will give you an estimate on your job, no matter how large or small. An inspection will be set up within 24 hours of your initial call, and an estimate will typically be completed within 1-2 days from an on-site visit to your property.​\r\n</p>\r\n\r\n<p>\r\n  ​​​​​​I want to personally thank you for the time you&rsquo;ve spent considering us for your next project. You have my personal guarantee that we will do everything in our power to make this transition as seamless as possible.\r\n</p>\r\n
\.


--
-- Name: about_aboutpageconfig_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.about_aboutpageconfig_id_seq', 1, true);


--
-- Data for Name: attachable_blocks_attachableblock; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.attachable_blocks_attachableblock (id, label, visible, created, updated, content_type_id) FROM stdin;
2	advantages	t	2019-02-18 13:40:21.786+00	2019-02-18 13:40:21.786+00	28
3	members	t	2019-02-18 13:40:44.405+00	2019-02-18 13:40:44.406+00	29
4	testimonials	t	2019-02-18 13:40:58.985+00	2019-02-18 13:40:58.992+00	36
6	Contact	t	2019-02-18 13:41:55.53+00	2019-03-01 12:42:53.497+00	17
8	insurance	t	2019-02-20 10:42:46.582+00	2019-02-20 10:42:46.586+00	20
9	recovery	t	2019-02-26 12:40:34.332+00	2019-02-26 12:40:34.332+00	30
10	estimate	t	2019-02-28 05:09:57.306+00	2019-04-04 22:18:19.637+00	18
7	licenses	t	2019-02-20 09:18:54.088+00	2019-05-14 06:46:10.772024+00	24
11	services	t	2019-10-23 06:11:17.833347+00	2019-10-23 06:11:17.833728+00	34
\.


--
-- Name: attachable_blocks_attachableblock_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.attachable_blocks_attachableblock_id_seq', 11, true);


--
-- Data for Name: attachable_blocks_attachablereference; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.attachable_blocks_attachablereference (id, object_id, ajax, set_name, sort_order, block_id, block_ct_id, content_type_id) FROM stdin;
11	1	f	default	3	6	17	8
12	1	f	default	1	4	36	8
13	1	f	default	2	8	20	8
21	1	f	default	0	4	36	19
24	1	f	default	1	6	17	19
26	1	f	default	0	10	18	8
28	2	f	default	0	10	18	33
29	2	f	default	1	4	36	33
30	2	f	default	2	6	17	33
37	1	f	default	0	10	18	33
38	1	f	default	1	4	36	33
39	1	f	default	2	6	17	33
41	7	f	default	0	10	18	33
42	7	f	default	1	4	36	33
43	7	f	default	2	6	17	33
45	6	f	default	0	10	18	33
46	6	f	default	1	4	36	33
47	6	f	default	2	6	17	33
49	5	f	default	0	10	18	33
50	5	f	default	1	4	36	33
51	5	f	default	2	6	17	33
52	16	f	default	0	10	18	33
53	16	f	default	1	4	36	33
54	16	f	default	2	6	17	33
66	26	f	default	0	10	18	33
67	26	f	default	1	4	36	33
68	26	f	default	2	6	17	33
84	28	f	default	0	10	18	33
85	28	f	default	1	4	36	33
86	28	f	default	2	6	17	33
91	20	f	default	0	10	18	33
92	20	f	default	1	4	36	33
93	20	f	default	2	6	17	33
95	21	f	default	0	10	18	33
96	21	f	default	1	4	36	33
69	1	f	default	1	10	18	25
5	1	f	default	2	2	28	25
6	1	f	default	3	3	29	25
8	1	f	default	4	9	30	25
9	1	f	default	5	4	36	25
10	1	f	default	6	8	20	25
65	1	f	default	7	7	24	25
70	1	f	default	8	6	17	25
88	1	f	default	0	11	34	25
97	21	f	default	2	6	17	33
33	4	f	default	0	10	18	33
34	4	f	default	1	4	36	33
35	4	f	default	2	6	17	33
25	1	f	second	2	10	18	32
20	1	f	second	3	4	36	32
64	1	f	second	4	8	20	32
19	1	f	second	5	6	17	32
89	1	f	second	1	11	34	32
80	29	f	default	0	10	18	33
81	29	f	default	1	4	36	33
82	29	f	default	2	6	17	33
76	27	f	default	0	10	18	33
77	27	f	default	1	4	36	33
78	27	f	default	2	6	17	33
98	31	f	default	0	10	18	33
99	31	f	default	1	4	36	33
100	31	f	default	2	6	17	33
101	22	f	default	0	10	18	33
102	22	f	default	1	4	36	33
103	22	f	default	2	6	17	33
104	32	f	default	0	10	18	33
105	32	f	default	1	4	36	33
106	32	f	default	2	6	17	33
107	25	f	default	0	10	18	33
108	25	f	default	1	4	36	33
109	25	f	default	2	6	17	33
110	23	f	default	0	10	18	33
111	23	f	default	1	4	36	33
112	23	f	default	2	6	17	33
17	1	f	default	0	4	36	39
23	1	f	default	1	6	17	39
113	33	f	default	0	10	18	33
114	33	f	default	1	4	36	33
115	33	f	default	2	6	17	33
116	34	f	default	0	10	18	33
117	34	f	default	1	4	36	33
118	34	f	default	2	6	17	33
119	37	f	default	0	10	18	33
120	37	f	default	1	4	36	33
121	37	f	default	2	6	17	33
122	36	f	default	0	10	18	33
123	36	f	default	1	4	36	33
124	36	f	default	2	6	17	33
125	24	f	default	0	10	18	33
126	24	f	default	1	4	36	33
127	24	f	default	2	6	17	33
128	38	f	default	0	10	18	33
129	38	f	default	1	4	36	33
130	38	f	default	2	6	17	33
\.


--
-- Name: attachable_blocks_attachablereference_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.attachable_blocks_attachablereference_id_seq', 130, true);


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth_group (id, name) FROM stdin;
1	Managers
\.


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 1, true);


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
1	1	10
2	1	11
3	1	12
4	1	13
5	1	14
6	1	15
7	1	22
8	1	23
9	1	24
10	1	25
11	1	26
12	1	27
13	1	29
14	1	30
15	1	31
16	1	32
17	1	33
18	1	34
19	1	35
20	1	36
21	1	37
22	1	38
23	1	39
24	1	40
25	1	41
26	1	42
27	1	43
28	1	44
29	1	45
30	1	46
31	1	47
32	1	48
33	1	49
34	1	50
35	1	51
36	1	52
37	1	53
38	1	54
39	1	55
40	1	56
41	1	57
42	1	58
43	1	59
44	1	60
45	1	61
46	1	62
47	1	63
48	1	64
49	1	65
50	1	66
51	1	67
52	1	68
53	1	69
54	1	70
55	1	71
56	1	72
57	1	73
58	1	74
59	1	75
60	1	76
61	1	77
62	1	78
63	1	79
64	1	80
65	1	81
66	1	82
67	1	87
68	1	88
69	1	89
70	1	90
71	1	91
72	1	92
73	1	93
74	1	94
75	1	95
76	1	96
77	1	97
78	1	98
79	1	99
80	1	100
81	1	101
82	1	102
83	1	103
84	1	104
85	1	105
86	1	106
87	1	107
88	1	117
\.


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 88, true);


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add log entry	1	add_logentry
2	Can change log entry	1	change_logentry
3	Can delete log entry	1	delete_logentry
4	Can add permission	2	add_permission
5	Can change permission	2	change_permission
6	Can delete permission	2	delete_permission
7	Can add group	3	add_group
8	Can change group	3	change_group
9	Can delete group	3	delete_group
10	Can add content type	4	add_contenttype
11	Can change content type	4	change_contenttype
12	Can delete content type	4	delete_contenttype
13	Can add session	5	add_session
14	Can change session	5	change_session
15	Can delete session	5	delete_session
16	Can add site	6	add_site
17	Can change site	6	change_site
18	Can delete site	6	delete_site
19	Can add cron job log	7	add_cronjoblog
20	Can change cron job log	7	change_cronjoblog
21	Can delete cron job log	7	delete_cronjoblog
22	Can add Settings	8	add_aboutpageconfig
23	Can change Settings	8	change_aboutpageconfig
24	Can delete Settings	8	delete_aboutpageconfig
25	Can add About block	9	add_aboutblock
26	Can change About block	9	change_aboutblock
27	Can delete About block	9	delete_aboutblock
28	Can change settings	10	change_config
29	Can change settings	11	change_contactsconfig
30	Can add address	12	add_address
31	Can change address	12	change_address
32	Can delete address	12	delete_address
33	Can add phone	13	add_phonenumber
34	Can change phone	13	change_phonenumber
35	Can delete phone	13	delete_phonenumber
36	Can add opening hours sequence	14	add_openinghours
37	Can change opening hours sequence	14	change_openinghours
38	Can delete opening hours sequence	14	delete_openinghours
39	Can add notification receiver	15	add_notificationreceiver
40	Can change notification receiver	15	change_notificationreceiver
41	Can delete notification receiver	15	delete_notificationreceiver
42	Can delete message	16	delete_message
43	Can add Contact block	17	add_contactblock
44	Can change Contact block	17	change_contactblock
45	Can delete Contact block	17	delete_contactblock
46	Can add Estimate block	18	add_estimateblock
47	Can change Estimate block	18	change_estimateblock
48	Can delete Estimate block	18	delete_estimateblock
49	Can add Settings	19	add_insurancepageconfig
50	Can change Settings	19	change_insurancepageconfig
51	Can delete Settings	19	delete_insurancepageconfig
52	Can add Insurance block	20	add_insuranceblock
53	Can change Insurance block	20	change_insuranceblock
54	Can delete Insurance block	20	delete_insuranceblock
55	Can add Insurance step	21	add_insurancestep
56	Can change Insurance step	21	change_insurancestep
57	Can delete Insurance step	21	delete_insurancestep
58	Can add Settings	22	add_licensespageconfig
59	Can change Settings	22	change_licensespageconfig
60	Can delete Settings	22	delete_licensespageconfig
61	Can add License	23	add_license
62	Can change License	23	change_license
63	Can delete License	23	delete_license
64	Can add Licenses block	24	add_licensesblock
65	Can change Licenses block	24	change_licensesblock
66	Can delete Licenses block	24	delete_licensesblock
67	Can change settings	25	change_mainpageconfig
68	Can add Advantage	26	add_advantage
69	Can change Advantage	26	change_advantage
70	Can delete Advantage	26	delete_advantage
71	Can add Member	27	add_member
72	Can change Member	27	change_member
73	Can delete Member	27	delete_member
74	Can add Advantages block	28	add_advantagesblock
75	Can change Advantages block	28	change_advantagesblock
76	Can delete Advantages block	28	delete_advantagesblock
77	Can add Members block	29	add_membersblock
78	Can change Members block	29	change_membersblock
79	Can delete Members block	29	delete_membersblock
80	Can add Recovery block	30	add_recoveryblock
81	Can change Recovery block	30	change_recoveryblock
82	Can delete Recovery block	30	delete_recoveryblock
83	Can add user	31	add_customuser
84	Can change user	31	change_customuser
85	Can delete user	31	delete_customuser
86	Can see hidden menu items	31	admin_menu
87	Can add Settings	32	add_servicesconfig
88	Can change Settings	32	change_servicesconfig
89	Can delete Settings	32	delete_servicesconfig
90	Can add service	33	add_service
91	Can change service	33	change_service
92	Can delete service	33	delete_service
93	Can add Services block	34	add_servicesblock
94	Can change Services block	34	change_servicesblock
95	Can delete Services block	34	delete_servicesblock
96	Can add Testimonial	35	add_testimonial
97	Can change Testimonial	35	change_testimonial
98	Can delete Testimonial	35	delete_testimonial
99	Can add Testimonials block	36	add_testimonialsblock
100	Can change Testimonials block	36	change_testimonialsblock
101	Can delete Testimonials block	36	delete_testimonialsblock
102	Can add Settings	39	add_workpageconfig
103	Can change Settings	39	change_workpageconfig
104	Can delete Settings	39	delete_workpageconfig
105	Can add attached block	41	add_attachablereference
106	Can change attached block	41	change_attachablereference
107	Can delete attached block	41	delete_attachablereference
108	Can change Defaults	48	change_seoconfig
109	Can change SEO data	49	change_seodata
110	Can add redirect	50	add_redirect
111	Can change redirect	50	change_redirect
112	Can delete redirect	50	delete_redirect
113	Can add counter	51	add_counter
114	Can change counter	51	change_counter
115	Can delete counter	51	delete_counter
116	Can change Settings	53	change_socialconfig
117	Can change Links	54	change_sociallinks
118	Can add feed post	55	add_feedpost
119	Can change feed post	55	change_feedpost
120	Can delete feed post	55	delete_feedpost
121	Can add vote	56	add_ratingvote
122	Can change vote	56	change_ratingvote
123	Can delete vote	56	delete_ratingvote
124	Can add Steps block	57	add_stepsblock
125	Can change Steps block	57	change_stepsblock
126	Can delete Steps block	57	delete_stepsblock
127	Can add Step	58	add_step
128	Can change Step	58	change_step
129	Can delete Step	58	delete_step
130	Can add Offer	59	add_offer
131	Can change Offer	59	change_offer
132	Can delete Offer	59	delete_offer
\.


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 132, true);


--
-- Data for Name: ckeditor_pagefile; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ckeditor_pagefile (id, app_name, model_name, instance_id, file) FROM stdin;
\.


--
-- Name: ckeditor_pagefile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ckeditor_pagefile_id_seq', 1, false);


--
-- Data for Name: ckeditor_pagephoto; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ckeditor_pagephoto (id, app_name, model_name, instance_id, photo, photo_crop) FROM stdin;
1	services	service	1	0000/photo_1.jpg	
2	services	service	1	0000/photo_2.jpg	
3	services	service	1	0000/photo_3.jpg	
33	services	service	37	0000/photo_33.jpg	
4	services	service	26	0000/photo_4.jpg	
5	services	service	26	0000/photo_5.jpg	
6	services	service	26	0000/photo_6.jpg	
7	services	service	16	0000/photo_7.jpg	
8	services	service	16	0000/photo_8.jpg	
9	services	service	4	0000/photo_9.jpg	
10	services	service	4	0000/photo_10.jpg	
11	services	service	20	0000/photo_11.jpg	
12	services	service	21	0000/photo_12.jpg	
13	services	service	29	0000/photo_13.jpg	
14	services	service	27	0000/photo_14.jpg	
15	services	service	0	0000/photo_15.jpg	
16	services	service	27	0000/photo_16.jpg	
17	services	service	28	0000/photo_17.jpg	
18	services	servicesconfig	1	0000/photo_18.jpg	
19	services	service	1	0000/photo_19.jpg	
20	services	service	2	0000/photo_20.jpg	
21	services	service	7	0000/photo_21.jpg	
22	services	service	6	0000/photo_22.jpg	
23	services	service	22	0000/photo_23.jpg	
24	services	service	22	0000/photo_24.jpg	
25	services	service	25	0000/photo_25.jpg	
26	services	service	23	0000/photo_26.jpg	
27	services	service	31	0000/photo_27.jpg	
28	services	service	32	0000/photo_28.jpg	
29	services	service	33	0000/photo_29.jpg	
30	services	service	34	0000/photo_30.jpg	
31	services	service	35	0000/photo_31.jpg	
32	services	service	36	0000/photo_32.jpg	
\.


--
-- Name: ckeditor_pagephoto_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ckeditor_pagephoto_id_seq', 33, true);


--
-- Data for Name: ckeditor_simplephoto; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ckeditor_simplephoto (id, app_name, model_name, instance_id, photo) FROM stdin;
\.


--
-- Name: ckeditor_simplephoto_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ckeditor_simplephoto_id_seq', 1, false);


--
-- Data for Name: config_config; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.config_config (id, updated) FROM stdin;
1	2019-03-15 07:01:18.761+00
\.


--
-- Name: config_config_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.config_config_id_seq', 1, true);


--
-- Data for Name: contacts_address; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contacts_address (id, address, city, region, zip, coords, sort_order, updated, url) FROM stdin;
1	14 Inverness Dr. E. #D-116	 Englewood	CO	80112	39.570549, -104.861605	1	2019-04-23 12:01:51.547+00	https://www.google.com/maps/place/14+Inverness+Dr+E+Suite+D-116,+Englewood,+CO+80112,+%D0%A1%D0%A8%D0%90/@39.5705526,-104.8637936,17z/data=!3m1!4b1!4m5!3m4!1s0x876c859374402373:0xd4d0d5143377459!8m2!3
\.


--
-- Name: contacts_address_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.contacts_address_id_seq', 1, true);


--
-- Data for Name: contacts_contactblock; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contacts_contactblock (attachableblock_ptr_id, header, description, background) FROM stdin;
6	Contact Us Today	We’re easy to talk to for all inquiries, questions, or comments. Don’t hesitate to reach out with the buttons below or call us	./background_6.jpg
\.


--
-- Data for Name: contacts_contactsconfig; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contacts_contactsconfig (id, header_index, updated, title_index, form_description, form_background, header_form, title_form) FROM stdin;
1	Element Exteriors Inc.	2019-10-03 11:20:38.034789+00	Contacts	We bring the same guaranteed quality service, completed in a timely manner, to every job, big or small, and we use only top of the line materials to ensure the best quality finished product.\n\nIf you're in the market for a new roofing or home improvement professional, give us a call or fill out the form and one of our representatives will contact you shortly.	./form_background_1.jpg	Contact Us	Contact Us Form
\.


--
-- Name: contacts_contactsconfig_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.contacts_contactsconfig_id_seq', 1, true);


--
-- Data for Name: contacts_estimateblock; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contacts_estimateblock (attachableblock_ptr_id, header, description, background) FROM stdin;
10	Guaranteed Inspection within 24 hours	Guaranteed inspection within 24 hours and a completed report within 48 hours.\n	./background_10.jpg
\.


--
-- Data for Name: contacts_message; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contacts_message (id, name, phone, email, message, date, referer) FROM stdin;
26	Kenny Powers	3035551569	kenny@fuckyou.com	Sahhhh. Y'all do ruthless roofs?	2019-05-01 21:08:29.234993+00	https://elementext.com/contact/form/
27	Aritra Agarwal	9831700890	seoservicesincheap@gmail.com	Hi\r\n\r\nI am Aritra;\r\n \r\nI was on your website. I am a business development manager of a renowned SEO, Web Design & Development Company.   We are offering SEO, Web Design, Web Development, PPC, Mail Marketing, Graphics Design and complete Link Building Services from last 7 years.\r\n\r\nWe will be happy to help execute SEO & Web Design and Development projects at a much lower cost than what you have in house. No compromise on quality!\r\n\r\nWe have just gone through your website and found some issues, that are as follows - \r\n1.\tYour Website Title tag is not properly optimized.\r\n2.\tDescription tag is not properly optimized.\r\n3.\tGoogle publisher is missing.\r\n4.\tCanonical Tag Missing.\r\n5.\tRobots File is not optimized properly. \r\n6.\tHeading Tags Distribution is not proper (h1 to h6). \r\n7.\tSome Image Alt Tags are missing.\r\n8.\tWebpage content is not properly optimized. \r\n9.\tWeb page keywords density is low. \r\n10.\tKeyword distribution is not proper throughout the webpage.\r\n11.\tSocial Media presence is low.\r\n12.\tWebsite position in Google SERP is not so good. \r\n13.\tWebsite is not ranked on the Majestic top million.\r\n14.\tWebsite Alexa Rank is not good. \r\n15.\tWebsite page speed is slow.\r\n\r\nWe would be happy to solve all this issue on behalf of you to bring the website in good SERP position. \r\n\r\nDo let me know if you are interested then I will be happy to share our Methodologies and work details.\r\n\r\nI look forward to your mail.\r\n\r\nKind Regards,\r\nAritra Agarwal\r\nSKYPE ID: seoserviceincheap\r\n\r\nDisclaimer: This is an advertisement and a promotional mail strictly on the guidelines of CAN-SPAM Act of 2003. We have clearly mentioned the source mail-id of this mail and the subject lines and they are in no way misleading in any form. We have found your mail address through our own efforts on the web search and not through any illegal way. If you find this mail unsolicited, please reply with "unsubscribe" in the subject line and we will take care that you do not receive any further promotional mail.\r\n	2019-05-22 08:12:03.401037+00	https://elementext.com/contact/form/
30	Darcy Velasquez	3035079864	darcybawiec@msn.com	Hail damage 	2019-07-22 14:15:32.702579+00	https://elementext.com/contact/form/
31	David Alley	3129895882	dca3301@gmail.com	A number of your employees seem to be living in a townhouse in our community (Waterside at Highland Park).  There must be 5-6 of them living in the unit.  While having their work trucks take up a good share of the parking spaces is somewhat annoying, what is more irritating is the amount of trash that they leave around the trucks.  Cigarette butts, packaging off work gloves, sales brochures, and Nelson Gonzalez's business cards have all been strewn about.  This isn't a good look for your business.	2019-08-12 23:37:22.415249+00	https://elementext.com/contact/form/
32	Simon	0000000000	simon.rockims@gmail.com	Hello Sir,\r\n          I offer a service We will bring you on the 1st page of google within 3-4 months in your favorite keywords. Also, Do one by one marketing, Manage your all social networking sites, Add more peoples in the LinkedIn page as you like. I could offer a free 15 min conference to talk about my services.  	2019-08-15 14:57:32.485113+00	https://elementext.com/contact/form/
33	Carolyn Hall	5305551212	carolyn.seotech12@gmail.com	Google Top 1st page rank .\r\n\r\nHi,\r\n\r\nI'm reaching out to find out if you're interested in improving your rankings in the search engines and getting more traffic to your site?  \r\n\r\nI found your site in the search engines, but I found you on Page 5, and no one ever looks that far. I have been a search engine optimizer for over a decade. \r\n\r\nI have a very impressive track record of getting great results for my clients. I could get you up to Page 1 without a problem, if you are interested please book and appointment here https://calendly.com/professional-lists-inc .\r\n\r\nIf not, I won't email you again.\r\n\r\nThanks,\r\nCarolyn Hall\r\ncarolyn.seotech12@gmail.com\r\n	2019-08-19 12:37:11.97888+00	https://elementext.com/contact/form/
34	Simon	0000000000	simon.rockims@gmail.com	Hello Sir,          I offer a service. We will bring you on the 1st page of google within 3-4 months in your favorite keywords. Also, Do one by one marketing, Manage your all social networking sites, Add more peoples in the LinkedIn page as you like. I could offer a free 15 min conference to talk about my services.  	2019-09-10 16:13:03.305332+00	https://elementext.com/contact/form/
35	Cory William	3154977011	corywilliam0055@gmail.com	I just bought a home in Denver,CO and i need complete exterior painting renovation for the home.. kindly contact me through text message to my cell  for 315) 497-7011‬  for quick reply.\r\n\r\n  Regards	2019-09-11 15:06:40.668302+00	https://elementext.com/contact/form/
36	Dylan Knutson	7203121380	dylan@ambitionmediamarketing.com	My name is Dylan and I am with Ambition Media Marketing. We are a local startup business with the goal of impacting our neighboring businesses with web design. \r\n\r\nDid you know 75% of potential clients judge your credibility solely on the design of your website? With just five minutes of your time, I would love to walk you through what we could do to turn all those judgments into positive ones.\r\n\r\nWe went ahead and spent a few hours creating a mock website for a contractor and we would love for you to take a look at it. Keep in mind this design isn’t set in stone, but just an example of our expertise and professionalism. And on a side note, we are quite a bit cheaper than our competitors since we are just starting out. Please feel free to contact me with any questions or comments you may have. I look forward to your reply.\r\n\r\nContractor Mock Home Page:\r\nwww.ambitionmediamarketing.com/contractor\r\n\r\nBest Regards,\r\n\r\nDylan Knutson	2019-09-25 17:52:56.253203+00	https://elementext.com/contact/form/
37	Estimator GE	(850) 400-6861	mt@guaranteeestimation.com	Guarantee Estimation delivers material take-offs and costs estimating services for construction projects to contractors, subs, and architects. We use Bluebeam plan swift and MS excel to compile the estimates. If you are interested in outsourcing your project just let me know so I can forward the additional details and samples. Thanks	2019-10-22 17:20:03.739323+00	https://elementext.com/contact/form/
38	Daniel Garvin	0918 220 1010	daniel.a@octabliz.com	Your website www.elementext.com is looking cool.\r\n\r\nWe are among the Top SEO Providers having 1000+ projects completion and available for communication almost 24*7. \r\n\r\n==================================\r\nWORK PROCESS :-\r\n\r\n> Keyword Research\r\n> On-page SEO\r\n> Off-page (Link-building)\r\n- Weekly Report\r\n- Article and Press Release \r\n- Final SEO Report\r\n==================================\r\n>> SEO <<\r\n\r\nOFF PAGE SEO - Targeted keywords 40\r\n\r\n>> Up to 100 Approved Links <<\r\n\r\n> CONTENT SUBMISSION <\r\n\r\n- Article Submission\r\n- Press Release Submission\r\n- Blog Posting\r\n- PDF Submission\r\n\r\n> NON-CONTENT SUBMISSION <\r\n\r\n- Profile Links\r\n- Forum links\r\n- URL based\r\n- Web Directories\r\n- Search Engine\r\n- Social Bookmarking \r\n- Social Media Promotion\r\n\r\nCONTENT :-\r\n- 4 Article \r\n- 2 Press Release\r\n\r\nON-PAGE SEO (REPORT ONLY)\r\n\r\n> 4-5 Main Pages\r\n> Meta Tags Optimization\r\n> Robots Optimization\r\n> Sitemap Creation\r\n==================================\r\n>> We provide Quality backlinks from HIGH DA and PA Sites.\r\n>> We write FRESH Article and Press Release for SEO Submissions.\r\n>> We provide 100% ethical and WHITE HAT SEO only. \r\n==================================\r\n\r\nLooking forward to discuss the project in detail if you are interested,\r\n\r\nBest Regards,\r\nDaniel Garvin\r\nwww.octabliz.com	2020-01-03 06:28:00.773423+00	https://elementext.com/contact/form/
39	Harry Gomes	7073272570	harry.gomes2@softwebworksinc.com	Hi,\r\n \r\nWE ARE PROVIDING 70% DISCOUNT ON OUR PLATINUM PACKAGE\r\n \r\nActual Cost: $300/month\r\nDiscounted Cost: $90/month\r\n \r\nI can provide excellent results for your website www.elementext.com \r\n \r\nI can handle your website SEO optimization and bring you on Google TOP 1st page rankings with in committed time frame. I will build a solid & proper WHITE HAT SEO plan for your website. I will provide quality SEO work with competitors back links. I will research your website's best marketing value.\r\n \r\nWe will do below activities:\r\n \r\n1) on page and off page optimization\r\n2) social bookmarking\r\n3) link building\r\n4) Blog Commenting\r\n5) Article Submission + Article wiring\r\n6) traffic management\r\n7) press releasing\r\n8) Classified Ads posting\r\n9) Internet Marketing\r\n10) Blog creation\r\n11) Directory submission\r\n12) Social Media Optimization/ SMM\r\n13) Advertising\r\n14) Email Marketing\r\n15) pdf posting\r\n16) forum posting\r\n \r\nMy activities will result good amount of traffic and boost your rankings in google.\r\n \r\nLet me know if you are interested and we'll start this campaign for you. If you have any kind of questions, don't hesitate to ask me.\r\n \r\nBest Regards,\r\nHarry Gomes\r\nwww.softwebworks.net\r\n\r\n	2020-01-08 05:43:03.604734+00	https://elementext.com/contact/form/
40	Harry Gomes	7073272570	harry.gomes2@softwebworksinc.com	Hi,\r\n \r\nWE ARE PROVIDING 70% DISCOUNT ON OUR PLATINUM PACKAGE\r\n \r\nActual Cost: $300/month\r\nDiscounted Cost: $90/month\r\n \r\nI can provide excellent results for your website www.elementext.com \r\n \r\nI can handle your website SEO optimization and bring you on Google TOP 1st page rankings with in committed time frame. I will build a solid & proper WHITE HAT SEO plan for your website. I will provide quality SEO work with competitors back links. I will research your website's best marketing value.\r\n \r\nWe will do below activities:\r\n \r\n1) on page and off page optimization\r\n2) social bookmarking\r\n3) link building\r\n4) Blog Commenting\r\n5) Article Submission + Article wiring\r\n6) traffic management\r\n7) press releasing\r\n8) Classified Ads posting\r\n9) Internet Marketing\r\n10) Blog creation\r\n11) Directory submission\r\n12) Social Media Optimization/ SMM\r\n13) Advertising\r\n14) Email Marketing\r\n15) pdf posting\r\n16) forum posting\r\n \r\nMy activities will result good amount of traffic and boost your rankings in google.\r\n \r\nLet me know if you are interested and we'll start this campaign for you. If you have any kind of questions, don't hesitate to ask me.\r\n \r\nBest Regards,\r\nHarry Gomes\r\nwww.softwebworks.net\r\n\r\n	2020-01-08 05:59:38.73081+00	https://elementext.com/contact/form/
41	Robert Davis	8154293254	operations@intelliname.com	We are selling www.repairyourroof.com if you are interested. You can visit the domain name online for pricing, a one minute presentation video, and some great marketing ideas and design examples for the roofing industry. It is a very powerful marketing tool that would drive a lot of business to you in the future. We have never used it, and I'm looking for a good home for it. Thanks!	2020-01-17 02:17:52.182618+00	https://elementext.com/contact/form/
42	Robert Graham	2233444000	robert.g1@expertphpbuddy.com	Hi,\t\t\r\n\r\nI will rank your www.elementext.com website top spots #1-3 in google for your chosen 30-40 keywords within your affordable\r\nbudget and get you 1000s of Customers from your targeted location. \r\n\t\t\r\nI have ranked more than 2000 websites top in google. \r\n\t\t\r\nWe are including these activities in SEO\r\n\t\r\nA. (ON PAGE OPTIMIZATION)\r\n• Website Analysis\t\r\n• Keyword Research\t\t\r\n• Meta Tag Creation & Website Promotion\r\n• Google Webmaster Tool\r\n• SEO Site Map\t\r\n• Ranking Report before start of work\r\n• will also included needful task of on page\r\n\t\r\nB. (OFF PAGE OPTIMIZATION)\r\n• Search Engine Submission\t\r\n• Directory Submission\t\t\r\n• Article Submission\r\n• Social Bookmarking\t\r\n• Forum Posting\r\n• Blog Commenting\r\n• Press Release\r\n• Web 2.0 \t\r\n• including all off page work\r\n\r\nC. (Social Media Marketing) \r\n\r\n* Facebook \r\n* Twitter \r\n* Youtube \r\n* Pinterest\r\n* Instagram \r\n\r\n\r\nWork Done Report: I will send work done report on bi-weekly basis\r\n\r\nMy techniques are 100% white hat and according to the current google updates like Panda, \r\nPenguin and Humming bird. So your website will never get affected from Google updates.\r\n\r\nWaiting for your response.\r\n\r\nRegards,\r\n\r\nRobert Graham\r\nwww.expertphpbuddy.com\r\n	2020-01-20 09:23:30.577494+00	https://elementext.com/contact/form/
43	Alex	Moran	alexandermor726@gmail.com	Can you please inspect my roof to see if there's any noticeable damage worth noting? I live in the Castle Rock area.	2020-02-02 20:42:17.817882+00	https://elementext.com/contact/form/
44	Robert Graham	2233444000	robert.g1@expertphpbuddy.com	Hi,\t\t\r\n\r\nI will rank your www.elementext.com website top spots #1-3 in google for your chosen 30-40 keywords within your affordable\r\nbudget and get you 1000s of Customers from your targeted location. \r\n\t\t\r\nI have ranked more than 2000 websites top in google. \r\n\t\t\r\nWe are including these activities in SEO\r\n\t\r\nA. (ON PAGE OPTIMIZATION)\r\n• Website Analysis\t\r\n• Keyword Research\t\t\r\n• Meta Tag Creation & Website Promotion\r\n• Google Webmaster Tool\r\n• SEO Site Map\t\r\n• Ranking Report before start of work\r\n• will also included needful task of on page\r\n\r\nB. (OFF PAGE OPTIMIZATION)\r\n• Search Engine Submission\t\r\n• Directory Submission\t\t\r\n• Article Submission\r\n• Social Bookmarking\t\r\n• Forum Posting\r\n• Blog Commenting\r\n• Press Release\r\n• Web 2.0 \t\r\n• including all off page work\r\n\r\nC. (Social Media Marketing) \r\n\r\n* Facebook \r\n* Twitter \r\n* Youtube \r\n* Pinterest\r\n* Instagram \r\n\r\n\r\nWork Done Report: I will send work done report on bi-weekly basis\r\n\r\nMy techniques are 100% white hat and according to the current google updates like Panda, \r\nPenguin and Humming bird. So your website will never get affected from Google updates.\r\n\r\nWaiting for your response.\r\n\r\nRegards,\r\n\r\nRobert Graham\r\nwww.expertphpbuddy.com\r\n\r\n	2020-02-11 09:41:22.259263+00	https://elementext.com/contact/form/
45	Harry Gomes	9313984313	harry.gomes@softwebworksinc.com	Hi,\r\n \r\nWE ARE PROVIDING 70% DISCOUNT ON OUR PLATINUM PACKAGE\r\n \r\nActual Cost: $300/month\r\nDiscounted Cost: $90/month\r\n \r\nI can provide excellent results for your website www.elementext.com \r\n \r\nI can handle your website SEO optimization and bring you on Google TOP 1st page rankings with in committed time frame. I will build a solid & proper WHITE HAT SEO plan for your website. I will provide quality SEO work with competitors back links. I will research your website's best marketing value.\r\n \r\nWe will do below activities:\r\n \r\n1) on page and off page optimization\r\n2) social bookmarking\r\n3) link building\r\n4) Blog Commenting\r\n5) Article Submission + Article wiring\r\n6) traffic management\r\n7) press releasing\r\n8) Classified Ads posting\r\n9) Internet Marketing\r\n10) Blog creation\r\n11) Directory submission\r\n12) Social Media Optimization/ SMM\r\n13) Advertising\r\n14) Email Marketing\r\n15) pdf posting\r\n16) forum posting\r\n \r\nMy activities will result good amount of traffic and boost your rankings in google.\r\n \r\nLet me know if you are interested and we'll start this campaign for you. If you have any kind of questions, don't hesitate to ask me.\r\n \r\nBest Regards,\r\nHarry Gomes\r\nwww.softwebworks.net\r\n\r\n	2020-03-03 04:56:56.851201+00	https://elementext.com/contact/form/
46	Curtis Perry	0000000000	curtis@livecallreps.org	Do You Know The Impact Missing One Business Call? Can You Imagine the number of New Customers You'd Get if you were to stay active on your business Phone 24/7/365?\r\nWe At LiveCallReps.org Enable Businesses To Ensure They Never Ever Miss a Business Call Again!\r\nOur U.S Based Agents virtually attend your phone & professionally engage each caller in a conversation, capture the details and send the message to you, ensuring you don't miss a single call.  \r\nIf you would like to explore this further - please reply by email and we can take it from there!\r\n\r\nBest,\r\nCurtis Perry\r\ncurtis@livecallreps.org\r\nwww.livecallreps.org	2020-03-09 23:29:35.870568+00	https://elementext.com/contact/form/
47	James Smith	1010101223	james.a@dwarfwebguy.com	I searched your TARGETED KEYWORDS in Google and didn't find your website www.elementext.com   on top rankings.\r\n\r\nWith our SEO $200/month(30 keywords) plan, we are offering Website maintenance free for 5 hours per month.\r\n\r\nWe provide both on page and off page SEO Services using white hat method and follow google guidelines, so traffic will be real and ranking will be organic.\r\n\r\nWe will do below activities to make your website more SEO friendly:\r\n\r\nON-PAGE OPTIMIZATION\r\n\r\n• Website analysis report\r\n• Keyword Research and Competition Analysis\r\n• Competitor analysis report\r\n• Optimization of Title Tags\r\n• Optimization of Meta Description Tags\r\n• Header Tags Optimization\r\n• URL Optimization\r\n• Optimizing HTML Code\r\n• Robots Optimization\r\n• Optimization of Alt and Title tags\r\n• Optimization of internal Navigation\r\n• Analysis of Broken Links\r\n• Page Content Optimization\r\n• Fix Canonical issue\r\n• Creation of XML Sitemap\r\n\r\nOFF Page SEO\r\n\r\n• Article Submission\r\n• Press Release Submission\r\n• Social Bookmarking\r\n• Blog Comments\r\n• Local listing\r\n• Video submission\r\n• Classified submission\r\n• Image sharing\r\n• Search engine submissions\r\n• Blog submission\r\n• Web 2.0 submission\r\n\r\nIf you are interested, reply to this email.\r\n \r\nThanks and Regards,\r\nJames Smith\r\nwww.dwarfwebguy.com\r\n	2020-03-13 11:35:23.265588+00	https://elementext.com/contact/form/
48	Jessica Carner	2356895054	jessicacarnerseo@gmail.com	Re: Error in your Website\r\n\r\nHi Website Owner,\r\n\r\nHope your business is doing fantastic this year.\r\nI was doing some industry benchmarking for a client of mine when I came across your website. I noticed a few technical errors which correspond with a drop of website traffic over the last 6-8 months which I thought I would bring to your attention.\r\n\r\nI was analyzing your site and it seems that some of your website rankings have dropped. It is due to non optimized techniques/errors And Google guidelines not being followed properly.\r\n\r\n•\t Your web page failed on 4 high priority checks: Meta Description, <h1> Headings Status, Broken Links Test, URL Canonicalization Test\r\n\r\n•\t Your most common keywords are not appearing in one or more of the meta-tags above. Your primary keywords should appear in your Meta.\r\n•\t Site link diversity and Domain Authority is low\r\n•\t URL Canonicalization should resolve to the same URL, but currently do not.\r\n•\t 5 of them are missing the required 'alt' attribute.\r\n•\t Your website should load quicker\r\n•\t Your webpage has so many 'img' tags and 5 of them are missing the required 'alt' attribute.\r\n•\t Your page has more than 20 http requests, which can slow down page loading.\r\n\r\nI would love the chance to help as well however; this report will at least give you a gauge on the quality of what I do. If you are interested then please share your requirement and contact details.\r\n\r\nThanks & Regards\r\nJessica Carner\r\njessicacarnerseo@gmail.com	2020-06-10 04:36:52.787355+00	https://elementext.com//contact/form/
49	Michael Bradley	3477669973	mb.usatopestimators@gmail.com	Hi,\r\n \r\nWe are an estimation services providing company. We provide Cost Estimation & Quantities Take-Off services for General As well as for Sub-contractors. We do both residential and commercial projects. We have more than 15 years of experience in Estimating services. We are giving almost 40% Discount on the first estimate. \r\nPlease send us the plans or link to any FTP site so that we can review the plans and submit you a very economical quote. In order to get a better idea of our work, ask for sample estimates and take-offs. Thanks\r\n	2020-06-10 19:58:05.885766+00	https://elementext.com/contact/form/
50	Carl Amos	5015555555	carlamos234@gmail.com	Hello, How are you doing today ? This is Carl Amos. I would like to confirm if you do Roof replacement and accept all major credit cards if yes kindly get back to me asap with your full name and shop address...\r\nRegards\r\nAmos	2020-06-18 00:28:01.262245+00	https://elementext.com/contact/form/
73	Matthew Herzog	3039299744	matthew.t.herzog@gmail.com	We are under contract on a extremely shallow roof slope home (close 4/16) that currently has and EPDM roof in need of replacement. I was interested in replacing with a PVC roof, I saw you offered PVC for commercial applications, do you offer that solution for residential as well?\r\n\r\nThanks!	2021-03-25 21:20:46.545203+00	https://elementext.com/contact/form/
51	Walter Powers	7202136565	walterpowers@gmail.com	Seeking estimates for wood trim and cement fiber/composite siding repair is needed for all 5 of 5 units of Cherry House Condominiums.  I'm the owner of one of the units and also the condo association co-chair.  I'm requesting two estimates. 1) Repair and or replace trim and siding for my unit at 3533 S. Corona St.  2)  Repair and or replace trim and siding for all townhouse/condo units, 3527 - 3535 S. Corona St. Englewood, CO 80113.  There are a total of 2 duplex buildings (2 units each) with chimneys and very steep roofs.  The 3rd building has no chimney and a flat roof. There are a total of 3 owners in the condo association.  Thank you, Walter Powers, 7202136565, 3533 S. Corona St., Engelwood, CO 80113, Cherry House Condominiums.	2020-06-23 05:47:34.63708+00	https://elementext.com/contact/form/
52	Jean Lewis	720-369-9957	Darwinsthumb@gmail.com	Hello - could you please tell me if Element Exteriors also does siding replacement/new siding?  We are looking to have new siding for part of our home in Erie, CO.  Thank you!	2020-07-07 03:21:43.289459+00	https://elementext.com/contact/form/
53	Max Williams	7077060205	Siterank6@gmail.com	Hello And Good Day\r\nI am Max (Jitesh Chauhan), a Marketing Manager with a reputable online marketing company based in India.\r\nWe can fairly quickly promote your website to the top of the search rankings with no long term contracts!\r\nWe can place your website on top of the Natural Listings on Google, Yahoo, and MSN. Our Search Engine Optimization team delivers more top rankings than anyone else, and we can prove it. We do not use "link farms" or "black hat" methods that Google and the other search engines frown upon and can use to de-list or ban your site. The techniques are proprietary, involving some valuable closely held trade secrets. Our prices are less than half of what other companies charge.\r\nWe would be happy to send you a proposal using the top search phrases for your area of expertise. Please contact me at your convenience so we can start saving you some money.\r\nIn order for us to respond to your request for information, please include your company’s website address (mandatory) and or phone number.\r\nSo let me know if you would like me to mail you more details or schedule a call. We'll be pleased to serve you.\r\nI look forward to your mail.\r\nFor any inquiry related to this, mail us.\r\nThanks and Regards\r\n	2020-07-09 11:25:11.260921+00	https://elementext.com//contact/form/
54	Rita Carner	2356895054	ritaseomarketing@gmail.com	Re: Website Error\r\n\r\nHello,\r\n\r\nMy name is Rita and I am a Digital Marketing Specialists for a Creative Agency.\r\n\r\nI was doing some industry benchmarking for a client of mine when I came across your website.\r\n\r\nI noticed a few technical errors which correspond with a drop of website traffic over the last 2-3 months which I thought I would bring to your attention.\r\n\r\nAfter closer inspection, it appears your site is lacking in 4 key criteria.\r\n\r\n1- Website Speed\r\n2- Link Diversity\r\n3- Domain Authority\r\n4- Competition Comparison\r\n\r\nI would love the chance to send you all the errors that at least give you a gauge on the quality of what I do.  \r\n\r\nIf you are interested then please share your Phone number and requirements.\r\n\r\nOur prices are less than half of what other companies charge.\r\n\r\nThanks\r\nRita Carner\r\nritaseomarketing@gmail.com	2020-07-16 11:46:50.822252+00	https://elementext.com//contact/form/
55	Leesa Singh	08457854511	leesasinghn@gmail.com	\r\nHello,\r\n\r\nDo you want to boost your business online?\r\n\r\nWe do work on Google, Facebook, Instagram and Houzz making it a highly effective and quick response for your company.\r\n\r\nShare your business social profile URLs (links). We will send you the costs and the next step.\r\n\r\nRegards,	2020-07-23 12:41:45.184818+00	https://elementext.com/contact/form/
56	Derrick Mark	8312727242	derrickmark385@gmail.com	Good day my name is Mr. Derrick Mark , I just bought a house in the city and I want the roof replaced and exterior painted can you please help me with an estimate for the roof replacement work ?\r\n\r\n	2020-07-23 15:57:53.552292+00	https://elementext.com/contact/form/
57	Michelle Stupar IgadI Ltd	303.567.2185	Mstupar@igadiltd.com	Looking for a someone to paint a 4,000 sqft EPDM roof on a warehouse on Aurora. Reaching out for a quote. 	2020-09-07 15:51:48.938864+00	https://elementext.com/contact/form/
58	Natalie Jones	3033586531	natalie@homeownerbliss.info	Hello!\r\n\r\nI'm Natalie Jones and I'd like to write an article for your site...\r\n\r\nI'm thinking - an article on getting settled quickly and happily in a new house!\r\n\r\nMy husband and I just moved into our new place and I learned a lot along the way about how to make a new house feel like home.  \r\n\r\nTo get a sense of my writing style you can check out my homepage: homeownerbliss.info\r\n\r\nWhat do you say, may I send you a free article?\r\n\r\nThank you!\r\nNatalie Jones\r\nnatalie@homeownerbliss.info\r\nHomeownerbliss.info\r\n\r\nP.S. If you’d like, I can link to a page on your site in the article. Let me know which one in your reply, and I’ll be sure to include it.	2020-09-13 14:04:11.944836+00	https://elementext.com/contact/form/
59	Shauna Peters	7242164327	Slcaughman@hotmail.com	Looking for a free roof estimate.	2020-09-17 21:24:51.64489+00	https://elementext.com/contact/form/
60	Tim Miller	3477669973	tm.ustopestimatorsinc@gmail.com	We are an estimation services providing company. We provide Cost Estimation & Quantities Take-Off services for General As well as for Sub-contractors. We do both residential and commercial projects. We have more than 15 years of experience in Estimating services. We claim 98% accuracy and also give almost 20% Discount on the first estimate. Please send us plans or FTP site link! In order to get a better idea of our work, ask for sample estimates and take-offs. Please visit our website for more detail www (dot) topestimators (dot) com 	2020-10-02 21:26:14.09833+00	https://elementext.com/contact/form/
61	Ricky Lawson	7777777777	rickygiants777@gmail.com	Remove old roof and install new.	2020-10-08 13:57:39.232444+00	https://elementext.com/contact/form/
62	Max Williams	707 706 0205	Siterank7@gmail.com	Hello And Good Day\r\nI am Max (Jitesh Chauhan), a Marketing Manager with a reputable online marketing company based in India.\r\nWe can fairly quickly promote your website to the top of the search rankings with no long term contracts!\r\nWe can place your website on top of the Natural Listings on Google, Yahoo, and MSN. Our Search Engine Optimization team delivers more top rankings than anyone else, and we can prove it. We do not use "link farms" or "black hat" methods that Google and the other search engines frown upon and can use to de-list or ban your site. The techniques are proprietary, involving some valuable closely held trade secrets. Our prices are less than half of what other companies charge.\r\nWe would be happy to send you a proposal using the top search phrases for your area of expertise. Please contact me at your convenience so we can start saving you some money.\r\nIn order for us to respond to your request for information, please include your company’s website address (mandatory) and or phone number.\r\nSo let me know if you would like me to mail you more details or schedule a call. We'll be pleased to serve you.\r\nI look forward to your mail.\r\nFor any inquiry related to this, mail us.\r\nThanks and Regards	2020-10-13 06:27:17.672444+00	https://elementext.com//contact/form/
74	Randy Smith	720-231-5857	randallt12@gmail.com	We have a wood shake roof that needs repair. Full replacement rejected by ins. company. Definitely need ridgeline repair. Please access roof from the front yard if possible. Thanks!	2021-04-04 17:05:10.931098+00	https://elementext.com/contact/form/
63	Frank Mir	2815099327	frank@estimationhubinc.com	Hi,\r\n\r\nWe are providing accurate Take-offs and Estimates to our clients through experience gained by our firm over time. We are utilizing certified software and have a team of experienced estimators and engineers to create the estimates.\r\n\r\nWe do complete estimates, or just specific trade estimates or takeoffs. To get a better idea of our formatting please ask for samples to review.\r\n\r\nLet me know if you have any questions or send over the drawings/plans of a project to get a quote.\r\n\r\nNote : For kind your information that we are offering 40% discount on every project this week. so it is the best chance for you to grab this opportunity.Thanks\r\n\r\nWarm Regards\r\n\r\nFrank Mir | T: 281.509.9327\r\nBDM at Estimation Hub Inc\r\n207 Greenway Plaza Houston, TX-77046\r\nE: frank@estimationhubinc.com	2020-11-09 20:21:07.416787+00	https://elementext.com/contact/form/
64	Philip	8887636152	marco@roelonlinemarketing.com	Hi, elementext.com,\r\n\r\n    Your website can generate more leads and sales in just less than a year. Do you know how? We do. It all starts with a proper SEO foundation.\r\n\r\n   If you are interested, We can happily send you the list of SEO services that we offer.\r\n\r\n   Thank You, and looking forward to serving your company.\r\n\r\n\r\nPhilip\r\nMarketing Specialist\r\nCompany Roel Online Marketing\r\nwww.roelonlinemarketing.com\r\n	2020-11-26 05:55:27.053431+00	https://elementext.com/contact/form/
65	Gideon Dailey (C134)	7204858082	gideon@printingdonequickly.com	Hello!\r\n\r\nI mistakenly had a package delivered to D116 (our old unit). Please contact me through email or cell phone and I can walk over to pick up the package. (FedEx said package was delivered which made me realize I had the wrong unit.)\r\n\r\nThank you!	2020-12-03 21:24:46.371213+00	https://elementext.com/contact/form/
66	Miles Steven	5015555555	milessteven0005@gmail.com	Hello, How are you doing today ? This is Miles Steven. I would like to confirm if you do Roof replacement and accept all major credit cards if yes kindly get back to me asap with your full name and shop address...    \r\nRegards\r\nSteven	2020-12-11 00:28:33.66893+00	https://elementext.com/contact/form/
67	Tim Miller	3477669973	tm.ustopestimators@gmail.com	Hello,\r\n \r\nWe provide accurate material take-offs and cost estimates at low cost and with fast turnaround. Our team of professionals has been providing these services to General Contractors, Subs (Painting, Electrical, Plumbing, Roofing, Drywall, Tile and Framing etc.) We offer both Residential and Commercial Estimates and we cover every trade that you wish to bid, whether you work with CSI Divisions or your unique classification. We use the latest estimating software backed up by professionals with over a decade of experience. Kindly send us the plans or link to any FTP site so that we can review the plans and submit you with a very economical quote.\r\n	2021-01-08 18:00:26.5706+00	https://elementext.com/contact/form/
68	Sneha Sonam	7077060205	Webrank02@gmail.com	Hello and Good Day\r\nI am Sneha Sonam Marketing Manager with a reputable online marketing company based in India.\r\nWe can fairly quickly promote your website to the top of the search rankings with no long term contracts!\r\nWe can place your website on top of the Natural Listings on Google, Yahoo and MSN. Our Search Engine Optimization team delivers more top rankings than anyone else and we can prove it. We do not use "link farms" or "black hat" methods that Google and the other search engines frown upon and can use to de-list or ban your site. The techniques are proprietary, involving some valuable closely held trade secrets.\r\nWe would be happy to send you a proposal using the top search phrases for your area of expertise. Please contact me at your convenience so we can start saving you some money.\r\nIn order for us to respond to your request for information, please include your company’s website address (mandatory) and or phone number.\r\nSo let me know if you would like me to mail you more details or schedule a call. We'll be pleased to serve you.\r\nI look forward to your mail.\r\nThanks and Regards\r\n	2021-02-02 07:28:57.145087+00	https://elementext.com//contact/form/
69	Nora Willson	2356895054	noradigitalmarketing@gmail.com	Re: Website Error\r\n\r\nHello,\r\n\r\nMy name is  Nora Willson  and I am a Digital Marketing Specialists for a Creative Agency.\r\n\r\nI was doing some industry bench marking for a client of mine when I came across your website.\r\n\r\nI noticed a few technical errors which correspond with a drop of website traffic over the last 2-3 months which I thought I would bring to your attention.\r\n\r\nAfter closer inspection, it appears your site is lacking in 4 key criteria.\r\n\r\n1- Website Speed\r\n2- Link Diversity\r\n3- Domain Authority\r\n4- Competition Comparison\r\n\r\nI would love the chance to send you all the errors that at least give you a gauge on the quality of what I do.  \r\n\r\nIf you are interested then please share your Phone number and requirements.\r\n\r\nOur prices are less than half of what other companies charge.\r\n\r\nThanks\r\nNora Willson\r\nnoradigitalmarketing@gmail.com	2021-02-23 08:18:01.122557+00	https://elementext.com//contact/form/
70	Piker Walter	6785860060	walter.k.p0077@gmail.com	My name is,Walter,I would like to know if you do the list work below,Roof replacement .Deck builder. Gutter.Fence installation.Roof replacement. Driveway installation?\r\n	2021-03-19 09:07:44.372006+00	https://elementext.com/contact/form/
71	Joshua C	7472876066	help@YourNewSecretWeapon.com	Hi my name is Joshua, I am a software engineer and I created the most powerful software at generating new customers for any type of business, especially for companies that do B2B and want to target commercial businesses. It is called YourNewSecretWeapon.com and the software is powerful because it is able to send your business message into the inbox of any type of business, without needing to know their email address. How? The software is an Automatic Contact Form Filler. So you can target all the business in your area, and contacting them automatically asking them if they need your services, and they respond and schedule appointments, espeically businesses, and you know how great business and accounts are. The price is $0.05 per contact form automatically filled out. This contact form submission that you are reading right now is an example of what about software does, and is evidence that our software works, and that it gets the attention of the business owner and and his team.The best part is that there is no email list or company list required, because our software uses the google search engine as it's database. Target Any type of business or industry type. Automate your lead generation.  Target any location in the United States or Worldwide.  No Contract, pay as you go.  Guaranteed to get your message into the inbox of any type of business, without needing to know their email address.  If you are interested, here is our website www.YourNewSecretWeapon.com	2021-03-21 08:04:47.710743+00	https://elementext.com/contact/form/
72	Kevin Phillips	3477669973	kp.topestimatorsinc@gmail.com	Hi,\r\n\r\nWe provide accurate material take-offs and cost estimates at low cost and with fast turnaround. Our team of professionals has been providing these services to General Contractors, Subs (Painting, Electrical, Plumbing, Roofing, Drywall, Tile and Framing etc.) We offer both Residential and Commercial Estimates and we cover every trade that you wish to bid, whether you work with CSI Divisions or your unique classification. We use the latest estimating software backed up by professionals with over a decade of experience. Kindly send us the plans or link to any FTP site so that we can review the plans and submit you with a very economical quote.\r\n	2021-03-25 19:26:48.799144+00	https://elementext.com/contact/form/
75	David Alonso	2815099327	david@estimationhubinc.com	Hi,\r\n\r\nI hope all is well with you, \r\nActually we do cost estimation and quantity takeoff and provide services to General and Sub contractors for their Residential and Commercial projects all over the USA.\r\n\r\nPlease let me know if you need our services then provide me your plans and mention its scope then we will move forward.\r\nThank You.	2021-04-09 17:02:49.953145+00	https://elementext.com/contact/form/
76	Milton Williams	719-338-4445	milt58@comcast.net	In 2018, Element Exteriors installed a new roof on my house due to hail damage.\r\nSince the installation of this roof, we have experienced wetness / dampness on the roof's plywood in the garage area. This along with a musty smell.\r\nIt's very obvious after a heavy snow or rain storm we see large wet areas\r\n\r\nI would appreciate a response from Element Exteriors.  I called the office a few weeks ago, however no one has yet to return my call.\r\n\r\nThank you,\r\nMilton Williams\r\n2130 Greenwich Circle East\r\nColorado Springs, CO 80909\r\n\r\n	2021-04-14 19:05:50.963105+00	https://elementext.com/contact/form/
77	Kevin Phillips	3473310929	kp.usatopestimatorsllc@gmail.com	Hi,\r\n \r\nWe provide Cost Estimating and Quantities Take-Off as well as Scheduling services for General and Subcontractor. We have more than 16 years of experience in Estimating services. We are giving almost 25% Discount on the first estimate. We are giving 98% accuracy on quantities with a money-back guarantee. To get started, kindly send us the plans or link to any FTP site so that we can review the plans and submit you a very economical quote.\r\n	2021-04-17 19:08:25.630378+00	https://elementext.com/contact/form/
78	Johnny Edison	4702847295	johnny.swiftestimating@gmail.com	Hi,\r\n\r\nReceive a quote by submitting your plans today!\r\nSwift Estimating is a full-service construction Cost Estimating & Architecture firm that specializes in preparing estimates and design development for building projects of various sizes and types.\r\nWe are providing quantity take-offs and cost estimates on all trades for commercial, Industrial, Civil, and Residential construction.\r\nTo have the best estimates, send us your project plan, we’ll respond with lead time and price as soon as possible.\r\nPlease include the scope of work & bid due date. We are available to answer any questions you may have. Thanks.\r\n\r\nRegards,\r\n\r\nJohnny Edison\r\njohnny(dot)swiftestimating(at)gmail(dot)com\r\n840 Windemere oak way Lilburn , GA 30047\r\n470-284-7295 | Swift Estimating,INC	2021-04-26 21:11:09.723676+00	https://elementext.com/contact/form/
79	Ivy Wilson	2356895054	ivyseodigitalmarketing@gmail.com	Re: Fix Website Errors\r\n\r\nHello,\r\n\r\nMy name is Ivy Wilson and I am a Digital Marketing Specialists for a Creative Agency.\r\n\r\nI was doing some industry benchmarking for a client of mine when I came across your website.\r\n\r\nI noticed a few technical errors which correspond with a drop of website traffic over the last 2-3 months which I thought I would bring to your attention.\r\n\r\nAfter closer inspection it appears your site is lacking in 4 key criteria.\r\n\r\n1- Website Speed\r\n2- Link Diversity\r\n3- Domain Authority\r\n4- Competition Comparison\r\n\r\nI can send you over the report which shows all of the above and so much more which will help you at least improve your site, its rankings and traffic.\r\n\r\nI would love the chance to help as well however; this report will at least give you a gauge on the quality of what I do. If you are interested then please share your requirement and contact details.\r\n\r\nIs this the best email to send it to?\r\n\r\nSincerely,\r\nIvy Wilson\r\nivyseodigitalmarketing@gmail.com	2021-04-28 05:01:50.164274+00	https://elementext.com//contact/form/
80	Ronnie Williams	3473310929	rw.topestimatorinc@gmail.com	Hi,\r\n\r\nJust Following up, Let me know if you have any projects that require takeoffs / Cost Estimation. We handle all types of residential and commercial projects (Painting, Electrical, Plumbing, Roofing, HVAC, etc.)  We have more than 16 years of experience in Estimating services. We claim 98% accuracy and also give almost 35% Discount on the first estimate. Ask for Samples or please send us plans or FTP site link! Thanks\r\n	2021-06-03 18:29:18.329057+00	https://elementext.com/contact/form/
81	Deep Patel	5408088720	dptl2583@gmail.com	Hi, My name is Deep. Are you tired of your knocking door to door, clients wasting your time to negotiate your price, re-used leads from third party sources like Home-Advisor or AngieLists? Would you rather focus on your business and let a professional bring you 10-20 high-ticket, GUARANTEED jobs for estimates? If you didn't make it past this, this isn't for you... I am a digital marketer, and I am looking to work with ONE reputable contractor in your area for our high- ticket jobs. If you received this email, this means spots are open!! We are only looking to work with motivated, enthusiastic business owners. At the end of the day, we partner with our clients and GROW their business. Feel free to email me if you have questions! CLICK https://calendly.com/envision-digital-llc to schedule an intro call with our team. We would like to learn to see if you would be a good fit for our program! Thank you and have a wonderful day and I hope you consider it.	2021-06-27 13:51:54.345779+00	https://elementext.com/contact/form/
82	Eileen Rosen	2012012012	eileenrosenus@gmail.com	Hey\r\nYour website's design is absolutely brilliant. The visuals really enhance your message and the content compels action. I have forwarded it to a few of my contacts who I think could benefit from your services.\r\n\r\nWhen I was looking at your website, though, I noticed a slight issue re: your SEO that I thought you might not be aware of. It is a relatively simple fix. Would you like me to write it up so that you can share it with your web team? If this is a priority, I can also get on a call.\r\n\r\nRegards,\r\nEileen Rosen	2021-06-30 06:42:20.789361+00	https://elementext.com/contact/form/
83	Danny Knight	2152058231	danny@fixitdads.com	Hi there,\r\n\r\nEvery year, I set goals for improving my home. Most of the tasks are ordinary repairs and maintenance, like replacing our HVAC unit and repairing some minor storm damage. Others are small updates, like painting and updating our decor. We also include at least one major renovation each year, like a bathroom remodel or building a new patio. \r\n\r\nI want to inspire others to live better every day by prioritizing the health of their home and making positive changes that serve your family well. If you’re open to receiving article submissions, I’d love to write something for you. It will offer tips and advice on which projects are easy to DIY, which require professional help, which will have the most impact, and more. I'll be sure to include a mention of your website, too.\r\n\r\nHope to hear from you soon.\r\n\r\nThanks!\r\nDanny Knight\r\nfixitdads.com	2021-07-23 11:37:07.496984+00	https://elementext.com/contact/form/
84	Peter van der Hoop	3033196722	peter.vanderhoop@gmail.com	The roof on my house is currently tar and gravel and is approaching its end of life. I'm looking to get a quote and recommendation on roofing materials. The roof is roughly 4000 sqft.	2021-07-27 22:07:01.388669+00	https://elementext.com/contact/form/
122	Jake Mize	4803802133	jakemize012@gmail.com	Hey I'm listing my house for sale soon and my wife and I are considering some roofing work to increase the curb appeal. I have some questions about certain jobs, I took some photos I want to send you. Do you have an email address? because I can't send them through this form. Thanks, Jake	2022-12-09 21:45:37.034953+00	https://elementext.com/contact/form/
85	Jeff Blu	3023199439	jeff.profineestimation@gmail.com	Hi,\r\n\r\nStop! It's the “GOLD KNOX” of the construction industry.\r\n\r\nProfine Estimating LLC has outnumbered leaders of the market by providing flawless estimating & takeoff via email.\r\n\r\nOur core values are;\r\n\r\n·         100% Money back guarantee if our estimations are not on merit.\r\n\r\n·         98% accuracy is our challenge.\r\n\r\n·         Quick turnarounds.\r\n\r\n·         Infinite reviews are available.\r\n\r\nProfine Estimating LLC has catered hundred & thousand of customers which is a long story but it would be unjust to mention not a few of our delighted customers.\r\n\r\n·         CWI Construction Works.\r\n\r\n·         G & B Speciality Structure.\r\n\r\n·         McHan Construction.\r\n\r\nFeel free to send us an email because we are offering 25% straight off on our service.\r\n\r\nLast but not least we don’t charge for quotes. Anxiously waiting for your mild response.	2021-08-02 18:42:55.347668+00	https://elementext.com/contact/form/
86	Matthieu HUET	3034063309	matthieuhuet@yahoo.fr	Hello, \r\n\r\nWe just bought a house in centennial (2036 E mineral Av) and the gutter system was poorly done and need remodeling. \r\n\r\nPlease get back in touch for a visit (in person or online) to provide quotation.\r\n\r\n\r\n\r\nRegards, \r\n\r\nMatthieu HUET\r\n\r\nCommunication by email or text message prefered. 	2021-08-17 02:09:04.393845+00	https://elementext.com/contact/form/
87	Ashley Allen	2012012012	ashleyallenmkt@gmail.com	Hey\r\nYour website's design is absolutely brilliant. The visuals really enhance your message and the content compels action. I have forwarded it to a few of my contacts who I think could benefit from your services.\r\n\r\nWhen I was looking at your website, though, I noticed a slight issue re: your SEO that I thought you might not be aware of. It is a relatively simple fix. Would you like me to write it up so that you can share it with your web team? If this is a priority, I can also get on a call.\r\n\r\nRegards,\r\nAshley Allen	2021-09-02 05:45:46.206576+00	https://elementext.com/contact/form/
88	Alice Robertson	3055034088	arobertson@tidyhome.info	Hi,\r\n\r\nMany people are deciding to continue working from home, even after the pandemic. I thought some of them might be looking to upgrade their home workspace since they’ll be using it for the long-term. \r\n\r\nI’d love to put together a resource guide for your website with tips and resources on how to do so to create an enjoyable home workspace in your home (whether or not there’s much room to work with!) without breaking the bank.\r\n\r\nAny interest in sharing the guide on your website?\r\n\r\nThank you for your consideration!\r\nAlice Robertson\r\nhttp://tidyhome.info/	2021-09-13 15:50:27.641425+00	https://elementext.com/contact/form/
89	Mel Ebenstein	8003985212	mel@seovendor.co	Hi\r\n\r\nWe are interested to increase organic traffic to your website, please get back to us in order to discuss the possibility in further detail. Please mention your phone number and suitable time to talk.\r\n\r\nOr please let me know your availability for a 20 minute call or if you prefer, I can send you a few preliminary questions.\r\n\r\nKind Regards,\r\nMel Ebenstein	2021-09-24 11:34:43.462372+00	https://elementext.com/contact/form/
90	Stephanie Grover	540-419-9443	groversm1967@gmail.com	we are the new homeowners of 11575 Crow Hill Drive and are needing to speak with someone about the roof certificate that was completed.  	2021-09-28 20:32:15.482575+00	https://elementext.com/contact/form/
91	Stephanie Grover	540-419-9443	groversm1967@gmail.com	we are the new homeowners of 11575 Crow Hill Drive and are needing to speak with someone about the roof certificate that was completed.  	2021-09-28 20:34:38.023243+00	https://elementext.com/contact/form/
92	Stephanie Grover	540-419-9443	groversm1967@gmail.com	new homeowner of 11575 Crow Hill Drive, need to speak with someone in reference to roof certificate	2021-09-28 20:37:26.178346+00	https://elementext.com/contact/form/
93	Stephanie Grover	540-419-9443	groversm1967@gmail.com	new homeowner of 11575 Crow Hill Drive, need to speak with someone in reference to roof certificate	2021-09-28 20:37:36.791891+00	https://elementext.com/contact/form/
94	test	970999999	test@tests.com	test	2021-10-11 16:34:54.034825+00	https://elementext.com/contact/form/
95	 Chetan Hira	7192384125	chetan.hira@gmail.com	Got a flat roof in 3 sections	2021-10-11 16:55:19.058181+00	https://elementext.com/contact/form/
96	Chetan Hira 	7192384155	chetan.hira@gmail.com		2021-10-11 16:57:18.826042+00	https://elementext.com/contact/form/
97	 Chetan Hira 	7192384128	chetan.hira@gmail.com	Flat roof 	2021-10-11 16:58:35.985351+00	https://elementext.com/contact/form/
98	Chris Paul	3473310929	cp.ustopestimatorsinc@gmail.com	Hi,\r\n\r\nWe provide accurate material take-offs and cost estimates at low cost and with fast turnaround. Our team of professionals has been providing these services to General Contractors, Subs (Painting, Electrical, Plumbing, Roofing, Drywall, Tile and Framing etc.) We offer both Residential and Commercial Estimates and we cover every trade that you wish to bid. Just send over the plans of your project and mention the scope of work so we will give you a free proposal on that and after your approval our estimators start working on your job. Thanks \r\n	2021-10-13 20:43:34.333049+00	https://elementext.com/contact/form/
99	Chris Paul	3473310929	paul.topestimatorsinc@gmail.com	Hi,\r\n \r\nWe have very professional practice for preparing takeoffs and estimates. First of all we produced the quantities takeoffs with the certified software against each trade and division. After that we'll incorporate the standard pricing for Labor & Material exactly according to the location and the region. Our charges are 30% less as compared to others. We'll also provide you with the color coded drawings/PDF (software backup file) and you can double verify the produced takeoffs at your end. Please provide us with the drawings and specifications. We'll write you with the quote and turnaround in at our earliest convenience. Thanks\r\n	2021-10-14 23:14:26.281821+00	https://elementext.com/contact/form/
100	Sneha Sonam	7077060205	Siterank3@gmail.com	Hello And Good Day\r\nI am  Sneha Sonam a Marketing Manager with a reputable online marketing company based in India.\r\nWe can fairly quickly promote your website to the top of the search rankings with no long term contracts!\r\nWe can place your website on top of the Natural Listings on Google, Yahoo, and MSN. Our Search Engine Optimization team delivers more top rankings than anyone else, and we can prove it. We do not use "link farms" or "black hat" methods that Google and the other search engines frown upon and can use to de-list or ban your site. The techniques are proprietary, involving some valuable closely held trade secrets. Our prices are less than half of what other companies charge.\r\nWe would be happy to send you a proposal using the top search phrases for your area of expertise. Please contact me at your convenience so we can start saving you some money.\r\nIn order for us to respond to your request for information, please include your company’s website address (mandatory) and or phone number.\r\nSo let me know if you would like me to mail you more details or schedule a call. We'll be pleased to serve you.\r\nI look forward to your mail.\r\nThanks and Regards\r\nSneha Sonam\r\n	2021-10-21 05:20:08.15463+00	https://elementext.com/contact/form/
101	Sneha Sonam	7077060205	Webrank06@gmail.com	Hello and Good Day\r\nI am Sneha Sonam Marketing Manager with a reputable online marketing company based in India.\r\nWe can fairly quickly promote your website to the top of the search rankings with no long term contracts!\r\nWe can place your website on top of the Natural Listings on Google, Yahoo and MSN. Our Search Engine Optimization team delivers more top rankings than anyone else and we can prove it. We do not use "link farms" or "black hat" methods that Google and the other search engines frown upon and can use to de-list or ban your site. The techniques are proprietary, involving some valuable closely held trade secrets.\r\nWe would be happy to send you a proposal using the top search phrases for your area of expertise. Please contact me at your convenience so we can start saving you some money.\r\nIn order for us to respond to your request for information, please include your company’s website address (mandatory) and or phone number.\r\nSo let me know if you would like me to mail you more details or schedule a call. We'll be pleased to serve you.\r\nI look forward to your mail.\r\nThanks and Regards	2021-10-22 11:09:15.871907+00	https://elementext.com//contact/form/
102	Sharon Josephs	7202327849	sharyjoe22@gmail.com	Replace Roof	2021-10-26 15:19:40.101999+00	https://elementext.com/contact/form/
103	Alexander Brown	9492390778	alexander@reviewvio.com	Hi There,\r\nWould you like help removing bad reviews from your Google, Yelp and Facebook pages? Our company, ReviewVio, has proprietary technology used by businesses like Bluepoint Medical Group and Compass Real Estate to remove bad reviews, manage online reviews and gather genuine customer reviews. We offer guaranteed pricing - pay after we remove the bad reviews - or unlimited removals for a monthly subscription.\r\nDo you have some time later today or tomorrow to see how we are able to help? Here’s a link to my calendar: https://calendly.com/reviewvio-consult-team/contact-n\r\nSincerely,\r\nAlexander Brown | Reviewvio - Remove, Prevent & Capture\r\nOffice (949) 239-0778\r\nalexander@reviewvio.com\r\nwww.reviewvio.com	2021-11-03 08:02:43.609232+00	https://elementext.com/contact/form/
104	Katrina Castel	0000000000	yourdomainguru.kat5@gmail.com	Hello, my name is Katrina from TDS. We have a domain that is currently on sale that you might be interested in - DenverPaintingContractors.com\r\n \r\nAnytime someone types Denver Painting Contractors, Painting Contractors in Denver, The Best Painting Contractors in Denver, or any other phrase with these keywords into their browser, your site could be the first they see!\r\n\r\nThe internet is the most efficient way to acquire new customers\r\n\r\nAvg Google Search Results for this domain is:  8,300,000 \r\nYou can easily redirect all the traffic this domain gets to your current site!\r\n\r\nEstibot.com appraises this domain at $810. \r\n\r\nPriced at only $398 for a limited time! If interested please go to DenverPaintingContractors.com and select Buy Now.  \r\nAct Fast! First person to select Buy Now gets it!  \r\n\r\nThank you very much for your time.\r\nTop Domain Sellers (TDS)\r\nKatrina Castel	2021-12-08 12:44:18.887594+00	https://elementext.com/contact/form/
105	Eileen Rosen	2012012012	eileenrosenus@gmail.com	Hi,\r\nI can help your website to get on the first page of Google and increase the number of leads and sales you are getting from your website.\r\nPlease email us back for the full proposal.\r\nLet me know if you are interested and I'll send you the cost and other details.\r\nThanks & Regards,\r\nEileen Rosen	2021-12-14 07:46:53.044204+00	https://elementext.com/contact/form/
106	Teresa Greenhill	2062718743	info@mentalhealthforseniors.com	Hi,\r\n\r\nI know there are many seniors who are looking to start a business during retirement - it’s a great way to keep a steady income and to keep your mind mentally sharp. \r\n\r\nI always suggest house flipping as a good way to earn income. Though it’s not as “passive” as some may think, it can be an incredibly lucrative investment.\r\n\r\nMay I write about this topic in a complimentary article for your website?\r\n\r\nI'll be sure to cover all the basics on how seniors can get into the house flipping business and become successful at it, including: \r\nhow to find the perfect property, \r\nhow to finance the expenses, \r\nhow to manage payroll for employees and contractors, etc. \r\n\r\nWhat do you think?\r\n\r\nLooking forward to hearing back,\r\nTeresa	2022-01-07 01:03:56.727565+00	https://elementext.com/contact/form/
107	Lorenzo Doxey	7777777777	lorenzo.doxey@millhouse.media	Hey! This is Lorenzo Doxey, with Mill House Media. We're looking to get in contact with you regarding your business's online presence. Mill House media has had many clients that have been very pleased with our photo and video services, as well as social media management. When you're ready to boost your online community and local awareness, we're the ones to talk to. Check out the site, thanks! Lorenzo Doxey Creative Director, Mill House Media LLC www.millhouse.media Call us at 801-882-4843	2022-01-13 13:55:10.127338+00	https://elementext.com/contact/form/
108	Jenson Button	3473310929	jenson.ustopestimators@gmail.com	Hello, \r\n\r\nWe are an estimation services providing company. We provide cost estimation & quantities take-Off services for general As well as for Sub-contractors. We do both residential and commercial projects. We have more than 16 years of experience in estimating services. We claim 98% accuracy and also give almost 25% discounts on the first estimate. Please send us plans and we would be very glad to review the drawings and send you our proposal for fee and turnaround time accordingly. In order to get a better idea of our work, ask for sample estimates and take-offs. Thanks\r\n	2022-03-02 22:35:55.081901+00	https://elementext.com/contact/form/
109	chandler c fendler	7203463400	chandler.fendler@sothebysrealty.com	Need rubber roof evaluation for a residential property. ASAP. Address: 921 Meadowrose Ln Castle Pines,CO 80108. Do y'all do siding too?	2022-03-08 00:28:39.07442+00	https://elementext.com/contact/form/
110	Keith k	8102440753	adi@ndmails.com	Just wanted to ask if you would be interested in getting external help with graphic design? We do all design work like banners, advertisements, photo edits, logos, flyers, etc. for a fixed monthly fee. \r\n\r\nWe don't charge for each task. What kind of work do you need on a regular basis? Let me know and I'll share my portfolio with you.\r\n	2022-03-31 07:09:05.830775+00	https://elementext.com/contact/form/
111	Joshua Hoopes	8016478943	crazynetads@gmail.com	Hi,\r\n\r\nHow far out are you scheduling?  The reason I ask is that, a lot of people are pretty busy and can't take the work that is coming in right now.  \r\n\r\nIf you're considering more work than what you're currently doing, are you opposed to looking at outside partnerships?\r\n\r\nIf you aren't opposed to it, let's chat a minute.  I'm not a sales guy, just a guy that to send me leads somewhere.  \r\n\r\nThere's no upfront costs...looking for a long term partnership. \r\n\r\nThanks,\r\n\r\nJosh\r\nText or email is the quickest way to reach me. \r\n801-647-8943   \r\n	2022-04-19 17:33:58.559094+00	https://elementext.com/contact/form/
112	Debbie Tormey	2037634785	guttercleaningleads@gmail.com	I wanted to send you a quick message and see if you might be interested in taking on some extra gutter cleaning jobs in the area.\r\nWe're running a promotion right now where we give you a couple of gutter cleaning jobs completely free to test out.\r\n\r\nShoot me a quick email if you have any interest/questions or want to hop on the phone for a quick chat to discuss the particulars.\r\n\r\nThanks,\r\nDebbie\r\nGutter Cleaning Leads\r\nwww.guttercleaningleads.com	2022-05-14 15:02:29.098073+00	https://elementext.com/contact/form/
113	Claire	775-861-3326	claire@caringfromafar.com	Hi! I would love to write an article for your site. Typically, my writing is more focused on caregiving from afar, but I like to be realistic: sometimes, it’s just not possible. Sometimes, your loved one needs you in the same city.   \r\n\r\nThat’s the topic I’d like to cover in an article for your site: How to identify when it’s time to move closer to a loved one who needs your time and care locally, and how to make the moving process as easy as possible.  \r\n\r\nWould that work as a new article on your site? If so, I’ll put it together and send it your way for review. Please let me know your thoughts!  \r\n\r\nBest to you, \r\nClaire Wentz \r\nclaire@caringfromafar.com 	2022-05-30 09:50:45.404361+00	https://elementext.com/contact/form/
114	Kelly Broecker	3037262856	kjbroecker@gmail.com	You installed a new roof on our home in 2019 and some of the shingles have blown loose and are now falling off. We would like someone to contact us to get the roof fixed. 	2022-06-14 17:09:09.776928+00	https://elementext.com/contact/form/
115	Rachel Thomas	2012012012	RachelThomasUSA@gmail.com	Hi,\r\n\r\nI came across your website and noticed that you were not ranking well for certain keyword phrases.\r\n\r\nI would like to send you a comprehensive SEO strategy & Proposal to help improve your Google rankings dramatically.\r\n\r\nWould that be okay? If so, I can send it to you sometime this week.\r\n\r\nKind Regards\r\nRachel Thomas	2022-06-30 10:45:14.223347+00	https://elementext.com/contact/form/
116	Kenna Weidert	3037897994	denverorders@arcpanels.com	Hey Element Team!\r\n\r\nMy name is Kenna, and I am the shop manager for Architectural Sheet Metal and Panels, Inc. in Englewood, CO. I wanted to reach out to you all about our metal fabrication services. We are capable of all custom trim fabrication, all necessary accessories, five roll former standing seam machines, five metal bending machines, plasma machine for details, WAV panel machine (for HR-16 Berridge), additional site in Fort Collins for your convenience, on-site standing seam fabrication (1” Nail Strip, 1.5” Mechanical Seam, 1.5” Snap Lock, 1.75” Snap Lock, and 2” Mechanical Seam), as well as personalized ordering for exposed fastener (Pro-Panel, Classic Rib, PBR, and Corrugated). Other services while working with us include delivery in Colorado with one of our five trucks operating daily, higher attention to detail, competitive and honest pricing, friendly service, and some of the fastest turnaround times in the Denver area. \r\n\r\nI would love to quote you on your next job. Feel free to email me at this address or give me a call at my number listed below for quotes, pricing, or any other general information. Our CEO/Owner is also currently offering free one-on-one meetings with you and your team about how we can help you on a large scale or even a small one, we care for our community regardless. You can get in touch with me to schedule this. \r\n\r\n\r\nCheers to another day!	2022-07-19 19:44:21.296885+00	https://elementext.com/contact/form/
117	Lew Spelgatti	7205731966	sales@system4-centralcolorado.com	Is your company in need of a proactive, professional cleaning partnership?\r\n\r\nWe are a professional management services partner that provides constant communication and monthly inspections to ensure your expectations are met. We are confident in proving our service quality month after month, so you are not bound by a long-term contract.\r\n\r\nIf we can clean from medical to retail, we know we can clean for you!\r\n\r\nWould you be interested in a Complimentary Evaluation? We will give you a no-cost assessment and proposal for your company.\r\n\r\nMay I give you more information?\r\n\r\nWith best,\r\n\r\nLew Spelgatti\r\nSystem4 Facility Services\r\n(720) 573-1966\r\n\r\n“System4 is amazing. Truly, I've never seen anything like it. I've been with my organization for 24 years and we have NEVER had anyone clean our building as thoroughly or efficiently or effectively as they did. Particularly during this health crisis, when I've been so desperate to keep my staff and the children and families we serve safe, I am grateful beyond words.” —Diana Goldberg\r\n\r\nPlease respond with "stop" to opt out.	2022-08-31 18:27:13.56584+00	https://elementext.com/contact/form/
118	Max Williams	7077060205	Siterank6@gmail.com	Hello and Good Day\r\nI am Max (Jitesh Chauhan) Marketing Manager with a reputable online marketing company based in India.\r\nWe can fairly quickly promote your website to the top of the search rankings with no long term contracts!\r\nWe can place your website on top of the Natural Listings on Google, Yahoo and MSN. Our Search Engine Optimization team delivers more top rankings than anyone else and we can prove it. We do not use "link farms" or "black hat" methods that Google and the other search engines frown upon and can use to de-list or ban your site. The techniques are proprietary, involving some valuable closely held trade secrets.\r\nWe would be happy to send you a proposal using the top search phrases for your area of expertise. Please contact me at your convenience so we can start saving you some money.\r\nIn order for us to respond to your request for information, please include your company’s website address (mandatory) and or phone number.\r\nSo let me know if you would like me to mail you more details or schedule a call. We'll be pleased to serve you.\r\nI look forward to your mail.\r\nThanks and Regards\r\n	2022-09-13 06:43:07.832041+00	https://elementext.com//contact/form/
119	Max Williams	7077060205	Siterank8@gmail.com	Hello And Good Day\r\nI am Max (Jitesh Chauhan), a Marketing Manager with a reputable online marketing company based in India.\r\nWe can fairly quickly promote your website to the top of the search rankings with no long term contracts!\r\nWe can place your website on top of the Natural Listings on Google, Yahoo, and MSN. Our Search Engine Optimization team delivers more top rankings than anyone else, and we can prove it. We do not use "link farms" or "black hat" methods that Google and the other search engines frown upon and can use to de-list or ban your site. The techniques are proprietary, involving some valuable closely held trade secrets. Our prices are less than half of what other companies charge.\r\nWe would be happy to send you a proposal using the top search phrases for your area of expertise. Please contact me at your convenience so we can start saving you some money.\r\nIn order for us to respond to your request for information, please include your company’s website address (mandatory) and or phone number.\r\nSo let me know if you would like me to mail you more details or schedule a call. We'll be pleased to serve you.\r\nI look forward to your mail.\r\nFor any inquiry related to this, mail us.\r\nThanks and Regards\r\n	2022-10-14 12:13:41.561245+00	https://elementext.com/contact/form/
120	Brad Clark	2815099327	bradestimation1@gmail.com	Doing Well,\r\n\r\nWe are providing Estimation for residential and commercial projects for General Contractors, Sub Contractors, Homebuilder s, Owners, Building Professionals, Developers, Engineers, and Real-estate industries in the entire USA.\r\n\r\nPlease, let me know if there is any procedure to work with you or send me the drawings/plans (PDF Files/Dropbox link).\r\n\r\nThank you.	2022-11-01 21:45:44.922225+00	https://elementext.com/contact/form/
121	Max Smith	2356895054	maxseocarner@gmail.com	Re: Website Errors\r\n\r\nHello,\r\n\r\nI found few errors which correspond with a drop of website traffic over the last 1-2 months Due to (Google Algorithm Updates) which I thought I would bring to your attention.\r\n\r\nI would be happy to send you errors and the solutions that would help to improve your website performance and traffic.\r\n\r\nKindly let me know if you would be interested so we can email you more details or schedule a call.\r\n\r\nThanks & Regards\r\nMax Smith\r\nmaxseocarner@gmail.com	2022-11-02 06:48:48.729507+00	https://elementext.com/contact/form/
123	John Mark	3156364446	estimator.johnmark@gmail.com	Hi,\r\n\r\nhope you are doing well.\r\n\r\nAll-Pro Estimation LLC provides the cost estimation and Quantity Take Off for General contractors or Subcontractors.\r\n \r\nWe are specialized in all Construction Csi Divisions.\r\n\r\nWe have expertise in all trades like Civil, Mechanical, Electrical, Plumbing, Concrete, Flooring, Drywall, HVAC and much more.\r\n\r\nWe deliver Accurately And On Time.\r\n\r\nWe charge according to the scope of work and size of the project.\r\n\r\nPlease, let us know if there is any procedure to work with you, or do send me the Drawings/Plans whenever you have them for estimation. \r\nI'll get back to you with an economic proposal shortly.\r\n\r\nI am looking forward to hearing from you soon. \r\n\r\nThanks.\r\n\r\nJohn Mark\r\nSenior Estimator\r\nEstimation Department\r\n315 636 4446\r\nWe do work in all states of America & Canada.	2023-01-02 22:11:25.959098+00	https://elementext.com/contact/form/
124	Tim Miller	3473310929	miller.ustopestimators@gmail.com	GREETINGS,\r\n\r\nDetailed analysis equips you with precise estimations. That helps contractors earn more profit. In fact, a 1% error in estimation can reduce the profit by four figures. That is the hard-earned money by the contractor. With Top Estimators, contractors gain more money and reduce costs. We handle all types of residential and commercial projects (Painting, Electrical, Plumbing, Roofing, HVAC, Tile and Framing, etc.) with 16 years of robust experience 98% accurate estimation Prompt delivery with minimum turnaround Every estimate costs 25% less than the market. Cost update with proper plan zip codes. In order to get a better idea of our work, ask for sample estimates and take-offs.\r\n	2023-01-09 16:29:48.238432+00	https://elementext.com/contact/form/
125	Lexie	323-642-4604	lexie_dy@readyjob.org	Hi,  \r\n\r\nWish you a wonderful day!   \r\n\r\nI'm writing to see if you'd be interested in my article. It'll provide invaluable insight on how best to transform an investment property for maximum return-on-investment. When it's completed, would your website like the piece ?  Your readers will love this valuable information!  \r\n\r\nThank you, \r\nThe team at ReadyJob.org  \r\n\r\nP.S. If, by any chance, you’d prefer an article on a different topic, please send over your suggestions. However, if you'd prefer not to receive emails from me, please let me know!	2023-02-07 17:49:47.132389+00	https://elementext.com/contact/form/
126	Jacob Joseph	2356895054	jacobjosephemailing@gmail.com	Re: Please Send me a Quote\r\n\r\nHi,\r\n\r\nI was looking at your website and realized that despite having a great design: it is not ranking on the search engines.\r\n\r\nI was not able to find your website on the starting pages on Google;:\r\n\r\nCan I Send audit, analysis and errors of your website?\r\n\r\nI’m a SEO Expert and I helped over 3000 businesses rank on the (1st Page on Google) we can place your website on Google's 1st page and my rates are very affordable.\r\n\r\nIf you are interested, then please let me know. I will send you "SEO Packages" and "Pricing".\r\n\r\nRegards,\r\nJacob Joseph	2023-02-16 10:47:56.505614+00	https://elementext.com/contact/form/
127	Sally	7208415885	sallyjswain@msn.com	Our shake roof is leaking.  We are located in Franktown CO	2023-05-15 09:40:05.316099+00	https://elementext.com/contact/form/
128	Ethan Turner	5306031186	info@atlantisestimating.com	Hi,\r\nThis is Ethan Turner from Atlantis Estimating LLC. Do you need effective and accurate estimation services for winning bids for your Roofing projects? \r\nWe are a team of expert estimating professionals who use latest software to help the contractors and subcontractors to win bids at an impressive rate. Please feel free to contact me on my phone number +1 (530) 603 1186 or email at info@atlantisestimating.com for further details.\r\nI look forward to hearing from you soon.\r\nThank you for your time.\r\nSincerely,\r\nEthan Turner\r\n	2023-06-15 14:06:18.781915+00	https://elementext.com/contact/form/
129	Jessica Chen	7204125457	yuch6434@gmail.com		2023-06-20 21:08:45.235139+00	https://elementext.com/contact/form/
130	Brian Fox	5026407530	brian.daniel.fox@gmail.com	I have two issues. One is leaking around a window that I need fixed. The second is there is a tree leaning on my house from the recent storm. not sure if there is damage that will need to be repaired on this one. \r\n\r\nI am looking for an inspection and quote for these services. 	2023-06-23 16:41:41.751784+00	https://elementext.com/contact/form/
131	Barbara Johnson	3032413143	jjohnson32@comcast.net	Due to hail storm in May, roof in Erie needs replacement.  This is a paired home so hoping to coordinate with other owner.\r\nThank you.	2023-07-21 13:27:10.152166+00	https://elementext.com/contact/form/
132	Leslie Cohen	7203304982	leslie@thekeypeople.net	Are you interested in a straightforward cleaning quote that meets the specific needs of your company? The Key People has been in business for 50 years and we have dedicated clients that have been with us for 15+.\r\n\r\nLet me know if you'd like some information about our services or references in your area. I'd be available to provide a no-obligation cleaning estimate based on your cleaning expectations and specifications.\r\n\r\nAll the best,\r\n\r\nLeslie Cohen\r\nCustomer Service Manager\r\nThe Key People\r\nleslie@thekeypeople.net\r\n\r\nRespond with stop to optout.	2023-07-31 13:06:37.155067+00	https://elementext.com/contact/form/
133	Steve Brown	8063046285	steve@roionlinehotleads.net	\r\nAre you looking to grow your brand and elevate your business this year? ROI Online is a full-service marketing group that can help you get there.\r\n\r\nI focus on telling the right story and creating impactful campaigns that connect your brand to your target audience, increase visibility, and generate qualified leads. \r\n\r\nI’ve recently acquired a prospecting agency that has the best lists available on the market for prospect email addresses and direct-dial phones. \r\n\r\nAfter spending millions on prospect data and marketing systems, we know which lists perform and which outreach methods work. \r\n\r\nWith a team of over 300+ business development reps that send 1x1 messages to prospects on behalf of our clientele. When a lead comes in we monitor the response and send the true "hot" exclusive leads to you within an hour. \r\n\r\nMay I give you more information?\r\n\r\nThank you for your time,\r\n\r\nSteve Brown\r\nOwner\r\nROI Online\r\nsteve@roionlinehotleads.net\r\n\r\nRespond with stop to optout.	2023-08-11 12:26:08.869516+00	https://elementext.com/contact/form/
134	Jane Johnston	3156364446	janejohnstonuser@gmail.com	Greetings,\r\n\r\n\r\nOur forte lies in furnishing precise construction estimates and comprehensive takeoffs. Should you find our services beneficial, please share your Drawings/Plans using PDF, Dropbox, or any format you prefer, and we'll generate a tailored quote to suit your needs. To gain insights into our past accomplishments, please send us an email requesting sample work.\r\n\r\n\r\nWe're excited about the opportunity to collaborate with you.\r\n\r\n\r\nBest Regards,\r\n\r\n\r\nJane Johnston| Estimating\r\n\r\nAll Pro Estimation LLC\r\n\r\n\r\nN: If you don't want to receive my mail in the future just send UNSUB.	2023-08-16 18:13:16.741319+00	https://elementext.com/contact/form/
135	Randell Morgan	9726387054	RandellMorgan@gmail.com	I was working as a State Farm insurance adjuster in the past. Now I'm offering Insurance estimates & supplements to Roofing companies. Have any roofing jobs that were paid by insurance claims? I can help you get more money from insurance companies using supplements. I also work with new estimates using Xactimate. I can offer you 2 to test it out. Send your phone # if this interests you.	2023-08-27 14:37:52.728304+00	https://elementext.com/contact/form/
136	Smith Roy	08327434250	smith.softestimating5@gmail.com	Hello\r\n\r\nI will provide you Construction Estimation and Material Take off for Residential & Commercial Projects. I have many years of working experience for many USA based Material Take off Projects. I will prepare Construction Estimate and Material take off for all types of Construction projects for you.\r\n\r\nPlease! Send us any Bid/Plan, PDF, Drawings, and link files of the Project procedure of estimating.\r\n\r\nSincerely,\r\n\r\nSmith Roy\r\nSoft Estimating \r\n469.638.3304\r\n3139 W Holcombe Blvd Houston, TX \r\nsmith01softestimating@gmail.com	2023-09-05 16:40:02.209718+00	https://elementext.com/contact/form/
137	Susan Watts	720 537-5506	susan33candy@gmail.com	I’m looking for an estimate to replace my roof at\r\n5722 S. Lee Ct.\r\nLittleton 80127\r\nAny day next week except 9/13.\r\nEarly morning works best.\r\nThank you	2023-09-07 20:04:34.412642+00	https://elementext.com/contact/form/
138	Kevin Phillips	3473310929	kevin.ustopestimatorsinc@gmail.com	Hello,\r\n\r\nBe proactive and remove all troubles. Work perfectly and earn more with Top Estimators LLC which have years of robust experience with 98% accurate estimation. Let me know if you have any projects that require takeoffs / Cost Estimation. We handle all types of residential and commercial projects Painting, Electrical, Plumbing, Roofing, HVAC, Steel structure, Tile and Framing etc. You may ask for our recent work samples or please send us plans or FTP site link to get an economical quote. Thanks\r\n	2023-09-13 19:47:39.112895+00	https://elementext.com/contact/form/
139	Kevin Phillips	3473310929	phillips.topestimators@gmail.com	Hello,\r\n\r\nWould you be interested in Cost Estimation Services? We can perform all types of estimates, MEP or Single Trade Electrical, we cover it all. We offer: Quantity Takeoff • Worker Rates • Accuracy with Experienced and Certified Estimators • Competitive Cost • Colored Take-off Sheets • Quick Turnaround time • Discount on projects. I’d be happy to send over a few sample estimates on your request. Moreover, please send us the plans or link to any FTP site so that we can review the plans and submit you a very economical quote. Thanks\r\n	2023-09-19 17:16:18.420439+00	https://elementext.com/contact/form/
140	Dipesh Lunthi	7077060205	Seorankings001@gmail.com	Hello and Good Day!\r\n\r\nI'm Dipesh Lunthi, Business Development Manager at a reputable online marketing company based in India. I noticed that your website is not ranking well on Google and other search engines, which could be affecting your visibility to potential customers.\r\n\r\nWhile your website design is impressive, it's crucial to enhance its visibility on search engines to attract more traffic. Our 360° Digital Marketing Agency, backed by experienced and innovative SEO Experts, has a proven track record of helping over 1000+ businesses achieve top rankings on Google's first page.\r\n\r\nWe specialize in providing cost-effective and high-quality solutions to small and medium-sized companies like yours. Our tailored strategies are designed to optimize your online presence and capture the attention of your target audience.\r\n\r\nTo improve your website's visibility on search engines and maximize your chances of reaching potential customers, I would be happy to send you a detailed proposal, price list, and compelling case studies.\r\n\r\nLet's elevate your online presence to new heights!\r\n\r\nThanks,\r\nDipesh Lunthi	2023-09-29 05:52:55.647703+00	https://elementext.com/contact/form/
141	Alexandra Niehaus	918-852-3319	alexandrasn912@gmail.com	I would like an estimate for durable slate roofing, my total roof area is 2182 square feet	2023-10-07 23:38:38.343737+00	https://elementext.com/contact/form/
142	Nick Webb	2143085337	info@epicmarketingpros.com	Your Message\r\n\r\nCan your roofing company handle a few more clients? If yes, we can help you. We have two roofing marketing services that would be a good fit and would like to run them by you quickly.\r\n\r\nThe first service is our Exclusive Roofing Lead Generation Services. We will set up a custom roofing lead generation campaign for your business and have local clients looking for roofing services call your business. All you have to do is sit back, relax, and let us work our magic. You’ll have leads calling your business soon!\r\n\r\nThe second service is our Local SEO Services for Roofing Contractors. Our Local SEO Services will rank your website at the top of Google for roofing services. You’ll receive more organic traffic and local visitors interested in your roofing services. This is the best deal for your dollars and is sustainable over time.\r\n\r\nWould you be interested in discussing either one of these services? Or both services to supercharge your business growth? If yes, please reply with the best date/time, and I would be happy to jump on a quick phone call with you. I am in Dallas, so I’m in the Central Standard Time zone.\r\n\r\nLooking forward to your response,\r\nNick Webb\r\n	2023-12-18 09:22:42.91185+00	https://elementext.com/contact/form/
143	Sarah Velasquez	4808974759	sarah@ourperfectabode.com	Hey there!\r\n\r\nMajor home renovations can be expensive and difficult, but they can also significantly increase your home's worth.\r\n\r\nI'd like to create an article for your website about the factors you should take into account before starting a home improvement project. In this article, I'll discuss the benefits and drawbacks of home renovations. For example, a total makeover enables you to modify your home to meet your unique wants and tastes (e.g. a complete renovation can be disruptive to your daily routine and expensive to finance).\r\n\r\nIf you're interested in publishing this guest article on your website, let me know, and I'll write it for you.\r\n\r\nThank you for your time, and have a wonderful day!\r\nSarah V of OurPerfectAbode.com \r\n\r\n\r\nP.S. Please let me know if you're interested but have a different topic preference. I understand if you don't want to hear from me again. Please let me know if this is the case.	2023-12-22 03:13:13.553453+00	https://elementext.com/contact/form/
144	Dave Horbin	7185771544	Dave@fastestimationllc.com	We specialize in concrete, masonry, structural steel, lumber, drywall, trim, doors and windows, and flooring takeoffs/Estimate. We count every material item required to build any size construction project. Do you have any projects that require estimation services? Thanks.\r\n\r\n“If you are Not Interested Reply with Unsub”	2024-02-21 16:53:08.816193+00	https://elementext.com/contact/form/
155	Steven Smith	7185771544	fastestimation@contractor.net	We provide realistic and up-to-date cost estimates according to the project area zip-code that will allow you to submit winning bids without sacrificing quality or profit margins.\r\nWe understand that time is precious in construction, which is why we deliver your estimates fast within twenty-four to thirty-six hours by a dedicated estimator assigned solely to your projects\r\nSend us the plans you have to get a quote and turnaround time on that. Thanks.	2024-06-24 17:11:27.107997+00	https://elementext.com/contact/form/
156	Nathan Reynolds	8483056754	nathanreynoldsrfg@gmail.com	Do you do roofing work after wind and hail storms?\r\n\r\nI was working for Allstate, SF and some other carriers for over 15 years as an adjuster before I started helping contractors.\r\n\r\nI know the inner workings of ins. companies and can help you use it to your advantage to secure higher payouts and even reverse denials.\r\n\r\nEmail or Text me your # if you're interested in me working 2 files without charge so that you can test out the service. \r\n\r\nNathan Reynolds\r\n(848) 305-6754	2024-06-25 14:40:38.120375+00	https://elementext.com/contact/form/
145	Jeremy Belisle	6124823314	jeremy@lightingsquadllc.com	Hi, would you be interested in partnering with my company, Lighting Squad, LLC. and Prospectr Marketing, Inc. to start a holiday lighting business (100% owned by you) in your market? If you are interested in learning more I can send more information, or we could schedule a 15 minute call to discuss the opportunity.\r\n\r\nWe started this business because our parent company Prospectr Marketing, Inc. generates leads for 130+ customers in commercial and residential exterior maintenance and janitorial services. We work with a company in Seattle providing window washing services and other exterior maintenance services and they also hired us to market their holiday lighting business. We saw that lighting  business grow from $60,000 in year 1 to $1.5mil by year 5. They taught us the model they used and we having provided the marketing support had learned how to generate the demand needed to grow the lighting business.\r\n\r\nI hope you’ll call me with any questions or concerns as I would like to do this with you!\r\n\r\nThe beautiful thing about this business is that it is a great door opener in that my marketing typically averages 1 lead for every 2,500 emails, in this business we averaged one lead for every 200 emails sent and the customers are already asking for other exterior services, so it is a useful magnet to then upsell customers into your other service offerings.\r\n\r\nWith best, \r\n\r\nJeremy Belisle\r\nPartner / VP\r\nLighting Partners, Inc\r\njeremy@lightingsquadllc.com\r\n\r\nRespond with stop to optout.	2024-03-06 18:05:08.75507+00	https://elementext.com/contact/form/
146	Alice Wilson	5011231234	aliceleadmkt@gmail.com	Hi,\r\nI would like to offer some suggestions for your website. No commitment for future work, fine print, or hidden anything - just an opportunity for you to see how we can improve your website and leads.\r\n\r\nWould it be ok to send you the suggestions I have in mind?\r\n\r\nPlease let me know.\r\nAlice Wilson	2024-03-26 07:51:29.781467+00	https://elementext.com/contact/form/
147	Brandon Cohen	866-782-5906	brandon.s@digitalsevenagency.com	Hey my name is Brandon, I am helping roofers and GC’s grow their business by ranking them on Google’s 1st page. It’s only $185 to get started and then when you are on the 1st page for your keywords it will be less than $400/mo for guaranteed SEO.  \r\n\r\nIf you are interested let me know what type of jobs you want more of and I can see what I can put together for you within your budget, is that cool? \r\n\r\nI also do websites. \r\n\r\nThanks\r\nBrandon\r\n646-375-2434\r\n	2024-03-27 18:26:27.027385+00	https://elementext.com/contact/form/
148	Nicole Miranda	3034899822	nicolemirandapt@gmail.com	I would like a roof inspection related to tree branch damage from the most recent heavy snow storm. We have a wood shake roof.	2024-04-08 16:36:44.108828+00	https://elementext.com/contact/form/
149	Adam Clark	2356895054	adamwebmastermarketing@gmail.com	\r\nHello Good Morning,\r\n\r\nI was checking your website and see you have a good design and it looks great, but it's not ranking on Google and other major search engines.\r\n\r\nWith your permission : I would like to send you a SEO report with prices showing you a few things to greatly improve these search results for you. These things are not difficult, and my report will be very specific. It will show you exactly what needs to be done to move you up in the rankings dramatically.\r\n\r\nKindly let me know if you would be interested so we can email you more details or schedule a call.\r\n\r\nThank you\r\nAdam Clark\r\n	2024-04-25 05:02:11.542888+00	https://elementext.com/contact/form/
150	Tony Smith	2356895054	tonyseocarner@gmail.com	Re: SEO Report\r\n\r\nHello Good Morning\r\n\r\nI was checking your website and see you have a good design and it looks great, but it's not ranking on Google and other major search engines.\r\n\r\nWith your permission : I would like to send you a SEO report with prices showing you a few things to greatly improve these search results for you. These things are not difficult, and my report will be very specific. It will show you exactly what needs to be done to move you up in the rankings dramatically.\r\n\r\nKindly let me know if you would be interested so we can email you more details or schedule a call.\r\n\r\nThank you\r\nTony Smith\r\n	2024-04-25 09:35:00.724297+00	https://elementext.com/contact/form/
151	Ryan Doheny	6128879993	ryan@prospectrleadgen.net	Hi,\r\n\r\nI was checking out your company and I'm curious about maybe working together? I work with exterior maintenance companies to help them gain new customers with our qualified leads and digital marketing experience.\r\n\r\nFor over 14 years we have been helping cleaning companies, in fact, we love cleaning so much we started our own Nationwide Solar Panel Cleaning Franchise System and a Nationwide Holiday Lighting Franchise System.\r\n\r\nAre you free possibly this week to see if working together could make sense?\r\n\r\nHere is what Aaron said about working with us:\r\n\r\n"Prospectr Marketing has completely gone beyond my marketing expectations. I started off just doing residential window cleaning but Prospectr Marketing has taken my business to another level. I'm now doing commercial jobs and have exceeded my financial goals. I've closed on about 90% of the leads they provided and have gained more jobs through those leads. Prospectr Marketing is amazing. Thanks".\r\n\r\nThank you,\r\n\r\nRyan Doheny\r\nDirector of Sales\r\n612-887-9993\r\nProspectr Marketing\r\nryan@prospectrleadgen.net\r\n\r\nRespond with stop to optout.	2024-04-25 19:21:25.399316+00	https://elementext.com/contact/form/
152	Sean Flanagan 	303-319-6427 	sean.flanagan@hedgestone.com	\r\nGood morning! \r\n\r\nMy name is Sean Flanagan and I am a business advisor with Hedgestone Business Advisors.  I am reaching out to local and national business owners and wanted to know if you had any interest in expanding your business through acquisitions?  \r\n\r\n\r\nFurther, we work with private investors as well as Private Equity firms and family offices who are specifically looking to acquire businesses such as yours.  \r\n\r\n\r\nWould you be open to a discussion in regards to selling or expanding your business? \r\n\r\n\r\nWe are happy to also offer free business evaluations.\r\n\r\n\r\n\r\n\r\nThank you for your time!\r\n	2024-05-03 13:09:20.015531+00	https://elementext.com/contact/form/
153	Brad Caulfield	6467796738	brad.caulfield@digitalsevenagency.com	Hi\r\n\r\nI just tried calling you guys; so just leaving you this email now. I’m Brad co-owner of Digital7; a US based company that works with Roofers, Siding, and basically General contractors. I know you get tunes of emails but I get these guys on Google’s 1st page but without paying anything upfront until they see results and are ranking in Google, nothing before! \r\n\r\nImagine if all this time you could have hired an SEO company that only gets paid if they deliver… What a thought!  If we fail you are out nothing however  if we succeed you get to benefit from 1st page rankings like your competitors are enjoying right now and start getting more jobs.\r\n\r\nWe also specialize in web design for your industry; I can share live results from our ongoing projects and discuss how Digital7 can specifically benefit your business.  What are some types of jobs you would like to get more of and be found in Google for?\r\n\r\n\r\nbrad.caulfield@digitalsevenagency.com\r\nCo-Owner, Digital7 Agency\r\nDigital7 Agency\r\nBrad Caulfield\r\n646-779-6738\r\n130 Church St Suite 432, New York, NY, 10001	2024-05-10 16:36:23.309066+00	https://elementext.com/contact/form/
154	Jeff Taylor	303-229-0243	taylorjl56@yahoo.com	Morning Christian.  I attempted to reach you by text several times and didn't hear back.  I noticed during the last rain storm that several of my gutters are leaking at the end caps.  Could you please give me a call to discuss.  Thanks.  (You replaced my roof and gutters at 2789 Winter Way, Parker last summer).	2024-05-28 12:57:21.202843+00	https://elementext.com/contact/form/
157	Ellie Watkins	8645960067	Ellie@ladieslovediy.com	Hello,\r\n\r\n\r\nDo you allow guest posts on your website? If so, is it possible for me to provide a free article about finding, creating, or designing the ideal space for a home-based business for your readers?\r\n\r\n\r\nI figured now would be a wonderful opportunity to talk about this subject on your website!\r\n\r\n\r\nThanks a lot.\r\n\r\n\r\nEllie @ ladieslovediy.com \r\n\r\n\r\nP.S. If you’re interested in an article, but want one on a different topic, please don’t hesitate to reach out. Alternatively, just let me know if ever you don't want to receive any further emails.	2024-07-11 22:39:03.325523+00	https://elementext.com/contact/form/
158	Derek Anderson	9082918968	derekandersonxact@gmail.com	Do you replace roofs from hail and windstorm damage?\r\n\r\nI am a retired adjuster and can help you secure more $ from ins. carriers and reverse denials with Xactimate supplements.\r\n\r\nText or email me your number if you're interested in testing out a few at no charge.\r\n\r\nDerek Anderson\r\n(908) 291-8968	2024-07-12 11:32:35.31226+00	https://elementext.com/contact/form/
159	BRAD CAULFIELD	6467796738	brad.caulfield@digitalsevenagency.com	I'm looking to see if you guys would be interested, I'm offering to rank your website on Google’s first page without paying me a penny until you actually see yourself ranking in Google, nothing before.\r\n\r\n\r\nNo setup fees, no deposits—nothing. If you are not ranking on Google’s first page, it’s simple you don’t pay. However, if I succeed typically within a month or two, you get to benefit from being high-up in Google like your competitors are currently enjoying right now and start getting more clients for only a few hundred dollars a month but again only start paying when you see I know what I am doing.\r\n\r\n\r\nIf you want to be seen in Google and like the idea of paying only for results message me back as soon as possible, thanks.\r\n\r\n\r\nBrad Caulfield\r\nCo-Owner, Digital7 Agency\r\nbrad.caulfield@digitalsevenagency.com\r\n646-779-6738\r\n130 Church St Suite 432, New York, NY, 10001	2024-07-26 18:19:49.828619+00	https://elementext.com/contact/form/
160	Brandon Carter	6467796738	Brandon@meetnoa.com	Hey, this can affect you guys. Home Service Pros like Roofers, Contractors, Cleaning companies are ditching voicemails in favor of this free “AI Call Answering Assistant”, named NOA because it’s converting 86% of missed calls into new jobs.\r\n\r\nNOA will answer all your missed calls, answering questions and will even instantly send you a call summary. You’ll know who called and who should be called back right away. No more checking voicemails or worrying about missing a new customer. You finally have an assistant!\r\n\r\nTry out Noa for free at www.meetnoa.com. Takes less than 2 minutes to have her answering your missed calls. \r\n\r\nHope this helps! Feel free to reach out if you have any questions.\r\nBrandon Carter | MeetNoa.com | 3501 Jack Northrop Ave Ste 65372, Hawthorne, California, 90250	2024-08-29 19:03:50.655034+00	https://elementext.com/contact/form/
161	Justin Kingston	5127301097	justinkingstontx@gmail.com	I have over 6 thousand Roofing landing pages bringing in hundreds of Roof Replacement leads daily. Can I give you a few to test out the quality?\r\n\r\nJustin Kingston\r\n‪512 730 1097‬	2024-09-19 16:03:10.762926+00	https://elementext.com/contact/form/
\.


--
-- Name: contacts_message_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.contacts_message_id_seq', 161, true);


--
-- Data for Name: contacts_notificationreceiver; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contacts_notificationreceiver (id, email, config_id) FROM stdin;
1	christian@elementext.com	1
\.


--
-- Name: contacts_notificationreceiver_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.contacts_notificationreceiver_id_seq', 1, true);


--
-- Data for Name: contacts_openinghours; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contacts_openinghours (id, weekdays, start_time, end_time, address_id) FROM stdin;
1	0,1,2,3,4	09:00:00	05:00:00	1
\.


--
-- Name: contacts_openinghours_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.contacts_openinghours_id_seq', 1, true);


--
-- Data for Name: contacts_phonenumber; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contacts_phonenumber (id, number, sort_order, address_id) FROM stdin;
1	303-747-3706	0	1
\.


--
-- Name: contacts_phonenumber_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.contacts_phonenumber_id_seq', 1, true);


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
1	2019-04-26 07:21:47.72261+00	None	robots.txt	1		52	1
2	2019-04-26 07:22:02.092133+00	1	elementext.com	2	Changed domain and name.	6	1
3	2019-04-26 07:23:39.301715+00	1	Managers	1		3	1
4	2019-04-26 07:23:51.858155+00	1	dladmin	2	Changed username.	31	1
5	2019-04-26 07:24:17.883337+00	1	dladmin	2	Changed password.	31	1
6	2019-04-26 07:26:40.2127+00	2	seo	1		31	1
7	2019-04-26 07:26:45.843061+00	2	seo	2	Changed is_staff and is_superuser.	31	1
8	2019-04-26 07:27:03.153163+00	3	elementext	1		31	1
9	2019-04-26 07:27:10.649937+00	3	elementext	2	Changed is_staff and groups.	31	1
10	2019-04-26 16:21:18.576414+00	1	Element Exteriors Inc.	2	Changed email for notification receiver "christian@elementext.com".	11	1
11	2019-04-29 06:27:38.385179+00	None	robots.txt	1		52	2
12	2019-04-29 06:34:30.913417+00	None	robots.txt	1		52	2
13	2019-04-29 06:34:44.089261+00	23	test	3		16	2
14	2019-04-29 06:34:44.091378+00	22	test	3		16	2
15	2019-04-29 06:34:44.092939+00	21	test	3		16	2
16	2019-04-29 06:34:44.094521+00	20	Ann Chebaeva	3		16	2
17	2019-04-29 06:34:44.095995+00	19	Test	3		16	2
18	2019-04-29 06:34:44.097463+00	18	1	3		16	2
19	2019-04-29 06:34:44.09897+00	17	 	3		16	2
20	2019-04-29 06:34:44.10036+00	16	ывывп	3		16	2
21	2019-04-29 06:34:44.101621+00	15	  	3		16	2
22	2019-04-29 06:34:44.102887+00	14	фцвфц	3		16	2
23	2019-04-29 06:34:44.104258+00	13	Ann Chebaeva	3		16	2
24	2019-04-29 06:34:44.105578+00	12	dg	3		16	2
25	2019-04-29 06:34:44.106982+00	11	hf	3		16	2
26	2019-04-29 06:34:44.108185+00	10	fgh	3		16	2
27	2019-04-29 06:34:44.109466+00	9	hfh	3		16	2
28	2019-04-29 06:34:44.11065+00	8	try	3		16	2
29	2019-04-29 06:34:44.112011+00	7	546	3		16	2
30	2019-04-29 06:34:44.113472+00	6	dsg	3		16	2
31	2019-04-29 06:34:44.114726+00	5	ghf	3		16	2
32	2019-04-29 06:34:44.116156+00	4	dg	3		16	2
33	2019-04-29 06:34:50.31359+00	3	y	3		16	2
34	2019-04-29 06:34:50.315218+00	2	rr	3		16	2
35	2019-04-29 06:34:50.316517+00	1	dgdgd	3		16	2
36	2019-05-07 11:18:30.75822+00	1	Home page	2	Deleted attached block "licenses (Licenses block) → main.mainpageconfig (#1)". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object".	25	3
37	2019-05-08 11:52:20.318573+00	1	Home page	2	Added attached block "licenses (Licenses block) → main.mainpageconfig (#1)". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object".	25	3
38	2019-05-14 06:45:32.872237+00	1	Licensed contractor in Colorado	2	Changed title, header and description.	22	2
39	2019-05-14 06:45:49.215839+00	1	Licenses	2	Changed title.	22	2
40	2019-05-14 06:46:10.774237+00	7	licenses	2	Changed header.	24	2
41	2019-05-14 06:46:11.898879+00	1	Home page	2	Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object".	25	2
42	2019-05-14 06:46:27.680852+00	1	Home page	2	Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object".	25	2
43	2019-06-07 12:32:43.977891+00	28	test	3		16	2
44	2019-06-07 12:32:43.980311+00	25	test	3		16	2
45	2019-06-07 12:32:43.981709+00	24	Test	3		16	2
46	2019-07-01 11:12:00.335957+00	4	Top-Notch New Roof Construction in Denver 	2	Changed title, header, description, slug, icon and text.	33	2
47	2019-07-01 11:12:00.343049+00	7	SeoData for service(#4)	1		49	2
48	2019-07-01 11:13:17.799828+00	4	Top-Notch New Roof Construction in Denver 	2	Changed icon.	33	2
49	2019-07-01 11:14:26.27431+00	4	New Roof Construction	2	Changed title and icon.	33	2
50	2019-07-01 11:15:17.521538+00	4	New Roof Construction	2	Changed description and icon.	33	2
51	2019-07-01 11:15:41.302401+00	4	New Roof Construction	2	Changed icon.	33	2
52	2019-07-01 11:25:24.503492+00	16	Emergency roof repair	2	Changed header, description, slug, icon and text.	33	2
53	2019-07-01 11:25:24.509529+00	8	SeoData for service(#16)	1		49	2
54	2019-07-01 11:26:10.83891+00	16	Emergency roof repair	2	Changed icon.	33	2
55	2019-07-01 11:33:40.536499+00	26	Roofing Contactors	1		33	2
56	2019-07-01 11:33:40.545154+00	9	SeoData for service(#26)	1		49	2
57	2019-07-01 11:34:36.533379+00	26	Roofing Contactors	2	Changed icon. Added attached block "estimate (Estimate block) → services.service (#26)". Added attached block "testimonials (Testimonials block) → services.service (#26)". Added attached block "Contact (Contact block) → services.service (#26)".	33	2
58	2019-07-01 11:35:57.314394+00	16	Emergency roof repair	2	Changed parent and icon.	33	2
59	2019-07-01 11:36:19.295592+00	2	Commercial Roofing	2	Changed sort_order.	33	2
60	2019-07-01 11:36:19.308371+00	23	TPO roofing	2	Changed sort_order.	33	2
61	2019-07-01 11:36:19.31834+00	24	PVC roofing	2	Changed sort_order.	33	2
62	2019-07-01 11:36:19.328679+00	25	EPDM roofing	2	Changed sort_order.	33	2
63	2019-07-01 11:36:19.338567+00	1	Residential Roofing	2	Changed sort_order.	33	2
64	2019-07-01 11:36:19.348348+00	21	Tile Roofs	2	Changed sort_order.	33	2
65	2019-07-01 11:36:19.358744+00	20	Asphalt Roofing	2	Changed sort_order.	33	2
66	2019-07-01 11:36:19.36856+00	22	Metal Roofs	2	Changed sort_order.	33	2
67	2019-07-01 11:36:19.379006+00	6	Painting	2	Changed sort_order.	33	2
68	2019-07-01 11:36:19.389996+00	7	Gutters	2	Changed sort_order.	33	2
69	2019-07-01 11:36:19.400017+00	5	Windows & Doors	2	Changed sort_order.	33	2
70	2019-07-01 11:36:19.409993+00	4	New Roof Construction	2	Changed sort_order.	33	2
71	2019-07-01 11:36:19.419293+00	26	Roofing Contactors	2	Changed sort_order.	33	2
72	2019-07-01 11:36:19.430198+00	16	Emergency roof repair	2	Changed sort_order.	33	2
73	2019-07-01 11:36:32.078771+00	2	Commercial Roofing	2	Changed sort_order.	33	2
74	2019-07-01 11:36:32.089836+00	23	TPO roofing	2	Changed sort_order.	33	2
75	2019-07-01 11:36:32.100875+00	24	PVC roofing	2	Changed sort_order.	33	2
76	2019-07-01 11:36:32.112029+00	25	EPDM roofing	2	Changed sort_order.	33	2
77	2019-07-01 11:36:32.120528+00	1	Residential Roofing	2	Changed sort_order.	33	2
78	2019-07-01 11:36:32.133519+00	21	Tile Roofs	2	Changed sort_order.	33	2
79	2019-07-01 11:36:32.145398+00	20	Asphalt Roofing	2	Changed sort_order.	33	2
80	2019-07-01 11:36:32.155711+00	22	Metal Roofs	2	Changed sort_order.	33	2
81	2019-07-01 11:36:49.478167+00	6	Painting	2	Changed sort_order.	33	2
82	2019-07-01 11:36:49.488973+00	7	Gutters	2	Changed sort_order.	33	2
83	2019-07-01 11:36:49.501028+00	5	Windows & Doors	2	Changed sort_order.	33	2
84	2019-07-01 11:36:49.509677+00	4	New Roof Construction	2	Changed sort_order.	33	2
85	2019-07-01 13:54:26.555049+00	26	Roofing Contactors	2	Changed icon.	33	2
86	2019-07-01 13:54:26.563036+00	9	SeoData for service(#26)	2	Changed keywords.	49	2
87	2019-07-01 13:57:20.663917+00	26	Roofing Contactors	2	Changed header and icon.	33	2
88	2019-07-01 13:58:35.301899+00	26	Roofing Contactors	2	Changed icon and text.	33	2
89	2019-07-01 13:59:40.059472+00	26	Roofing Contactors	2	Changed icon and text.	33	2
90	2019-07-01 14:00:08.849598+00	26	Roofing Contactors	2	Changed icon and text.	33	2
91	2019-07-01 14:00:38.807751+00	26	Roofing Contactors	2	Changed icon and text.	33	2
92	2019-07-01 14:01:25.59627+00	26	Roofing Contactors	2	Changed icon and text.	33	2
93	2019-07-01 14:09:01.406852+00	26	Roofing Contactors	2	Changed icon and text.	33	2
94	2019-07-01 14:11:21.943537+00	1	Residential Roofing	2	Changed icon.	33	2
95	2019-07-01 14:11:21.951094+00	2	SeoData for service(#1)	2	Changed keywords.	49	2
96	2019-07-01 14:12:02.791772+00	16	Emergency roof repair	2	Changed visible and icon.	33	2
97	2019-07-01 14:12:35.682874+00	16	Emergency roof repair	2	Changed slug and icon.	33	2
98	2019-07-01 14:14:11.724723+00	16	Emergency roof repair	2	Changed icon.	33	2
99	2019-07-01 14:15:21.324613+00	16	Emergency roof repair	2	Changed icon.	33	2
100	2019-07-01 14:15:21.331195+00	8	SeoData for service(#16)	2	Changed description.	49	2
101	2019-07-01 14:15:59.558834+00	16	Emergency roof repair	2	Changed icon.	33	2
102	2019-07-01 14:15:59.564834+00	8	SeoData for service(#16)	2	Changed keywords.	49	2
103	2019-07-01 14:17:19.248014+00	16	Emergency roof repair	2	Changed icon and text.	33	2
104	2019-07-01 14:18:02.35902+00	16	Emergency roof repair	2	Changed icon and text.	33	2
105	2019-07-01 14:19:34.332445+00	16	Emergency roof repair	2	Changed icon.	33	2
106	2019-07-01 14:30:36.90618+00	4	New Roof Construction	2	Changed slug and icon.	33	2
107	2019-07-01 14:33:10.751282+00	4	New Roof Construction	2	Changed icon and text.	33	2
108	2019-07-01 14:33:10.760243+00	7	SeoData for service(#4)	2	Changed keywords and description.	49	2
109	2019-07-01 14:33:27.159159+00	4	New Roof Construction	2	Changed icon.	33	2
110	2019-07-01 14:34:04.426395+00	4	New Roof Construction	2	Changed icon and text.	33	2
111	2019-07-02 08:47:26.040086+00	4	New Roof Construction	2	Changed visible and icon.	33	2
112	2019-07-02 08:49:06.507761+00	4	New Roof Construction	2	Changed icon.	33	2
113	2019-07-03 10:41:14.59339+00	26	Roofing Contactors	2	Changed background, icon and text.	33	2
114	2019-07-03 10:42:02.378353+00	26	Roofing Contactors	2	Changed background, icon and text.	33	2
115	2019-07-03 10:42:49.709865+00	26	Roofing Contactors	2	Changed icon.	33	2
116	2019-07-03 10:44:02.770649+00	16	Emergency roof repair	2	Changed background, icon and text.	33	2
117	2019-07-03 10:44:29.465965+00	16	Emergency roof repair	2	Changed icon.	33	2
118	2019-07-03 10:45:27.600204+00	4	New Roof Construction	2	Changed background, icon and text.	33	2
119	2019-07-03 10:45:59.862435+00	4	New Roof Construction	2	Changed icon.	33	2
120	2019-07-05 09:55:58.17096+00	1	(301) "/news/addendum-1-to-531-main-street-rfq/" → "/news/addendum-main-street-rfq/"	1		50	2
121	2019-07-05 09:56:48.270845+00	1	(301) "/news/addendum-1-to-531-main-street-rfq/" → "/news/addendum-main-street-rfq/"	3		50	2
122	2019-07-08 10:56:18.559636+00	29	test	3		16	2
123	2019-09-04 05:39:49.870731+00	1	Home page	2	Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object".	25	2
124	2019-09-04 05:39:49.878971+00	1	SeoData for settings(#1)	2	Changed title.	49	2
125	2019-09-10 05:54:28.623325+00	1	Home page	2	Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object".	25	2
126	2019-09-10 05:54:28.631149+00	1	SeoData for settings(#1)	2	Changed keywords.	49	2
127	2019-09-10 05:56:59.229886+00	1	About us	2	No fields changed.	8	2
128	2019-09-10 05:56:59.236053+00	10	SeoData for Settings(#1)	1		49	2
129	2019-09-10 06:17:09.020098+00	1	About us	2	No fields changed.	8	2
130	2019-09-10 06:17:09.028439+00	10	SeoData for Settings(#1)	2	Changed keywords and description.	49	2
131	2019-09-10 06:19:39.486696+00	1	About us	2	No fields changed.	8	2
132	2019-09-10 06:22:19.360989+00	26	Roofing Contactors	2	Changed icon.	33	2
133	2019-09-10 06:22:19.368191+00	9	SeoData for service(#26)	2	Changed title.	49	2
134	2019-09-10 06:23:39.331221+00	1	Services	2	No fields changed.	32	2
135	2019-09-10 06:23:39.338638+00	4	SeoData for Settings(#1)	2	Changed title.	49	2
136	2019-09-27 11:49:58.441047+00	1	Home page	2	Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object".	25	2
137	2019-09-27 11:49:58.451591+00	1	SeoData for settings(#1)	2	Changed title.	49	2
138	2019-10-03 10:47:43.851796+00	1	Home page	2	Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object".	25	2
139	2019-10-03 10:47:43.86011+00	1	SeoData for settings(#1)	2	Changed description.	49	2
140	2019-10-03 11:15:35.450865+00	1	Services	2	No fields changed.	32	2
141	2019-10-03 11:15:35.458835+00	4	SeoData for Settings(#1)	2	Changed keywords and description.	49	2
142	2019-10-03 11:19:10.45789+00	1	About us	2	No fields changed.	8	2
143	2019-10-03 11:19:10.466543+00	10	SeoData for Settings(#1)	2	Changed description.	49	2
144	2019-10-03 11:19:24.221231+00	1	About us	2	No fields changed.	8	2
145	2019-10-03 11:19:24.226719+00	10	SeoData for Settings(#1)	2	Changed keywords.	49	2
146	2019-10-03 11:20:38.038849+00	1	Element Exteriors Inc.	2	No fields changed.	11	2
147	2019-10-03 11:20:38.044956+00	11	SeoData for settings(#1)	1		49	2
148	2019-10-03 11:22:39.116078+00	1	Licenses	2	No fields changed.	22	2
149	2019-10-03 11:22:39.122359+00	12	SeoData for Settings(#1)	1		49	2
150	2019-10-03 11:26:53.165667+00	1	Insurance Claims	2	No fields changed.	19	2
151	2019-10-03 11:26:53.175306+00	13	SeoData for Settings(#1)	1		49	2
152	2019-10-03 11:29:14.83253+00	26	Roofing Contactors	2	Changed icon.	33	2
153	2019-10-03 11:29:14.839615+00	9	SeoData for service(#26)	2	Changed title and description.	49	2
154	2019-10-03 11:32:41.462344+00	16	Emergency roof repair	2	Changed icon.	33	2
155	2019-10-03 11:32:41.468807+00	8	SeoData for service(#16)	2	Changed keywords and description.	49	2
156	2019-10-03 11:35:02.253428+00	1	Residential Roofing	2	Changed icon.	33	2
157	2019-10-03 11:35:02.259895+00	2	SeoData for service(#1)	2	Changed description.	49	2
158	2019-10-03 11:40:38.197694+00	2	Commercial Roofing	2	Changed icon.	33	2
159	2019-10-03 11:40:38.204233+00	6	SeoData for service(#2)	2	Changed title.	49	2
160	2019-10-03 11:41:36.585934+00	2	Commercial Roofing	2	Changed icon.	33	2
161	2019-10-03 11:41:36.592485+00	6	SeoData for service(#2)	2	Changed description.	49	2
162	2019-10-03 11:42:56.134644+00	4	New Roof Construction	2	Changed icon.	33	2
163	2019-10-03 11:42:56.141471+00	7	SeoData for service(#4)	2	Changed keywords and description.	49	2
164	2019-10-03 11:47:31.475329+00	6	Painting	2	Changed icon.	33	2
165	2019-10-03 11:47:31.481946+00	5	SeoData for service(#6)	2	Changed title and description.	49	2
166	2019-10-03 11:47:54.378778+00	6	Painting	2	Changed icon.	33	2
167	2019-10-03 11:50:59.970359+00	7	Gutters	2	Changed icon.	33	2
168	2019-10-03 11:50:59.977139+00	3	SeoData for service(#7)	2	Changed title and description.	49	2
169	2019-10-09 10:10:12.815605+00	1	Home page	2	Deleted attached block "estimate (Estimate block) → main.mainpageconfig (#1)". Deleted attached block "Contact (Contact block) → main.mainpageconfig (#1)". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object".	25	3
170	2019-10-09 10:11:45.870592+00	1	Home page	2	Added attached block "estimate (Estimate block) → main.mainpageconfig (#1)". Added attached block "Contact (Contact block) → main.mainpageconfig (#1)". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object".	25	3
171	2019-10-12 15:26:32.872373+00	1	Home page	2	Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object".	25	2
172	2019-10-12 15:26:32.879743+00	1	SeoData for settings(#1)	2	Changed description.	49	2
173	2019-10-12 15:30:09.053029+00	1	Home page	2	Changed description. Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object".	25	2
174	2019-10-23 05:34:17.00974+00	27	Roof Replacement	1		33	2
175	2019-10-23 05:34:17.016588+00	14	SeoData for service(#27)	1		49	2
176	2019-10-23 05:34:32.992339+00	16	Emergency roof repair	2	Changed sort_order.	33	2
177	2019-10-23 05:34:33.005007+00	27	Roof Replacement	2	Changed sort_order.	33	2
178	2019-10-23 05:34:33.014641+00	1	Residential Roofing	2	Changed sort_order.	33	2
179	2019-10-23 05:34:33.026176+00	21	Tile Roofs	2	Changed sort_order.	33	2
180	2019-10-23 05:34:33.036223+00	20	Asphalt Roofing	2	Changed sort_order.	33	2
181	2019-10-23 05:34:33.046042+00	22	Metal Roofs	2	Changed sort_order.	33	2
182	2019-10-23 05:34:33.055529+00	2	Commercial Roofing	2	Changed sort_order.	33	2
183	2019-10-23 05:34:33.066904+00	23	TPO roofing	2	Changed sort_order.	33	2
184	2019-10-23 05:34:33.07668+00	24	PVC roofing	2	Changed sort_order.	33	2
185	2019-10-23 05:34:33.086491+00	25	EPDM roofing	2	Changed sort_order.	33	2
186	2019-10-23 05:34:33.097039+00	4	New Roof Construction	2	Changed sort_order.	33	2
187	2019-10-23 05:34:33.107229+00	6	Painting	2	Changed sort_order.	33	2
188	2019-10-23 05:34:33.117256+00	7	Gutters	2	Changed sort_order.	33	2
189	2019-10-23 05:35:16.396526+00	22	Metal Roofs	2	Changed sort_order.	33	2
190	2019-10-23 05:35:16.407158+00	21	Tile Roofs	2	Changed sort_order.	33	2
191	2019-10-23 05:35:16.417004+00	20	Asphalt Roofing	2	Changed sort_order.	33	2
192	2019-10-23 05:35:16.428375+00	25	EPDM roofing	2	Changed sort_order.	33	2
193	2019-10-23 05:35:16.438171+00	23	TPO roofing	2	Changed sort_order.	33	2
194	2019-10-23 05:35:16.447481+00	5	Windows & Doors	2	Changed sort_order.	33	2
195	2019-10-23 05:41:36.137586+00	28	Roof Repair	1		33	2
196	2019-10-23 05:41:36.142449+00	15	SeoData for service(#28)	1		49	2
197	2019-10-23 05:44:04.52854+00	28	Roof Repair	2	Changed icon and text.	33	2
198	2019-10-23 05:44:17.658067+00	16	Emergency roof repair	2	Changed sort_order.	33	2
199	2019-10-23 05:44:17.670208+00	28	Roof Repair	2	Changed sort_order.	33	2
200	2019-10-23 05:44:17.680074+00	1	Residential Roofing	2	Changed sort_order.	33	2
201	2019-10-23 05:44:17.691593+00	22	Metal Roofs	2	Changed sort_order.	33	2
202	2019-10-23 05:44:17.701403+00	21	Tile Roofs	2	Changed sort_order.	33	2
203	2019-10-23 05:44:17.711261+00	20	Asphalt Roofing	2	Changed sort_order.	33	2
204	2019-10-23 05:44:17.720876+00	2	Commercial Roofing	2	Changed sort_order.	33	2
205	2019-10-23 05:44:17.733107+00	25	EPDM roofing	2	Changed sort_order.	33	2
206	2019-10-23 05:44:17.742908+00	24	PVC roofing	2	Changed sort_order.	33	2
207	2019-10-23 05:44:17.75249+00	23	TPO roofing	2	Changed sort_order.	33	2
208	2019-10-23 05:44:17.763025+00	4	New Roof Construction	2	Changed sort_order.	33	2
209	2019-10-23 05:44:17.773187+00	5	Windows & Doors	2	Changed sort_order.	33	2
210	2019-10-23 05:44:17.783547+00	6	Painting	2	Changed sort_order.	33	2
211	2019-10-23 05:50:15.534813+00	27	Roof Replacement	2	Changed icon and text.	33	2
212	2019-10-23 05:56:26.116849+00	29	Roof Maintenance	1		33	2
213	2019-10-23 05:58:45.351286+00	29	Roof Maintenance	2	Changed icon.	33	2
214	2019-10-23 05:58:45.359126+00	16	SeoData for service(#29)	1		49	2
215	2019-10-23 05:58:55.456922+00	29	Roof Maintenance	2	Changed sort_order.	33	2
216	2019-10-23 05:58:55.467109+00	1	Residential Roofing	2	Changed sort_order.	33	2
217	2019-10-23 05:58:55.4787+00	22	Metal Roofs	2	Changed sort_order.	33	2
218	2019-10-23 05:58:55.488413+00	21	Tile Roofs	2	Changed sort_order.	33	2
219	2019-10-23 05:58:55.499009+00	20	Asphalt Roofing	2	Changed sort_order.	33	2
220	2019-10-23 05:58:55.508502+00	2	Commercial Roofing	2	Changed sort_order.	33	2
221	2019-10-23 05:58:55.519664+00	25	EPDM roofing	2	Changed sort_order.	33	2
222	2019-10-23 05:58:55.529032+00	24	PVC roofing	2	Changed sort_order.	33	2
223	2019-10-23 05:58:55.538955+00	23	TPO roofing	2	Changed sort_order.	33	2
224	2019-10-23 05:58:55.549647+00	4	New Roof Construction	2	Changed sort_order.	33	2
225	2019-10-23 05:58:55.559905+00	7	Gutters	2	Changed sort_order.	33	2
226	2019-10-23 05:58:55.569544+00	5	Windows & Doors	2	Changed sort_order.	33	2
227	2019-10-23 06:01:44.792003+00	16	Emergency roof repair	2	Changed sort_order.	33	2
228	2019-10-23 06:01:44.80602+00	29	Roof Maintenance	2	Changed sort_order.	33	2
229	2019-10-23 06:06:35.39283+00	27	Roof Replacement	2	Changed sort_order.	33	2
230	2019-10-23 06:06:35.405811+00	28	Roof Repair	2	Changed sort_order.	33	2
231	2019-10-23 06:06:35.416023+00	29	Roof Maintenance	2	Changed sort_order.	33	2
232	2019-10-23 06:06:35.428148+00	16	Emergency roof repair	2	Changed sort_order.	33	2
233	2019-10-23 06:07:26.521869+00	29	Roof Maintenance	2	Changed sort_order.	33	2
234	2019-10-23 06:07:26.533442+00	16	Emergency roof repair	2	Changed sort_order.	33	2
235	2019-10-23 06:07:26.544022+00	28	Roof Repair	2	Changed sort_order.	33	2
236	2019-10-23 06:08:10.745956+00	1	services	3		34	2
237	2019-10-23 06:08:18.221865+00	29	Roof Maintenance	2	Changed icon. Deleted attached block "estimate (Estimate block) → services.service (#29)". Deleted attached block "testimonials (Testimonials block) → services.service (#29)". Deleted attached block "Contact (Contact block) → services.service (#29)".	33	2
238	2019-10-23 06:08:31.087918+00	6	Painting	2	Changed sort_order.	33	2
239	2019-10-23 06:09:13.98815+00	6	Painting	2	Changed sort_order.	33	2
240	2019-10-23 06:11:17.83639+00	11	services	1		34	2
241	2019-10-23 06:11:48.49519+00	27	Roof Replacement	2	Changed icon. Added attached block "services (Services block) → services.service (#27)". Added attached block "estimate (Estimate block) → services.service (#27)". Added attached block "testimonials (Testimonials block) → services.service (#27)". Added attached block "Contact (Contact block) → services.service (#27)".	33	2
242	2019-10-23 06:12:35.603572+00	29	Roof Maintenance	2	Changed icon. Added attached block "services (Services block) → services.service (#29)". Added attached block "estimate (Estimate block) → services.service (#29)". Added attached block "testimonials (Testimonials block) → services.service (#29)". Added attached block "Contact (Contact block) → services.service (#29)".	33	2
243	2019-10-23 06:12:42.349325+00	29	Roof Maintenance	2	Changed icon.	33	2
244	2019-10-23 06:13:15.900012+00	28	Roof Repair	2	Changed icon. Added attached block "services (Services block) → services.service (#28)". Added attached block "estimate (Estimate block) → services.service (#28)". Added attached block "testimonials (Testimonials block) → services.service (#28)". Added attached block "Contact (Contact block) → services.service (#28)".	33	2
245	2019-10-23 06:14:49.343044+00	1	Home page	2	Added attached block "services (Services block) → main.mainpageconfig (#1)". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object".	25	2
246	2019-10-23 06:15:50.915729+00	1	Home page	2	Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object".	25	2
247	2019-10-23 06:16:07.427186+00	1	Home page	2	Deleted attached block "services (Services block) → main.mainpageconfig (#1)". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object".	25	2
248	2019-10-23 06:16:20.800791+00	1	Home page	2	Changed sort_order for attached block "estimate (Estimate block) → main.mainpageconfig (#1)". Changed sort_order for attached block "advantages (Advantages block) → main.mainpageconfig (#1)". Changed sort_order for attached block "members (Members block) → main.mainpageconfig (#1)". Changed sort_order for attached block "recovery (Recovery block) → main.mainpageconfig (#1)". Changed sort_order for attached block "testimonials (Testimonials block) → main.mainpageconfig (#1)". Changed sort_order for attached block "insurance (Insurance block) → main.mainpageconfig (#1)". Changed sort_order for attached block "licenses (Licenses block) → main.mainpageconfig (#1)". Changed sort_order for attached block "Contact (Contact block) → main.mainpageconfig (#1)". Changed sort_order and icon for Advantage "Advantage object". Changed sort_order and icon for Advantage "Advantage object". Changed sort_order and icon for Advantage "Advantage object". Changed sort_order and icon for Advantage "Advantage object". Changed sort_order and icon for Advantage "Advantage object". Changed sort_order and icon for Advantage "Advantage object". Changed sort_order for Member "Member object". Changed sort_order for Member "Member object". Changed sort_order for Member "Member object". Changed sort_order for Member "Member object".	25	2
249	2019-10-23 06:16:25.94613+00	1	Home page	2	Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object".	25	2
250	2019-10-23 06:17:42.336662+00	1	Home page	2	Added attached block "services (Services block) → main.mainpageconfig (#1)". Changed sort_order and icon for Advantage "Advantage object". Changed sort_order and icon for Advantage "Advantage object". Changed sort_order and icon for Advantage "Advantage object". Changed sort_order and icon for Advantage "Advantage object". Changed sort_order and icon for Advantage "Advantage object". Changed sort_order and icon for Advantage "Advantage object". Changed sort_order for Member "Member object". Changed sort_order for Member "Member object". Changed sort_order for Member "Member object". Changed sort_order for Member "Member object".	25	2
251	2019-10-23 06:17:45.676985+00	1	Home page	2	Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object".	25	2
287	2019-10-23 07:00:39.584055+00	21	Tile Roof	2	Changed icon.	33	2
288	2019-10-23 07:03:23.071442+00	26	Roofing Contactors	2	Changed icon and text.	33	2
289	2019-10-23 07:04:32.486118+00	21	Tile Roof	2	Changed icon and text.	33	2
290	2019-10-23 07:04:42.60045+00	21	Tile Roof	2	Changed icon and text.	33	2
291	2019-10-23 07:07:34.183556+00	21	Tile Roof	2	Changed icon and text.	33	2
292	2019-10-23 07:07:42.93281+00	21	Tile Roof	2	Changed icon.	33	2
293	2019-10-23 07:07:54.792512+00	26	Roofing Contactors	2	Changed icon.	33	2
294	2019-10-23 07:08:07.307701+00	21	Tile Roof	2	Changed icon.	33	2
252	2019-10-23 06:18:38.517314+00	1	Home page	2	Changed sort_order for attached block "estimate (Estimate block) → main.mainpageconfig (#1)". Changed sort_order for attached block "advantages (Advantages block) → main.mainpageconfig (#1)". Changed sort_order for attached block "members (Members block) → main.mainpageconfig (#1)". Changed sort_order for attached block "recovery (Recovery block) → main.mainpageconfig (#1)". Changed sort_order for attached block "testimonials (Testimonials block) → main.mainpageconfig (#1)". Changed sort_order for attached block "insurance (Insurance block) → main.mainpageconfig (#1)". Changed sort_order for attached block "licenses (Licenses block) → main.mainpageconfig (#1)". Changed sort_order for attached block "Contact (Contact block) → main.mainpageconfig (#1)". Changed sort_order for attached block "services (Services block) → main.mainpageconfig (#1)". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object".	25	2
253	2019-10-23 06:18:48.731827+00	1	Home page	2	Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object".	25	2
254	2019-10-23 06:20:43.995194+00	1	Services	2	Added attached block "services (Services block) → services.servicesconfig (#1)". Changed sort_order for attached block "estimate (Estimate block) → services.servicesconfig (#1)". Changed sort_order for attached block "testimonials (Testimonials block) → services.servicesconfig (#1)". Changed sort_order for attached block "insurance (Insurance block) → services.servicesconfig (#1)". Changed sort_order for attached block "Contact (Contact block) → services.servicesconfig (#1)".	32	2
255	2019-10-23 06:20:53.323098+00	1	Services	2	Changed sort_order for attached block "estimate (Estimate block) → services.servicesconfig (#1)". Changed sort_order for attached block "testimonials (Testimonials block) → services.servicesconfig (#1)". Changed sort_order for attached block "insurance (Insurance block) → services.servicesconfig (#1)". Changed sort_order for attached block "Contact (Contact block) → services.servicesconfig (#1)". Changed sort_order for attached block "services (Services block) → services.servicesconfig (#1)".	32	2
256	2019-10-23 06:28:03.566693+00	20	Asphalt Roofing	2	Changed header, description and icon.	33	2
257	2019-10-23 06:28:03.573497+00	17	SeoData for service(#20)	1		49	2
258	2019-10-23 06:28:24.886912+00	20	Asphalt Roofing	2	Changed icon. Added attached block "services (Services block) → services.service (#20)". Added attached block "estimate (Estimate block) → services.service (#20)". Added attached block "testimonials (Testimonials block) → services.service (#20)". Added attached block "Contact (Contact block) → services.service (#20)".	33	2
259	2019-10-23 06:29:09.007992+00	20	Asphalt Roofing	2	Changed icon and text.	33	2
260	2019-10-23 06:29:28.154912+00	20	Asphalt Roofing	2	Changed icon.	33	2
261	2019-10-23 06:30:08.353592+00	22	Metal Roofs	2	Changed sort_order.	33	2
262	2019-10-23 06:30:08.363687+00	21	Tile Roofs	2	Changed sort_order.	33	2
263	2019-10-23 06:30:08.375019+00	20	Asphalt Roofing	2	Changed sort_order.	33	2
264	2019-10-23 06:32:08.738218+00	20	Asphalt Roofing	2	Changed icon and text.	33	2
265	2019-10-23 06:38:51.358249+00	22	Metal Roofs	2	Changed background and icon.	33	2
266	2019-10-23 06:39:17.42075+00	21	Tile Roofs	2	Changed background and icon.	33	2
267	2019-10-23 06:42:38.074184+00	21	Tile Roof	2	Changed title, header, description, icon and text.	33	2
268	2019-10-23 06:44:39.608091+00	21	Tile Roof	2	Changed icon.	33	2
269	2019-10-23 06:44:39.614366+00	18	SeoData for service(#21)	1		49	2
270	2019-10-23 06:45:08.690065+00	21	Tile Roof	2	Changed icon. Added attached block "services (Services block) → services.service (#21)". Added attached block "estimate (Estimate block) → services.service (#21)". Added attached block "testimonials (Testimonials block) → services.service (#21)". Added attached block "Contact (Contact block) → services.service (#21)".	33	2
271	2019-10-23 06:47:03.742685+00	22	Metal Roofs	2	Changed sort_order.	33	2
272	2019-10-23 06:47:03.755357+00	21	Tile Roof	2	Changed sort_order.	33	2
273	2019-10-23 06:52:14.074097+00	1	Services	2	Changed text.	32	2
274	2019-10-23 06:56:22.362165+00	29	Roof Maintenance	2	Changed icon. Deleted attached block "services (Services block) → services.service (#29)".	33	2
275	2019-10-23 06:56:25.458557+00	29	Roof Maintenance	2	Changed icon. Changed sort_order for attached block "estimate (Estimate block) → services.service (#29)". Changed sort_order for attached block "testimonials (Testimonials block) → services.service (#29)". Changed sort_order for attached block "Contact (Contact block) → services.service (#29)".	33	2
276	2019-10-23 06:56:53.069349+00	27	Roof Replacement	2	Changed icon. Deleted attached block "services (Services block) → services.service (#27)".	33	2
277	2019-10-23 06:56:55.499794+00	27	Roof Replacement	2	Changed icon. Changed sort_order for attached block "estimate (Estimate block) → services.service (#27)". Changed sort_order for attached block "testimonials (Testimonials block) → services.service (#27)". Changed sort_order for attached block "Contact (Contact block) → services.service (#27)".	33	2
278	2019-10-23 06:57:13.796204+00	28	Roof Repair	2	Changed icon. Deleted attached block "services (Services block) → services.service (#28)".	33	2
279	2019-10-23 06:57:15.925609+00	28	Roof Repair	2	Changed icon. Changed sort_order for attached block "estimate (Estimate block) → services.service (#28)". Changed sort_order for attached block "testimonials (Testimonials block) → services.service (#28)". Changed sort_order for attached block "Contact (Contact block) → services.service (#28)".	33	2
280	2019-10-23 06:57:41.59196+00	20	Asphalt Roofing	2	Changed icon. Deleted attached block "services (Services block) → services.service (#20)".	33	2
281	2019-10-23 06:57:44.431589+00	20	Asphalt Roofing	2	Changed icon. Changed sort_order for attached block "estimate (Estimate block) → services.service (#20)". Changed sort_order for attached block "testimonials (Testimonials block) → services.service (#20)". Changed sort_order for attached block "Contact (Contact block) → services.service (#20)".	33	2
282	2019-10-23 06:57:46.222783+00	20	Asphalt Roofing	2	Changed icon.	33	2
283	2019-10-23 06:58:15.668543+00	21	Tile Roof	2	Changed icon. Deleted attached block "services (Services block) → services.service (#21)".	33	2
284	2019-10-23 06:58:17.776764+00	21	Tile Roof	2	Changed icon. Changed sort_order for attached block "estimate (Estimate block) → services.service (#21)". Changed sort_order for attached block "testimonials (Testimonials block) → services.service (#21)". Changed sort_order for attached block "Contact (Contact block) → services.service (#21)".	33	2
285	2019-10-23 06:59:21.540499+00	21	Tile Roof	2	Changed icon and text.	33	2
286	2019-10-23 07:00:33.311731+00	21	Tile Roof	2	Changed icon and text.	33	2
295	2019-10-23 07:08:09.978423+00	21	Tile Roof	2	Changed icon.	33	2
296	2019-10-23 07:09:07.813852+00	21	Tile Roof	2	Changed icon and text.	33	2
297	2019-10-23 07:09:49.89297+00	21	Tile Roof	2	Changed icon and text.	33	2
298	2019-10-23 07:09:52.345015+00	21	Tile Roof	2	Changed icon.	33	2
299	2019-10-23 09:45:01.644235+00	26	Roofing Contactors	2	Changed sort_order.	33	2
300	2019-10-23 09:45:01.656089+00	29	Roof Maintenance	2	Changed sort_order.	33	2
301	2019-10-23 09:45:01.666828+00	27	Roof Replacement	2	Changed sort_order.	33	2
302	2019-10-23 09:45:01.677855+00	16	Emergency roof repair	2	Changed sort_order.	33	2
303	2019-10-23 09:45:01.688676+00	28	Roof Repair	2	Changed sort_order.	33	2
304	2019-10-23 09:45:01.697748+00	1	Residential Roofing	2	Changed sort_order.	33	2
305	2019-10-23 09:45:01.711431+00	20	Asphalt Roofing	2	Changed sort_order.	33	2
306	2019-10-23 09:45:01.725022+00	21	Tile Roof	2	Changed sort_order.	33	2
307	2019-10-23 09:45:01.736651+00	22	Metal Roofs	2	Changed sort_order.	33	2
308	2019-10-23 09:45:07.129049+00	1	Residential Roofing	2	Changed sort_order.	33	2
309	2019-10-23 09:45:07.141797+00	20	Asphalt Roofing	2	Changed sort_order.	33	2
310	2019-10-23 09:45:07.15402+00	21	Tile Roof	2	Changed sort_order.	33	2
311	2019-10-23 09:45:07.1651+00	22	Metal Roofs	2	Changed sort_order.	33	2
312	2019-10-23 09:45:07.174089+00	26	Roofing Contactors	2	Changed sort_order.	33	2
313	2019-10-23 09:45:07.187262+00	29	Roof Maintenance	2	Changed sort_order.	33	2
314	2019-10-23 09:45:07.19983+00	27	Roof Replacement	2	Changed sort_order.	33	2
315	2019-10-23 09:45:07.213585+00	16	Emergency roof repair	2	Changed sort_order.	33	2
316	2019-10-23 09:45:07.224555+00	28	Roof Repair	2	Changed sort_order.	33	2
317	2019-10-23 09:45:15.289219+00	6	Painting	2	Changed icon.	33	2
318	2019-10-23 09:45:22.834437+00	29	Roof Maintenance	2	Changed icon.	33	2
319	2019-10-28 04:47:13.431734+00	1	Home page	2	Changed description. Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object". Changed icon for Advantage "Advantage object".	25	2
320	2019-10-28 04:53:00.995429+00	1	Element Exteriors in Denver | About Us	2	Changed title.	8	2
321	2019-10-28 04:53:09.267146+00	1	About Us	2	Changed title.	8	2
322	2019-10-28 05:01:57.227456+00	26	Roofing Contactors	2	Changed icon and text.	33	2
323	2019-10-28 05:02:40.762786+00	26	Roofing Contactors	2	Changed icon and text.	33	2
324	2019-10-28 05:05:46.809029+00	26	Roofing Contactors	2	Changed icon and text.	33	2
325	2019-10-28 05:08:45.938265+00	26	Roofing Contactors	2	Changed icon and text.	33	2
326	2019-10-28 05:09:28.220392+00	26	Roofing Contactors	2	Changed icon.	33	2
327	2019-10-28 05:16:04.148671+00	16	Emergency roof repair	2	Changed icon and text.	33	2
328	2019-10-28 05:21:10.611952+00	16	Emergency roof repair	2	Changed icon and text.	33	2
329	2019-10-28 05:23:32.678123+00	6	Painting	2	Changed icon and text.	33	2
330	2019-10-28 05:30:15.402664+00	4	New Roof Construction	2	Changed icon and text. Changed sort_order for attached block "estimate (Estimate block) → services.service (#4)". Changed sort_order for attached block "testimonials (Testimonials block) → services.service (#4)". Changed sort_order for attached block "Contact (Contact block) → services.service (#4)".	33	2
331	2019-10-28 05:36:50.617551+00	4	New Roof Construction	2	Changed icon and text.	33	2
332	2019-10-28 05:37:54.396651+00	4	New Roof Construction	2	Changed icon.	33	2
333	2019-10-28 05:59:36.493864+00	20	Asphalt Roofing	2	Changed icon and text.	33	2
334	2019-10-28 06:09:48.019789+00	21	Tile Roof	2	Changed icon and text.	33	2
335	2019-10-28 06:10:31.540274+00	21	Tile Roof	2	Changed icon and text.	33	2
336	2019-10-28 06:10:54.297041+00	21	Tile Roof	2	Changed icon and text.	33	2
337	2019-10-28 06:17:42.071398+00	29	Roof Maintenance	2	Changed icon and text.	33	2
338	2019-10-28 06:20:38.434459+00	29	Roof Maintenance	2	Changed icon and text.	33	2
339	2019-10-28 06:20:50.742852+00	29	Roof Maintenance	2	Changed icon.	33	2
340	2019-10-28 06:23:34.671647+00	27	Roof Replacement	2	Changed icon and text.	33	2
341	2019-10-28 06:23:41.828836+00	27	Roof Replacement	2	Changed icon.	33	2
342	2019-10-28 06:27:00.813804+00	27	Roof Replacement	2	Changed icon and text.	33	2
343	2019-10-28 06:27:52.966318+00	27	Roof Replacement	2	Changed icon.	33	2
344	2019-10-28 06:27:52.974164+00	14	SeoData for service(#27)	2	Changed description.	49	2
345	2019-10-28 06:30:28.735661+00	28	Roof Repair	2	Changed icon and text.	33	2
346	2019-10-28 09:53:50.417726+00	1	Services	2	Changed text.	32	2
347	2019-10-28 09:54:06.811068+00	1	Services	2	No fields changed.	32	2
348	2019-10-28 10:00:27.656806+00	1	Residential Roofing	2	Changed icon and text.	33	2
349	2019-10-28 10:01:06.543208+00	1	Residential Roofing	2	Changed icon.	33	2
350	2019-10-28 10:03:27.0724+00	2	Commercial Roofing	2	Changed icon and text.	33	2
351	2019-10-28 10:07:42.250228+00	7	Gutters	2	Changed icon and text.	33	2
352	2019-10-28 10:10:15.664568+00	6	Painting	2	Changed icon and text.	33	2
353	2019-10-28 10:10:20.097812+00	6	Painting	2	Changed icon.	33	2
354	2019-10-28 10:10:50.344573+00	1	Services	2	Changed text.	32	2
355	2019-10-28 10:16:22.742836+00	1	Services	2	No fields changed.	32	2
356	2019-10-28 13:17:35.069214+00	1	Services	2	No fields changed.	32	2
357	2019-10-28 13:17:35.076702+00	4	SeoData for Settings(#1)	2	Changed title.	49	2
358	2019-11-19 05:58:38.902422+00	30	Roof Installation	1		33	2
359	2019-11-19 05:59:09.815594+00	30	Roof Installation	2	Changed visible and icon.	33	2
360	2019-11-19 06:00:06.406071+00	None	Roof Installation	3		33	2
361	2019-11-22 07:03:55.494562+00	22	Metal Roof	2	Changed title, header, description, icon and text.	33	2
362	2019-11-22 07:04:21.959252+00	22	Metal Roof	2	Changed icon and text.	33	2
363	2019-11-22 07:06:29.669394+00	22	Metal Roof	2	Changed icon.	33	2
364	2019-11-22 07:06:29.67979+00	19	SeoData for service(#22)	1		49	2
365	2019-11-22 07:06:45.070833+00	22	Metal Roof	2	Changed icon.	33	2
366	2019-11-22 07:08:19.722305+00	22	Metal Roof	2	Changed icon and text.	33	2
367	2019-11-22 07:08:35.602914+00	22	Metal Roof	2	Changed icon and text.	33	2
368	2019-11-22 07:12:15.783623+00	22	Metal Roof	2	Changed icon and text.	33	2
369	2019-11-22 07:21:46.946954+00	31	Exterior Painting	1		33	2
370	2019-11-22 07:21:46.951549+00	20	SeoData for service(#31)	1		49	2
371	2019-11-22 07:22:41.546472+00	31	Exterior Painting	2	Changed icon. Added attached block "estimate (Estimate block) → services.service (#31)". Added attached block "testimonials (Testimonials block) → services.service (#31)". Added attached block "Contact (Contact block) → services.service (#31)".	33	2
372	2019-11-22 07:22:45.711039+00	31	Exterior Painting	2	Changed icon.	33	2
373	2019-11-22 07:23:52.170107+00	22	Metal Roof	2	Changed icon. Added attached block "estimate (Estimate block) → services.service (#22)". Added attached block "testimonials (Testimonials block) → services.service (#22)". Added attached block "Contact (Contact block) → services.service (#22)".	33	2
374	2019-11-22 07:24:16.370011+00	22	Metal Roof	2	Changed icon.	33	2
375	2019-11-22 07:26:20.240101+00	32	Interior Painting	1		33	2
376	2019-11-22 07:26:53.017253+00	32	Interior Painting	2	Changed icon. Added attached block "estimate (Estimate block) → services.service (#32)". Added attached block "testimonials (Testimonials block) → services.service (#32)". Added attached block "Contact (Contact block) → services.service (#32)".	33	2
377	2019-11-22 07:26:58.870387+00	32	Interior Painting	2	Changed icon.	33	2
378	2019-11-22 07:28:44.412336+00	32	Interior Painting	2	Changed icon.	33	2
379	2019-11-22 07:28:44.418702+00	21	SeoData for service(#32)	1		49	2
380	2019-11-22 07:30:00.76929+00	32	Interior Painting	2	Changed icon and text.	33	2
381	2019-11-22 07:30:34.972371+00	32	Interior Painting	2	Changed icon and text.	33	2
382	2019-11-22 07:34:23.299581+00	25	EPDM Roofing	2	Changed title, header, description, icon and text.	33	2
383	2019-11-22 07:34:53.703248+00	25	EPDM Roofing	2	Changed icon. Added attached block "estimate (Estimate block) → services.service (#25)". Added attached block "testimonials (Testimonials block) → services.service (#25)". Added attached block "Contact (Contact block) → services.service (#25)".	33	2
384	2019-11-22 07:36:41.504912+00	25	EPDM Roofing	2	Changed icon.	33	2
385	2019-11-22 07:36:41.512307+00	22	SeoData for service(#25)	1		49	2
386	2019-11-22 07:36:46.432908+00	25	EPDM Roofing	2	Changed icon.	33	2
387	2019-11-22 07:38:19.066322+00	23	TPO roofing	2	Changed background and icon.	33	2
388	2019-11-22 07:38:43.252117+00	25	EPDM Roofing	2	Changed background and icon.	33	2
389	2019-11-22 07:41:03.708953+00	23	TPO Roofing	2	Changed title, header, description, visible, icon and text.	33	2
390	2019-11-22 07:41:45.635531+00	23	TPO Roofing	2	Changed icon and text.	33	2
391	2019-11-22 07:42:01.805284+00	23	TPO Roofing	2	Changed icon. Added attached block "estimate (Estimate block) → services.service (#23)". Added attached block "testimonials (Testimonials block) → services.service (#23)". Added attached block "Contact (Contact block) → services.service (#23)".	33	2
392	2019-11-22 07:43:16.203271+00	23	TPO Roofing	2	Changed icon.	33	2
393	2019-11-22 07:43:16.209793+00	23	SeoData for service(#23)	1		49	2
394	2019-11-22 12:08:50.134432+00	22	Metal Roof	2	Changed icon and text.	33	2
395	2019-11-25 11:35:11.833557+00	25	EPDM Roofing	2	Changed icon and text.	33	2
396	2019-11-25 11:35:52.888807+00	23	TPO Roofing	2	Changed icon and text.	33	2
397	2019-11-25 11:36:24.096524+00	31	Exterior Painting	2	Changed icon and text.	33	2
398	2019-11-25 11:36:58.399249+00	32	Interior Painting	2	Changed icon and text.	33	2
399	2019-12-06 06:50:20.361755+00	1	Our Work	2	Changed text. Changed sort_order for attached block "testimonials (Testimonials block) → work.workpageconfig (#1)". Changed sort_order for attached block "Contact (Contact block) → work.workpageconfig (#1)".	39	2
400	2019-12-06 06:50:24.350034+00	1	Our Work	2	No fields changed.	39	2
401	2019-12-06 06:51:44.51033+00	1	Our Work	2	No fields changed.	39	2
402	2019-12-06 06:51:44.520699+00	24	SeoData for Settings(#1)	1		49	2
403	2019-12-06 06:51:50.493094+00	1	Our Work	2	No fields changed.	39	2
404	2019-12-10 05:14:50.490876+00	33	Roof Installation	1		33	2
405	2019-12-10 05:14:50.497411+00	25	SeoData for service(#33)	1		49	2
406	2019-12-10 05:15:30.359224+00	33	Roof Installation	2	Changed icon.	33	2
407	2019-12-10 05:19:49.044921+00	34	Specialty Roof Types	1		33	2
408	2019-12-10 05:20:50.112347+00	34	Specialty Roof Types	2	Changed icon.	33	2
409	2019-12-10 05:20:50.120798+00	26	SeoData for service(#34)	1		49	2
410	2019-12-10 05:20:56.273518+00	34	Specialty Roof Types	2	Changed icon.	33	2
411	2019-12-10 08:07:51.259944+00	33	Roof Installation	2	Changed icon and text.	33	2
412	2019-12-10 08:08:30.192326+00	34	Specialty Roof Types	2	Changed icon and text.	33	2
413	2019-12-10 08:08:39.808943+00	34	Specialty Roof Types	2	Changed icon.	33	2
414	2019-12-18 10:21:12.288596+00	33	Roof Installation	2	Changed icon. Added attached block "estimate (Estimate block) → services.service (#33)". Added attached block "testimonials (Testimonials block) → services.service (#33)". Added attached block "Contact (Contact block) → services.service (#33)".	33	2
415	2019-12-18 10:21:47.213819+00	34	Specialty Roof Types	2	Changed icon. Added attached block "estimate (Estimate block) → services.service (#34)". Added attached block "testimonials (Testimonials block) → services.service (#34)". Added attached block "Contact (Contact block) → services.service (#34)".	33	2
416	2019-12-30 06:26:48.730401+00	35	Roof Inspection	1		33	2
417	2019-12-30 06:27:49.915539+00	35	Roof Inspection	2	Changed icon.	33	2
418	2019-12-30 06:27:49.927726+00	27	SeoData for service(#35)	1		49	2
419	2019-12-30 06:28:09.263615+00	35	Roof Inspection	2	Changed icon.	33	2
420	2019-12-30 06:30:20.968119+00	35	Roof Inspection	2	Changed icon and text.	33	2
421	2019-12-30 06:33:57.271822+00	36	Slate Roofing	1		33	2
422	2019-12-30 06:34:31.154492+00	36	Slate Roofing	2	Changed icon and text.	33	2
423	2019-12-30 06:37:18.49626+00	37	Cedar Shake Roof	1		33	2
424	2019-12-30 06:38:17.60358+00	37	Cedar Shake Roof	2	Changed icon.	33	2
425	2019-12-30 06:38:17.614129+00	28	SeoData for service(#37)	1		49	2
426	2019-12-30 06:38:59.625235+00	37	Cedar Shake Roof	2	Changed icon. Added attached block "estimate (Estimate block) → services.service (#37)". Added attached block "testimonials (Testimonials block) → services.service (#37)". Added attached block "Contact (Contact block) → services.service (#37)".	33	2
427	2019-12-30 06:40:09.801456+00	36	Slate Roofing	2	Changed icon.	33	2
428	2019-12-30 06:40:09.810511+00	29	SeoData for service(#36)	1		49	2
429	2019-12-30 06:40:27.005446+00	36	Slate Roofing	2	Changed icon. Added attached block "estimate (Estimate block) → services.service (#36)". Added attached block "testimonials (Testimonials block) → services.service (#36)". Added attached block "Contact (Contact block) → services.service (#36)".	33	2
430	2019-12-30 08:27:44.171437+00	35	Roof Inspection	2	Changed icon and text.	33	2
431	2019-12-30 08:28:24.120686+00	36	Slate Roofing	2	Changed icon and text.	33	2
432	2019-12-30 08:28:49.922683+00	37	Cedar Shake Roof	2	Changed icon and text.	33	2
433	2020-01-10 05:59:45.762205+00	24	PVC roofing	2	Changed icon.	33	2
434	2020-01-10 05:59:45.769843+00	30	SeoData for service(#24)	1		49	2
435	2020-01-10 06:00:14.264963+00	24	PVC roofing	2	Changed icon. Added attached block "estimate (Estimate block) → services.service (#24)". Added attached block "testimonials (Testimonials block) → services.service (#24)". Added attached block "Contact (Contact block) → services.service (#24)".	33	2
436	2020-01-10 06:03:22.529797+00	24	PVC roofing	2	Changed header, description, visible, icon and text.	33	2
437	2020-01-10 06:07:37.180142+00	24	PVC roofing	2	Changed icon and text.	33	2
438	2020-01-10 06:09:49.857328+00	24	PVC roofing	2	Changed icon and text.	33	2
439	2020-01-10 06:10:37.900122+00	24	PVC roofing	2	Changed icon and text.	33	2
440	2020-01-10 06:14:26.016015+00	38	Modified Bitumen Roof	1		33	2
441	2020-01-10 06:18:25.220283+00	38	Modified Bitumen Roof	2	Changed icon.	33	2
442	2020-01-10 06:18:25.23123+00	31	SeoData for service(#38)	1		49	2
443	2020-01-10 06:21:15.866982+00	38	Modified Bitumen Roof	2	Changed icon and text.	33	2
444	2020-01-10 06:22:54.791402+00	38	Modified Bitumen Roof	2	Changed icon and text.	33	2
445	2020-01-27 06:11:08.407679+00	3	HTML Tag	1		51	2
446	2020-05-01 17:05:51.894332+00	1	COVID-19 Response	2	Changed header, text, visible, url, text_for_link, name, status, number and email.	59	1
447	2020-05-01 20:25:13.658103+00	1	COVID-19 Response	2	Changed visible.	59	1
448	2020-05-01 22:39:08.322977+00	1	Settings	2	Changed google_apikey.	53	1
449	2020-05-01 22:53:47.272627+00	1	Settings	2	No fields changed.	53	1
450	2020-05-02 07:04:00.284886+00	1	COVID-19 Response	2	Changed url.	59	1
451	2023-03-22 11:48:20.749071+00	1	COVID-19 Response	2	Changed visible.	59	1
452	2024-01-23 18:30:22.42321+00	1	COVID-19 Response	2	Changed date_start, date_end and visible.	59	1
453	2024-01-23 18:31:22.285177+00	1	COVID-19 Response	2	Changed visible.	59	1
454	2024-01-23 18:31:24.323636+00	1	COVID-19 Response	2	No fields changed.	59	1
\.


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 454, true);


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
1	admin	logentry
2	auth	permission
3	auth	group
4	contenttypes	contenttype
5	sessions	session
6	sites	site
7	django_cron	cronjoblog
8	about	aboutpageconfig
9	about	aboutblock
10	config	config
11	contacts	contactsconfig
12	contacts	address
13	contacts	phonenumber
14	contacts	openinghours
15	contacts	notificationreceiver
16	contacts	message
17	contacts	contactblock
18	contacts	estimateblock
19	insurance	insurancepageconfig
20	insurance	insuranceblock
21	insurance	insurancestep
22	licenses	licensespageconfig
23	licenses	license
24	licenses	licensesblock
25	main	mainpageconfig
26	main	advantage
27	main	member
28	main	advantagesblock
29	main	membersblock
30	main	recoveryblock
31	users	customuser
32	services	servicesconfig
33	services	service
34	services	servicesblock
35	testimonials	testimonial
36	testimonials	testimonialsblock
37	work	galleryimageservice
38	work	galleryservice
39	work	workpageconfig
40	attachable_blocks	attachableblock
41	attachable_blocks	attachablereference
42	backups	backup
43	ckeditor	pagephoto
44	ckeditor	pagefile
45	ckeditor	simplephoto
46	gallery	galleryitembase
47	google_maps	mapandaddress
48	seo	seoconfig
49	seo	seodata
50	seo	redirect
51	seo	counter
52	seo	robots
53	social_networks	socialconfig
54	social_networks	sociallinks
55	social_networks	feedpost
56	rating	ratingvote
57	main	stepsblock
58	main	step
59	offers	offer
\.


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 59, true);


--
-- Data for Name: django_cron_cronjoblog; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.django_cron_cronjoblog (id, code, start_time, end_time, is_success, message, ran_at_time) FROM stdin;
\.


--
-- Name: django_cron_cronjoblog_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.django_cron_cronjoblog_id_seq', 1, false);


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
1	contenttypes	0001_initial	2019-04-26 07:16:30.659464+00
2	contenttypes	0002_remove_content_type_name	2019-04-26 07:16:30.674743+00
3	attachable_blocks	0001_initial	2019-04-26 07:16:30.716453+00
4	attachable_blocks	0002_auto_20170607_0345	2019-04-26 07:16:30.769541+00
5	attachable_blocks	0003_auto_20170905_0746	2019-04-26 07:16:30.778763+00
6	attachable_blocks	0004_auto_20170930_0822	2019-04-26 07:16:30.803127+00
7	attachable_blocks	0005_auto_20190213_0459	2019-04-26 07:16:30.850413+00
8	about	0001_initial	2019-04-26 07:16:30.876711+00
9	about	0002_remove_aboutpageconfig_btn_text	2019-04-26 07:16:30.884486+00
10	about	0003_auto_20190312_0216	2019-04-26 07:16:30.890812+00
11	auth	0001_initial	2019-04-26 07:16:30.956672+00
12	auth	0002_alter_permission_name_max_length	2019-04-26 07:16:30.973179+00
13	auth	0003_alter_user_email_max_length	2019-04-26 07:16:30.990552+00
14	auth	0004_alter_user_username_opts	2019-04-26 07:16:31.007884+00
15	auth	0005_alter_user_last_login_null	2019-04-26 07:16:31.025028+00
16	auth	0006_require_contenttypes_0002	2019-04-26 07:16:31.027405+00
17	users	0001_initial	2019-04-26 07:16:31.072731+00
18	admin	0001_initial	2019-04-26 07:16:31.108054+00
19	backups	0001_initial	2019-04-26 07:16:31.11459+00
20	ckeditor	0001_initial	2019-04-26 07:16:31.145691+00
21	ckeditor	0002_auto_20160916_0501	2019-04-26 07:16:31.153464+00
22	ckeditor	0003_auto_20170905_0746	2019-04-26 07:16:31.161563+00
23	config	0001_initial	2019-04-26 07:16:31.172374+00
24	contacts	0001_initial	2019-04-26 07:16:31.256744+00
25	contacts	0002_auto_20170427_1121	2019-04-26 07:16:31.266542+00
26	contacts	0003_openinghours	2019-04-26 07:16:31.284734+00
27	contacts	0004_contactblock_description	2019-04-26 07:16:31.320759+00
28	contacts	0005_auto_20190220_0141	2019-04-26 07:16:31.437931+00
29	contacts	0006_contactsconfig_title	2019-04-26 07:16:31.455952+00
30	contacts	0007_auto_20190221_0613	2019-04-26 07:16:31.55356+00
31	contacts	0008_contactsconfig_form_description	2019-04-26 07:16:31.570196+00
32	contacts	0009_estimateblock	2019-04-26 07:16:31.603205+00
33	contacts	0010_auto_20190227_0216	2019-04-26 07:16:31.664808+00
34	contacts	0011_address_url	2019-04-26 07:16:31.683517+00
35	contacts	0012_auto_20190301_0046	2019-04-26 07:16:31.752634+00
36	contacts	0013_auto_20190301_0052	2019-04-26 07:16:31.8068+00
37	contacts	0014_auto_20190423_0102	2019-04-26 07:16:31.833779+00
38	django_cron	0001_initial	2019-04-26 07:16:31.865745+00
39	django_cron	0002_remove_max_length_from_CronJobLog_message	2019-04-26 07:16:31.874805+00
40	gallery	0001_initial	2019-04-26 07:16:31.948743+00
41	gallery	0002_auto_20170330_1316	2019-04-26 07:16:32.000133+00
42	gallery	0003_auto_20190213_0459	2019-04-26 07:16:32.048946+00
43	google_maps	0001_initial	2019-04-26 07:16:32.064765+00
44	insurance	0001_initial	2019-04-26 07:16:32.119235+00
45	insurance	0002_insuranceblock	2019-04-26 07:16:32.161765+00
46	insurance	0003_auto_20190221_0410	2019-04-26 07:16:32.242005+00
47	insurance	0004_auto_20190221_0431	2019-04-26 07:16:32.288561+00
48	insurance	0005_auto_20190312_0216	2019-04-26 07:16:32.301063+00
49	licenses	0001_initial	2019-04-26 07:16:32.51789+00
50	licenses	0002_auto_20190312_0216	2019-04-26 07:16:32.528801+00
51	main	0001_initial	2019-04-26 07:16:32.541925+00
52	main	0002_advantages_advantagesblock	2019-04-26 07:16:32.601853+00
53	main	0003_members_membersblock	2019-04-26 07:16:32.665259+00
54	main	0004_auto_20190215_0734	2019-04-26 07:16:32.707644+00
55	main	0005_auto_20190218_0129	2019-04-26 07:16:32.785971+00
56	main	0006_license_licensesblock	2019-04-26 07:16:32.85608+00
57	main	0007_auto_20190218_0327	2019-04-26 07:16:33.006973+00
58	main	0008_auto_20190219_0443	2019-04-26 07:16:33.117243+00
59	main	0009_recoveryblock	2019-04-26 07:16:33.163472+00
60	main	0010_auto_20190424_0127	2019-04-26 07:16:33.18107+00
61	rating	0001_initial	2019-04-26 07:16:33.203185+00
62	rating	0002_auto_20161203_1045	2019-04-26 07:16:33.215238+00
63	seo	0001_initial	2019-04-26 07:16:33.375625+00
64	seo	0002_redirect_last_usage	2019-04-26 07:16:33.392007+00
65	seo	0003_auto_20160916_0233	2019-04-26 07:16:33.483847+00
66	seo	0004_auto_20161109_0306	2019-04-26 07:16:33.661509+00
67	seo	0005_auto_20170203_1458	2019-04-26 07:16:33.678166+00
68	seo	0006_auto_20170330_1316	2019-04-26 07:16:33.725512+00
69	seo	0007_auto_20170413_0355	2019-04-26 07:16:33.764296+00
70	seo	0008_auto_20181121_0817	2019-04-26 07:16:33.822444+00
71	services	0001_initial	2019-04-26 07:16:33.860959+00
72	services	0002_auto_20190214_0815	2019-04-26 07:16:34.255818+00
73	services	0003_auto_20190215_0217	2019-04-26 07:16:34.285186+00
74	services	0004_auto_20190215_0314	2019-04-26 07:16:34.304556+00
75	services	0005_auto_20190215_0557	2019-04-26 07:16:34.318775+00
76	services	0006_auto_20190218_0651	2019-04-26 07:16:34.332492+00
77	services	0007_auto_20190312_0216	2019-04-26 07:16:34.348527+00
78	sessions	0001_initial	2019-04-26 07:16:34.36694+00
79	sites	0001_initial	2019-04-26 07:16:34.381361+00
80	social_networks	0001_initial	2019-04-26 07:16:34.509562+00
81	social_networks	0002_sociallinks_social_instagram	2019-04-26 07:16:34.527733+00
82	social_networks	0003_socialconfig	2019-04-26 07:16:34.546276+00
83	social_networks	0004_auto_20170120_0920	2019-04-26 07:16:34.571557+00
84	social_networks	0005_auto_20170120_0957	2019-04-26 07:16:34.585268+00
85	social_networks	0006_auto_20170120_1013	2019-04-26 07:16:34.642349+00
86	social_networks	0007_auto_20170121_0848	2019-04-26 07:16:34.677234+00
87	social_networks	0008_auto_20190228_0543	2019-04-26 07:16:34.725173+00
88	testimonials	0001_initial	2019-04-26 07:16:34.797981+00
89	testimonials	0002_auto_20190312_0216	2019-04-26 07:16:34.810381+00
90	work	0001_initial	2019-04-26 07:16:34.901847+00
91	work	0002_auto_20190312_0216	2019-04-26 07:16:35.085635+00
92	licenses	0003_license_updated	2019-05-07 03:48:55.327662+00
93	main	0011_auto_20190516_0039	2019-06-20 11:27:51.181633+00
94	main	0012_auto_20190610_0009	2019-06-20 11:27:51.259862+00
95	offers	0001_initial	2020-05-01 14:51:41.805746+00
96	offers	0002_auto_20200428_1742	2020-05-01 14:51:41.822721+00
97	offers	0003_auto_20200429_0415	2020-05-01 14:51:41.874767+00
\.


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 97, true);


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
0o5drusurq077h6qfhftkxsezoybjgta	YzQwNzQxYzIyNzc2YjNkZDBkYmUxYTdjMDU2ZDAzYTM2YjU5M2YxZDp7Il9hdXRoX3VzZXJfaGFzaCI6IjcxYjZiZDI2ZjJkYmVkMjYxYTZmNjkxYzI3ZGY4ZWYxYzYwNjAxMDgiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxIn0=	2019-04-10 06:15:01.911+00
25fywky6mg81van12tz1y0l12nzl2l33	OGU3NGZlZTE4M2VlYWNlZDc4ZTJkM2ViYzcxOTk2NzY4OTljZTQ0ODp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9oYXNoIjoiZDRkMzU0M2IyOTFlZmJjMjJhMmM2Y2Q3NGMxOTJjYjJhMzNhY2YwMCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=	2019-03-20 06:09:26.238+00
264dh0rm0vgontfdw3fhr0fyxt3ah3ho	MTkwYzczOTkyOTUwOTQyNDk2ZDYwMmYyODE3ZDZhODliZGY1ZGVkNDp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9oYXNoIjoiNzFiNmJkMjZmMmRiZWQyNjFhNmY2OTFjMjdkZjhlZjFjNjA2MDEwOCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=	2019-05-26 06:57:45.643+00
2iz1cvsq9kmkbj1n28c3zo76fuatiaun	YzQwNzQxYzIyNzc2YjNkZDBkYmUxYTdjMDU2ZDAzYTM2YjU5M2YxZDp7Il9hdXRoX3VzZXJfaGFzaCI6IjcxYjZiZDI2ZjJkYmVkMjYxYTZmNjkxYzI3ZGY4ZWYxYzYwNjAxMDgiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxIn0=	2019-05-05 05:59:41.082+00
3ki13j03vdxmc7bzimpl4vrqp1f0xc9e	MjdhMTA4OGI5MWFlOTg3NjNkOWRmNjdiY2EzNDM1MDc5N2Q3ZDc0OTp7Il9hdXRoX3VzZXJfaGFzaCI6ImQ0ZDM1NDNiMjkxZWZiYzIyYTJjNmNkNzRjMTkyY2IyYTMzYWNmMDAiLCJfYXV0aF91c2VyX2lkIjoiMSIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=	2019-03-22 06:26:48.352+00
5stevsr9fkvaa9xct9oaqq2jer94wr8v	YzQwNzQxYzIyNzc2YjNkZDBkYmUxYTdjMDU2ZDAzYTM2YjU5M2YxZDp7Il9hdXRoX3VzZXJfaGFzaCI6IjcxYjZiZDI2ZjJkYmVkMjYxYTZmNjkxYzI3ZGY4ZWYxYzYwNjAxMDgiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxIn0=	2019-04-07 21:23:23.946+00
aiz5345m03u20hesievhdjygmnnb668z	YzQwNzQxYzIyNzc2YjNkZDBkYmUxYTdjMDU2ZDAzYTM2YjU5M2YxZDp7Il9hdXRoX3VzZXJfaGFzaCI6IjcxYjZiZDI2ZjJkYmVkMjYxYTZmNjkxYzI3ZGY4ZWYxYzYwNjAxMDgiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxIn0=	2019-04-06 10:00:35.799+00
bj93o5iy5leiyqj2dhc5431ljvbdowe7	ZGJhYjIwMDk0ZmZiZjVjYzkwY2Y5NDg2ZWY1ZmQ3Yjg5OGU3MTc5Mjp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiZDRkMzU0M2IyOTFlZmJjMjJhMmM2Y2Q3NGMxOTJjYjJhMzNhY2YwMCIsIl9hdXRoX3VzZXJfaWQiOiIxIn0=	2019-03-15 12:28:19.667+00
c2x6edmdi5yebcv7ksgmbdoexlgjoiig	MTkwYzczOTkyOTUwOTQyNDk2ZDYwMmYyODE3ZDZhODliZGY1ZGVkNDp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9oYXNoIjoiNzFiNmJkMjZmMmRiZWQyNjFhNmY2OTFjMjdkZjhlZjFjNjA2MDEwOCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=	2019-05-23 20:33:53.905+00
jovnrpvpcc1fzptaboavx7eppa5v6fbx	MTkwYzczOTkyOTUwOTQyNDk2ZDYwMmYyODE3ZDZhODliZGY1ZGVkNDp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9oYXNoIjoiNzFiNmJkMjZmMmRiZWQyNjFhNmY2OTFjMjdkZjhlZjFjNjA2MDEwOCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=	2019-03-30 12:17:23.477+00
jvuvplil8a4emsom6ceqvbgfvthesubc	YzQwNzQxYzIyNzc2YjNkZDBkYmUxYTdjMDU2ZDAzYTM2YjU5M2YxZDp7Il9hdXRoX3VzZXJfaGFzaCI6IjcxYjZiZDI2ZjJkYmVkMjYxYTZmNjkxYzI3ZGY4ZWYxYzYwNjAxMDgiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxIn0=	2019-05-04 18:04:25.898+00
mh32svgkbjnmui0ryzfov7p0tbmqop8s	YzQwNzQxYzIyNzc2YjNkZDBkYmUxYTdjMDU2ZDAzYTM2YjU5M2YxZDp7Il9hdXRoX3VzZXJfaGFzaCI6IjcxYjZiZDI2ZjJkYmVkMjYxYTZmNjkxYzI3ZGY4ZWYxYzYwNjAxMDgiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxIn0=	2019-04-06 12:10:35.389+00
p1hz3irzfhmpn3ydmv1xjonk8cqgs4qt	NWZlMWI3MDU0MGIzMzg1NTdlZTM4YTZiNzYzMWM3MjBkMDVkNmEzZTp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI3MWI2YmQyNmYyZGJlZDI2MWE2ZjY5MWMyN2RmOGVmMWM2MDYwMTA4In0=	2019-04-14 07:00:56.749+00
qtc9o214equp8k5a66adkdgxulwaqv4v	YzQwNzQxYzIyNzc2YjNkZDBkYmUxYTdjMDU2ZDAzYTM2YjU5M2YxZDp7Il9hdXRoX3VzZXJfaGFzaCI6IjcxYjZiZDI2ZjJkYmVkMjYxYTZmNjkxYzI3ZGY4ZWYxYzYwNjAxMDgiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxIn0=	2019-05-05 06:26:32.179+00
qxxcgv0jtd282cuhe7vkfml5mt6t7lqo	MjdhMTA4OGI5MWFlOTg3NjNkOWRmNjdiY2EzNDM1MDc5N2Q3ZDc0OTp7Il9hdXRoX3VzZXJfaGFzaCI6ImQ0ZDM1NDNiMjkxZWZiYzIyYTJjNmNkNzRjMTkyY2IyYTMzYWNmMDAiLCJfYXV0aF91c2VyX2lkIjoiMSIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=	2019-03-21 11:40:28.345+00
rrozpqu6ov1h1ky2jer6ivitl1ap549i	OGU3NGZlZTE4M2VlYWNlZDc4ZTJkM2ViYzcxOTk2NzY4OTljZTQ0ODp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9oYXNoIjoiZDRkMzU0M2IyOTFlZmJjMjJhMmM2Y2Q3NGMxOTJjYjJhMzNhY2YwMCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=	2019-03-23 05:39:35.098+00
sdn0r8ue3xtyp466rxl76x0w0dxh7es1	YzczZDk1ZmI1MjBlZmQ0MDM5ODQzYjYzZTFiNWRjMGZlYjBkMzhkYTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiNzFiNmJkMjZmMmRiZWQyNjFhNmY2OTFjMjdkZjhlZjFjNjA2MDEwOCIsIl9hdXRoX3VzZXJfaWQiOiIxIn0=	2019-05-01 13:28:50.376+00
u29ivfww27sl12m9m9zhyyehp30tk2if	MTkwYzczOTkyOTUwOTQyNDk2ZDYwMmYyODE3ZDZhODliZGY1ZGVkNDp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9oYXNoIjoiNzFiNmJkMjZmMmRiZWQyNjFhNmY2OTFjMjdkZjhlZjFjNjA2MDEwOCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=	2019-05-23 08:20:17.154+00
w5q14obz2xsvf2soontsylnsg0v8km7a	MTkwYzczOTkyOTUwOTQyNDk2ZDYwMmYyODE3ZDZhODliZGY1ZGVkNDp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9oYXNoIjoiNzFiNmJkMjZmMmRiZWQyNjFhNmY2OTFjMjdkZjhlZjFjNjA2MDEwOCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=	2019-05-23 11:15:43.832+00
w9wupm9t7bzomlpnyeuc2cagcsm4c3zk	NWZlMWI3MDU0MGIzMzg1NTdlZTM4YTZiNzYzMWM3MjBkMDVkNmEzZTp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI3MWI2YmQyNmYyZGJlZDI2MWE2ZjY5MWMyN2RmOGVmMWM2MDYwMTA4In0=	2019-04-06 07:59:35.21+00
y9t5uqhrjocbey7zkxttog14nh2a4b7z	NjhkNDA2OTBlOGJjZjRkODNjYWMxYTNlMjg2YjVjZDllZmQxNjhkYzp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6IjEiLCJfYXV0aF91c2VyX2hhc2giOiI3MWI2YmQyNmYyZGJlZDI2MWE2ZjY5MWMyN2RmOGVmMWM2MDYwMTA4In0=	2019-04-03 08:14:06.952+00
zc0p3o4zvnp88sq3l68doby71xu2bbhe	YzQwNzQxYzIyNzc2YjNkZDBkYmUxYTdjMDU2ZDAzYTM2YjU5M2YxZDp7Il9hdXRoX3VzZXJfaGFzaCI6IjcxYjZiZDI2ZjJkYmVkMjYxYTZmNjkxYzI3ZGY4ZWYxYzYwNjAxMDgiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxIn0=	2019-05-05 07:05:40.755+00
a0z5sjk433q9uzmcyapd2b6a49up1ygo	OWUyZmJmYTRlNzgyODg4MGVjZmQ0ZmQzOTFlZThmYzE2MGRjMDM4Njp7Il9hdXRoX3VzZXJfaGFzaCI6IjliMGQwMzBlMzhjYjdmMzczOGMxN2U0Yjg1YTBmZjMwMmI3ZmQzZTIiLCJfYXV0aF91c2VyX2lkIjoiMSIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=	2019-05-26 07:24:17.886208+00
rlqkipq6cgintcp5jon94xbmsdnn43fq	YWM4YTEwNmE1ZjViZWUxZGM1YmEwMDg5MWZiMWFjZjcwMTcyYzEwMzp7Il9hdXRoX3VzZXJfaGFzaCI6Ijc3ZDFlZjBmMTIzNmE1ZmIwODc2YjIyMzExNWQ4YjIwNDMyODY2NjEiLCJfYXV0aF91c2VyX2lkIjoiMiIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=	2019-05-29 06:27:24.722263+00
yknjy8vev0t772srx1iynitgoqwcgo9y	NzlhNDI2ZmJmMTFmYWNjZTU4OGJlNjAzNDEwMTM1MTRhYmQ1MWNjNDp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6IjMiLCJfYXV0aF91c2VyX2hhc2giOiI5ZTdiNDZhNDI2NDlkMjBiYmMzZDJhM2Y3ZDkyOTVhOWMyMjZhODI2In0=	2019-06-06 11:18:13.866334+00
mhvsdjnh2wrlthcakn7akb4px7bkuvko	NzJiMDM0ODE0Y2M0MGI0MzgxMzhhMGYwOWFhMGMxMjVlZmZkNmVmMDp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6IjEiLCJfYXV0aF91c2VyX2hhc2giOiI5YjBkMDMwZTM4Y2I3ZjM3MzhjMTdlNGI4NWEwZmYzMDJiN2ZkM2UyIn0=	2019-06-22 18:28:57.144929+00
c4fmb8wdsiqms1bhvm574d0woljmdtf6	YmRkOTBkYmQwNjYyZGQ5Yjg3MTM5NThkZTc1OGI2YWFlYTUxYTBhYzp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6IjIiLCJfYXV0aF91c2VyX2hhc2giOiI3N2QxZWYwZjEyMzZhNWZiMDg3NmIyMjMxMTVkOGIyMDQzMjg2NjYxIn0=	2019-06-29 13:50:14.794964+00
gizao0skqucvpwsw4xs6k54s4rkhkzt0	YmRkOTBkYmQwNjYyZGQ5Yjg3MTM5NThkZTc1OGI2YWFlYTUxYTBhYzp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6IjIiLCJfYXV0aF91c2VyX2hhc2giOiI3N2QxZWYwZjEyMzZhNWZiMDg3NmIyMjMxMTVkOGIyMDQzMjg2NjYxIn0=	2019-07-26 12:54:38.161045+00
tf2yc822bt810mu5ad82axwnk5xntnao	NzJiMDM0ODE0Y2M0MGI0MzgxMzhhMGYwOWFhMGMxMjVlZmZkNmVmMDp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6IjEiLCJfYXV0aF91c2VyX2hhc2giOiI5YjBkMDMwZTM4Y2I3ZjM3MzhjMTdlNGI4NWEwZmYzMDJiN2ZkM2UyIn0=	2019-07-28 19:00:30.58691+00
nh2vqttx4qbb4gsmmxrt80lz8dftl0g8	YmRkOTBkYmQwNjYyZGQ5Yjg3MTM5NThkZTc1OGI2YWFlYTUxYTBhYzp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6IjIiLCJfYXV0aF91c2VyX2hhc2giOiI3N2QxZWYwZjEyMzZhNWZiMDg3NmIyMjMxMTVkOGIyMDQzMjg2NjYxIn0=	2019-07-31 10:55:07.447302+00
9yycbmnobjbor3snuj1ud4mqy6plx7o6	YmRkOTBkYmQwNjYyZGQ5Yjg3MTM5NThkZTc1OGI2YWFlYTUxYTBhYzp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6IjIiLCJfYXV0aF91c2VyX2hhc2giOiI3N2QxZWYwZjEyMzZhNWZiMDg3NmIyMjMxMTVkOGIyMDQzMjg2NjYxIn0=	2019-07-31 13:52:01.017637+00
sth2pqn3p3s81fsy1xz0upmkn6ninuvk	YmRkOTBkYmQwNjYyZGQ5Yjg3MTM5NThkZTc1OGI2YWFlYTUxYTBhYzp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6IjIiLCJfYXV0aF91c2VyX2hhc2giOiI3N2QxZWYwZjEyMzZhNWZiMDg3NmIyMjMxMTVkOGIyMDQzMjg2NjYxIn0=	2019-09-04 07:38:24.634251+00
9lqhlpmmfn73utlq5jofh79secongl6c	YmRkOTBkYmQwNjYyZGQ5Yjg3MTM5NThkZTc1OGI2YWFlYTUxYTBhYzp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6IjIiLCJfYXV0aF91c2VyX2hhc2giOiI3N2QxZWYwZjEyMzZhNWZiMDg3NmIyMjMxMTVkOGIyMDQzMjg2NjYxIn0=	2019-09-19 13:49:58.714131+00
i3icjd0j8o6kt45x3m9yn8pdu7013dgh	YTAzOTY3MTY0MWFmNDgxNDZlNjVjNTk4ZDFkNDVjYzZkYzE3ZmQxYzp7Il9hdXRoX3VzZXJfaWQiOiIyIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI3N2QxZWYwZjEyMzZhNWZiMDg3NmIyMjMxMTVkOGIyMDQzMjg2NjYxIn0=	2019-10-09 09:33:22.854082+00
ax7oxue3mhl97yk7gzx903y21rnm9b4m	MTZiMzk3MWNkYjY5OWNhNWQ3YTZiMjY1ZDM3YmNhZTBhY2Y4MDQ0Mzp7Il9hdXRoX3VzZXJfaWQiOiIzIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI5ZTdiNDZhNDI2NDlkMjBiYmMzZDJhM2Y3ZDkyOTVhOWMyMjZhODI2In0=	2019-11-08 10:09:16.425392+00
kn5y708dfmye8prjy3oc9h93xpv5cg00	NzZiNzkxZGRiNjYxNGE4NGVlZDM3YmM2Mzg3MjE3ZGI2ZWQ2OTMwMzp7Il9hdXRoX3VzZXJfaGFzaCI6Ijc3ZDFlZjBmMTIzNmE1ZmIwODc2YjIyMzExNWQ4YjIwNDMyODY2NjEiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIyIn0=	2019-11-11 15:25:40.219688+00
g6z6fbpl3xtq1d19piex5r63w903wc2a	NzZiNzkxZGRiNjYxNGE4NGVlZDM3YmM2Mzg3MjE3ZGI2ZWQ2OTMwMzp7Il9hdXRoX3VzZXJfaGFzaCI6Ijc3ZDFlZjBmMTIzNmE1ZmIwODc2YjIyMzExNWQ4YjIwNDMyODY2NjEiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIyIn0=	2019-11-13 05:51:22.049238+00
lmxmsphznkcmeokqtsg3081irzvs1fls	YmRkOTBkYmQwNjYyZGQ5Yjg3MTM5NThkZTc1OGI2YWFlYTUxYTBhYzp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6IjIiLCJfYXV0aF91c2VyX2hhc2giOiI3N2QxZWYwZjEyMzZhNWZiMDg3NmIyMjMxMTVkOGIyMDQzMjg2NjYxIn0=	2019-11-22 09:44:35.452371+00
bw1z9ebyrvhnrkllny5k1kdqaxa7irbd	YmRkOTBkYmQwNjYyZGQ5Yjg3MTM5NThkZTc1OGI2YWFlYTUxYTBhYzp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6IjIiLCJfYXV0aF91c2VyX2hhc2giOiI3N2QxZWYwZjEyMzZhNWZiMDg3NmIyMjMxMTVkOGIyMDQzMjg2NjYxIn0=	2019-11-22 09:44:35.669004+00
t6d99ait8ie6hbnmkju4daop41m4u0g9	ZDk1NjJiYTc0Nzg0MmMzM2QzZWM2ZDU5M2NlZGZhZjIyYWY1MjU4Zjp7Il9hdXRoX3VzZXJfaWQiOiIyIiwiX2F1dGhfdXNlcl9oYXNoIjoiNzdkMWVmMGYxMjM2YTVmYjA4NzZiMjIzMTE1ZDhiMjA0MzI4NjY2MSIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=	2019-12-19 05:57:38.153325+00
jc9wigq1yp780jx4t5hr7747eu4185f0	YmRkOTBkYmQwNjYyZGQ5Yjg3MTM5NThkZTc1OGI2YWFlYTUxYTBhYzp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6IjIiLCJfYXV0aF91c2VyX2hhc2giOiI3N2QxZWYwZjEyMzZhNWZiMDg3NmIyMjMxMTVkOGIyMDQzMjg2NjYxIn0=	2020-01-29 06:22:21.526048+00
4lq2yrhqk270y8gh1skhwytl6j76i5x9	NzlhNDI2ZmJmMTFmYWNjZTU4OGJlNjAzNDEwMTM1MTRhYmQ1MWNjNDp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6IjMiLCJfYXV0aF91c2VyX2hhc2giOiI5ZTdiNDZhNDI2NDlkMjBiYmMzZDJhM2Y3ZDkyOTVhOWMyMjZhODI2In0=	2020-02-21 21:26:29.20173+00
gf2iq6aa9ds7twrb9itl0ln49ve3srio	YzBmZDE1ZWQzNmFiOTA0ODVjZTQ2OGIyYWI3MzNhMzdmZTI3Y2E5Mjp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiOWIwZDAzMGUzOGNiN2YzNzM4YzE3ZTRiODVhMGZmMzAyYjdmZDNlMiIsIl9hdXRoX3VzZXJfaWQiOiIxIn0=	2020-05-16 20:57:12.011123+00
cl4jz3rh0fpcf7vl58p8l93d65llr023	M2YwYWYwNTU4YTI0Y2YzMDhhYTAxOTdmOGUzOWY4YTdjMThjZDc3Nzp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9oYXNoIjoiOWIwZDAzMGUzOGNiN2YzNzM4YzE3ZTRiODVhMGZmMzAyYjdmZDNlMiIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=	2020-05-31 17:04:55.407853+00
axdafqja2hxw7p5aacjs99bhlbq6q4hs	M2YwYWYwNTU4YTI0Y2YzMDhhYTAxOTdmOGUzOWY4YTdjMThjZDc3Nzp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9oYXNoIjoiOWIwZDAzMGUzOGNiN2YzNzM4YzE3ZTRiODVhMGZmMzAyYjdmZDNlMiIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=	2020-05-31 22:53:14.142702+00
ficmhfez55q9296lu4cq7p3brno1fgco	M2YwYWYwNTU4YTI0Y2YzMDhhYTAxOTdmOGUzOWY4YTdjMThjZDc3Nzp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9oYXNoIjoiOWIwZDAzMGUzOGNiN2YzNzM4YzE3ZTRiODVhMGZmMzAyYjdmZDNlMiIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=	2020-06-01 07:03:42.804122+00
2v0ybdjsnsipo705vfp106wubpfxjgqj	NzJiMDM0ODE0Y2M0MGI0MzgxMzhhMGYwOWFhMGMxMjVlZmZkNmVmMDp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6IjEiLCJfYXV0aF91c2VyX2hhc2giOiI5YjBkMDMwZTM4Y2I3ZjM3MzhjMTdlNGI4NWEwZmYzMDJiN2ZkM2UyIn0=	2023-04-21 11:48:06.542892+00
8hbriqjd1npszh29niyeuku1b100fn4f	NzJiMDM0ODE0Y2M0MGI0MzgxMzhhMGYwOWFhMGMxMjVlZmZkNmVmMDp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6IjEiLCJfYXV0aF91c2VyX2hhc2giOiI5YjBkMDMwZTM4Y2I3ZjM3MzhjMTdlNGI4NWEwZmYzMDJiN2ZkM2UyIn0=	2024-02-22 18:30:06.264359+00
\.


--
-- Data for Name: django_site; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.django_site (id, domain, name) FROM stdin;
1	elementext.com	elementext.com
\.


--
-- Name: django_site_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.django_site_id_seq', 1, true);


--
-- Data for Name: gallery_galleryitembase; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.gallery_galleryitembase (id, object_id, description, sort_order, created, changed, content_type_id, self_type_id) FROM stdin;
1	1	Denver 0	1	2019-02-21 05:50:20.71+00	2019-03-14 10:41:36.657+00	38	37
2	1	Denver 1	2	2019-02-21 05:50:24.061+00	2019-03-14 10:40:41.708+00	38	37
3	1	Denver 2	3	2019-02-21 05:50:26.204+00	2019-03-14 10:40:47.887+00	38	37
4	1	denver 3	4	2019-02-21 05:50:27.595+00	2019-03-14 10:40:54.498+00	38	37
5	1		5	2019-02-21 05:50:28.683+00	2019-02-21 05:50:28.72+00	38	37
6	1		6	2019-02-21 05:50:30.282+00	2019-02-21 05:50:30.313+00	38	37
7	1		7	2019-02-21 05:50:32.064+00	2019-02-21 05:50:32.099+00	38	37
8	1		8	2019-02-21 05:50:34.777+00	2019-02-21 05:50:34.806+00	38	37
\.


--
-- Name: gallery_galleryitembase_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.gallery_galleryitembase_id_seq', 8, true);


--
-- Data for Name: google_maps_mapandaddress; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.google_maps_mapandaddress (id, address, longitude, latitude) FROM stdin;
\.


--
-- Name: google_maps_mapandaddress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.google_maps_mapandaddress_id_seq', 1, false);


--
-- Data for Name: insurance_insuranceblock; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.insurance_insuranceblock (attachableblock_ptr_id, header, description) FROM stdin;
8	Insurance Claims	If you think your home is damaged by a storm, it's essential for you to quickly begin the insurance and repair process.
\.


--
-- Data for Name: insurance_insurancepageconfig; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.insurance_insurancepageconfig (id, title, header, description, background, visible, updated) FROM stdin;
1	Insurance Claims	Insurance Claims Process – Element Exteriors	If you think your home is damaged by a storm, it's essential for you to quickly begin the insurance and repair process. A typical claims process works as follows:	./background_1_7iHdGF4.jpg	t	2019-10-03 11:26:53.157802+00
\.


--
-- Name: insurance_insurancepageconfig_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.insurance_insurancepageconfig_id_seq', 1, true);


--
-- Data for Name: insurance_insurancestep; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.insurance_insurancestep (id, header, description, image, config_id, number, sort_order) FROM stdin;
1	Assess the Damage	Sometimes roof damage is as obvious as a fallen tree on your home or a section of missing shingles, telling you right away repairs are necessary. This is not always the case, which is why it's importance to call a trained inspector like Element Exteriors as soon as possible. This complimentary inspection will tell you how much damage you have and whether repairs or replacement is necessary.	./image_1.jpg	1	1	3
2	Claims Adjustment	Because we have on-staff claims adjusters, we can handle this step of the process. We will provide an initial valuation of the roof and provide a complete report including estimate for repairs or replacement. We will prepare all pertinent information about your claim and share it with all parties involved.	./image_2.jpg	1	2	4
3	Insurance Company Approval	Once the claim is submitted to the insurance company, they will provide you with a claim number and schedule an adjuster to come out and access any damages. Element Exteriors will be present during this inspection to work with your adjuster and represent your interests. In most cases the claim is settled on the spot and you are issued a “Loss Statement”. The Loss statement gives us approval to proceed with repairs and outlines what is being covered.	./image_3.jpg	1	3	5
4	Roof Repairs or Replacement	After everything is cleared with the insurance company, we will provide you with complete roof repairs or full roof replacement. Our experts work with a variety of materials and will give you a complete solution.	./image_4.jpg	1	4	6
5	Completing the Process	Once the work is completed, we send a final invoice to the insurance company. The insurer will then release the remainder of the money and give you a check that covers the remaining cost of the work done to your home.	./image_5.jpg	1	5	7
\.


--
-- Name: insurance_insurancestep_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.insurance_insurancestep_id_seq', 5, true);


--
-- Data for Name: licenses_license; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.licenses_license (id, title, slug, text, visible, sort_order, updated) FROM stdin;
73	Arvada, CO	arvada-co	<p>\r\n  Arvada, CO\r\n</p>\r\n	t	0	2019-05-06 07:46:17.447426+00
74	Aurora, CO	aurora-co	<p>\r\n  Aurora, CO\r\n</p>\r\n	t	0	2019-05-06 07:46:17.447426+00
75	Berthoud, CO	berthoud-co	<p>\r\n  Berthoud, CO\r\n</p>\r\n	t	0	2019-05-06 07:46:17.447426+00
76	Boulder, CO	boulder-co	<p>\r\n  Boulder, CO\r\n</p>\r\n	t	0	2019-05-06 07:46:17.447426+00
77	Brighton, CO	brighton-co	<p>\r\n  Brighton, CO\r\n</p>\r\n	t	0	2019-05-06 07:46:17.447426+00
78	Broomfield, CO	broomfield-co	<p>\r\n  Broomfield, CO\r\n</p>\r\n	t	0	2019-05-06 07:46:17.447426+00
79	Castle Pines, CO	castle-pines-co	<p>\r\n  Castle Pines, CO\r\n</p>\r\n	t	0	2019-05-06 07:46:17.447426+00
80	Castle Rock, CO	castle-rock-co	<p>\r\n  Castle Rock, CO\r\n</p>\r\n	t	0	2019-05-06 07:46:17.447426+00
81	Centennial, CO	centennial-co	<p>\r\n  Centennial, CO\r\n</p>\r\n	t	0	2019-05-06 07:46:17.447426+00
82	Colorado Springs, CO	colorado-springs-co	<p>\r\n  Colorado Springs, CO\r\n</p>\r\n	t	0	2019-05-06 07:46:17.447426+00
83	Commerce City, CO	commerce-city-co	<p>\r\n  Commerce City, CO\r\n</p>\r\n	t	0	2019-05-06 07:46:17.447426+00
84	Dacono, CO	dacono-co	<p>\r\n  Dacono, CO\r\n</p>\r\n	t	0	2019-05-06 07:46:17.447426+00
85	Denver, CO	denver-co	<p>\r\n  Denver, CO\r\n</p>\r\n	t	0	2019-05-06 07:46:17.447426+00
86	Englewood, CO	englewood-co	<p>\r\n  Englewood, CO\r\n</p>\r\n	t	0	2019-05-06 07:46:17.447426+00
87	Erie, CO	erie-co	<p>\r\n  Erie, CO\r\n</p>\r\n	t	0	2019-05-06 07:46:17.447426+00
88	Evans, CO	evans-co	<p>\r\n  Evans, CO\r\n</p>\r\n	t	0	2019-05-06 07:46:17.447426+00
89	Federal Heights, CO	federal-heights-co	<p>\r\n  Federal Heights, CO\r\n</p>\r\n	t	0	2019-05-06 07:46:17.447426+00
90	Firestone, CO	firestone-co	<p>\r\n  Firestone, CO\r\n</p>\r\n	t	0	2019-05-06 07:46:17.447426+00
91	Fort Lupton, CO	fort-lupton-co	<p>\r\n  Fort Lupton, CO\r\n</p>\r\n	t	0	2019-05-06 07:46:17.447426+00
92	Fountain, CO	fountain-co	<p>\r\n  Fountain, CO\r\n</p>\r\n	t	0	2019-05-06 07:46:17.447426+00
93	Franktown, CO	franktown-co	<p>\r\n  Franktown, CO\r\n</p>\r\n	t	0	2019-05-06 07:46:17.447426+00
94	Fredrick, CO	fredrick-co	<p>\r\n  Fredrick, CO\r\n</p>\r\n	t	0	2019-05-06 07:46:17.447426+00
95	Garden City, CO	garden-city-co	<p>\r\n  Garden City, CO\r\n</p>\r\n	t	0	2019-05-06 07:46:17.447426+00
96	Glendale, CO	glendale-co	<p>\r\n  Glendale, CO\r\n</p>\r\n	t	0	2019-05-06 07:46:17.447426+00
97	Golden, CO	golden-co	<p>\r\n  Golden, CO\r\n</p>\r\n	t	0	2019-05-06 07:46:17.447426+00
98	Greely, CO	greely-co	<p>\r\n  Greely, CO\r\n</p>\r\n	t	0	2019-05-06 07:46:17.447426+00
99	Highlands Ranch, CO	highlands-ranch-co	<p>\r\n  Highlands Ranch, CO\r\n</p>\r\n	t	0	2019-05-06 07:46:17.447426+00
100	Johnstown, CO	johnstown-co	<p>\r\n  Johnstown, CO\r\n</p>\r\n	t	0	2019-05-06 07:46:17.447426+00
101	Lafayette, CO	lafayette-co	<p>\r\n  Lafayette, CO\r\n</p>\r\n	t	0	2019-05-06 07:46:17.447426+00
102	Lakespur, CO	lakespur-co	<p>\r\n  Lakespur, CO\r\n</p>\r\n	t	0	2019-05-06 07:46:17.447426+00
103	Lakewood, CO	lakewood-co	<p>\r\n  Lakewood, CO\r\n</p>\r\n	t	0	2019-05-06 07:46:17.447426+00
104	Littleton, CO	littleton-co	<p>\r\n  Littleton, CO\r\n</p>\r\n	t	0	2019-05-06 07:46:17.447426+00
105	Lochbuie, CO	lochbuie-co	<p>\r\n  Lochbuie, CO\r\n</p>\r\n	t	0	2019-05-06 07:46:17.447426+00
106	Lone Tree, CO	lone-tree-co	<p>\r\n  Lone Tree, CO\r\n</p>\r\n	t	0	2019-05-06 07:46:17.447426+00
108	Louisville, CO	louisville-co	<p>\r\n  Louisville, CO\r\n</p>\r\n	t	0	2019-05-06 07:46:17.447426+00
109	Loveland, CO	loveland-co	<p>\r\n  Loveland, CO\r\n</p>\r\n	t	0	2019-05-06 07:46:17.447426+00
110	Lyons, CO	lyons-co	<p>\r\n  Lyons, CO\r\n</p>\r\n	t	0	2019-05-06 07:46:17.447426+00
111	Manitou Springs, CO	manitou-springs-co	<p>\r\n  Manitou Springs, CO\r\n</p>\r\n	t	0	2019-05-06 07:46:17.447426+00
112	Mead, CO	mead-co	<p>\r\n  Mead, CO\r\n</p>\r\n	t	0	2019-05-06 07:46:17.447426+00
113	Milliken, CO	milliken-co	<p>\r\n  Milliken, CO\r\n</p>\r\n	t	0	2019-05-06 07:46:17.447426+00
114	Monument, CO	monument-co	<p>\r\n  Monument, CO\r\n</p>\r\n	t	0	2019-05-06 07:46:17.447426+00
115	Morrison, CO	morrison-co	<p>\r\n  Morrison, CO\r\n</p>\r\n	t	0	2019-05-06 07:46:17.447426+00
116	Northglenn, CO	northglenn-co	<p>\r\n  Northglenn, CO\r\n</p>\r\n	t	0	2019-05-06 07:46:17.447426+00
117	Parker, CO	parker-co	<p>\r\n  Parker, CO\r\n</p>\r\n	t	0	2019-05-06 07:46:17.447426+00
118	Platteville, CO	platteville-co	<p>\r\n  Platteville, CO\r\n</p>\r\n	t	0	2019-05-06 07:46:17.447426+00
119	Pueblo, CO	pueblo-co	<p>\r\n  Pueblo, CO\r\n</p>\r\n	t	0	2019-05-06 07:46:17.447426+00
120	Sedalia, CO	sedalia-co	<p>\r\n  Sedalia, CO\r\n</p>\r\n	t	0	2019-05-06 07:46:17.447426+00
121	Sheridan, CO	sheridan-co	<p>\r\n  Sheridan, CO\r\n</p>\r\n	t	0	2019-05-06 07:46:17.447426+00
122	Superior, CO	superior-co	<p>\r\n  Superior, CO\r\n</p>\r\n	t	0	2019-05-06 07:46:17.447426+00
123	Thornton, CO	thornton-co	<p>\r\n  Thornton, CO\r\n</p>\r\n	t	0	2019-05-06 07:46:17.447426+00
124	Westminster, CO	westminster-co	<p>\r\n  Westminster, CO\r\n</p>\r\n	t	0	2019-05-06 07:46:17.447426+00
125	Wheat Ridge, CO	wheat-ridge-co	<p>\r\n  Wheat Ridge, CO\r\n</p>\r\n	t	0	2019-05-06 07:46:17.447426+00
126	Woodland Park, CO	woodland-park-co	<p>\r\n  Woodland Park, CO\r\n</p>\r\n	t	0	2019-05-06 07:46:17.447426+00
\.


--
-- Name: licenses_license_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.licenses_license_id_seq', 126, true);


--
-- Data for Name: licenses_licensesblock; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.licenses_licensesblock (attachableblock_ptr_id, header) FROM stdin;
7	Licensed contractor in Colorado
\.


--
-- Data for Name: licenses_licensespageconfig; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.licenses_licensespageconfig (id, title, header, description, background, visible, updated) FROM stdin;
1	Licenses	Licensed contractor in Colorado		./background_1_CmSoz4h.jpg	t	2019-10-03 11:22:39.113246+00
\.


--
-- Name: licenses_licensespageconfig_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.licenses_licensespageconfig_id_seq', 1, true);


--
-- Data for Name: main_advantage; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.main_advantage (id, title, description, updated, sort_order, icon, config_id) FROM stdin;
1	One Day Job Completion	Most jobs including cleanup are completed in one day so that you don’t have to wait weeks or months for a brand-new roof.	2019-10-28 04:47:13.422472+00	10	completion	1
2	Final Inspection by a 3rd Party Certified Inspector	Commercial jobs always receive a 3rd party inspection.	2019-10-28 04:47:13.423662+00	11	cleanup	1
3	Clean Up to Your Full Satisfaction	We do not leave the jobsite until your yard and exterior is inspected and cleaned to your full satisfaction.	2019-10-28 04:47:13.424723+00	12	ceo	1
4	We Use Products Made to Last	We only use quality products and skilled installers, ensuring our product is guaranteed to stand the test of time.	2019-10-28 04:47:13.426017+00	13	warranty	1
5	CEO on Site to Personally Inspect Your Roof	CEO or GM is on site in most cases to inspect work being performed and ensure a quality project.	2019-10-28 04:47:13.427149+00	14	products	1
6	10 Year Labor & Material Warranty	If anything happens to your Element installed Roof due to faulty workmanship, we will promptly complete repairs at no cost to you.	2019-10-28 04:47:13.42818+00	15	final	1
\.


--
-- Name: main_advantage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.main_advantage_id_seq', 6, true);


--
-- Data for Name: main_advantagesblock; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.main_advantagesblock (attachableblock_ptr_id, header) FROM stdin;
2	Our Benefits
\.


--
-- Data for Name: main_mainpageconfig; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.main_mainpageconfig (id, updated, background, description, text, title, coupon_discount, coupon_visible) FROM stdin;
1	2019-10-28 04:47:13.417195+00	./background_1_ipShsdn.png	for Residential Roofing and Exterior Services	Element Exteriors is a Roofing Company renowned for superb products and exceptional customer service. We aim to give you peace of mind about your roofing repair or re-roofing project by presenting high-quality work and using superior materials to ensure results that last for decades. Whether you own a residential or commercial property needing improvements, our local Home Improvement Company can help. Moreover, you pay after the job is finished and you are satisfied. What’s more, we offer a 10-year labor and material warranty. Our Roofing Company serves the repair and improvement needs of residents in Denver, Centennial, Thornton, Parker, and Castle Rock, CO.	Quality Home Improvement and Roofing Company in Denver, CO	25	f
\.


--
-- Name: main_mainpageconfig_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.main_mainpageconfig_id_seq', 1, true);


--
-- Data for Name: main_member; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.main_member (id, logo, link, visible, updated, sort_order, config_id) FROM stdin;
1	./logo_1.png	https://www.homeadvisor.com/rated.ElementExteriors.82053905.html	t	2019-10-23 06:17:42.32995+00	17	1
2	./logo_2.png	http://www.nrca.net/RoofingContractors/Details/17048603/Element-Exteriors-Inc/search/80112/RES/	t	2019-10-23 06:17:42.331181+00	18	1
3	./logo_3.png	https://madskymrp.com/homeowners-2/	t	2019-10-23 06:17:42.332443+00	19	1
4	./logo_4.png	https://www.owenscorning.com/roofing	t	2019-10-23 06:17:42.333578+00	20	1
\.


--
-- Name: main_member_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.main_member_id_seq', 4, true);


--
-- Data for Name: main_membersblock; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.main_membersblock (attachableblock_ptr_id, header) FROM stdin;
3	Proud members of these Networks 
\.


--
-- Data for Name: main_recoveryblock; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.main_recoveryblock (attachableblock_ptr_id, header) FROM stdin;
9	Recovery
\.


--
-- Data for Name: main_step; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.main_step (id, number, header, description, icon, updated, sort_order, config_id) FROM stdin;
\.


--
-- Name: main_step_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.main_step_id_seq', 1, false);


--
-- Data for Name: main_stepsblock; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.main_stepsblock (attachableblock_ptr_id) FROM stdin;
\.


--
-- Data for Name: offers_offer; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.offers_offer (id, delay, header, text, date_start, date_end, visible, url, text_for_link, updated, email, name, number, status) FROM stdin;
1	0	COVID-19 Response	<p>\r\n  <!--(figmeta)eyJmaWxlS2V5IjoiZVQyanB1Y3NQU3JhR0JyVFFwQ0ZYS044IiwicGFzdGVJRCI6MTE1MjU1ODMyMSwiZGF0YVR5cGUiOiJzY2VuZSJ9Cg==(/figmeta)--><!--(figma)ZmlnLWtpd2kBAAAAXxwAALVb+Z8kSVWPyKq+pmd3Z3aXU0RERETF2dlld0FEsrOyurK7qjI3M6t6ZkWK7Krs7typriorq3umV0REvG9FVFREvBCQ+5bbAw8OOQQRRA79P/x+I/Lq6ZHf3M9nO9578fIbES9evHgRUZN24jSN9uPwZBYLcduW63QHQWj6ocB/XbdhD6yW2d20A7CyF9h+hTeUtt1tgK4FzmbXbIOqB+HVtg1iSRGDwCbWstJVyINg2/EGvt12TX650nVDp3l1ELTcXrsx6Hmbvtng96sZOWi4XfJrOe/bTd8OWhCdCyy7aw8g9lqDh3q2fxXC9arQt702hefNG0mKLl8BLSiQ5nCIoUPk22Zj4HaVmlDMju+EbFF2p6PYO4jSGGoWqkKbPYZSx+0rUu4kk1Ey2fePxtTput2Hbd9FhXAbqp4I2rYXUWlDJBqu1evYXVpFWma3bwagjE3f7Xkgak3f7FCvvuG6bdvsDlzP9s3QcbsQLvVtK3R9UMu0JcqVtqNgV+122/ECkms+lDBJahbO+fZmr236A89tX91UIOtoqtuwGzBOqXc+tK+wS7cFbcei4PbgamfD5Yze4XTRWFdJL2yM48mog1EJcZdnBsEgbAFuk7MBf/E7ygdkw/S3bbZldHrt0NFzUGNX0ZONns+quuW23YJbajubrVB9sxzA1opSg8MXDbexaYNf1Z/k7BpmwW+bxD4XuM1woDDArbdMv1Fw5xtOs2n7th7BbfYVq90LtD1vb/UouyMww15h5AuqFRAX272O03UDJ2QTd3pRMlnoyVwJ3LbDCRZws4aD2URr7CokshCxVPbA7IKkCObmbEBWK2RQ6rhqFdWdjqlGtgQP23JALDuHWJ3BMBrH2uhYXr4dWsreTYfDk02nrRoJHTWTNXtvLx5mHa073S4WbdAyG+4OKkXDd72SlU0X/oEJ7DYGG+0e+2VsmNb2aVEtjG8sLLUMll3f2XT0Shc9D66JUrbdHUWgC6HuQwBHaA8s06Nz10tu0HR9Sy2dJYI24uF0Hi2S6QTf5AsELWNaYU7QEsN1tu3SyYzu0eFuPO9NkkWKb3yTwxCec8VuByAkeoTlT7sY1nSSLuaVScNkQi5Yr7orOybjgYE2MpPWAstUA6g3gdgY6C+WMkZpLweL+fRabI6T/Qk+KMAEVomjApd0e2FGGlrZimZAyceHoajZlsFDPdOnyDB9391RLsRB1DRrP9Rz2og5vrJ2XUNtTRM220GEUq1u2H2b1TJHNTam03EcTdxZnFu23utqz0Yf8VmAZQ9aBr2N0DcVbVxRDq8mWo2sNZ0nj04ni2iMz9t2k0oVw8EJ1NIytnoBorejZrT8uh/PFwl8ljLXQ1Xl0w03DN0OKKMzPUpj62ieTueYnIbdNBErUCEs3w3goo4PWtpXbfos5hWcgc1HNeWZGApihwXfAF/3VLxYQmE5bVDLfSyB6byTzOdEL3wL60/Nr1QEliPChN3dDDn5RiNKD/QqMywEU4hE6RpSrUTtSXWvuwmR2PJsljLoszC8RhNFzb4xm84XN3tfzXJhAnQ6dzGRC3achmpf5oKWnZu3HZ1Mjxab82SkQeraISvmLDtoaP+sld940WIRzyeogpbjKd9CwFKBS6rJOlpM/ThNHgV0YSLVHWWZoh+yoODQJ+M4iLNBweB+4GbhILRNzqu04BN6hrFPY1fuWgyftdDueK5vqj0azqxhYKVFXJjoTFQFKfOYiKaj4TU9P0VnW4hHD8NsqgcS20HowLygtbbyRqifMZu2lVaypkfoxDzTPWviXLewdE19tnWULpK9k2/1hWda9gALVCcX+rNAWdtQIQVCJBOB87A9CN1BFs5hkgmcFytXW6WIG/B424etB8zLwMuer0a6gYCNsma1XbX/1x0OJ6pAnHe7A3i0UhNmEzCD0OnYiFPgZcdFYjdQYzA0rStq+KrFLRZ0XVdg16DakuZUwrIMLQ+DoHMhl1NdXW34JlfEGuq27av5Z+fA9l2dXqyH82iSJmUfn4D4iSwjHCAmIZJme7FoOAG8om+DlE1kfygNpChIA5u+28HiVaGpVhHlsalekekotFSRFGFo2esFLS3LwFZKSY61Woo01FopKJDOMSvUsgxpvZTkSOdLkUa6rRQUSLfrjmIaoJSD3XFKmONdOCXVkBdPyQrUO1VLmTQDvasqyzHvrgo15GOqogLxsViajjVgHbjHYZtHem92sWJV/vx4O0qRHOv5RSYysHobjoUKQaCckUixKqzBXVBnSMFwPh2PG8lcLwdgZP71LZY9+qaXqPoWa2nBlRCPsPYWMertKx5Cm156FhC4ASpObvYQe6SR4lSAxkCvCDmeYhdTJLKJMXYSWZ+LNSH38cfYxZ9ahD91vdng4xvg5An+GD5E0C4F1/GndoA/dYUULKYzfDAkLUIhZ1O9GKBgdKLFPLkh5PLhpUvg5eGle1AYh5cuo6gd3kNh/fAeCpcO76Fw2YvmCKPOZBTjO2P/KBkJvwK6nudNqDyOxkcxvpFHKod6PGIRrNSNDmMha3vRYTI+gb5MGaFBGABZpMN5MluAq1G3H82TCJ8cHcbzZNhM9o/mMC1icpb+C0yho3ZI6bYb6hgIWjVz+tNgFg3hIKe+9bDZu5jPbFeRobmRZcy3AGhycjnAKgLyaRx0FI3tEcFRzW/1ayuapVjn5SfwXJVDSxSDnDE8G/ksu16DYFBwTKcsU4XaJYgw2E2QyxV8L7d7tVtIt/AXWRf2TBCqP4EyMian0HLg02odSCRwKjQ242ihDPw/0kMKjSphXfaUStYLw/ICymvsDUrVQZRL2WF0OXC6zExWXL/RRblqNn3WrzW6ahmf6/Y67NI6TkwmyvPYKzik2xq6vL2lyzuQlbO8YJoqUbto6fJO31LlXYHm7/b76kz3GC5MlI8NdtRx/XFWsMPy8Zgcyp9gWR32+4mB3le/reUElD+JOyLKb3f9Lvv3ZBoF5XdgZ+BUPqURqmT/O5ttk+N4amfT59b2XQF8DeXTtrFPovzuJnIZlE9v6fJ7WrrdZ4Sa/96HdPlMT5ffx2wW5fe3mxvkf8D1VPksP1TlD3r6+0vedpd2uqeN8IHyMkr2814/bJO/DyX5Z5sbfh/l/eZGn/wDKNnvB/sa5zl9dAjlczfaO5yfH0JJveehpN4Pm9stjuP51pbK0n/EaqqF8ALLU7xp9XzqbWCTJG8huLFsNDW+3cRJDWUT5WWUmyjvRdlCs2zPQUn8rZYeD1rbZH/aLXeLfoO8RqUkXQdbMEp3y3vgQZTelvcgcR7a8p5zCaW/5V26D2XQ3urwu7DtWtTvYT/gvPQ7doOH2R2U7MeVznaH8qvdtkpJHu72tkOUP4o8gv16IcoA5Y/1YXCUL/KCkPIBSspf7G/75CPfa7Hc9XsbnPdh0PGoPwp1P+KwqzLSPUwT52+/j2M+yoO+rk/6etyP9LeVv1zr+6GPcozyMsrDIEDkFWKCkvwU5b0oZyjvQ/njKJ+Nco7yfpQpygdQLlDSTkcon4PyOAgQs4W4jpJ4N1AS7wQl8R5FSbyfQEm8l6Ak3k+iJN5LURLvp1AS72UyCC4T8Kel1Vc9fDkJQv4MCWK+ggRBf5YEUX+OBGF/ngRxf4EEgX+RBJF/CYTq6i+TIPKvkCDyr5Ig8q+RIPKvkyDyb5Ag8m+SIPJvkSDyb5Mg8itBqD7/Dgkiv4oEkX+XBJF/jwSRf58EkV9Ngsh/QILIf0iCyH9EgsivAXEvkf+YBJFfS4LIf0KCyK8jQeQ/JUHkPyNB5D8nQeS/IEHkvyRB5NeDuI/If0WCyG8gQeQ3kiDym0gQ+a9JEPnNJIj8FhJEfisJIr+NBJHfDuLZRH4HCSK/kwSR30WCyO8mQeT3kCDye0kQ+X0kiPx+EkT+GxJE/gCI+4n8QRJE/hAJIn+YBJE/QoLIHyVB5I+RIPLfkiDy35Eg8t+TIPI/gHiAyB8nQeR/JEHkfyJB5H8mQeR/IUHkT5Ag8idJEPlTJIj8aRJE/lcQDxL5MySI/FkSRP4cCSJ/ngSR/40Ekb9AgshfJEHkfydB5C+RIPJ/gFAh6sskiPwVEkT+TxJE/ioJIv8XCSJ/jQSRv06CyN8gQeRvkiDyf8ubj/lIrRbYrsUlIfMUy2BO2YlmMyY50tibTw+Zli2m+GtsjKe7Qsrdk0WciprU9wvCqOG++YD8hBkZ8q9RtIiU7gqyr2SMo53FpNEcPYIDqJCrC7aNdC49iEbT6ylI4yDZP8Bp9gDpHRLGUbyIkjGoeowup8wlkDge47Qb434A9PIiPlS3Rbpq5TjZxeFsSHpVXXrqZrOnAmGc+/9tcojEaB5hbGtibXdOzAlaBndOdUYYF5WdbxdySEMgezamTCQXzLNrx0ma7CKpkqKOIrurPi+WUiTcqXhYLgN7ku5N54fihWIlUUa/IVYVER4gSZ6w58jbowlkODk4rIHgghYgrUPWialZERfBVy9nL4hz8ynOGVBBT9ZTVoA4v6fMZ7Gz2aw9Km6bcSxNVSNeIm6PD6ePJBZQPFzwwYgr8g4miB0YsgEHEMbStfhEwGH2IG0nk7gV0zKANyhpJPsxcGvI4MHptHIi6mR2tOISklVc+Wiw9eFBxNQ5nqdwMVlw6kOnweaNlLR7HM9xkxSHEYyJoCBrY3W9pG4x+jAxboXH6E2K7UUu7Y9PZgcp9hW5PCpudlPsKnJFf9ZHgxDBdqvsWjG6l0m5theNx7u4IGmiIhW78twBZnkO8Gsb0xto4BVSrrcqIiyVXdzcjFJxBWeZ+RgDyQ8+tY2sW8JYgfvpXLwv5PVktOARzGDdVRA1EoUl6+TMdIiTFLiVvWSeLqzcNOjzEtypyi9vcrzCWB5ODw8j9CRbpuW5qy+0GZFeYvXuYWTKcGjqLHg0Os5WwHKjMJ4wjDlOkhijlCWSoQ+cynRG7Vgx3XhxfTq/lndhAgePxmhspFrMO3J2PhmicFGIYUhaLxW+lMHJ4e50nMGnikG7iFyazkFSAhg4RnI1BfT2JkaDFQnD5rB59DMMNTNyBhlSCFziYOzonAL0470Y51cM3ljbS8bxNlwdbpmqStWygSbpOa0IwRHHUHbVA1QGnyLjkPU8lC6NE0ST+Qn7EE6Do10eX3ehRoFYSM7XbDrBNOuGVo4me2PelU6gU0VcTdJeXhWPEFLWdK+t/PtOlGL2MkMNc6lGlbOj3XGSHgCM7bK34TSMo8N22Ts2YtzcSPaAA79Sce5OUYlze3tpvMBs1ubRKDliUKyXAW8JRRHwlkPGOeWGzmRviglQaFtCjo4y38JC8BCwpqxoxMfJML/ezq9ZmIer+3Vp4WSkzoqGkuHmhSd08DX9oZ/HPZ5l9ceWtTNQe6+8qRFh1MkglcMUZ845m8cYmDOC9ZK9BAsCc4yvNOZrEMvpc4ghXrayQgLgPRA9UadpgWuq/E5Lki5qDHL5zVYN10MYR65Zz9hCeSkT5PrLHbPbU2eQlawDG4hQ+3PGHae8ZUUrxah5CYvnZH3fyhuz7ClIngHQYyi+xBnLaQzyt8ez6uZsFiNcqFVi7BZihfIXMGUpsnJ36UbYcpUNlRZuI8w+jvjqFkPg0i57PJXBjrpXMGxs1vNFgD0aTpsKYzU92tvDTRScWW11CuVZArdWRdIzF7X0eJ8roMtNETMFFkkPnfDNcElw7tGCgZW7D+qx+GA4hHh3gosmKVag0ZzOh3Gg3rewoq6lEK9mfelvZmDCcJqDrm1nd3dme8e8GoCQbbWz8L0D0WPBHl4WMuJzv4GwUSyO2uToMMCygjFSsSTq2VJCWpJqaUBXRPDdP8JKnGfcyjCz5eqMCxSPKfeJtU0EH0xCLWtEFlDF/uNhsWOWriflrwNWBZbxqW0Crw+IyCF7zLso7QXZYy4urnx3mxIje5iv2XjEVsf+Oo75uCEDtZQ95izrsKTwKrFUh/wsGsGdKgE0D79UgMkxMk4hxpRSkn2Ch7nyKgvflKE5u17diA/gYbAP8PBo11a3MhgCnjYGOy0bi6DltBsDt4lHL1bjpgw33fr3DdKcD4s2I7wXTvbNyT4MhbwSUazCGgkeROZ+HvBq3vhoP5lk384UAyugvzrtRkev6U56qs6Px9HRZHhwiw8OkVfCrUHCpdXcgKzxNxvYmSeoML6pNkVMqSrDaB/z9uzZAdILsSwMRWjh/TPYM7+BfZGoVVit8MCCE31OqNinRQ9OIiyZdbHEUoueUzrsckbqiufiKvqa2h5WNKXFP1RmvqsZqSuehy+LvWCtYHTlDw8RJhYgzilCC5+f0uX7yFtRatGPYJEXufL5gtGVLxjBleDo8B1sJfK2CqsVzEg9L3Jw6PbtJaerN8qAZU+YjnBwd5wRamXrEHEB9RdYalEjVhHCOh1OLp6VanWbXzqpq4MRNO88JdBKzbJ5V1sThr3rjFArbyJJqzrm3VVeq7QqKd9jclpXOfCQaH8ezQ7oJJiNNfHYm0RacauQ5tfla+JxN8u06jZXksPVorIxKD7+tESrtQ8TzFI7QQGVJ6DIOF3dSVUkzs4Na+KJVV6rdBcI5iF2v2toGyrfVuW1intQ/IQAkwEItV08UTzpVnL9iQcODZk4R07Ek8S3V1it8JCWWNFMPFk8uWB0pa959QOJp4jvKDldHbCLCqtVdEA8TTzlFmL9QVjU9POfMzxdfOcZoVbuUW4hGoi7xVNzWlf1yVYy+seK7zot0Wo7uzf/buOp4mk3y7TqleOs7dKAMOx3n5Vq9auI22OPfCpeKp9ecrr6YSjDUloEhe+p8lrlR7lCsmPSi8UzSk5Xv5Ce3cXCxvn0e3NaV/2YGioj78uleGbO6LoXxSrPTXHvJ78vo3XNANF3hI1J/XoDHiWeKb7/JpFWfLFe7UGesbxJyh84LdJ6EVs2VQBKsQLF/eJZpyVabXdc5BIpbu3kD1Z4rTHUhy0OAlej4lLJ6vqR2j+xu6yIezJSV8RlELGylOLyTSKtuMf52Yynh/FifoJrQXlvVaB19vUU5UJq3XdapPUOsPqzn0w8TyQFoysfUXwWP7CGr1V5rTJWIi8acTuGymGV1yoT7osI++pQN80ZXTfTBzhaB3fE4sdLVtfP93iR0kEYbiSpCvYIy+kZoVZezPVETZuIWlLg3qhgtcKxnvgN9FAbNf8e2tdVxy1IEerU8hUvEDeUcAv3MfwZx4Y4SXVOpHpZplGvlOLRJNVSTx/pCAvUnwBVfFA9N75khMfJ47yGA+ZJ+Ser6n2djmH3fylXTPZwaCELmU7aTNo5QLTxU6dq0f0bi6NoXNV4mboSylQw5uE8ZqjACbOq9dNVrRZ8AasIsaKq8vKqijvHHCPkSTwpVMTBGLt8PHo4nk9R9YpqVTd7ktXPwSM8PJytzLxL7OG66GxtExsIuy4O8EZRqUaIT8UjuFaqyIq8dIzXC7odhvB2KX9JIvJlx17mcViJPh4zZjhLqhNogO1wUVT8SllRuo1ai1ievyoRAJHMRGMmERjtr8npsbr4wN6sJ1GB/Hp2T9GIYXq8kqNlzOpvSN7bIInEpjudteM9zF6ZHWAt/eYpBZ/R9CaN3yo1NqaLxfTwFii/fbPOrYBeWSqVNQlzDDwxYzBcT79zs06Iree0yqtoLS4xjDCFLyLiRNgJuL5+V2rfhv/qKxCsX9hOef6rJAI8VLNZUZcRr5Z44yllISYANxOvroga5SXFH8g4Kn5H0sa1AeyMw0f5u5Aunn6GqtPB4XS64I0LPnutTCYHcCteso4DHYsxXa/JxYEKmGXF6/KKEGusFP9lLrZVeCkrXl9UqK2rrPirvIL7Ril+Qy6u9KfJH4KwG6h/n0zSogo2/SPwujKX/IlMSSk7vFviLUuxp/3uw/Iov0yCGapB6c/kGHsibJStwRfj6QtfwpKuPr/2cY0AB8/C0huzKQ3YRmU63y+xy1aqykD5XolHsCQ9HSPfLGNlNxrVTHGcJwH5W6AZTPeQBqFXGRTEb4W4O530ZiNs2RnE27JuwuXgH0OljVrhYcEPSxl2AwzhHRIXFnDEg2Q8QrcayTFCA6+T3llxLg8BL54f4+qeuGjiXQSaYBZRqczbhIFLEX9oty7eQ//X0SK7yHqtxKBTBVIchT8gYSIVOdAtfBtCXbTwQFc2HyaHMdIK+OgHqpqdCAz+VyvqgxJMXlNZDB+Soxgb1kTxOL1gwpCk4IOPVC6AdO6GXO6j8pY+t1Fowu8+JqPsJP4hifc/WOv01tVWOVA/c4wl7GQTjBTbBlg1uDdIPBJOj1VH8rCsKl4n8WiYVfAUvgBwroCp+nheV3bHKceMF1o8MJ7RMMtbsNdLPDyqLSHr2zreHxdwrx4mt32q1yt4kNQHf44ItpKfwCvcPoLdyJ24YVP/xCYVM/nJQr63d6riU5UJDA6mR+NRcIi9xFSPQnTTT8uU+YTOLp6PR03FlqeKLG3CHH5GV6FzKl8vKz6rK3bUM0VDfE6zOtUG/3llDgQVdQvj4yl0ptcaZpf3CF/IeRVvvggHzqIx1dfxPJqk1mX09Eu5XjzqZwZax1OpNhAnqrgu+ZiUXwYMug+3nAdHMy7lLEoxMpncLhl4mT98RXc3y7KwHjmoBh5aC4A0Q/g/AL4qD+A26n0H5sN77LX4JJwn+/tYwJ+S4mvof8CVvwlPmEH/6+WCrDhOCqeT35DHU6xQ+xij9w7wmkj7fLO8ia7o405I3/DEVIbPCUNXpHAnWSs+sVW1sZyUn4YQY23LiujUIsbNVVFRWcO10+Oq36KrS6WzldFiueiLqSDxjleqFUlNxU9DqGJfNUpJtRendtV6qVM2WOnFLV2ed7lZiFQwTd6X5hIdNFfpsuNbrv+1s3HkXNngmRi9npmsoWOvWNq2r264ps8LUNHrbnfdHVw48ieduGlUt/nyyoZ7BXfxNmjDC+5DUQt2nNBqDTz1w7j6djkRBm8N+QCL22EJGypp1tYnMJUtdFG7pmHo10aVdsLgRj+Jr9Ot8bAxjCbHUcotFvkYwhUe7oScYUcaYzzH0MNADMU3Yg6U90s1/dGmRqurfxZBKP0vI54hpK5XoO3pUBkM5jMq4gC7qDI630Wv3IxojZPhNYGHphECIR4n4ZX8Xlu2mBBpTDB66Gc7GgKgzgqMUBsDMVHPpZC1qaayFuTBdJHOpouMNdLr0Syjazd/rOKKUZ9qLtP6VgCz3OmdcjFldfUeXCS/qr146pe7mR/qZTjBiRIThhc6ndrX4cD7sXbQJc6Kmr3PwqEPlfE/j1vWNDcpHkRXp7to6BirBQ/ja6OYTtHVmOeQhGLhKhOniMASz/60Xm7WFGFX4ur0tBFShFt5G5qao7fr4nacqnB9lum0tC0wvjtOyb1bGAKf++LCIlfJ4ZWRvyLlxQCdQ7zEReFDRzFuCvgmgCWMkXSzyUaGj80GrxEUaFumnXgRjQhhyF28VSDgx2NuiPQH2LYDQ8N+wribvcE6klXTI3peU0RtUiIia5B1jjfnvyolniuBLY7lcootMxpnFl2JhkPAibpYTZmxBLG6T0LNWs6HbPZBcS7nLWwwmAQlfq5Yn8FqjIVL4rwis573+aMLsNh91AYKu+uGvehkPI1GENyRnrJXgo5+TcoLlYEUpvkG7pr3gNTH3oWhY7x3KnQn9WjgaDw+cY8WaTKK7clwDG+Y7ON8i3FIcZdS9GBCZ4QpuPt/AYoiAADtm2eYVFXart+qbqCRIFG0USizMoqgSO52i2kwYhoVR4cWGmUkDUHQUVjkxhExM+Y2ZwUFjOA2KygCZkcUURxUVNBRQQznflZVtS/nfOf6rvPv+3H6mu16at3rDSvsvVbtYjKZrJVY4zVXXr20rGn1Sfv/deTYgaP7nTiq6og+o046fuQhh5961LHdraW1Onn30tKMWdZKM/UOHTFw7LDq4WOsfqZsopk1tGbWwixj0ZntbKXZev2qzq7Odf69RWMV/MVi24wMWkrvP+HVpUuLlyrG2SWZRaXTd7DMj5m19eUws4uVNql30njFa2AFf42mm/WeYla7leMm1jTm0spaw5ptZ20okh0mgcrVYEfbKdPO2luOJHexXW132yOTseyEi2fOLF5qVqL/0NGM7Wl74aE2s/cJI84aMWaEnVB99tihVaMs/3Hf4scOmc5dR47P5WtzxdrSYo71CDLZ5m7KTg+repZYaayz+i35H9Ejytc2o3aChfaWyWQn2/jOnmQKJJud8r+RLCSBlEBavexJSf2LLGyxTGl2qk3e05PS+heaQepBKvt6Uk/eelmmPqTxjZ7Uh9hulmkAueELTxpAlEH97DS7qK0nZRDZlEEO6+NJQ+V2bN7m/VM82aZgUwq5dYInjeqynmZhtieNsVHWDSFnP+5JE5FtLbMN5LxVnjQVIetGzMvKjCfbipRbpnF2ul3dypNmymCjZZpg896OnjTHJmxnmabYnLqfJy3U0/5WVr9hJpNfIlZcIpZlqe2j/3XMTMyETGYSKyVjUzI2NWPTMjY9YzMyVpOxmRlWod2WKbmD2+y+jN2f0copMXsgk6nu3GP/6h5dunav6tqjuvvgLoM69ajq0f2sAwbvXz14/85ndek2qLpH54GDqi17YLeuPbscYPZgxpZkuGO/a7jwYHnJcM82qXfw6Ny46tzwqvOGnF01pjo35pzq0dW5gedUDR1aPfzsIcPPzg0cMoo7f/SYquEDq0fvkztsaLUeA7nDxo+pHjVkxKjRueFjh51VPSo3Ynh1bqRqhow5PzdktDzlRlcNrubTiMG5EWNH5QaOHT1mxLBqTKoUdOhQlRGMqh6Xqxo+KEeUwYM75o4YocCDR4waVzVqEC1z44bQeOCI4WOGDB9LjiNyVYOqRo7JnXV+bkzVuWqrYINHDB06Ypw+jR5TPZIERuTOra4emas+r3rU+cpO2XTMHazYOfqXO3f4iHHoKozJoWp47qzq3Njh1eNHVg8cUz1IydFwIBnnhgzHGcmPGpYbXV01esTwjv/FONBn8j9fCVSdU101SN3GNd0edV61ch0ybGTeSE1Efs94GF7Hjqoe3XOrx12N2Wk8Tkrzj7tZNrJlfOLNtKQDD734PP0/H3l63tl/8byTpb9K9J//t+fdwXFE/v9a+Z+yVkqLC6QeszjFNu2TrVm9/sT8E6i2wWSz1WwtpxnPFbtwMOyy/iUiDp9WfyGPFptmlW2zNbX9TiiZCnJ8Yab+7Gy+wRQcXHFqyTSz7q7B7Gz9dYUGX2Zn2H5d1cB7WJetP7vEuDLbZmOO+fTym56xFTTLTrbVZ3miTc/KtBVMsbkVnmT1IN5imeaQvSZ5UoJNGrQVTLV39/CkFKKtQNvhD8M9qVfw1gLy8GWeaNMLbAVNIE/9yxNtenrgt2RjObGFJ2U88G2DZVpBDjnAk4aKw/ahzejVQzzRppewGTWBbBniSSOI4mgL3XSpJ42JExg3bXrd7vCkuOlpCz38FU+aKgN6Km+7ve/JtgVvrSEDN3jSDG/GGDRk0/tyG0+06SlOMza973b0pAVEM4eN/b2jJy0hsinF2+TEk1aF3LaDbPyjJ62xscbKbXpY1N+T7UTITRvyuGGetIFo3LSJ/zDRk+0Vh1mAhJ41nuxQIMp64mWelONNWbfAZvqtnrSFBDLYBpu+CzzZEaI5bYXNgJc92akQB292x3JP2mFT8BbO/sST9hB5Y9xs4g+e5OQtP2729a+e7IyNxq0VN+QZZZ7sIhsyaJqdkUxs7MmuWgf95W1GaLPVut6t4K0R5JdyT3aHJOWWaZOdkZ65myd7QNJUK2RGcsRW98KeEK2QMkij3p7spQxYiU3I+vqDPdkbG81pC2zeP9KTDiJkoKx7neTJHyDKuiFk5zM82QeiOVVuuw/2ZF+Ictse8vlwTzpq3K7QLMwIB43yZD8RZmEHsh53nied5G1XrbcZIRc86SwbZoHc0j5TPdkfG+XGiIbDZ3lyAEQjio3td4MnXSCyYXTS/bd6HhwI0egw1nbVg550LYw1/Ul3ne9JN+WW709y+mOedMeb+lOCTemznvSQN2yIk45e4klPEeKQdSjZasX3wpuy1kps8J4nvWXTP796l3zoSYVyY9zqY7N+jSeVeDO+PMjbTes9Oajgjdm2qm89SWTDbDMGtvsWTw5WHPrDiIY//+ZJH2w0oo3YC8+k6ndyCCSBtMnWhG0benIoRDPXIFuTTmnmyWEQ3dsN2Xr7tvbkcJE4OjVh6Q6eHFHoTykZ3L+jJ38sZF0fby+386Qv3jQ6LSC37OrJkZBQHjNITtjLk6MgyoA4uTf38eToQpwsGXzT0ZNjZEN/yDpdsNVdf2wh61Z4m9PVk+PkLc5pTXJ3d0/64U1Z4y2ZVOHJ8b97qz0r8eSEgrcyMhjdx5MTZcNKLMem12GenCTyaexp0qevJyfLGz0ljp15lCd/EiFOM/oz4hhPTlHWcVXV5FYc78mpssFbWTYex4rVpyk8ibXOTrINAz3pL1flmpzJ9s9VnpwOyU/OFL4rePLnQpBmkPCsJ2dgo8R0pBmwpydnQvR4bQvp/zdP/qLcBiqDqbbNzZ4MwEYZlEH2+rcnVbKhP+XZafZGQ0/OEokDPc3KOngysJC13gp81tOTQcTRImgLebDKk2p5Izd5O+F8TwY7b50u9uTsgrdGkE1zPTkHkjDWTSEXve3JEMXpn49T85Unfy3E2Q4y+FdPzsWbNh/eMdhvzTwZClEcjk7hmV09GQbR/JRB+h7oyXBlwIjWx1urxJMRsqE/bSDjT/RkJEQPHR1p+m41p3+DaOZ4YxH6TfFklOL0j7nZ25d6Mhob5aZDyJm1nowpjAEHMXvtbk/GYqNVhbdw1JOenAcpeAtvvOrJuIK35pA+b3kyHpv88R6brz05H6L+aJsdZp5cIG/cpJB0dqknfy8QPfofLvPkQhEy4BASPm/syUXEyfdnRrrXdp5MgOT7MyNd386TiQVv2rB229WTkJERU8epKnl7H48mCWmNsJmFbl09mpwpTBGhkp96eTQlU4jFUSjtnHg0VQ61HHGYtunr0bSiQzZom3usR9NlpYFtjtUjp3g0Q0izoTQuHORRTTENBjB95ByPZspKI8i2at9ttSYvjqjcMjvi8KS/e/QPoTQXY6Xrp3p0STEWU5LsNtOjWbLSnHAkSdZd7tGlscvcTmRo4+d4NFtWyrAtVo/WenRZtOJxI1R7p0eXF9FOoJn3e3RFRE3yyZfO8+jKYvLtsOq9wKOrlEb6Z9OySVemHl0tpGXD4SidusSja6JDFrWG965lHs2RlYZ3G2KVvevRP4W0Z5OhXfWxR9dGh2RIl8PStR5dF/tFl8kwzP/So+vlUBmy2MLg7z26IVr1jysqHLfFoxtlpRXVhK22calHNwlpUjgH1N5X5tHNRYc7st2Pa+RRrazyy6bGDt3qEXxLsV/NsfpLC49ujVZBt0ONPb+9R7cJ6XbA4erDdvLoduewtqq9R3fISg45Qqx+YXeP7oxWzFdjYr2zp0d3OZRbt7dHdxcRaSSb/+DRPRGRxnY4bN3Ro3uVhp4AnLKsZn+P7ouI+eJwaFXdPLpfSMuG01Rt894ePRBHnpuIfoX3Kj16MKZBhjis/SLx6KGiQ47PyfWHeTRXKAEx8quPOtKjeRHlRz597ViPHo6x6DIZhs/7efRIMUO6nLthq71xvhyqyzjMjT3VowVFh02yeqPVtli/UCZahDtmJ9u6PT16VEgrrUl2il24r0ePCclKv96MfMajx4V03+kAtd1WVk8UM9cLq6tO8+jJYnr6Mabf3z16quiwHLTmRY8WRYefyuE0u5P3c7+jxUWHejE0tZVHT0cr0tC7qec6eJQqlvrVHpQe59EzEZVoYfB2apRHz8ZYcWFgNdmj56IVs683ZIfd7dHzQuqXkh+zzKMXosNC8id85NGLxeT1Wuvy7z16SQ6NWDpKTG7i0ctC+ZU23S5u79ErxVhtQZu3WgBLYqyBxkqbbksP8GipHGql8c7J9jvCo1ejQ0YDFEZvNYavFZEcPnaKR8uKDjkh2Y7nevS6UP5RM90emOrR8qJDXjyFjZd4tEJWgdHgzZPNv9mjlUL5kZ8elj7s0RvRIaOhw13PJz16U1b5nXd6ePZVj96KA8WkMPK25h2P3paVRj6L1eefe/RORKRBLMv84tG7QorF5hUObeDRe8UMOQDYhY08er+YBptX8nEzj/4VHTK8OEyuLPfog6LD9uy8S9p5tEpWoUT9mmGVe3r0oZD6BUoP7uTRR0WUJfnDeni0OiK6rDRW9PHo42Iaclh2hEdrohUOW4K+3mpFfaIu6900VtbkVI8+LVqxX6fNqjxaKyttr+WgzYM9+iyiT01jaGuHe/RvOdQY6hwyZ7xH64S02Egj2TTJo8+FlAZdtp8v9uiLYpc55oUDZnv0pay0ADjLhR/neLReSM8oTi9p11s8+iomPzCmka6/06OvZaU0OMuFDQ959E20yp/lbOh8jzYUM9wWq9se82ijHBqLTck/8ZxH30ZE8jgME7a6U74rOuSkZAuXe/QfWek2J/kwYZVH3wspeRwmkz/z6IeiQwYqffwLj36UlQaKr0m2+TuPNkUrnhugpO0mjzYXEbFCxc8e/RQRsdqzKffcahvdEmOVaG3UDJhZ6tHPEbE22K+tZ0OPfhHSiuJ8ZS2bevSrkEaDrTwZ18qj34ppyOrK7TwK2YIVh43kxx09miSkMeQgmjt/Z48mC2mgOGyk2+/h0ZSs1gaz3Jozz+q9PJoqK6NfxMrN3tejaUKKxcnWmu/v0fTosH/s14Bvu3g0I1voF8e8XNNuHtXIoY55Sn5SL49mCil5Rj7NJR5dHFF5PtaKQz36RzEW7y5zXx3u0SWy0jOKftkjR3k0KyL6hcPVXfp5dGnRYaN4vppSrOdXREzIoUV2su21j0eXCQVQwyy/+W2FLhdSIP0bmEFPeXRFHEACZbNT7V7NYx26MlrFzKda2XCProoIh9uB9ljo0dVCGlsd2P70i0fXxFjMvn6R+6KVR3NkJYc7gjZ39+ifQjo36mBz+l88urY4Sjp69Rjp0XWy0jw2A3W92qPrhfLPE37+e8yjG4oOm4N2e8WjG2WVvxew+tmjm4SUvA4AHZp5dHPRIT8+hWu396hWVhooTi+huoNHt0TEjcz7qvBKhUe3ChVeWIXrTvfoNqFCGnbrMI9uL6ahM0/z8zy6IyIeUDrznDzBozvlUCuKI4ptf7lHdxWnUsmvud6ju2Wl5EkjHK6toQ7dE2ORBkeUsOBRj+6NVkwKsULFViN/n4tlZW96dH+0IhYv6Wzovz16IFr1z4/hxm89elBWGkOeyUlVmUcP/Z7hjPSfjT2aKytlyIaS/rm1R/OENPLsGmFAO48eFsqvwxnpzXt69IiQHHI2SAd28mh+RPSLs0HauqdHC4Q0Key8Nu4QjxbGLud33vDtER49WuwXP1dZh6M9ekwO9XsVm1d442SPHo9WrA11+fvTPHpCVuqyfoHbfJZHTwppeLGyNX/z6CkhWalfay/waJGQ+qWD6BFTPVoc+8UCoF/p2zM9ejpmmO9X0vRSj1I5VL/0O9yjczx6JjrEiljpHrUePRsRsUg+LLzDo+fkUMlzAkyeeNCj56NVf91fM+yi+R69EDNkDJnl5ObHPHpRDjXLcnj8sx69VHTIsrFWL3v0crRi2TAa9u5yj16JsegXaYRt3/JoSUSkgcO083seLXUO0+8/9ujVaIVDrJJ9P/PotaIVY5hs/NqjZTF5xpDbwSb9x6PXZaXbgaNyctMvHi2PVp8q+Zr0raxHK2IaJM+mvPqzUo9WRofl+l5WE+Y09OgNIe1fbK8Dzmjq0ZvRIf3SAeD8Zh69JStlyBEl3b61R28LGbHYypOXdvDoHSGtDTnsu9UT4F0hOdTLt3W7ePSeUH5rq7EFe3r0fjFDjnnp8r09+pestGzagu7p6NEHcQwHRofJTZ09WlV0yKnMnjjAow+jFfNFl1dP6urRRzFWvssDOvXyaLWQuqxYDx/k0cfFWBy9bNnBHq2RlXY9Xm3ZwYd79IlQQiyOebUbj/To05hhf31lq8l9doxHa4XyX9lqku+P9+iz6DCfYW7cnzz6dzHDBvF89WWxfl00Yc2UZyfbHzW2dehzBdL61I+Jm9p49EXRWyvQyNM9+jIilm4b0FU3erResfSc1NGrqYaiDn0lpDQag4Ze4dHXRYc6lU14xKNvohX9bQO6YYtHG4QUS6eXkT082igkK71umniGR98KhXKtmWlUefRdHA3WjN5fHXKtR/8pZiiHr97j0fdFh3p/dfzrHv0gpC7rVBa+9+jH6JDh5Wxg+5V4tKmYhv7p07FNPdosh0YsnZTKdvboJyF1mSOKNTvAoy3FWHp/NbGXRz/HWNxcOoccf4RHv8ihbkleUtmC/h79Gh0yGqD8RlmHfisiOaw816NQUnCo91e3TvBokpAOojrLHfBPjyaXFBzqLDeu1qMpsgqMht5f9XzEo6lC+ZGfHo5/0aNp0SGjoUNUusyj6bLKr6jp4fL1Hs0Q0vDqx85rf/WoRkgPQzaU9B9lHs0U0obCL33pcc09ulgoIXk2SptX7tE/SjQp/ZXGjKRvzqNLohVpEMuO2dujWUKKlQPFb5R16NLY5Q1W1vD/9u/RS1qtarvTvIM2/rhz92e6vLhf9183dev73V9LrV5tfah1zE78b/6p+l3x/7xxR8YySzK2NJO1+jsfaRlLFlYaf1lLZziRKz8oa3ZvhVnDomgn8VClre6KkFWd0N+0Enylb2CpWomwCyJZGkWJJVfTbpeDLPyVihZUhA5UlFCRq7T0tcoSs/6Ir7lu4vqaimRZFBa+qLRELQLN0/uooAzDChX2U4Ul6/A1uKLE0lcQuacsuSaWOD00CiJRXkILm1rBSuCDyosr6RIiuQFnEgMMz23oWrkyHEaoA6lY6nqFsIzZHFJ6GaMwIQoLf8LlE6roSNL38aE94JpK/EtMg0iETlxHQL9TKiMR04h+TSyxXRCFJS9RfkxF8h7N22FPaUPwEcV1XGoxjwrDRPELCVmt/rFvyrAkU6ES1gTyJS2m4NBeRzAcGmNKKk6PgjmiPKEimxf9FpP3Jcx5USQN6H4ox5NE7MkG/IdT6GxDYuCOkoDLojAjIFNHhTJYwgfKUFPJGCLIzVh49CXMpI1E8ihtXuBaoYqHqVjPdRnXeirC0VHkk3upklQQoRHEjqZmSoWlNKWkAluEBZzZeirk3f6APSXhbByhw9+JdB9+0scB6lL6TUEkc0BKNHyLnW4HW1QUF+HhSJBZseb23pQSRxWsbHnvvB+rV5kXhVhEnRnn5iHqr6Rl6OIEf5jczYjXCS24cCuoK+Nqq6OwwPq0vajINUeUHxTL8CsDEcUHrNwGB1nyHBXhF0zuJTaV4Ubi5HbAJO1VEIqT/kqTKPJJkZ6SCU/Q2m6PghlkqSGiH3uNCmNgwkd8UKnQErlm3JqrKHcgOd2FOe719Dbc6ikgr3VCzt7TUFhX5k0LQCLMw+O1rDQtAHuXAdhI011xlMFjOJ0EWFfh8lgSgrWOsPQLPH+FSahPp5QqZZhRSSgECy1PQg+a/0KE71kRLEzuPUKupHy5Ny0WIrgJ7IpYEr9rFGafkIfuTGVo21JJGabjXYLcjRHbhgxiHITufqOPtkFGZyKmYCi3WpsJNysi3hC2kYr0Q0QnUqPEW74iWYifV6jQSIT5fPiKi45TUnFmFHEkk5Wq2AYfj1JBSR75J4CVFjovERpDv6TVZEIWnwB2cyyxPyUKC+0pL+AJYG0RWhW68fkriETTtwuoKNL4BOiPYB7CTbGkB/hHWErARE8AZWB0R2USbxEJEuVeeI/EYrcR6WN80ASqUxop3fDGoqQkzpFR5AM/U5nPIOwAsWNoNpNpoSklzuZHkX+Kah7kPfwBO5UzK20VW6CFQ6B7qSuIRDdqcpUTrKs8qhNWn2BRLGU0jqe8F9+aDruYiomxpGJGFBaupryG4YyC/ceSKQgG2gbFksz3iIIFSvlBbyqW4Wgyl8r6xJWICdhlvX4XMUmhOlHXEYT9Swsg0WgoSOgehdm/aTaeBK0nySmiyolyiWBiCmQu5DqaLlcFt6EejLYr42BMbt1sz4olfXo2ivg8iOsh/Znmy/hAmczCu4SNQVijKPDaBLEbU9GDci0ZhcEIbotUIxXvkwejsORpyvtUsRzxBlmtwmwbnCWbqVgk8g6C7hX6a0zsLNroTrGBUZhVcL2nijbk9TwfmnLV4iUscyLcRpPwKk1e5MOTkPdVcS8fcFLwapfqmGMJA6V1K6Enkb1FbnGx744945FOjiX5zY9C46ktk8xXVubnLTAwdcL69SaWxGOLLFlF2+0XY7yYipMX69GgEvenRWG2c6VZb1WsJPCui9n+Kb9ZxCj/iAiLIN1w0nCxnlYqcXZ3FGbq2ktqQaftvEX5ckMvbCVOraDpwwgGM6EXlGRGtxD5fk6jhToen4eUgewYkyZ0Jz5xELYvsfan1EPOTkVwP6azYom3x6PIx2tVmQ/Mfs3qeQwn67ku5dJtrw4jzA7g0oNB3tNH+UBJOLtb93J8nv4Jz/YQgjzD2FhS0T6K/IM8pxaKu4CrhquiktiI/DTk8FgU4SBiSah9HAYlnigwFZry0BJjiWhjPzrBH2JpUeSTs/2MtdkBHStvIHydiE9UoTrB37NxpS2JH8j7RUTobeE5ykHK5TaEejYslrTYKYr8fdKYFtYfcQuXyu3oj4SO3/YV5SWq6MaH2xnQq2NJf551InmcJhJhBR+0jj9SxR18+JpKZp2SUaqKguRp8bEq2lHxFi0oSZc+TiHecxCJ9B2aPkXFF6r4AfELFftgUsrtEs7ACbdLckksacFqRVjAof0skw1UfMqHjZRPyjvCflF/Jfrh8CdK681IRmE0WRKFMQEXoGap8ZVRWLiT8glVPIHgGRk73Aa/EjyycXNTFDRpGUUseSTmK+wbRrcT5WI5OQYhrxfky2lanRoxW0vz5HpS/owPs2NJ80OiiHuZpQolETPWjlsU+YWVI7hE2BnxjayPw5qhSS6PJVNDooh8wDKaRrG20saTRfIdulIxDiwIW1OMMaA3pcQVIJ077amCqN2VR1dEjQqi4AeP4QQyny5HhMiLuyptwPaYFZCt0xoOKR+2JWEJI7oeL6EvFcntiDOpnEQ5jArrjbiQqwU9iVsSizm5khb3MTO3qIIvaclcKlQ+X6gIJGD/odQC0XNHo2DTYkmLR6Kw8DrlFlrEB8qn5KHyafJOF0XBCEqsJP4DNP2ICg7O8bEvZ5RUnBKFWS/KNapoh3iHizJ9oVBhC7h6UHm/Kk7kw+2Eu4TrBir0lApXcT2PyUxVvE+LCdBPqfwLFSn3UzgYShlv3SiuZwxWUNZnpaXzEdztGmVKfBwdBV8KKLWb2HKmtxnXHK7rMLFKxFdclGGPSqarMVH2wHtois0GSGfKx9X0JAQ3a/SuHTmtjSJ/PHiAijiXHA9UMrkWtNITRtl+q2CRsGziYh3QsyCsJSiuH32DkUgX4+E10ggXIVSjmeOPxvf3Llh9wixH8WdQGY3tgcp8TbKyKPJB7XFlEHYq1IYcOa1X385kGGmS3BJL+vZjFJaqfLiSRBD8YfOKF49gnCCS5Xx4ivJDKjR1yXquK7mi+/OjiOsiWa2KAxFvUsGtnP4393QhW9NrmDCeZls0dk/HSujXRTELJMNwUkHY1OIAfVh0lTe3Z+IodOBDbHdDMSQi3w5UJ/THHjOrwnJ/0Mgg0k6M5t0VVttFFc8zwd2p+CmWVGxPx1SxB98zYosu9FImlHkfiLA7FbRId1YFJrw6ij4oqcApIkbJtyBsNKHER2EiGbVUN5wNQDBd/8PmL79VCxUF2drHOnqH2dTqptGJC2HpE5RPq+I1BJOUvI7/Dvi2LVFwf22GbMLtl5S3q+kHiBwD8xzlSN3O9yG4v6N33fChUxRxCdgETKw7zRtSSZlOlXdEuATvEjYfcg0knqKWQzZS0a7SkgyDqpWlQU3wTklCT0Vh6fu02CQTZbiKSynPw3vsxDyIepUupdmTVHxARbgH8RUVs2OJ7alR5J8vb1LBGT6OSiwvxpmETS6QwNqJTdfRK02MBjHgTOU9GmLbCe9xFbenub532Ol4Il+rjSUdeDcKvRzAES3Sn2i6hWVaRq9KaKFHklqwCFXSkWOjYGPFbAFZSfCXtdXdnAgP4y2K18miMzarqKjtgBELydrGkhcyTaOw2nq00LAkSuA1rh+5HsG9BH/EecWJRGMaBcbJbC55C4dEwStUjF+opCmCP8Q/mNyiiINSGB07SyM1Hdp8MZXn9GafWYTr86jpuEhrhnXAMSmKf1UgynFZJ1pV0Fbi1Kd4SlDGbxUraLt2UdFtfJlmmwh3dyX96eKE3YijlLH+XcQk78GwTuiIEci0TtS9JKoTDDKNCVEnCGG36Blh46htQG14gtrYc0YoijCBDO5SwkfTpv9ingAsof6LacI7JjtNYi9qTiiKBhJ0KjRcjNGnUcQN0r7CS1yRLy2y0I3y0EU0PRqhd2nWqfgkXl1REOOI2KDwlkEnSv6oRaRfVCI29P5d5A1AdSLXmoUosZr1pDlO9fov9GMd9WEdXRFLFvOtUWgtWtATyObSdF9IcjvvADtiOyeW2IYoLJxTaYleHVo/mrLmVYbWskXEBNJbnMgnCaoT/CHITX+1WXWvskJfBPCJSF+iyVtU6JbXN0bdS2FyLGlBpgi96uftNx6jiKn/7IVihBUFkbyOOKcCd48g9LDDHSXuNCOqICDzRgUZWDMqVU7HvwS5GVk2rtR3Rdogwj602Z/LfzWNO6y+4YXHo4jJhZZ4keC7F00hyXo+XBpLKrBF5J2tVEVjevgoHygJZ1fGBXAZ6fTBcxSXc93PNU8VryBWcGUwWUFF4LZFxC9D+Ra9EJdToTL6kHi1d75FrnfBZO6TeR9zn6SFnKpCUdQihpWJyj4V9ommLfCMym9ILRAd2O0zlIHmyRocMax6B0nJQmMEEfzYSflzb0I2RFyJs5cYNh1NeanEz5NUjqG8vZKBRyTPi0g0Yg1gsnpn1oB+JNHxIZ0bS7x/HoUlvKJdvTcVtW0OsgFkF7hqjTURSqLAdjOjuxtpzosltqxrhIXjKFtSoc1sdZYKBiU+IiXSu0hEwk6mVldjKtLpVMwk34WxpMWKKCxdS3kLFfYT4nFGhvj2bQXfhBDJpXg1luLvQtuEkq0TjGv+MGxnEOwCavmqyGIsCi1rnXT4K4iEbkZUFOkcGmtHDtHp4srCTflDQWi18sUEoWmTn/RVzCUKQe0OTTP3heaczkhoId3KFVcWScaltolrBRVhexyoYk/KeVTEN+CXU6Ey+pDQQlKLnBaCTLTU5COuPTlVhaKoRQwrE5V9KpTRDNT3TIBE0DeB2yhLNXkpQpvE5lhSsQM9oSIQL7YIJCATldGHRNACokV88SATe58LH5RU4BQRo+RbKCwmKvFh9r8A(/figma)-->As we navigate these challenging circumstances, Element Exteriors number one priority is the safety of our customers as well as our crew and staff. Going forward we will continue to adapt by taking the following steps to keep everyone safe. As we all know weather can be unexpected as we come into storm season. Element Exteriors is staying ahead of the curve by implementing the following measures:\r\n</p>\r\n\r\n<ul>\r\n  <li>\r\n    <!--(figmeta)eyJmaWxlS2V5IjoiZVQyanB1Y3NQU3JhR0JyVFFwQ0ZYS044IiwicGFzdGVJRCI6Mjg4MzY2LCJkYXRhVHlwZSI6InNjZW5lIn0K(/figmeta)--><!--(figma)ZmlnLWtpd2kBAAAAXxwAALVb+Z8kSVWPyKq+pmd3Z3aXU0RERETF2dlld0FEsrOyurK7qjI3M6t6ZkWK7Krs7typriorq3umV0REvG9FVFREvBCQ+5bbAw8OOQQRRA79P/x+I/Lq6ZHf3M9nO9578fIbES9evHgRUZN24jSN9uPwZBYLcduW63QHQWj6ocB/XbdhD6yW2d20A7CyF9h+hTeUtt1tgK4FzmbXbIOqB+HVtg1iSRGDwCbWstJVyINg2/EGvt12TX650nVDp3l1ELTcXrsx6Hmbvtng96sZOWi4XfJrOe/bTd8OWhCdCyy7aw8g9lqDh3q2fxXC9arQt702hefNG0mKLl8BLSiQ5nCIoUPk22Zj4HaVmlDMju+EbFF2p6PYO4jSGGoWqkKbPYZSx+0rUu4kk1Ey2fePxtTput2Hbd9FhXAbqp4I2rYXUWlDJBqu1evYXVpFWma3bwagjE3f7Xkgak3f7FCvvuG6bdvsDlzP9s3QcbsQLvVtK3R9UMu0JcqVtqNgV+122/ECkms+lDBJahbO+fZmr236A89tX91UIOtoqtuwGzBOqXc+tK+wS7cFbcei4PbgamfD5Yze4XTRWFdJL2yM48mog1EJcZdnBsEgbAFuk7MBf/E7ygdkw/S3bbZldHrt0NFzUGNX0ZONns+quuW23YJbajubrVB9sxzA1opSg8MXDbexaYNf1Z/k7BpmwW+bxD4XuM1woDDArbdMv1Fw5xtOs2n7th7BbfYVq90LtD1vb/UouyMww15h5AuqFRAX272O03UDJ2QTd3pRMlnoyVwJ3LbDCRZws4aD2URr7CokshCxVPbA7IKkCObmbEBWK2RQ6rhqFdWdjqlGtgQP23JALDuHWJ3BMBrH2uhYXr4dWsreTYfDk02nrRoJHTWTNXtvLx5mHa073S4WbdAyG+4OKkXDd72SlU0X/oEJ7DYGG+0e+2VsmNb2aVEtjG8sLLUMll3f2XT0Shc9D66JUrbdHUWgC6HuQwBHaA8s06Nz10tu0HR9Sy2dJYI24uF0Hi2S6QTf5AsELWNaYU7QEsN1tu3SyYzu0eFuPO9NkkWKb3yTwxCec8VuByAkeoTlT7sY1nSSLuaVScNkQi5Yr7orOybjgYE2MpPWAstUA6g3gdgY6C+WMkZpLweL+fRabI6T/Qk+KMAEVomjApd0e2FGGlrZimZAyceHoajZlsFDPdOnyDB9391RLsRB1DRrP9Rz2og5vrJ2XUNtTRM220GEUq1u2H2b1TJHNTam03EcTdxZnFu23utqz0Yf8VmAZQ9aBr2N0DcVbVxRDq8mWo2sNZ0nj04ni2iMz9t2k0oVw8EJ1NIytnoBorejZrT8uh/PFwl8ljLXQ1Xl0w03DN0OKKMzPUpj62ieTueYnIbdNBErUCEs3w3goo4PWtpXbfos5hWcgc1HNeWZGApihwXfAF/3VLxYQmE5bVDLfSyB6byTzOdEL3wL60/Nr1QEliPChN3dDDn5RiNKD/QqMywEU4hE6RpSrUTtSXWvuwmR2PJsljLoszC8RhNFzb4xm84XN3tfzXJhAnQ6dzGRC3achmpf5oKWnZu3HZ1Mjxab82SkQeraISvmLDtoaP+sld940WIRzyeogpbjKd9CwFKBS6rJOlpM/ThNHgV0YSLVHWWZoh+yoODQJ+M4iLNBweB+4GbhILRNzqu04BN6hrFPY1fuWgyftdDueK5vqj0azqxhYKVFXJjoTFQFKfOYiKaj4TU9P0VnW4hHD8NsqgcS20HowLygtbbyRqifMZu2lVaypkfoxDzTPWviXLewdE19tnWULpK9k2/1hWda9gALVCcX+rNAWdtQIQVCJBOB87A9CN1BFs5hkgmcFytXW6WIG/B424etB8zLwMuer0a6gYCNsma1XbX/1x0OJ6pAnHe7A3i0UhNmEzCD0OnYiFPgZcdFYjdQYzA0rStq+KrFLRZ0XVdg16DakuZUwrIMLQ+DoHMhl1NdXW34JlfEGuq27av5Z+fA9l2dXqyH82iSJmUfn4D4iSwjHCAmIZJme7FoOAG8om+DlE1kfygNpChIA5u+28HiVaGpVhHlsalekekotFSRFGFo2esFLS3LwFZKSY61Woo01FopKJDOMSvUsgxpvZTkSOdLkUa6rRQUSLfrjmIaoJSD3XFKmONdOCXVkBdPyQrUO1VLmTQDvasqyzHvrgo15GOqogLxsViajjVgHbjHYZtHem92sWJV/vx4O0qRHOv5RSYysHobjoUKQaCckUixKqzBXVBnSMFwPh2PG8lcLwdgZP71LZY9+qaXqPoWa2nBlRCPsPYWMertKx5Cm156FhC4ASpObvYQe6SR4lSAxkCvCDmeYhdTJLKJMXYSWZ+LNSH38cfYxZ9ahD91vdng4xvg5An+GD5E0C4F1/GndoA/dYUULKYzfDAkLUIhZ1O9GKBgdKLFPLkh5PLhpUvg5eGle1AYh5cuo6gd3kNh/fAeCpcO76Fw2YvmCKPOZBTjO2P/KBkJvwK6nudNqDyOxkcxvpFHKod6PGIRrNSNDmMha3vRYTI+gb5MGaFBGABZpMN5MluAq1G3H82TCJ8cHcbzZNhM9o/mMC1icpb+C0yho3ZI6bYb6hgIWjVz+tNgFg3hIKe+9bDZu5jPbFeRobmRZcy3AGhycjnAKgLyaRx0FI3tEcFRzW/1ayuapVjn5SfwXJVDSxSDnDE8G/ksu16DYFBwTKcsU4XaJYgw2E2QyxV8L7d7tVtIt/AXWRf2TBCqP4EyMian0HLg02odSCRwKjQ242ihDPw/0kMKjSphXfaUStYLw/ICymvsDUrVQZRL2WF0OXC6zExWXL/RRblqNn3WrzW6ahmf6/Y67NI6TkwmyvPYKzik2xq6vL2lyzuQlbO8YJoqUbto6fJO31LlXYHm7/b76kz3GC5MlI8NdtRx/XFWsMPy8Zgcyp9gWR32+4mB3le/reUElD+JOyLKb3f9Lvv3ZBoF5XdgZ+BUPqURqmT/O5ttk+N4amfT59b2XQF8DeXTtrFPovzuJnIZlE9v6fJ7WrrdZ4Sa/96HdPlMT5ffx2wW5fe3mxvkf8D1VPksP1TlD3r6+0vedpd2uqeN8IHyMkr2814/bJO/DyX5Z5sbfh/l/eZGn/wDKNnvB/sa5zl9dAjlczfaO5yfH0JJveehpN4Pm9stjuP51pbK0n/EaqqF8ALLU7xp9XzqbWCTJG8huLFsNDW+3cRJDWUT5WWUmyjvRdlCs2zPQUn8rZYeD1rbZH/aLXeLfoO8RqUkXQdbMEp3y3vgQZTelvcgcR7a8p5zCaW/5V26D2XQ3urwu7DtWtTvYT/gvPQ7doOH2R2U7MeVznaH8qvdtkpJHu72tkOUP4o8gv16IcoA5Y/1YXCUL/KCkPIBSspf7G/75CPfa7Hc9XsbnPdh0PGoPwp1P+KwqzLSPUwT52+/j2M+yoO+rk/6etyP9LeVv1zr+6GPcozyMsrDIEDkFWKCkvwU5b0oZyjvQ/njKJ+Nco7yfpQpygdQLlDSTkcon4PyOAgQs4W4jpJ4N1AS7wQl8R5FSbyfQEm8l6Ak3k+iJN5LURLvp1AS72UyCC4T8Kel1Vc9fDkJQv4MCWK+ggRBf5YEUX+OBGF/ngRxf4EEgX+RBJF/CYTq6i+TIPKvkCDyr5Ig8q+RIPKvkyDyb5Ag8m+SIPJvkSDyb5Mg8itBqD7/Dgkiv4oEkX+XBJF/jwSRf58EkV9Ngsh/QILIf0iCyH9EgsivAXEvkf+YBJFfS4LIf0KCyK8jQeQ/JUHkPyNB5D8nQeS/IEHkvyRB5NeDuI/If0WCyG8gQeQ3kiDym0gQ+a9JEPnNJIj8FhJEfisJIr+NBJHfDuLZRH4HCSK/kwSR30WCyO8mQeT3kCDye0kQ+X0kiPx+EkT+GxJE/gCI+4n8QRJE/hAJIn+YBJE/QoLIHyVB5I+RIPLfkiDy35Eg8t+TIPI/gHiAyB8nQeR/JEHkfyJB5H8mQeR/IUHkT5Ag8idJEPlTJIj8aRJE/lcQDxL5MySI/FkSRP4cCSJ/ngSR/40Ekb9AgshfJEHkfydB5C+RIPJ/gFAh6sskiPwVEkT+TxJE/ioJIv8XCSJ/jQSRv06CyN8gQeRvkiDyf8ubj/lIrRbYrsUlIfMUy2BO2YlmMyY50tibTw+Zli2m+GtsjKe7Qsrdk0WciprU9wvCqOG++YD8hBkZ8q9RtIiU7gqyr2SMo53FpNEcPYIDqJCrC7aNdC49iEbT6ylI4yDZP8Bp9gDpHRLGUbyIkjGoeowup8wlkDge47Qb434A9PIiPlS3Rbpq5TjZxeFsSHpVXXrqZrOnAmGc+/9tcojEaB5hbGtibXdOzAlaBndOdUYYF5WdbxdySEMgezamTCQXzLNrx0ma7CKpkqKOIrurPi+WUiTcqXhYLgN7ku5N54fihWIlUUa/IVYVER4gSZ6w58jbowlkODk4rIHgghYgrUPWialZERfBVy9nL4hz8ynOGVBBT9ZTVoA4v6fMZ7Gz2aw9Km6bcSxNVSNeIm6PD6ePJBZQPFzwwYgr8g4miB0YsgEHEMbStfhEwGH2IG0nk7gV0zKANyhpJPsxcGvI4MHptHIi6mR2tOISklVc+Wiw9eFBxNQ5nqdwMVlw6kOnweaNlLR7HM9xkxSHEYyJoCBrY3W9pG4x+jAxboXH6E2K7UUu7Y9PZgcp9hW5PCpudlPsKnJFf9ZHgxDBdqvsWjG6l0m5theNx7u4IGmiIhW78twBZnkO8Gsb0xto4BVSrrcqIiyVXdzcjFJxBWeZ+RgDyQ8+tY2sW8JYgfvpXLwv5PVktOARzGDdVRA1EoUl6+TMdIiTFLiVvWSeLqzcNOjzEtypyi9vcrzCWB5ODw8j9CRbpuW5qy+0GZFeYvXuYWTKcGjqLHg0Os5WwHKjMJ4wjDlOkhijlCWSoQ+cynRG7Vgx3XhxfTq/lndhAgePxmhspFrMO3J2PhmicFGIYUhaLxW+lMHJ4e50nMGnikG7iFyazkFSAhg4RnI1BfT2JkaDFQnD5rB59DMMNTNyBhlSCFziYOzonAL0470Y51cM3ljbS8bxNlwdbpmqStWygSbpOa0IwRHHUHbVA1QGnyLjkPU8lC6NE0ST+Qn7EE6Do10eX3ehRoFYSM7XbDrBNOuGVo4me2PelU6gU0VcTdJeXhWPEFLWdK+t/PtOlGL2MkMNc6lGlbOj3XGSHgCM7bK34TSMo8N22Ts2YtzcSPaAA79Sce5OUYlze3tpvMBs1ubRKDliUKyXAW8JRRHwlkPGOeWGzmRviglQaFtCjo4y38JC8BCwpqxoxMfJML/ezq9ZmIer+3Vp4WSkzoqGkuHmhSd08DX9oZ/HPZ5l9ceWtTNQe6+8qRFh1MkglcMUZ845m8cYmDOC9ZK9BAsCc4yvNOZrEMvpc4ghXrayQgLgPRA9UadpgWuq/E5Lki5qDHL5zVYN10MYR65Zz9hCeSkT5PrLHbPbU2eQlawDG4hQ+3PGHae8ZUUrxah5CYvnZH3fyhuz7ClIngHQYyi+xBnLaQzyt8ez6uZsFiNcqFVi7BZihfIXMGUpsnJ36UbYcpUNlRZuI8w+jvjqFkPg0i57PJXBjrpXMGxs1vNFgD0aTpsKYzU92tvDTRScWW11CuVZArdWRdIzF7X0eJ8roMtNETMFFkkPnfDNcElw7tGCgZW7D+qx+GA4hHh3gosmKVag0ZzOh3Gg3rewoq6lEK9mfelvZmDCcJqDrm1nd3dme8e8GoCQbbWz8L0D0WPBHl4WMuJzv4GwUSyO2uToMMCygjFSsSTq2VJCWpJqaUBXRPDdP8JKnGfcyjCz5eqMCxSPKfeJtU0EH0xCLWtEFlDF/uNhsWOWriflrwNWBZbxqW0Crw+IyCF7zLso7QXZYy4urnx3mxIje5iv2XjEVsf+Oo75uCEDtZQ95izrsKTwKrFUh/wsGsGdKgE0D79UgMkxMk4hxpRSkn2Ch7nyKgvflKE5u17diA/gYbAP8PBo11a3MhgCnjYGOy0bi6DltBsDt4lHL1bjpgw33fr3DdKcD4s2I7wXTvbNyT4MhbwSUazCGgkeROZ+HvBq3vhoP5lk384UAyugvzrtRkev6U56qs6Px9HRZHhwiw8OkVfCrUHCpdXcgKzxNxvYmSeoML6pNkVMqSrDaB/z9uzZAdILsSwMRWjh/TPYM7+BfZGoVVit8MCCE31OqNinRQ9OIiyZdbHEUoueUzrsckbqiufiKvqa2h5WNKXFP1RmvqsZqSuehy+LvWCtYHTlDw8RJhYgzilCC5+f0uX7yFtRatGPYJEXufL5gtGVLxjBleDo8B1sJfK2CqsVzEg9L3Jw6PbtJaerN8qAZU+YjnBwd5wRamXrEHEB9RdYalEjVhHCOh1OLp6VanWbXzqpq4MRNO88JdBKzbJ5V1sThr3rjFArbyJJqzrm3VVeq7QqKd9jclpXOfCQaH8ezQ7oJJiNNfHYm0RacauQ5tfla+JxN8u06jZXksPVorIxKD7+tESrtQ8TzFI7QQGVJ6DIOF3dSVUkzs4Na+KJVV6rdBcI5iF2v2toGyrfVuW1intQ/IQAkwEItV08UTzpVnL9iQcODZk4R07Ek8S3V1it8JCWWNFMPFk8uWB0pa959QOJp4jvKDldHbCLCqtVdEA8TTzlFmL9QVjU9POfMzxdfOcZoVbuUW4hGoi7xVNzWlf1yVYy+seK7zot0Wo7uzf/buOp4mk3y7TqleOs7dKAMOx3n5Vq9auI22OPfCpeKp9ecrr6YSjDUloEhe+p8lrlR7lCsmPSi8UzSk5Xv5Ce3cXCxvn0e3NaV/2YGioj78uleGbO6LoXxSrPTXHvJ78vo3XNANF3hI1J/XoDHiWeKb7/JpFWfLFe7UGesbxJyh84LdJ6EVs2VQBKsQLF/eJZpyVabXdc5BIpbu3kD1Z4rTHUhy0OAlej4lLJ6vqR2j+xu6yIezJSV8RlELGylOLyTSKtuMf52Yynh/FifoJrQXlvVaB19vUU5UJq3XdapPUOsPqzn0w8TyQFoysfUXwWP7CGr1V5rTJWIi8acTuGymGV1yoT7osI++pQN80ZXTfTBzhaB3fE4sdLVtfP93iR0kEYbiSpCvYIy+kZoVZezPVETZuIWlLg3qhgtcKxnvgN9FAbNf8e2tdVxy1IEerU8hUvEDeUcAv3MfwZx4Y4SXVOpHpZplGvlOLRJNVSTx/pCAvUnwBVfFA9N75khMfJ47yGA+ZJ+Ser6n2djmH3fylXTPZwaCELmU7aTNo5QLTxU6dq0f0bi6NoXNV4mboSylQw5uE8ZqjACbOq9dNVrRZ8AasIsaKq8vKqijvHHCPkSTwpVMTBGLt8PHo4nk9R9YpqVTd7ktXPwSM8PJytzLxL7OG66GxtExsIuy4O8EZRqUaIT8UjuFaqyIq8dIzXC7odhvB2KX9JIvJlx17mcViJPh4zZjhLqhNogO1wUVT8SllRuo1ai1ievyoRAJHMRGMmERjtr8npsbr4wN6sJ1GB/Hp2T9GIYXq8kqNlzOpvSN7bIInEpjudteM9zF6ZHWAt/eYpBZ/R9CaN3yo1NqaLxfTwFii/fbPOrYBeWSqVNQlzDDwxYzBcT79zs06Iree0yqtoLS4xjDCFLyLiRNgJuL5+V2rfhv/qKxCsX9hOef6rJAI8VLNZUZcRr5Z44yllISYANxOvroga5SXFH8g4Kn5H0sa1AeyMw0f5u5Aunn6GqtPB4XS64I0LPnutTCYHcCteso4DHYsxXa/JxYEKmGXF6/KKEGusFP9lLrZVeCkrXl9UqK2rrPirvIL7Ril+Qy6u9KfJH4KwG6h/n0zSogo2/SPwujKX/IlMSSk7vFviLUuxp/3uw/Iov0yCGapB6c/kGHsibJStwRfj6QtfwpKuPr/2cY0AB8/C0huzKQ3YRmU63y+xy1aqykD5XolHsCQ9HSPfLGNlNxrVTHGcJwH5W6AZTPeQBqFXGRTEb4W4O530ZiNs2RnE27JuwuXgH0OljVrhYcEPSxl2AwzhHRIXFnDEg2Q8QrcayTFCA6+T3llxLg8BL54f4+qeuGjiXQSaYBZRqczbhIFLEX9oty7eQ//X0SK7yHqtxKBTBVIchT8gYSIVOdAtfBtCXbTwQFc2HyaHMdIK+OgHqpqdCAz+VyvqgxJMXlNZDB+Soxgb1kTxOL1gwpCk4IOPVC6AdO6GXO6j8pY+t1Fowu8+JqPsJP4hifc/WOv01tVWOVA/c4wl7GQTjBTbBlg1uDdIPBJOj1VH8rCsKl4n8WiYVfAUvgBwroCp+nheV3bHKceMF1o8MJ7RMMtbsNdLPDyqLSHr2zreHxdwrx4mt32q1yt4kNQHf44ItpKfwCvcPoLdyJ24YVP/xCYVM/nJQr63d6riU5UJDA6mR+NRcIi9xFSPQnTTT8uU+YTOLp6PR03FlqeKLG3CHH5GV6FzKl8vKz6rK3bUM0VDfE6zOtUG/3llDgQVdQvj4yl0ptcaZpf3CF/IeRVvvggHzqIx1dfxPJqk1mX09Eu5XjzqZwZax1OpNhAnqrgu+ZiUXwYMug+3nAdHMy7lLEoxMpncLhl4mT98RXc3y7KwHjmoBh5aC4A0Q/g/AL4qD+A26n0H5sN77LX4JJwn+/tYwJ+S4mvof8CVvwlPmEH/6+WCrDhOCqeT35DHU6xQ+xij9w7wmkj7fLO8ia7o405I3/DEVIbPCUNXpHAnWSs+sVW1sZyUn4YQY23LiujUIsbNVVFRWcO10+Oq36KrS6WzldFiueiLqSDxjleqFUlNxU9DqGJfNUpJtRendtV6qVM2WOnFLV2ed7lZiFQwTd6X5hIdNFfpsuNbrv+1s3HkXNngmRi9npmsoWOvWNq2r264ps8LUNHrbnfdHVw48ieduGlUt/nyyoZ7BXfxNmjDC+5DUQt2nNBqDTz1w7j6djkRBm8N+QCL22EJGypp1tYnMJUtdFG7pmHo10aVdsLgRj+Jr9Ot8bAxjCbHUcotFvkYwhUe7oScYUcaYzzH0MNADMU3Yg6U90s1/dGmRqurfxZBKP0vI54hpK5XoO3pUBkM5jMq4gC7qDI630Wv3IxojZPhNYGHphECIR4n4ZX8Xlu2mBBpTDB66Gc7GgKgzgqMUBsDMVHPpZC1qaayFuTBdJHOpouMNdLr0Syjazd/rOKKUZ9qLtP6VgCz3OmdcjFldfUeXCS/qr146pe7mR/qZTjBiRIThhc6ndrX4cD7sXbQJc6Kmr3PwqEPlfE/j1vWNDcpHkRXp7to6BirBQ/ja6OYTtHVmOeQhGLhKhOniMASz/60Xm7WFGFX4ur0tBFShFt5G5qao7fr4nacqnB9lum0tC0wvjtOyb1bGAKf++LCIlfJ4ZWRvyLlxQCdQ7zEReFDRzFuCvgmgCWMkXSzyUaGj80GrxEUaFumnXgRjQhhyF28VSDgx2NuiPQH2LYDQ8N+wribvcE6klXTI3peU0RtUiIia5B1jjfnvyolniuBLY7lcootMxpnFl2JhkPAibpYTZmxBLG6T0LNWs6HbPZBcS7nLWwwmAQlfq5Yn8FqjIVL4rwis573+aMLsNh91AYKu+uGvehkPI1GENyRnrJXgo5+TcoLlYEUpvkG7pr3gNTH3oWhY7x3KnQn9WjgaDw+cY8WaTKK7clwDG+Y7ON8i3FIcZdS9GBCZ4QpuPt/AZ4aAADNmgmUVdWVhvd9VRQFFoNAQJDhAYIGUQGRQaoe1zFxDMGJYKIglGJahYWixvFYQAEKDlGxNWiXCk4QccABpPAaEVQcAGMrRgxG7RhFxWgHIg79/fu+V167k5XuXqvX6rc87v/uf+999tlnuOe9IopyVmZVb97cu3Xt8YN+PmXahHNHHTd1/A8Onnr8j6cccviYo44dZu2twwl9yssjs5yVR80OnTxh2tm155xnFVHl5WbWwtpaO7PIPJT1tPJcs1Hjz6jND/zWokqCj4s2kRzaCw+67IV160pNigtsbtRYXt/Zou3RexUKGPWy8lbNjr9Q/TW3Yrxd6s2qp5s1fCdwK2vtuXSw78G17WidEHHnK6C6yKCrdYu6Ww/Lk2Qv6219rG8UWe6yK+fMKTWZlel/DDSyPW0vIjRE3x89+bTJ50220bVnTDtr/FRLH/cpPfaLBg6ZcmE+1eZL2vJSjs3opM4e2JGrD5sPLLNy11lFe/6jd6dSbVu0l1noYVGUq7MLB2aZqMjkctP/E5ODiWHKYDo8m2XKKi61sNOi8twMq9szy5RXXGIG0wymcESWaaZoIyyqgKm6NctUwNgeFjWHWfBBlmkOowwqcjPt0t2zTCWMfCphDjs4y7RQbsemPm+clGVaFn3KYe64LMvs0pT1TAvXZJkqfJR1C5gzlmeZVmLaWNQS5vzNWaa1GLLehXnZGGWZNmK6WFSVq7cbO2SZtsrgU4ta4bOpa5bZFZ/Q0aLW+IzZL8u000jHWmVFiyhKl4iVlojlWGr99d++0eVRiKIrWCmRTY9sRmQzI6uPbFZksyObE7EK7c6obBHbbHFkSyKtnDKzX0dR7cDhg2qHDx4ybPyQ4bXDTh88ccDw8cOHnbb/6YNqTx808LTBQyfWDh84YWKt5Q4YOuTAwfub3R/Z8xE79rMWjx+kKBF7tlWzQyafc974CeflD59aW5s/4pxzp9ROOO/Myeecm/9DuD5fIs+bNHXytDMm5S+oPe3cM8+r7Z+vPXv8mWf1z0+emp8yafI5tXk2wLkTJtVOnHZWbf4Xk6dNzZ/ZFGnf7+zg2RaOnsFOSHfwPFvZ3jfxHEuOYR/7EfFfd7G2sP2NLSzPbCvT//5nW7g0wv/D4ed2q/g7n7Kcj1Uj+m+lO7DZP1oud0ff8GlD+6bNIhaNJvzv9HHw5LMmljpwPLDifxO9vDSjzXJ42Y7+udnj1h+W7oKG5nVmWzjeTjDC2SWnsxu3H1UmJkOfUDHOKsZFbXLuXlYhKj0T7UcWtc3V2bYJWcbPxJ4W7crJt/qoLKMzMeluUTuY6nezjM5EG2tRe06xdvksU45PaGdRB5gvJ2UZnYm2i6LNsPeXZpmKYjSdsG9uzjLNdVJ8bdH3YFZ8k2V0JobdLOpIDQ7aI8v4mTjNok4wZ1dnGZ2JSYeUGTo+y+xSZHRaRvVZpqqYwW4w2+ZnmVbqp5/qNtPW3ZdldCaqbp1h/rQ+y/iZ2NyiLjDvf5Zl2orJK7f60LVVltGZqNw6wFzRI8u0g0krWh+qB2aZ9uSmiu4Os/w7NegAE9poHdSHpw7LMt8jWroO6m3nmCzTESYdT721PCvLdILReMqJNudSZyxldlPddlrUFWbHzCzTGR8blfr8cEGW6VL06Qbz2MIsszs+8TF6z9Xb5hVZpiuM3nPdYQ56Kct0gwld9NasD2VvZ5nuqgFvTd4/1ntrlukhH94/PfC5/essk4exKkWblQypzDI9i9HKc7PCmnTmikyv4njwsa93zTK9iz55os3jZP6W2UP9kHVrmA/SnVVk+shnrGowy6b3zTJ95UMNdoE5YECW2RMm7qL39qx4/vAss5cY3ttkYL0OyTLfhzF8GI9dfnSW6VccT09G+uioLLM3PknQzQGfn2WZ/jAx660546k7PcvsI4YMehGt9ZQssy+MVVrUG2bjhVlmP2XAzYGKJp9fkmUGqDpUlAzCjLosM5BoymAPajD7qiwzSNF+6SMNb12dZfYXw0iJZh2vzzKDi9H6kEHnBVnmAJgk0aqaFecWZ5khMFpVGs9By7LMUPXDeKqINuHxLDOsyOxBBvUrs8xwMWnW8ZtPZpkDxZA1KyRpvzrLjCADrRCtqmdezDLVqttYjxZmv5JlaorRcmSQvJZlCkTTzLF2kqO+s7NGwmjtKIN7PsgysRgy6A4z9vMscxBMwEe1XvlVljkYRrUuz83ecmpZljmkmFtlbnbDxc2yzKEaD+ugIjc73rcyyxxGNGVAtLh5qyxzeDFar9xs690my/xAPqzEHjAz22eZH4rhPMjD7OiUZY4Q4+OZHe7qmmWOhNF4+vJO36tnljkKJslrB89u+LxPljkaJiZaFVkv6pdljlHWrBD6Gfdo/yxzrHzoRyMdNjDL/Eg+jHRPsj5+/ywzSnV71+vWcMTQLPNjoqluyq1XdZYZDaPcWtPPK3GWOU7RxnoGDcsOyTLHFzPonfMbTEl9gtQMpnvuCru2MsucSCehiyanzqY8kGVOgtHk+Je5iVlmDIwWaAuYwV9lmZ+IoTQ9uFA8fniWGQujCa2EeX9eljlZg2FJ9YY5fUWW+Wkxa33Nu/B3WeZnikbRuudm2owOWeYUGI1nL5gWB2aZU9VPK6ts0SL3t7/ilHXYvHu3B0d+ur3nsKcGr9lv2Nc7hh7x2c/LrVlDhZU8/OpZMq9655KPFpz6/HONq0cvHPRUn9lTVhx+AeY7WsLavrl/fD/VzweLIr+ZrotyVvH9I7l5xo8WjE/OklkZkO8yMmd2X41ZixLoLrC0YFuGAOTVBPSZyVcmS17BU1qB0AsQr3NQZvGN2PUaaeHnKNqhCP1QlKHIFyx5sVDGDQfwMe022sco4pccWPigYLEsAubJYhTIcHZRYV/UWPw+sU6vKbPkOUB+pcXzXRL0UAf0hJyLhc2o4fTmQfLKAkMCxAsIJjDOiNyJoXVRhmfT1QEo1mVGBTAu9jeR0rM4hcscWDiRkCuk2JekF/PQA2J+gfgCM2EEwgDaD2A/UypTADPpfb5LfB9xYPFa5Nso4k2Yd8cfaWcSw8EtNFk8iMJwUf/FhKwhR3YJZYlnwApYK5gPsZhOQHsZQDlUYySKkx0wR8jRNbkUjFpF3nOZ8xKImzP80IVIAj6SbcQPJzHYFvRBOCQdvuTAjA6ZOhTK4HkekGF2gRoCyM1YeIwlzMFGIH4Mm2doG6R4CMVW2rW0rSjC0Q7S5NYWSAUQdoGxo9FMr7EEUyQKfAEWCGZbUSi67Y0/ku74NS2ycDE9LSZOshxCQ0o+KYL4JiglGv6Mn7aDNZbApUQ4EsqspFlYjRQ4quhl66vTONaskIJiX/Q6x+dmKfrrsQyDM4APLvdQ8SagBRfugBpCXW2LAwusT9sLRX5XQJeRLsPXFMLBm6zc5iMtfhpF+AqX++gbZbiVfvKdcUlGFIH6Sb7GxEGaFOkpmbACa1vogBlkqQE8jr2IwihM+D0PkupaIN+WrbkZ2ZnktAvz7PXkTsLqFFDUJqBgm1QKG8K8aQEIhAeJeDMrTQvAXqcAn2Lam0AREcPJJMC6Cte5pAvWOsCSD4j8ES6hgkEpVWSYVaArAAstZcJwzL+ih39nRbAw2Xt0uRH5bDUWjwLYBPZLl/Q/xIHZO+ShnakMrQ1KZKgnugC5GxVrSQbeD0C73xijbZPTKYDpOCqs1mbMZgX4hrBPUSRvAQaQGpJoqSJ+lDjPoVAlwjIePqIxcCSKUxx4JeONUrQkxmMokOSRngBWXhy8QKiC/RCrOrosnQD2Ly7xP8kBP6QiL+IEsN0BWhXa+HyKINb09YIqgcRPgLEA5iHc5pIREB9gCR3GOgGUgTEcydi3iACJshc2kZgPG5A8zoMmUINSpbThjUWJpJ8jHaQdP1VIMwidYewYzOYwLZgiCbbMQXqKah4UPeyNn+Scgm3mFWjhENi9NBRArI0a35ABrKuUagJWQWcO1lGNHyPvI7amw65EcblLFLMcWLgROZ9yOuD9Y/F0AIW2iS7JvK8DFijyzWoULxGojiZZQb8CnoBdO+Jb4EmKagJNAwHY77QAYlVDnYRhDsz+iNmFJGgHkpx6lLxcIQFMTJF5AOYWTNdLwTbUwWi9qYMxuU2zPc8lY/qNAz8PfD0kX2L+Eg/IeB7RBew8gO3igKitAHswFcOR75FROB3AtkhUKd8n9zuw+EnkYinWA14hq824tSRY/FcUjWJeAzC84niNiZ2HjXaKTXBgVkPbJEUn8lrNQ2taA1HCSxkQ7sQkvIDJGh6egHlDivt4IEgxql2ta47FFErrVkAnkb1Kbr7Y++BPPZI6l+S3zIHqqVcmmW8spPMWKEwTsFHV9CXweKPFm7HdbRXOq1CcsEpHgyThf+LArGeBv6NIsZGOe6/i9Y/8pJEqbweERpihBGmxSqeVJMHucWCmoa2VBYO28xtTuW0EvgJjajB9CEAxY0aBJDOGBUjHORMLDdzPQ2QgO2rSiuH4iQOwfehrEFKHnI0BsB+TeS6JttxB2l+HQtox72tWz+ME2Uq7mqZtrwEDzPan6WBQ9OQxHpB0Z/doL/t5eiKRbSmAPMM0lyh6OEgP8rws1O8jtNm0mgJ9A9JpyBOxBMJI+hKQvZdBicfqGIWmPLTHWcB9bHsG8AGsK4E0OdvPWJv9wK5cQPdNwE9UUU2Az298pT3vD+S9BhCqLTyNnKhc7gRoZGe7xKKbg3SfVGFhYwG30yQ7Mh4BXb/tI+RcKYbysJCC3uiS8fwmA+LlmAiEDTxoHf9eikU8fIySWUdSpfEOSB6Lt6XojuJVLJCkyxin09/TMALJa5iuRPGBFH8BfIWiPy7lbJfwM4KwXeK5LrFgtQIsENC+lMs2FO/y8CnyCUUH2Fcar8AoAn6BtGoq6cAwed6BMQEXgebJ+HoHFu5CrpBiBYAz0gfcibgCHNmEuc0BJu0duORITBX2CdUdgFylIMcAFPWiVM7U6lTF7D3M41+R8r/xcI1LzA9x4O8yS9SVgGesN24JpAsrT+cCoSfgE3n/CG9KE1/nkqkhUUDaYSWmDt4r2Hq9EfI9qOJU+XXjOPqixsZhmn5p+hAzVo5uqUhm4SgHPj3cRXHpz5i0nyV1bxbgNZwy8V9gGmos34Yk7ANAb7oaTjL7oNA3pDCMrJa4TLsDWJ7+G/ZEMa4rbMeRNk4Z6oxMPsNCbxNN6RbMdP1NdsU0fhnA9VXBkCh43QL07cjiKhT6wpd8RULUNn6GYALJvQoG0Pry182eKPhWpq9Z6bj1dSu85MDfZtYWi2QbYACBlNBUguWV4tSCPauKWjm+czATsIcwDfjq1sZi8Nytc+n+ehxJMJD4WpdYrHVg4U9Y/RmXvG6p6zGvZDA30dU4QNCB6qAKs49pusLF6wBMT3KtS6L3d8D1nG5l4QlVoUTyAqAIAFI1dsBAhqKwAlbNw7HI9lL8E+BV7BT2VUVZ7MC/JIV2suC4sxE8IImWKsJSHrCIV6Nwl008KMYmFB4UhXpxC3Wb4CJJHrZcWySQhy9uOwjgi/tizKiPrgJIBk0QgB818RdYNEQU6m3WBzK5v5BzwIcd8gR9NoFfY+tgNR0+iPNLUtxNtNd5IE8kigkOzA5DriKaAB/AaGpZAp5kMVt7wVOfSNi9pAWgBTRkQNhUAEA1Aeuj7gSa06bQPqfW4WLAG/R0tUsKcIuD9Jx/u4aLg0A8AkYmmu3JLlHcj58U9zDbbejGgfqzhhHfAs9JVBNoyhtg6/S+CY8TU++b8DBgQbXFVMwOVj43AdTJWJdYtHRgtoTe28qiErCQJrkbg3RwDlZPI69GoaPLFtHmFSxeRFrx/RmQLMNEIKylLUSxEYX9Cvu3MKt3iWKSA7PjUL6KIhQwf4GGjBsLDG0YY2yEEUh+i+l85PtSrAd8iaIbTe8bG003rCq70iWKlQ58ufkySzjc4rdRIpOHiS7A8YnpdkBMQH0nr+R940ArpVhFo56/AD2HcTLXgcW3IN+T4m5ARGwGzDGRlsDOF7jeAR0c6CC9/OwNoyOYVwRDFmhOOwxmK9HCGADhi/2lJ36sPrWRYxYiwE/NYPjHywEdGRCSDU3krxzACJTDfoxcgm+is7AXE7gGOaWargiieQ9MIpI093TAV2msLsNFh01ogRKZzCS6QLiS6AL+XXAtlfhYir4kQbmNYEi6e9KBxW+Rw19kQULJJh4k7yWYcgaQqsAqGgkl66TQMDfxcJVLfGsd+K8zYQ0KHTrxMh6QdhXBBML0IhNUZ0ytjRQTAdSsWESrNWZzJ8FvwM1OygA+gDpG1gT0203Cgd4EGjoBZNwE4g24K2ATIGDxwvAwD8+Tgy0CvEC7mfYCCt21AGY/pD2InwPv9hS6LYF0g8fEdnAoQMUOHBhe29tcUrD7HGjn6b1DqmnPxa+Q/0xsTbBe5QC+fdHHJZrgtoBKlMgkKA2BWXQh4F8hZyHXS7EGZhu17YrS34Qn0gV9+smrJJK1Diz8EattuOgXwvAiSmTsXyEB4VRAGILJqZiEGkA/2jhaSxRWR3hmyW51SZA1DnwdsUB5O2hzLoUJn6LpS1a6UV5Yje8KAMMrjtd4sZMb6wZqmgM/9MLzKPhe4EeEDaPdTtiQZEByFyYmsAp71VLL0u7GREHSqOkXgXFgn64bSboJaLk41QT4PKKDWadD+B7RBHQloVOzkSjsBphjeTgHOVaKwdT+ChTI+MmiIn4HxQbkThRhD1JTyakaEotHHfhh6RbJZ5jjIhmv1PAWO8AXwLAs3I58VYqbMN0CSzAkwcY58J9mue2joFjhZRRIbtWpIqFLpR0vRRFqYe9BOQ/lHSgSHmLmMn4CxXwU4XPAFTTJ3YsKu5Np/C2yNfNqjwCYvkR5+LI9yEF6dxpXjcUDlLgLbRLtdrlsqU7vuJL9C0xCH0z7E50lY6EZTTH+INOfApZTvxkuUdzsQD8b6HeS4sTswALJTNk12kMNXBOSGQQUUCLJn7Gqwzz8K4Ds4rtcorjIQbqlq2tIRmDUKgBbugnE2tJa/yk4GJvPiW8XEFszuMglFXzNgQVmMGj3NygDzl6X+h1OgNyM9b6WKFdiI5AsxWE58VejiJegeJ32S9rrKPwEQqHkWOXkBOC7CcxpgFdJ8HqXaTBAKq8s2FM622wUD77eL4EpgVhjEdUE9MF6LFw/RiMwbhA7+J9rrGGoFKtrmDVG0pwbYDWK0N+BV8Qt9EqUi6THEDB+lTYskq4oDJfQCQtiIFGsYT5R6Hfo1IJu3QVJjHTr8kN7codGfgdWJcBNmNmAagJQ6WvYdifAGVSoQaH/yACaIUdTIR15PuVLXNLfSQ74oxtyERZ2Dgnsx4PkIiI7eJZgAskXME8SsK1yLacAvUngcA7zfVGEGQyL71nxAy6ZzA8cWAMvpNj/iLAb38JonuF2om/JOcD3m4LFDCLgAstyepWi7YEfwZAEq3Pgk5W0R2FdAfKXXEMwAXZHygTMwjG0llJcTtQ5DETjnqNhahOjiP+E3IAi+RrQigEp4BkKphTPKH1d6EZ2WikhT8StRNTPsFrt8e0uibjdgSWSDxFAgA8+z2XBwzjHgHg9DyuRfsVcCthKYykjCf8LB/5bebxFigMAJM1tzJKkQDAAHxKdy7hKIE0yzdbe1mII12Dnv3He48CSFcgnpXgRsBOflwnbj5C20wHF+CvMDsJ+iFwo0zcBeRbd00jdyWwxgHXj0bWQwgAHZm/h5neyYZi3QIlMZig6IMwluoAtg5kP4zfu9TB6SXYnb39lH88gqWVMdCQJrXRgyRtY7JCLMtxMU8q6l/ggHoTRqPS68IP8TRThXsBHKK5xiS/bEmA2kPZbFCwRr4rLKwkmYHVFJvTlQabvMyrNh4oYCCaZrg6mIvHI4wCk+f9sUaS/8okqAbK1oNRjkrNvaqgfG5k1w68ABxaBtYdSiFgXGQGOX77xq5tLAdLoawEfjJdUF73eYUE5+ClUJcZ8H0418cYSSDu193XPCAmptNFgAKYBPYTiCBTxQsApKK9Ano3CqgGX0NoxgtlS8MujqsNP9pbcLsUMFA+gkNTrRCC8h+Jz5JcolHGi/me6xOJhB35fSHZioQrbu+Qh+WSBYTc6YBUKbKR/RsS3FILdysNHKAmGRMHMAPTNxsIfpOgOeI2GTJ4pKvziMBzlEimO42Eh3c2lLUChaQ830FbjMkeKN7C4DPZdlKeiSD4GHASLtI5Fhf2KGmxAVrBMk2UAdmOod0mMox1wG0GOqkbBntPd2X/HvwUXKwA+oiFZ8sxbFb30JXpojc82mIFIv4kcD5iOmaLraEkaHKQX8V+j8Ll8HQWSyU3fxBwtrBUtlgUEKwFfEaKagD68xObxs97emiBAMoAZu4f3zmApVhN4GIovXKLYjV6k6Mub2C0GUxy5INMYgNAHBRZJTylwse4oiIFEQVCA95Ja0K27IIlhpymneox2XUXik6qZlkaszkezbyPzU0NJq2EEflcDUKWbQIcabAXGrGRwSP+LCddje6+xFNbuzamPbqVS9CBnfT2xk0maFWoNLin36w70Z2hOJSz0Wg47GWslR00ZFtq7smAkkizqYx3wEy5ujxTICsCHN/DQDAgPEc3By2QxEJ/NKBq4iPhu4JWI5DXe2oHfK5I3UcRK4EXadpp+sxDgQz+canxSEOuAdoBzfA1N0cIhDrj34PxMAVMAH8BVFKYEvCjF6hT/5lxginyHAJK1OHH5C74P+6QVCnUusXjIgf7dj9ln9OFAx6F9mQXqLGwogvhlwKQawj0M0O4hHJJwrCOAd8jsoSADfsBNZT3xBcjNyLKKlGeQlEDoj80g2qdyGgPgEhLmuaSf5Q48udCeKAK2Rr4wXqOrXaLAF5AG2yhFFSN8jAck3dnt2nK6pHPZZEwr0HoBtxZB4ESxuxtxPBqbsat475DJ2FWYcBm1nwjshWZ0CTQXYKWGFqtweteB92YfESWoImsbLQxFHtqI6dEA/eMPG1B6NWwpTeIF9Ni8YNd7itfS28E1hBS4jraE9qAUzwE20LRfNqAITD7Ar9GpxQjAdSgkPYbAC9WpRb666PLAE2mMB57AQkGlUC+y8G7lInkw7T8A(/figma)--><strong>Contact Free Inspections </strong>&ndash; Contact through website, email, or phone to schedule your inspection.\r\n  </li>\r\n  <li>\r\n    <!--(figmeta)eyJmaWxlS2V5IjoiZVQyanB1Y3NQU3JhR0JyVFFwQ0ZYS044IiwicGFzdGVJRCI6NDMwNDc0MjY3LCJkYXRhVHlwZSI6InNjZW5lIn0K(/figmeta)--><!--(figma)ZmlnLWtpd2kBAAAAXxwAALVb+Z8kSVWPyKq+pmd3Z3aXU0RERETF2dlld0FEsrOyurK7qjI3M6t6ZkWK7Krs7typriorq3umV0REvG9FVFREvBCQ+5bbAw8OOQQRRA79P/x+I/Lq6ZHf3M9nO9578fIbES9evHgRUZN24jSN9uPwZBYLcduW63QHQWj6ocB/XbdhD6yW2d20A7CyF9h+hTeUtt1tgK4FzmbXbIOqB+HVtg1iSRGDwCbWstJVyINg2/EGvt12TX650nVDp3l1ELTcXrsx6Hmbvtng96sZOWi4XfJrOe/bTd8OWhCdCyy7aw8g9lqDh3q2fxXC9arQt702hefNG0mKLl8BLSiQ5nCIoUPk22Zj4HaVmlDMju+EbFF2p6PYO4jSGGoWqkKbPYZSx+0rUu4kk1Ey2fePxtTput2Hbd9FhXAbqp4I2rYXUWlDJBqu1evYXVpFWma3bwagjE3f7Xkgak3f7FCvvuG6bdvsDlzP9s3QcbsQLvVtK3R9UMu0JcqVtqNgV+122/ECkms+lDBJahbO+fZmr236A89tX91UIOtoqtuwGzBOqXc+tK+wS7cFbcei4PbgamfD5Yze4XTRWFdJL2yM48mog1EJcZdnBsEgbAFuk7MBf/E7ygdkw/S3bbZldHrt0NFzUGNX0ZONns+quuW23YJbajubrVB9sxzA1opSg8MXDbexaYNf1Z/k7BpmwW+bxD4XuM1woDDArbdMv1Fw5xtOs2n7th7BbfYVq90LtD1vb/UouyMww15h5AuqFRAX272O03UDJ2QTd3pRMlnoyVwJ3LbDCRZws4aD2URr7CokshCxVPbA7IKkCObmbEBWK2RQ6rhqFdWdjqlGtgQP23JALDuHWJ3BMBrH2uhYXr4dWsreTYfDk02nrRoJHTWTNXtvLx5mHa073S4WbdAyG+4OKkXDd72SlU0X/oEJ7DYGG+0e+2VsmNb2aVEtjG8sLLUMll3f2XT0Shc9D66JUrbdHUWgC6HuQwBHaA8s06Nz10tu0HR9Sy2dJYI24uF0Hi2S6QTf5AsELWNaYU7QEsN1tu3SyYzu0eFuPO9NkkWKb3yTwxCec8VuByAkeoTlT7sY1nSSLuaVScNkQi5Yr7orOybjgYE2MpPWAstUA6g3gdgY6C+WMkZpLweL+fRabI6T/Qk+KMAEVomjApd0e2FGGlrZimZAyceHoajZlsFDPdOnyDB9391RLsRB1DRrP9Rz2og5vrJ2XUNtTRM220GEUq1u2H2b1TJHNTam03EcTdxZnFu23utqz0Yf8VmAZQ9aBr2N0DcVbVxRDq8mWo2sNZ0nj04ni2iMz9t2k0oVw8EJ1NIytnoBorejZrT8uh/PFwl8ljLXQ1Xl0w03DN0OKKMzPUpj62ieTueYnIbdNBErUCEs3w3goo4PWtpXbfos5hWcgc1HNeWZGApihwXfAF/3VLxYQmE5bVDLfSyB6byTzOdEL3wL60/Nr1QEliPChN3dDDn5RiNKD/QqMywEU4hE6RpSrUTtSXWvuwmR2PJsljLoszC8RhNFzb4xm84XN3tfzXJhAnQ6dzGRC3achmpf5oKWnZu3HZ1Mjxab82SkQeraISvmLDtoaP+sld940WIRzyeogpbjKd9CwFKBS6rJOlpM/ThNHgV0YSLVHWWZoh+yoODQJ+M4iLNBweB+4GbhILRNzqu04BN6hrFPY1fuWgyftdDueK5vqj0azqxhYKVFXJjoTFQFKfOYiKaj4TU9P0VnW4hHD8NsqgcS20HowLygtbbyRqifMZu2lVaypkfoxDzTPWviXLewdE19tnWULpK9k2/1hWda9gALVCcX+rNAWdtQIQVCJBOB87A9CN1BFs5hkgmcFytXW6WIG/B424etB8zLwMuer0a6gYCNsma1XbX/1x0OJ6pAnHe7A3i0UhNmEzCD0OnYiFPgZcdFYjdQYzA0rStq+KrFLRZ0XVdg16DakuZUwrIMLQ+DoHMhl1NdXW34JlfEGuq27av5Z+fA9l2dXqyH82iSJmUfn4D4iSwjHCAmIZJme7FoOAG8om+DlE1kfygNpChIA5u+28HiVaGpVhHlsalekekotFSRFGFo2esFLS3LwFZKSY61Woo01FopKJDOMSvUsgxpvZTkSOdLkUa6rRQUSLfrjmIaoJSD3XFKmONdOCXVkBdPyQrUO1VLmTQDvasqyzHvrgo15GOqogLxsViajjVgHbjHYZtHem92sWJV/vx4O0qRHOv5RSYysHobjoUKQaCckUixKqzBXVBnSMFwPh2PG8lcLwdgZP71LZY9+qaXqPoWa2nBlRCPsPYWMertKx5Cm156FhC4ASpObvYQe6SR4lSAxkCvCDmeYhdTJLKJMXYSWZ+LNSH38cfYxZ9ahD91vdng4xvg5An+GD5E0C4F1/GndoA/dYUULKYzfDAkLUIhZ1O9GKBgdKLFPLkh5PLhpUvg5eGle1AYh5cuo6gd3kNh/fAeCpcO76Fw2YvmCKPOZBTjO2P/KBkJvwK6nudNqDyOxkcxvpFHKod6PGIRrNSNDmMha3vRYTI+gb5MGaFBGABZpMN5MluAq1G3H82TCJ8cHcbzZNhM9o/mMC1icpb+C0yho3ZI6bYb6hgIWjVz+tNgFg3hIKe+9bDZu5jPbFeRobmRZcy3AGhycjnAKgLyaRx0FI3tEcFRzW/1ayuapVjn5SfwXJVDSxSDnDE8G/ksu16DYFBwTKcsU4XaJYgw2E2QyxV8L7d7tVtIt/AXWRf2TBCqP4EyMian0HLg02odSCRwKjQ242ihDPw/0kMKjSphXfaUStYLw/ICymvsDUrVQZRL2WF0OXC6zExWXL/RRblqNn3WrzW6ahmf6/Y67NI6TkwmyvPYKzik2xq6vL2lyzuQlbO8YJoqUbto6fJO31LlXYHm7/b76kz3GC5MlI8NdtRx/XFWsMPy8Zgcyp9gWR32+4mB3le/reUElD+JOyLKb3f9Lvv3ZBoF5XdgZ+BUPqURqmT/O5ttk+N4amfT59b2XQF8DeXTtrFPovzuJnIZlE9v6fJ7WrrdZ4Sa/96HdPlMT5ffx2wW5fe3mxvkf8D1VPksP1TlD3r6+0vedpd2uqeN8IHyMkr2814/bJO/DyX5Z5sbfh/l/eZGn/wDKNnvB/sa5zl9dAjlczfaO5yfH0JJveehpN4Pm9stjuP51pbK0n/EaqqF8ALLU7xp9XzqbWCTJG8huLFsNDW+3cRJDWUT5WWUmyjvRdlCs2zPQUn8rZYeD1rbZH/aLXeLfoO8RqUkXQdbMEp3y3vgQZTelvcgcR7a8p5zCaW/5V26D2XQ3urwu7DtWtTvYT/gvPQ7doOH2R2U7MeVznaH8qvdtkpJHu72tkOUP4o8gv16IcoA5Y/1YXCUL/KCkPIBSspf7G/75CPfa7Hc9XsbnPdh0PGoPwp1P+KwqzLSPUwT52+/j2M+yoO+rk/6etyP9LeVv1zr+6GPcozyMsrDIEDkFWKCkvwU5b0oZyjvQ/njKJ+Nco7yfpQpygdQLlDSTkcon4PyOAgQs4W4jpJ4N1AS7wQl8R5FSbyfQEm8l6Ak3k+iJN5LURLvp1AS72UyCC4T8Kel1Vc9fDkJQv4MCWK+ggRBf5YEUX+OBGF/ngRxf4EEgX+RBJF/CYTq6i+TIPKvkCDyr5Ig8q+RIPKvkyDyb5Ag8m+SIPJvkSDyb5Mg8itBqD7/Dgkiv4oEkX+XBJF/jwSRf58EkV9Ngsh/QILIf0iCyH9EgsivAXEvkf+YBJFfS4LIf0KCyK8jQeQ/JUHkPyNB5D8nQeS/IEHkvyRB5NeDuI/If0WCyG8gQeQ3kiDym0gQ+a9JEPnNJIj8FhJEfisJIr+NBJHfDuLZRH4HCSK/kwSR30WCyO8mQeT3kCDye0kQ+X0kiPx+EkT+GxJE/gCI+4n8QRJE/hAJIn+YBJE/QoLIHyVB5I+RIPLfkiDy35Eg8t+TIPI/gHiAyB8nQeR/JEHkfyJB5H8mQeR/IUHkT5Ag8idJEPlTJIj8aRJE/lcQDxL5MySI/FkSRP4cCSJ/ngSR/40Ekb9AgshfJEHkfydB5C+RIPJ/gFAh6sskiPwVEkT+TxJE/ioJIv8XCSJ/jQSRv06CyN8gQeRvkiDyf8ubj/lIrRbYrsUlIfMUy2BO2YlmMyY50tibTw+Zli2m+GtsjKe7Qsrdk0WciprU9wvCqOG++YD8hBkZ8q9RtIiU7gqyr2SMo53FpNEcPYIDqJCrC7aNdC49iEbT6ylI4yDZP8Bp9gDpHRLGUbyIkjGoeowup8wlkDge47Qb434A9PIiPlS3Rbpq5TjZxeFsSHpVXXrqZrOnAmGc+/9tcojEaB5hbGtibXdOzAlaBndOdUYYF5WdbxdySEMgezamTCQXzLNrx0ma7CKpkqKOIrurPi+WUiTcqXhYLgN7ku5N54fihWIlUUa/IVYVER4gSZ6w58jbowlkODk4rIHgghYgrUPWialZERfBVy9nL4hz8ynOGVBBT9ZTVoA4v6fMZ7Gz2aw9Km6bcSxNVSNeIm6PD6ePJBZQPFzwwYgr8g4miB0YsgEHEMbStfhEwGH2IG0nk7gV0zKANyhpJPsxcGvI4MHptHIi6mR2tOISklVc+Wiw9eFBxNQ5nqdwMVlw6kOnweaNlLR7HM9xkxSHEYyJoCBrY3W9pG4x+jAxboXH6E2K7UUu7Y9PZgcp9hW5PCpudlPsKnJFf9ZHgxDBdqvsWjG6l0m5theNx7u4IGmiIhW78twBZnkO8Gsb0xto4BVSrrcqIiyVXdzcjFJxBWeZ+RgDyQ8+tY2sW8JYgfvpXLwv5PVktOARzGDdVRA1EoUl6+TMdIiTFLiVvWSeLqzcNOjzEtypyi9vcrzCWB5ODw8j9CRbpuW5qy+0GZFeYvXuYWTKcGjqLHg0Os5WwHKjMJ4wjDlOkhijlCWSoQ+cynRG7Vgx3XhxfTq/lndhAgePxmhspFrMO3J2PhmicFGIYUhaLxW+lMHJ4e50nMGnikG7iFyazkFSAhg4RnI1BfT2JkaDFQnD5rB59DMMNTNyBhlSCFziYOzonAL0470Y51cM3ljbS8bxNlwdbpmqStWygSbpOa0IwRHHUHbVA1QGnyLjkPU8lC6NE0ST+Qn7EE6Do10eX3ehRoFYSM7XbDrBNOuGVo4me2PelU6gU0VcTdJeXhWPEFLWdK+t/PtOlGL2MkMNc6lGlbOj3XGSHgCM7bK34TSMo8N22Ts2YtzcSPaAA79Sce5OUYlze3tpvMBs1ubRKDliUKyXAW8JRRHwlkPGOeWGzmRviglQaFtCjo4y38JC8BCwpqxoxMfJML/ezq9ZmIer+3Vp4WSkzoqGkuHmhSd08DX9oZ/HPZ5l9ceWtTNQe6+8qRFh1MkglcMUZ845m8cYmDOC9ZK9BAsCc4yvNOZrEMvpc4ghXrayQgLgPRA9UadpgWuq/E5Lki5qDHL5zVYN10MYR65Zz9hCeSkT5PrLHbPbU2eQlawDG4hQ+3PGHae8ZUUrxah5CYvnZH3fyhuz7ClIngHQYyi+xBnLaQzyt8ez6uZsFiNcqFVi7BZihfIXMGUpsnJ36UbYcpUNlRZuI8w+jvjqFkPg0i57PJXBjrpXMGxs1vNFgD0aTpsKYzU92tvDTRScWW11CuVZArdWRdIzF7X0eJ8roMtNETMFFkkPnfDNcElw7tGCgZW7D+qx+GA4hHh3gosmKVag0ZzOh3Gg3rewoq6lEK9mfelvZmDCcJqDrm1nd3dme8e8GoCQbbWz8L0D0WPBHl4WMuJzv4GwUSyO2uToMMCygjFSsSTq2VJCWpJqaUBXRPDdP8JKnGfcyjCz5eqMCxSPKfeJtU0EH0xCLWtEFlDF/uNhsWOWriflrwNWBZbxqW0Crw+IyCF7zLso7QXZYy4urnx3mxIje5iv2XjEVsf+Oo75uCEDtZQ95izrsKTwKrFUh/wsGsGdKgE0D79UgMkxMk4hxpRSkn2Ch7nyKgvflKE5u17diA/gYbAP8PBo11a3MhgCnjYGOy0bi6DltBsDt4lHL1bjpgw33fr3DdKcD4s2I7wXTvbNyT4MhbwSUazCGgkeROZ+HvBq3vhoP5lk384UAyugvzrtRkev6U56qs6Px9HRZHhwiw8OkVfCrUHCpdXcgKzxNxvYmSeoML6pNkVMqSrDaB/z9uzZAdILsSwMRWjh/TPYM7+BfZGoVVit8MCCE31OqNinRQ9OIiyZdbHEUoueUzrsckbqiufiKvqa2h5WNKXFP1RmvqsZqSuehy+LvWCtYHTlDw8RJhYgzilCC5+f0uX7yFtRatGPYJEXufL5gtGVLxjBleDo8B1sJfK2CqsVzEg9L3Jw6PbtJaerN8qAZU+YjnBwd5wRamXrEHEB9RdYalEjVhHCOh1OLp6VanWbXzqpq4MRNO88JdBKzbJ5V1sThr3rjFArbyJJqzrm3VVeq7QqKd9jclpXOfCQaH8ezQ7oJJiNNfHYm0RacauQ5tfla+JxN8u06jZXksPVorIxKD7+tESrtQ8TzFI7QQGVJ6DIOF3dSVUkzs4Na+KJVV6rdBcI5iF2v2toGyrfVuW1intQ/IQAkwEItV08UTzpVnL9iQcODZk4R07Ek8S3V1it8JCWWNFMPFk8uWB0pa959QOJp4jvKDldHbCLCqtVdEA8TTzlFmL9QVjU9POfMzxdfOcZoVbuUW4hGoi7xVNzWlf1yVYy+seK7zot0Wo7uzf/buOp4mk3y7TqleOs7dKAMOx3n5Vq9auI22OPfCpeKp9ecrr6YSjDUloEhe+p8lrlR7lCsmPSi8UzSk5Xv5Ce3cXCxvn0e3NaV/2YGioj78uleGbO6LoXxSrPTXHvJ78vo3XNANF3hI1J/XoDHiWeKb7/JpFWfLFe7UGesbxJyh84LdJ6EVs2VQBKsQLF/eJZpyVabXdc5BIpbu3kD1Z4rTHUhy0OAlej4lLJ6vqR2j+xu6yIezJSV8RlELGylOLyTSKtuMf52Yynh/FifoJrQXlvVaB19vUU5UJq3XdapPUOsPqzn0w8TyQFoysfUXwWP7CGr1V5rTJWIi8acTuGymGV1yoT7osI++pQN80ZXTfTBzhaB3fE4sdLVtfP93iR0kEYbiSpCvYIy+kZoVZezPVETZuIWlLg3qhgtcKxnvgN9FAbNf8e2tdVxy1IEerU8hUvEDeUcAv3MfwZx4Y4SXVOpHpZplGvlOLRJNVSTx/pCAvUnwBVfFA9N75khMfJ47yGA+ZJ+Ser6n2djmH3fylXTPZwaCELmU7aTNo5QLTxU6dq0f0bi6NoXNV4mboSylQw5uE8ZqjACbOq9dNVrRZ8AasIsaKq8vKqijvHHCPkSTwpVMTBGLt8PHo4nk9R9YpqVTd7ktXPwSM8PJytzLxL7OG66GxtExsIuy4O8EZRqUaIT8UjuFaqyIq8dIzXC7odhvB2KX9JIvJlx17mcViJPh4zZjhLqhNogO1wUVT8SllRuo1ai1ievyoRAJHMRGMmERjtr8npsbr4wN6sJ1GB/Hp2T9GIYXq8kqNlzOpvSN7bIInEpjudteM9zF6ZHWAt/eYpBZ/R9CaN3yo1NqaLxfTwFii/fbPOrYBeWSqVNQlzDDwxYzBcT79zs06Iree0yqtoLS4xjDCFLyLiRNgJuL5+V2rfhv/qKxCsX9hOef6rJAI8VLNZUZcRr5Z44yllISYANxOvroga5SXFH8g4Kn5H0sa1AeyMw0f5u5Aunn6GqtPB4XS64I0LPnutTCYHcCteso4DHYsxXa/JxYEKmGXF6/KKEGusFP9lLrZVeCkrXl9UqK2rrPirvIL7Ril+Qy6u9KfJH4KwG6h/n0zSogo2/SPwujKX/IlMSSk7vFviLUuxp/3uw/Iov0yCGapB6c/kGHsibJStwRfj6QtfwpKuPr/2cY0AB8/C0huzKQ3YRmU63y+xy1aqykD5XolHsCQ9HSPfLGNlNxrVTHGcJwH5W6AZTPeQBqFXGRTEb4W4O530ZiNs2RnE27JuwuXgH0OljVrhYcEPSxl2AwzhHRIXFnDEg2Q8QrcayTFCA6+T3llxLg8BL54f4+qeuGjiXQSaYBZRqczbhIFLEX9oty7eQ//X0SK7yHqtxKBTBVIchT8gYSIVOdAtfBtCXbTwQFc2HyaHMdIK+OgHqpqdCAz+VyvqgxJMXlNZDB+Soxgb1kTxOL1gwpCk4IOPVC6AdO6GXO6j8pY+t1Fowu8+JqPsJP4hifc/WOv01tVWOVA/c4wl7GQTjBTbBlg1uDdIPBJOj1VH8rCsKl4n8WiYVfAUvgBwroCp+nheV3bHKceMF1o8MJ7RMMtbsNdLPDyqLSHr2zreHxdwrx4mt32q1yt4kNQHf44ItpKfwCvcPoLdyJ24YVP/xCYVM/nJQr63d6riU5UJDA6mR+NRcIi9xFSPQnTTT8uU+YTOLp6PR03FlqeKLG3CHH5GV6FzKl8vKz6rK3bUM0VDfE6zOtUG/3llDgQVdQvj4yl0ptcaZpf3CF/IeRVvvggHzqIx1dfxPJqk1mX09Eu5XjzqZwZax1OpNhAnqrgu+ZiUXwYMug+3nAdHMy7lLEoxMpncLhl4mT98RXc3y7KwHjmoBh5aC4A0Q/g/AL4qD+A26n0H5sN77LX4JJwn+/tYwJ+S4mvof8CVvwlPmEH/6+WCrDhOCqeT35DHU6xQ+xij9w7wmkj7fLO8ia7o405I3/DEVIbPCUNXpHAnWSs+sVW1sZyUn4YQY23LiujUIsbNVVFRWcO10+Oq36KrS6WzldFiueiLqSDxjleqFUlNxU9DqGJfNUpJtRendtV6qVM2WOnFLV2ed7lZiFQwTd6X5hIdNFfpsuNbrv+1s3HkXNngmRi9npmsoWOvWNq2r264ps8LUNHrbnfdHVw48ieduGlUt/nyyoZ7BXfxNmjDC+5DUQt2nNBqDTz1w7j6djkRBm8N+QCL22EJGypp1tYnMJUtdFG7pmHo10aVdsLgRj+Jr9Ot8bAxjCbHUcotFvkYwhUe7oScYUcaYzzH0MNADMU3Yg6U90s1/dGmRqurfxZBKP0vI54hpK5XoO3pUBkM5jMq4gC7qDI630Wv3IxojZPhNYGHphECIR4n4ZX8Xlu2mBBpTDB66Gc7GgKgzgqMUBsDMVHPpZC1qaayFuTBdJHOpouMNdLr0Syjazd/rOKKUZ9qLtP6VgCz3OmdcjFldfUeXCS/qr146pe7mR/qZTjBiRIThhc6ndrX4cD7sXbQJc6Kmr3PwqEPlfE/j1vWNDcpHkRXp7to6BirBQ/ja6OYTtHVmOeQhGLhKhOniMASz/60Xm7WFGFX4ur0tBFShFt5G5qao7fr4nacqnB9lum0tC0wvjtOyb1bGAKf++LCIlfJ4ZWRvyLlxQCdQ7zEReFDRzFuCvgmgCWMkXSzyUaGj80GrxEUaFumnXgRjQhhyF28VSDgx2NuiPQH2LYDQ8N+wribvcE6klXTI3peU0RtUiIia5B1jjfnvyolniuBLY7lcootMxpnFl2JhkPAibpYTZmxBLG6T0LNWs6HbPZBcS7nLWwwmAQlfq5Yn8FqjIVL4rwis573+aMLsNh91AYKu+uGvehkPI1GENyRnrJXgo5+TcoLlYEUpvkG7pr3gNTH3oWhY7x3KnQn9WjgaDw+cY8WaTKK7clwDG+Y7ON8i3FIcZdS9GBCZ4QpuPt/AVMVAADFmWd4VlW2x9d5E0KCgUTq0F+6BRUYB1CSlwN2RQYRRbEFISIOGC5ldBzUTUhIQFAU29ieYHcERQXmgpSjIkUsiBVrVBwrCOrYsNzfWue8Yc/9cj/Nc8/z7Kz/Wf/V9tr7tDdBkJIcKVy5cMNtOc3KR/W7ZMqMcdNGnD517AlDp446bcoxx591yvCB0kJantEjNycQSUlu0OjYinEzJpdfOl3ygvyrRaRAiqW5SCAWTLpIbqrRiLETytN991sUquAwURSoQwvF/a56fuvW7FDFZTI/WJs7p60E3xSsGqIBAwI2bXTSpdOmlI+bPrHi0vTI8mkzJk2flv7QLUqPLk9fNnHSpPSUqRV/nji+PD1xv9nUxOzPE8emyyePnTgJy+kXp6dNL58yLQ1/ccVl6ekV6jmuvHx8TP6lYsbU9LhJYydOPpzaG0tS/QG14oZVidTF01gga1rYTOZKdG5TaWbTaTVbpLi1tEGEbWdBtpMO0lE6SWdJ05Ou0k16SM8gkJR6+iNH/9DXQHrJQbjXBQePrLiwYnqFDK2YNF5ifJjhQ4KT9k9wZDLB/3AfUhWU97+O/P/kkZPKzv/U8vETZ0zOdiA569v4uUAkazKyfMKMSWOnZm2yp33z1Sg3u26NUoHMlh96p2qjymNzJFe73LhSpL6R5I1m51bJzItSc2T7lBxlPHp0XoXkVbBo5h57FuN0pbhDJAhSs2RZqc8EeVdJ1IkrIVUpm1/ymRRM2FiCnNRsqZ/mMznKpCXITVXJDXk+kwsTtZSgEUzPET7TCEYOkCAPpvktPpNHbTJGgsYwec/6TGMYVyRBPkzPz3wmn2iui86nWvLa+0wBjM6nAKb7EJ9pkjdT5FcJmsC0GOkzB6jP8Tqfapl1pc8UKsN8UjCn3O0zTWG0OwfAnPxvVTeDcZ0kKIQZ/YXPFCXzyYOZ8IvPFMNoD1KpOa5PE585kGiap4DVXhbPND9mmut89knQFKZzd59pgY+MiH0qjvaZlolPM5j3hvpMK3zCjRIUUUFVmc+0VoaqNdr8qT7TJolWDLPvCp/5HT6Rk+BAmPk3+kxb9dkrQXPybLvDZ9rtZ6TVfT7TPmGowJ291Gc6KEMFLWA2r/CZjlQQdpagJdHqN/tMJ3rt6HUrfIpf9ZnO+Eh3CVrD9PnEZ9L4yB6bj3vwe5/pohVQWxvy7PrNZ7oSLUprR2vkugKf6QYTd7QmuqG5z3TXaMznwFRN+Fxrn+mhDHl+l6pxX7bzmZ5Ec+0kaEu0U7v7TC8Yydfu1EQHHuYzB8Fod6jN3dnfZw5WhtraUcHiwT5zCIwUStAepuZEnzmU7rjhVrW0Ge4zvZOqW+Fz1EifOUyj0WvmE35xjs8cDqPzoTtuWLnPHKHR6E5L8lRN9Jk+WsEYm0/YocJn+hJN50N3JH25z/SD0e50gNnpfOb3MGE73Yk14XHzfOZIrYD50AM34Vqf+YNWQA/IE36/yGf6E03zMJ/wyX/b8QM0GvNpzfp8XeczA4kW77ea6PCHfOYo9aGCjlR92lKfOZo8rnWcZ+FKnxmkPuShO9Gm1T5Tgo92pxPz2fqMz5TCRFGcZ/l2n8nAaB5qC79522cGax5qo2+uVb3PhAlDbdGAnT4zRBlqKyZaxac+M5Q88T0En3/5zDHqQzRWQcb86DPH0jddhc74fParzxxHNGFNC1K1Zd1Q7WeO12hU0DZVmx4cP80S5gT1YeXawyxu4jMnJnmKUrUysanPnISPdrRFqrb+8wN95mRluObIEy1r7TOnwGgeaouat/eZYUltrVK17vCOPnOq+tj1U+sad/WZ4TAunmn6v3v6zB+TaJ2p7ZWDfGYEPoIPecoqD/OZ05QhTzHMOf18ZiSMrg956tYP9JnTkzz0rezto31mVNI38si1pT5zBtE0D9FkwlCfOTOJ1iJlbz1Z9WgctJ0tU5VyeV+fOUuTjNEkleJ2+szZ+GiSdqnZUrbAZ8Yow82tKFUl9U195hwYXVBlfj3DZ85NmDYwHe7ymfNg9NZfAFP/uc+cn0ymOFUtw/N85gL1cbrdq2XKUT5Tpj623avlx5N8ZqzOlHZ2hhlY5jMXEk0XVF+DllT7zDiNRgVpmHk3+8x4jbZT+1YtA1b6TLlG6663ymr57R2fuQgmJI8+ZocGPjNBo43RCua4TYU+c3FSQTuY/q18ZiLRdBV4BXCpXj5zifrQg47kOeEIn/kTPvHtaI57dojPTEp8OuHT5GSfmYyP3ty6wLw9wWcu1aqbSn5BQU4Qv6HH3zSiH0G9c1oWfjRz1x0XPLdl7YaR9/Z7qkftlNXHX5YrjX5oIlnzkckLfdbj3fYdHxu89/suA586cuMRA3/9YcBJ31yCR11eg0fymZB1uKD1t6+/vfzevYfN+2x87ZL07ctvufA+HD5tDCuHp64OXBDMCqSSDwS+AwKpDmROIDWB1AYyN5AHgt84ihi/Fd0XSMBnxdYgJXldj+CzwZVl+Bji40BuKkVmQf/BqZhqAByrcBZXkuH1E60MAXyVyRH5a0aigsESPmIyR8IdBiTcjcVPWNQFg0U+yEg9MnokkzLAQegnLXQClmJrYENG3GM4v6iKB4j2JicLTaIYZ0DkOOQ6oingAIyk9CywIpNqZQUf4Vaga0UEBdKHsZgxGIXcCDOck0uRY1RxZKm4WSiQ4fpEEX6E4mXkPhSuO9mZpKs0icVKAxK9Skq1iL7BHBeV4ZoMxTxsAF9AtJVUi5GvqeIWTOthCYYkWJkBkWFYvKGKgZi/hAIZPZ0oIlJq2eGjKFw57IMoF6C8G0XESXgng466m1G4bwGzGCrbJwq5p9RKlmalBF0BSK+RSOtIr8FiiAFxhciyEiyW0eJ2jIsZi9WlvkTkO05U9s7Q+x6Y9ia69CJNI4bG+FBNzwWson9VJlH8zYC4e5BvorCF+QELJCsl16Uk4DuWplYRUIEWEn2NVSXm7nUA1YX3m0RxhQGRE5ElpRSjYMQ6wPmUmAWhbY3STAKGYvMt8eUyYusK3meSDr5hQBwr6HZjUacVbMnEsjaTMkBtEohsIso8bBREj+KwivgbUIRLULzJuIFhG3isASsu3sAASStzIeA1ClxkMg4GiOW8jLytDQlv5cSme5QBkXexmKnmxYB8lMjIaWQFNURW4JbB1CC3qWIjzB7K7IAyYLLuTKphsnad2ezJCRD3CVZ7cIlyOHkBJTJcQHQF7gKA64/JBZhoU90hjDJGExRSSXidwJ0mCbLRgITvIXvhWy/cCx6FcXvR9KSq15CXl+C7GsD0kvkKTaY22aFhZxjgE5k8z6FwgzlZwxjIWExYF3kguh8TUbAO+yeQW1XxACYaJI4q26y58znRQsM6AxItwUUwD1cBWuOLlEEa+RcDMApyYXcjl+AbvQ/oyqx1slOYiiOITsEtMEnuXgZENmN1FS6Sy8IUoERG1URX4OYRXYFsgdlE13QXSk+KYGGEYEjSrTdgPXXfqQUFRTs4UfkQwbRmAKUqWMegIGuCTXMHJ9eYxLfcgMgp+G9E4fpmJFzOCVKuIZgCNzth3O/RYipFqhgPoGdJE+V5e2KgdAcNxg8Q2hVHzgbgdmhIqAbAHSQJ1ZgxhfEtDXJ/BbxFK641SaG3GZBQ7x4flKZiEA6CURNtboVJFI/gp4oH6WkRaQxoPqkbtB9YTUo1gIa6AfKUzkZGENOeMTOJmQWxA1QD0APrMXCHsEQKyvqxZreWSt0AVWwo5ZbJ9cMckcyvtwG7HZmFOytjLiothgLpSgwsog4oBBfXBgtiIFFspGQU8jc2kVmQ1lyQxJDNusV1Q0Vz6bECeZygDreXVbEOxV4UbTOStpvC6aTSnbXQJBabDIj7DKuvcUnncbIN83yy3EIjywCuCsZAIWa7GXq7DrcCWIVooUmi9zYg8gJp1cIKKkSJdHMIpoBShV3UlzlqWAVSwslwZAtV/AnAZrOweuXKwwZs07vmarEZxSBOkESLFe5RTrAIN6Awlx2caAy9CiwoCs1iFpo2wkUldVDRXO1l+AC8Xa6jPcABqGQyDUBfpCKMAXTiUwP8qsvohSLNooVtB5uUX0mnwJ4RRcj1KIQnjeAf7mLcqnk6oagflADN477AXkGodtVaoxXztFo/aIDUGwxI9Ao221TxESfvcYKUHxJFva7dqyiLKU42siO1HsIiCUbUBqDBHtQrI1rLybna/3sALKubYJLeFRsQeZZGpNViFGA5YwTrfHSGQIBQLx13LEmzgJs6zgB5ndWsNYliqQF7r5FOOCswn3peKxsABx3nzsgBiIsTfedNLk+yzqSEBhDiaFQD4FB7dyBzv5tEcjdlZAF7iCqhGgCUrNROuP+i9nLVXg1oBJB5hDtXwXaA7gX3UwLK0tSqVFkPQC4gPBhwEcAdB1CbuvMS4PoCtOK69gkIv2QtcpX6J7maA6L6RCOLSKE2uok50HxbEseRX5iwgqTU5MVCHWzBBhoQ+QSzy+m5HM2E81CqvJrSFIS1LI8Ce7G4DVPdT7zISfQVim7sK2H7uDGAAvq0wCQb7GkD4t5H7sEl+hnzFzlBhvZiAZDpADnAAFGbArpT61HIj6nIXQSYTaqbTBL1EQP6us7lrIptgFeo6l3cmhAs/BHFWmXeADC9ZL7Cii3AZpfmGWdApJShNwJpQ10bOGnGqCOKe9ED7h5M3POYbOSEfShvqeLvnBAkiSpON0XIjOW3UsroNjjepWVHJ0BaQOn6hJIAfUTLC5rkSoBqXL8EyJKSxOsjJmvgXKh8jGVpJtaE27MgTho/uvTFjAO7O+hKFpidUg1AD66SBaWSPpTlUhD1IQ7Pw7ojVbGBJR+I4ieTKH7HHFXRk51nFkfSEXVBxjEArgcKLKIuqsDFblzEQKIgKMCyxBakNRckMeIrMa4uLpwjAXrBGtUAOOp0R+sbaljFkijQPRR+AavbRV4CsPbRXSZRnGNAXFfkSNbJgH0yzCdHFsRdakckBdKZeekWdqOZmDabcEgSsjsAIiSM9K3NKniOE6SrzbDGAGoTtsYOouhzSUH4D2yeZegDOXwcxZeMhYwvUbhhBuLiNmUoBeAOgJFhaGbTPEyRKPAFiCOYfIlCo8uh+CNJp78T0KH7UH6Mf3g7Of/JyXUm8T/GgGXg3TlOxcGs6QNHDOI+pAmrwHUBfKXef8Sb+YfXm2T+cWfihPmYGvg4Izt0oaQ/lWsLFOi3v77ChNoCvZ/oO4nrxl4KCOTOiQO5600SebMBiT4nt17EjncSmmPS1WSoCkCrY0ZvIdEvZPgXPWFpeMUk5Xbk5hIsVgLYBnKDSfL3N2CXm1TjohVKEUpk/JICoHZhfzahAssDcIdjw76XPep0PmA2jhpWVydcYcC2hOxFoc9g/VFCJdFiRbiSOFtQaCfcck52MZg4EsX5BsQdieV2VTQhBvtHJXXIyVrT5ej2lXIvWI/S1mh3FiyA0nV0oxIgVdmby3u0X0HiHl9OkmHKWpuCiA7raxYVkLkHRbIGrtIkFo8bkOgFrL7JsNwK9AKVn32gWd3LCQhfAlxMM/QbzZpOOCThehqwhDIHC61AilGqtFUAUJtQZSHz01VQYO+Y/RjaYzkLMBe7BSbJs8qAFedaEEWBbFRfGL3Q9FsCiQJfQBxMm63RI5qtknTJz2MdObG+cUU49dNF0kaEi03i970BiVQ+niEngAOfLT54AucQYM+xNcj3UMijgC8ZixgW/i8G7AYU1qviD4BXUXQl/P9x2SbVyqf685iLcCrSCADRKI+jOAlFeC+Aacgs5GQU9v49k9GcHPYWwHNWS+LBK9FiVVShWIZC5YZE4T5G8S3yZxSuH760QapNYvGEAfuZK9qHhU5LdlKHyvUZGrXWAJeGgu3kX4rp+yjcnZzsQkkwJAraAYhf+z9URSfAGwxk9GyikBWMo1AuUcXpnNxLuvmMO1Bor92NjA24zFXFW1hcBbsT5QUoot2AIbBIaZ0o5HZ6oDs6jw0WLQewb90ck8QYZoAf0ZAjSlBsY1WKGbcwbsNFN7LsYiBdzwzLVUiWnkR3zfDZA9MXaT+gjQJwE7HoeleJ6gzEb2RLUdhacgdVyeLKB3oZu+tQqnn4oAGJViPXq+IFwD6W7CXMD9Hc+wwQ+UeYH8j9BfJeNX0HkCbyM8gpOpGHAczMoutUXR8Ddi+Jf+MYiHkBSmRUpdEBbj7RFchymJth7OLaBrMXRaeMhHbXH0Wb2R0h0ZEUtMaARG9hod8tohW+y9CSHyO6TeIxGJ1VtBWzJ1G8g8I9BNiF4jqT+HJxA+LOvopC76DaFZPzCKaAu1HMsBqx6afMSreaNtERTOW7dh84hpOD9BIDcIlRzY0e4FEVUw1A8jS2gq204jTk3zX2+YB5KK42iaLGgLibkDeX4qtAhEnOBmi3x5tkTlokCpeHfKcExYsEqmSozCOvAitAFg7aD6xIpRpAw0QA8beePbXOpB69RizJDJMoOhuIH5f2rcftVVYwahmlmgNgofUW2QDibz2A2oeVJpnUPwzYIz6+PwPMR773AAeAFeYAxMXJ03pXsxPtD3d1fugoiffreI19D0ArnWwSi44G7GYmhVjoryb8yB1LvbwVuEuw4vKM9+0ATu5lGW8ySX1PeyBchYkC9zInyzF7XxX3cbIb5VyTzHqsAZEQiw9U0QnFa1ggKZcZzSbfMzAKojcwXYPic1V8B/gFRW9ccrks3HkE4bII55vEgk0PEEdA+Vld9qDYycle5JMaHcAHIYyCEQT8CSklLIyBbEs52NhXgBao8SID4u5HrlbFagAfjDbhNsRVwK4kzF0GMGlhwKR0SxTyFd3tg1ynQU4FaNQrYvmQ3q90YWytHZvL6eu2nEPtTErqTNLUNw3o+x9XJRbRT5ju45Uxn1tEDhb6kaUWfFyoZP2HG+BNFbcVGSYJ4ODngwEecI8TzcBLVMH3d/Quijp+TLPnEt/hSH6waWbAftKJ3kERagEvML5nPEF4BRzk2eKBUG9QBnAOr2NoNL3YAPx2h/OzGUwBHIBr6FYWWFOS7iTvH9hFdkcrAzC7cLFJFKQH2NtG9P/22mEvfkZlAdXKYi1d//3CL5loVxPKZkYCA+4qHB5YSx3DsBmzjsLYImPWYcJngpyt4CA0I7OgsYI5gIJ1OO00wDWd4coliusJ2LRW3ADksWsxHQaIBgH6ZN9/67PdvYyMjTOyyEpcSLahpYRUcD1jCeMxVWwBvMwIiPQyCseqAOzCjC0GAa5HodJiKHi+JLZIlyQuy56MYyx7EgsNqgrNohaWVl1UDmX8Dw==(/figma)--><strong>Inspection Results</strong> &ndash; We will provide inspection results via email with steps on how to proceed with your claim.\r\n  </li>\r\n  <li>\r\n    <strong><!--(figmeta)eyJmaWxlS2V5IjoiZVQyanB1Y3NQU3JhR0JyVFFwQ0ZYS044IiwicGFzdGVJRCI6ODIzNjM0MDQyLCJkYXRhVHlwZSI6InNjZW5lIn0K(/figmeta)--><!--(figma)ZmlnLWtpd2kBAAAAXxwAALVb+Z8kSVWPyKq+pmd3Z3aXU0RERETF2dlld0FEsrOyurK7qjI3M6t6ZkWK7Krs7typriorq3umV0REvG9FVFREvBCQ+5bbAw8OOQQRRA79P/x+I/Lq6ZHf3M9nO9578fIbES9evHgRUZN24jSN9uPwZBYLcduW63QHQWj6ocB/XbdhD6yW2d20A7CyF9h+hTeUtt1tgK4FzmbXbIOqB+HVtg1iSRGDwCbWstJVyINg2/EGvt12TX650nVDp3l1ELTcXrsx6Hmbvtng96sZOWi4XfJrOe/bTd8OWhCdCyy7aw8g9lqDh3q2fxXC9arQt702hefNG0mKLl8BLSiQ5nCIoUPk22Zj4HaVmlDMju+EbFF2p6PYO4jSGGoWqkKbPYZSx+0rUu4kk1Ey2fePxtTput2Hbd9FhXAbqp4I2rYXUWlDJBqu1evYXVpFWma3bwagjE3f7Xkgak3f7FCvvuG6bdvsDlzP9s3QcbsQLvVtK3R9UMu0JcqVtqNgV+122/ECkms+lDBJahbO+fZmr236A89tX91UIOtoqtuwGzBOqXc+tK+wS7cFbcei4PbgamfD5Yze4XTRWFdJL2yM48mog1EJcZdnBsEgbAFuk7MBf/E7ygdkw/S3bbZldHrt0NFzUGNX0ZONns+quuW23YJbajubrVB9sxzA1opSg8MXDbexaYNf1Z/k7BpmwW+bxD4XuM1woDDArbdMv1Fw5xtOs2n7th7BbfYVq90LtD1vb/UouyMww15h5AuqFRAX272O03UDJ2QTd3pRMlnoyVwJ3LbDCRZws4aD2URr7CokshCxVPbA7IKkCObmbEBWK2RQ6rhqFdWdjqlGtgQP23JALDuHWJ3BMBrH2uhYXr4dWsreTYfDk02nrRoJHTWTNXtvLx5mHa073S4WbdAyG+4OKkXDd72SlU0X/oEJ7DYGG+0e+2VsmNb2aVEtjG8sLLUMll3f2XT0Shc9D66JUrbdHUWgC6HuQwBHaA8s06Nz10tu0HR9Sy2dJYI24uF0Hi2S6QTf5AsELWNaYU7QEsN1tu3SyYzu0eFuPO9NkkWKb3yTwxCec8VuByAkeoTlT7sY1nSSLuaVScNkQi5Yr7orOybjgYE2MpPWAstUA6g3gdgY6C+WMkZpLweL+fRabI6T/Qk+KMAEVomjApd0e2FGGlrZimZAyceHoajZlsFDPdOnyDB9391RLsRB1DRrP9Rz2og5vrJ2XUNtTRM220GEUq1u2H2b1TJHNTam03EcTdxZnFu23utqz0Yf8VmAZQ9aBr2N0DcVbVxRDq8mWo2sNZ0nj04ni2iMz9t2k0oVw8EJ1NIytnoBorejZrT8uh/PFwl8ljLXQ1Xl0w03DN0OKKMzPUpj62ieTueYnIbdNBErUCEs3w3goo4PWtpXbfos5hWcgc1HNeWZGApihwXfAF/3VLxYQmE5bVDLfSyB6byTzOdEL3wL60/Nr1QEliPChN3dDDn5RiNKD/QqMywEU4hE6RpSrUTtSXWvuwmR2PJsljLoszC8RhNFzb4xm84XN3tfzXJhAnQ6dzGRC3achmpf5oKWnZu3HZ1Mjxab82SkQeraISvmLDtoaP+sld940WIRzyeogpbjKd9CwFKBS6rJOlpM/ThNHgV0YSLVHWWZoh+yoODQJ+M4iLNBweB+4GbhILRNzqu04BN6hrFPY1fuWgyftdDueK5vqj0azqxhYKVFXJjoTFQFKfOYiKaj4TU9P0VnW4hHD8NsqgcS20HowLygtbbyRqifMZu2lVaypkfoxDzTPWviXLewdE19tnWULpK9k2/1hWda9gALVCcX+rNAWdtQIQVCJBOB87A9CN1BFs5hkgmcFytXW6WIG/B424etB8zLwMuer0a6gYCNsma1XbX/1x0OJ6pAnHe7A3i0UhNmEzCD0OnYiFPgZcdFYjdQYzA0rStq+KrFLRZ0XVdg16DakuZUwrIMLQ+DoHMhl1NdXW34JlfEGuq27av5Z+fA9l2dXqyH82iSJmUfn4D4iSwjHCAmIZJme7FoOAG8om+DlE1kfygNpChIA5u+28HiVaGpVhHlsalekekotFSRFGFo2esFLS3LwFZKSY61Woo01FopKJDOMSvUsgxpvZTkSOdLkUa6rRQUSLfrjmIaoJSD3XFKmONdOCXVkBdPyQrUO1VLmTQDvasqyzHvrgo15GOqogLxsViajjVgHbjHYZtHem92sWJV/vx4O0qRHOv5RSYysHobjoUKQaCckUixKqzBXVBnSMFwPh2PG8lcLwdgZP71LZY9+qaXqPoWa2nBlRCPsPYWMertKx5Cm156FhC4ASpObvYQe6SR4lSAxkCvCDmeYhdTJLKJMXYSWZ+LNSH38cfYxZ9ahD91vdng4xvg5An+GD5E0C4F1/GndoA/dYUULKYzfDAkLUIhZ1O9GKBgdKLFPLkh5PLhpUvg5eGle1AYh5cuo6gd3kNh/fAeCpcO76Fw2YvmCKPOZBTjO2P/KBkJvwK6nudNqDyOxkcxvpFHKod6PGIRrNSNDmMha3vRYTI+gb5MGaFBGABZpMN5MluAq1G3H82TCJ8cHcbzZNhM9o/mMC1icpb+C0yho3ZI6bYb6hgIWjVz+tNgFg3hIKe+9bDZu5jPbFeRobmRZcy3AGhycjnAKgLyaRx0FI3tEcFRzW/1ayuapVjn5SfwXJVDSxSDnDE8G/ksu16DYFBwTKcsU4XaJYgw2E2QyxV8L7d7tVtIt/AXWRf2TBCqP4EyMian0HLg02odSCRwKjQ242ihDPw/0kMKjSphXfaUStYLw/ICymvsDUrVQZRL2WF0OXC6zExWXL/RRblqNn3WrzW6ahmf6/Y67NI6TkwmyvPYKzik2xq6vL2lyzuQlbO8YJoqUbto6fJO31LlXYHm7/b76kz3GC5MlI8NdtRx/XFWsMPy8Zgcyp9gWR32+4mB3le/reUElD+JOyLKb3f9Lvv3ZBoF5XdgZ+BUPqURqmT/O5ttk+N4amfT59b2XQF8DeXTtrFPovzuJnIZlE9v6fJ7WrrdZ4Sa/96HdPlMT5ffx2wW5fe3mxvkf8D1VPksP1TlD3r6+0vedpd2uqeN8IHyMkr2814/bJO/DyX5Z5sbfh/l/eZGn/wDKNnvB/sa5zl9dAjlczfaO5yfH0JJveehpN4Pm9stjuP51pbK0n/EaqqF8ALLU7xp9XzqbWCTJG8huLFsNDW+3cRJDWUT5WWUmyjvRdlCs2zPQUn8rZYeD1rbZH/aLXeLfoO8RqUkXQdbMEp3y3vgQZTelvcgcR7a8p5zCaW/5V26D2XQ3urwu7DtWtTvYT/gvPQ7doOH2R2U7MeVznaH8qvdtkpJHu72tkOUP4o8gv16IcoA5Y/1YXCUL/KCkPIBSspf7G/75CPfa7Hc9XsbnPdh0PGoPwp1P+KwqzLSPUwT52+/j2M+yoO+rk/6etyP9LeVv1zr+6GPcozyMsrDIEDkFWKCkvwU5b0oZyjvQ/njKJ+Nco7yfpQpygdQLlDSTkcon4PyOAgQs4W4jpJ4N1AS7wQl8R5FSbyfQEm8l6Ak3k+iJN5LURLvp1AS72UyCC4T8Kel1Vc9fDkJQv4MCWK+ggRBf5YEUX+OBGF/ngRxf4EEgX+RBJF/CYTq6i+TIPKvkCDyr5Ig8q+RIPKvkyDyb5Ag8m+SIPJvkSDyb5Mg8itBqD7/Dgkiv4oEkX+XBJF/jwSRf58EkV9Ngsh/QILIf0iCyH9EgsivAXEvkf+YBJFfS4LIf0KCyK8jQeQ/JUHkPyNB5D8nQeS/IEHkvyRB5NeDuI/If0WCyG8gQeQ3kiDym0gQ+a9JEPnNJIj8FhJEfisJIr+NBJHfDuLZRH4HCSK/kwSR30WCyO8mQeT3kCDye0kQ+X0kiPx+EkT+GxJE/gCI+4n8QRJE/hAJIn+YBJE/QoLIHyVB5I+RIPLfkiDy35Eg8t+TIPI/gHiAyB8nQeR/JEHkfyJB5H8mQeR/IUHkT5Ag8idJEPlTJIj8aRJE/lcQDxL5MySI/FkSRP4cCSJ/ngSR/40Ekb9AgshfJEHkfydB5C+RIPJ/gFAh6sskiPwVEkT+TxJE/ioJIv8XCSJ/jQSRv06CyN8gQeRvkiDyf8ubj/lIrRbYrsUlIfMUy2BO2YlmMyY50tibTw+Zli2m+GtsjKe7Qsrdk0WciprU9wvCqOG++YD8hBkZ8q9RtIiU7gqyr2SMo53FpNEcPYIDqJCrC7aNdC49iEbT6ylI4yDZP8Bp9gDpHRLGUbyIkjGoeowup8wlkDge47Qb434A9PIiPlS3Rbpq5TjZxeFsSHpVXXrqZrOnAmGc+/9tcojEaB5hbGtibXdOzAlaBndOdUYYF5WdbxdySEMgezamTCQXzLNrx0ma7CKpkqKOIrurPi+WUiTcqXhYLgN7ku5N54fihWIlUUa/IVYVER4gSZ6w58jbowlkODk4rIHgghYgrUPWialZERfBVy9nL4hz8ynOGVBBT9ZTVoA4v6fMZ7Gz2aw9Km6bcSxNVSNeIm6PD6ePJBZQPFzwwYgr8g4miB0YsgEHEMbStfhEwGH2IG0nk7gV0zKANyhpJPsxcGvI4MHptHIi6mR2tOISklVc+Wiw9eFBxNQ5nqdwMVlw6kOnweaNlLR7HM9xkxSHEYyJoCBrY3W9pG4x+jAxboXH6E2K7UUu7Y9PZgcp9hW5PCpudlPsKnJFf9ZHgxDBdqvsWjG6l0m5theNx7u4IGmiIhW78twBZnkO8Gsb0xto4BVSrrcqIiyVXdzcjFJxBWeZ+RgDyQ8+tY2sW8JYgfvpXLwv5PVktOARzGDdVRA1EoUl6+TMdIiTFLiVvWSeLqzcNOjzEtypyi9vcrzCWB5ODw8j9CRbpuW5qy+0GZFeYvXuYWTKcGjqLHg0Os5WwHKjMJ4wjDlOkhijlCWSoQ+cynRG7Vgx3XhxfTq/lndhAgePxmhspFrMO3J2PhmicFGIYUhaLxW+lMHJ4e50nMGnikG7iFyazkFSAhg4RnI1BfT2JkaDFQnD5rB59DMMNTNyBhlSCFziYOzonAL0470Y51cM3ljbS8bxNlwdbpmqStWygSbpOa0IwRHHUHbVA1QGnyLjkPU8lC6NE0ST+Qn7EE6Do10eX3ehRoFYSM7XbDrBNOuGVo4me2PelU6gU0VcTdJeXhWPEFLWdK+t/PtOlGL2MkMNc6lGlbOj3XGSHgCM7bK34TSMo8N22Ts2YtzcSPaAA79Sce5OUYlze3tpvMBs1ubRKDliUKyXAW8JRRHwlkPGOeWGzmRviglQaFtCjo4y38JC8BCwpqxoxMfJML/ezq9ZmIer+3Vp4WSkzoqGkuHmhSd08DX9oZ/HPZ5l9ceWtTNQe6+8qRFh1MkglcMUZ845m8cYmDOC9ZK9BAsCc4yvNOZrEMvpc4ghXrayQgLgPRA9UadpgWuq/E5Lki5qDHL5zVYN10MYR65Zz9hCeSkT5PrLHbPbU2eQlawDG4hQ+3PGHae8ZUUrxah5CYvnZH3fyhuz7ClIngHQYyi+xBnLaQzyt8ez6uZsFiNcqFVi7BZihfIXMGUpsnJ36UbYcpUNlRZuI8w+jvjqFkPg0i57PJXBjrpXMGxs1vNFgD0aTpsKYzU92tvDTRScWW11CuVZArdWRdIzF7X0eJ8roMtNETMFFkkPnfDNcElw7tGCgZW7D+qx+GA4hHh3gosmKVag0ZzOh3Gg3rewoq6lEK9mfelvZmDCcJqDrm1nd3dme8e8GoCQbbWz8L0D0WPBHl4WMuJzv4GwUSyO2uToMMCygjFSsSTq2VJCWpJqaUBXRPDdP8JKnGfcyjCz5eqMCxSPKfeJtU0EH0xCLWtEFlDF/uNhsWOWriflrwNWBZbxqW0Crw+IyCF7zLso7QXZYy4urnx3mxIje5iv2XjEVsf+Oo75uCEDtZQ95izrsKTwKrFUh/wsGsGdKgE0D79UgMkxMk4hxpRSkn2Ch7nyKgvflKE5u17diA/gYbAP8PBo11a3MhgCnjYGOy0bi6DltBsDt4lHL1bjpgw33fr3DdKcD4s2I7wXTvbNyT4MhbwSUazCGgkeROZ+HvBq3vhoP5lk384UAyugvzrtRkev6U56qs6Px9HRZHhwiw8OkVfCrUHCpdXcgKzxNxvYmSeoML6pNkVMqSrDaB/z9uzZAdILsSwMRWjh/TPYM7+BfZGoVVit8MCCE31OqNinRQ9OIiyZdbHEUoueUzrsckbqiufiKvqa2h5WNKXFP1RmvqsZqSuehy+LvWCtYHTlDw8RJhYgzilCC5+f0uX7yFtRatGPYJEXufL5gtGVLxjBleDo8B1sJfK2CqsVzEg9L3Jw6PbtJaerN8qAZU+YjnBwd5wRamXrEHEB9RdYalEjVhHCOh1OLp6VanWbXzqpq4MRNO88JdBKzbJ5V1sThr3rjFArbyJJqzrm3VVeq7QqKd9jclpXOfCQaH8ezQ7oJJiNNfHYm0RacauQ5tfla+JxN8u06jZXksPVorIxKD7+tESrtQ8TzFI7QQGVJ6DIOF3dSVUkzs4Na+KJVV6rdBcI5iF2v2toGyrfVuW1intQ/IQAkwEItV08UTzpVnL9iQcODZk4R07Ek8S3V1it8JCWWNFMPFk8uWB0pa959QOJp4jvKDldHbCLCqtVdEA8TTzlFmL9QVjU9POfMzxdfOcZoVbuUW4hGoi7xVNzWlf1yVYy+seK7zot0Wo7uzf/buOp4mk3y7TqleOs7dKAMOx3n5Vq9auI22OPfCpeKp9ecrr6YSjDUloEhe+p8lrlR7lCsmPSi8UzSk5Xv5Ce3cXCxvn0e3NaV/2YGioj78uleGbO6LoXxSrPTXHvJ78vo3XNANF3hI1J/XoDHiWeKb7/JpFWfLFe7UGesbxJyh84LdJ6EVs2VQBKsQLF/eJZpyVabXdc5BIpbu3kD1Z4rTHUhy0OAlej4lLJ6vqR2j+xu6yIezJSV8RlELGylOLyTSKtuMf52Yynh/FifoJrQXlvVaB19vUU5UJq3XdapPUOsPqzn0w8TyQFoysfUXwWP7CGr1V5rTJWIi8acTuGymGV1yoT7osI++pQN80ZXTfTBzhaB3fE4sdLVtfP93iR0kEYbiSpCvYIy+kZoVZezPVETZuIWlLg3qhgtcKxnvgN9FAbNf8e2tdVxy1IEerU8hUvEDeUcAv3MfwZx4Y4SXVOpHpZplGvlOLRJNVSTx/pCAvUnwBVfFA9N75khMfJ47yGA+ZJ+Ser6n2djmH3fylXTPZwaCELmU7aTNo5QLTxU6dq0f0bi6NoXNV4mboSylQw5uE8ZqjACbOq9dNVrRZ8AasIsaKq8vKqijvHHCPkSTwpVMTBGLt8PHo4nk9R9YpqVTd7ktXPwSM8PJytzLxL7OG66GxtExsIuy4O8EZRqUaIT8UjuFaqyIq8dIzXC7odhvB2KX9JIvJlx17mcViJPh4zZjhLqhNogO1wUVT8SllRuo1ai1ievyoRAJHMRGMmERjtr8npsbr4wN6sJ1GB/Hp2T9GIYXq8kqNlzOpvSN7bIInEpjudteM9zF6ZHWAt/eYpBZ/R9CaN3yo1NqaLxfTwFii/fbPOrYBeWSqVNQlzDDwxYzBcT79zs06Iree0yqtoLS4xjDCFLyLiRNgJuL5+V2rfhv/qKxCsX9hOef6rJAI8VLNZUZcRr5Z44yllISYANxOvroga5SXFH8g4Kn5H0sa1AeyMw0f5u5Aunn6GqtPB4XS64I0LPnutTCYHcCteso4DHYsxXa/JxYEKmGXF6/KKEGusFP9lLrZVeCkrXl9UqK2rrPirvIL7Ril+Qy6u9KfJH4KwG6h/n0zSogo2/SPwujKX/IlMSSk7vFviLUuxp/3uw/Iov0yCGapB6c/kGHsibJStwRfj6QtfwpKuPr/2cY0AB8/C0huzKQ3YRmU63y+xy1aqykD5XolHsCQ9HSPfLGNlNxrVTHGcJwH5W6AZTPeQBqFXGRTEb4W4O530ZiNs2RnE27JuwuXgH0OljVrhYcEPSxl2AwzhHRIXFnDEg2Q8QrcayTFCA6+T3llxLg8BL54f4+qeuGjiXQSaYBZRqczbhIFLEX9oty7eQ//X0SK7yHqtxKBTBVIchT8gYSIVOdAtfBtCXbTwQFc2HyaHMdIK+OgHqpqdCAz+VyvqgxJMXlNZDB+Soxgb1kTxOL1gwpCk4IOPVC6AdO6GXO6j8pY+t1Fowu8+JqPsJP4hifc/WOv01tVWOVA/c4wl7GQTjBTbBlg1uDdIPBJOj1VH8rCsKl4n8WiYVfAUvgBwroCp+nheV3bHKceMF1o8MJ7RMMtbsNdLPDyqLSHr2zreHxdwrx4mt32q1yt4kNQHf44ItpKfwCvcPoLdyJ24YVP/xCYVM/nJQr63d6riU5UJDA6mR+NRcIi9xFSPQnTTT8uU+YTOLp6PR03FlqeKLG3CHH5GV6FzKl8vKz6rK3bUM0VDfE6zOtUG/3llDgQVdQvj4yl0ptcaZpf3CF/IeRVvvggHzqIx1dfxPJqk1mX09Eu5XjzqZwZax1OpNhAnqrgu+ZiUXwYMug+3nAdHMy7lLEoxMpncLhl4mT98RXc3y7KwHjmoBh5aC4A0Q/g/AL4qD+A26n0H5sN77LX4JJwn+/tYwJ+S4mvof8CVvwlPmEH/6+WCrDhOCqeT35DHU6xQ+xij9w7wmkj7fLO8ia7o405I3/DEVIbPCUNXpHAnWSs+sVW1sZyUn4YQY23LiujUIsbNVVFRWcO10+Oq36KrS6WzldFiueiLqSDxjleqFUlNxU9DqGJfNUpJtRendtV6qVM2WOnFLV2ed7lZiFQwTd6X5hIdNFfpsuNbrv+1s3HkXNngmRi9npmsoWOvWNq2r264ps8LUNHrbnfdHVw48ieduGlUt/nyyoZ7BXfxNmjDC+5DUQt2nNBqDTz1w7j6djkRBm8N+QCL22EJGypp1tYnMJUtdFG7pmHo10aVdsLgRj+Jr9Ot8bAxjCbHUcotFvkYwhUe7oScYUcaYzzH0MNADMU3Yg6U90s1/dGmRqurfxZBKP0vI54hpK5XoO3pUBkM5jMq4gC7qDI630Wv3IxojZPhNYGHphECIR4n4ZX8Xlu2mBBpTDB66Gc7GgKgzgqMUBsDMVHPpZC1qaayFuTBdJHOpouMNdLr0Syjazd/rOKKUZ9qLtP6VgCz3OmdcjFldfUeXCS/qr146pe7mR/qZTjBiRIThhc6ndrX4cD7sXbQJc6Kmr3PwqEPlfE/j1vWNDcpHkRXp7to6BirBQ/ja6OYTtHVmOeQhGLhKhOniMASz/60Xm7WFGFX4ur0tBFShFt5G5qao7fr4nacqnB9lum0tC0wvjtOyb1bGAKf++LCIlfJ4ZWRvyLlxQCdQ7zEReFDRzFuCvgmgCWMkXSzyUaGj80GrxEUaFumnXgRjQhhyF28VSDgx2NuiPQH2LYDQ8N+wribvcE6klXTI3peU0RtUiIia5B1jjfnvyolniuBLY7lcootMxpnFl2JhkPAibpYTZmxBLG6T0LNWs6HbPZBcS7nLWwwmAQlfq5Yn8FqjIVL4rwis573+aMLsNh91AYKu+uGvehkPI1GENyRnrJXgo5+TcoLlYEUpvkG7pr3gNTH3oWhY7x3KnQn9WjgaDw+cY8WaTKK7clwDG+Y7ON8i3FIcZdS9GBCZ4QpuPt/AUIbAADNmXmUVdWVxvd7QDGIgAwyCPgQIYg4EUSUqscNikkMKkFUgkYLtRRsBsOgxjgcGYrCgDIYTTSxC8XWqBhwjEIV13nAAW2NQzTBIYkdFaE1SjRD/7597yuPa/Va/Wf6rXVrf3d/ezzn3HOHKhSK1so6frKmaWVVp7pJw889b/6ZcyecMGfqN8fOmfTd8448evJ3jhtl3az7iYNatyqYFa11oc1Rs8+cP7Nu1jyrKrS7zMzaWxfralYwD2YDrHWxzYSp59SVDvnSoqMEPxedC3LoJjz80me2bKkcUlxgywpNret7W+Hj9g9+QwELBNy9zbF1dfOmzzqndMH0edNKU886d/7ceXVzSm+H1aVxM+pUTWnchWimz54zF5sZM0ozcQBF1sNKU2edVZpbN2/ejLrSvGl1pTNnTJ0+szR7VumHs+fPKZ1RN23qjLMPLJ1chxsBpp4zdfqs0nlzZp8//aw6maAm2py6ufNnzJtbOn/61FLdzKnTZxxIl20t73O3BgvjF5k1Zg0vt03dvOellv7b7tbJG++x0KzLntYTkfS+HLKP9bV+1t/2thKjt48NtEE2uFCwojzjo5X+MAMF+5oNwb2xsN/E2WfMnjfbxs6ecZZl+ADHQwvHMgD/X0es+LMCnfwvv3b/+l+rlkGdWHfO/BlT51TGtXJ6SLunqb51ZabbFAu20HYNKzZY/bhW1lrz0naB2bY2VjWZq2KRXXx2cUny8GutxET05CpGgYOJ9gCZbxfcLrWQWqFQXGANb8RMASbtLmahzbg8Zoo5UywusmM6xEyrqkvMplihFUx5VMy0hgmdrdAa5rRTY6aNovW3QhuY626NmSqYZF8rVMGM/zRm2lZdbPYPK7QtLrYeHWOmnXwuVAWLbc9yzLTPKyjCDJ4QMx1gVHU7mNI5MbMb0UJ/VbDYDlgeMx3zCtrD9L0hZnaXT1crdIBZ+XDMdBJTssJuMG+/FzOdVUEHK3SEWfZ5zHSRT38r7F6sD+O7xMweMElb9VNvzwyIma6KRj8FmG8fEDPd8NHMdYK5c0zMdMcnzFen9dZ7fMz0yDvtTAUrJjnTLmP2JJpNcJ+w7dyY6SmfL6zQBeb4uTHTSz4DrbAHzI31MdNbPjut0JUK/nRlzPTBJ2HmuuGzvTFm9oJJU/cJm5tjpi+MfLoT7YmtMdMPJvSxQg98lr4TM/01Bsd5P/bL7TGzt2rL+rFen8VMiWjqZ8/iknBom5gZoGj49IBZu3vM7COGPF2LS5IR3WJmINFUdc/iEhvVN2b2lc8UK/QqLkk/z2Y7ZwapNsatNz79BsfMYKIZ14+iPX9QzHwtj9aHaCsPjZkh8mmnMViSnliOmf2Uh372ourlY2NmKD5pyGo78fiY2V8+1LYHFVx4QswM+5JJrjs5Zg7IGSoIm06JmQPFUEE3on1yeswcpApSH9HwxqyYORhGIwqTbLsgZg7JGebH3g0xM1yjw/xQQTq3Pma+nlegMbj9ipgZQbTKGMy9NmYOlQ/9KM8118fMyDxPX3wGrYmZw4hmfbIKFtwWM6MUjQr6UcGDd8bM4fiEPa3QnzH46/0xcwRMWrLC3lSw6qGYGa1o/2WFEtFueixmqvFJqIAVElo/HzM1MFoh9BOefCVmynk/GuvJb8bMGHw01lqJp/4xZhL5TLHCAHx6vh8z31Btq3wMwsztMTNWTDYGdvN/x8yR5NEYdCfau1/EzFFi+mh0GtIbizEzDkajU8U9dXbbmDk6z9MHnyvax8w38dEYdIX54CvX9rdg1GmPYkPjrK4x8211yujAhJE9YuaYnNmj2FD7j54x8x1VwNohT+jcJ2bG53mounZl/5g5Vj5UTZ7SulLMHJfn6Uun8wfGzPFEM0ZHeQYOiZkJMJU8Nw+Lme/mefYhz0MHxsxEfKyj91Ma8fWYOUE+9NOv2JCMOzRmJuGjmetVbNj27uExc2Lu042qPx0dMyfho6ue2pJzj4yZk+VDbb2L/kRUUU/GQRti9+ICS0bGzPdgAgNQxdIYcUjMTMlDDYS5Y17MnKLhfFdJFlrtxzFzKtGUp8SDS/LNmPk+TEKenjDHrIqZ0xRtiipYZLVpzJyeV7AvTN+3Y6ZW0fbWtC22mp4xM1UM09YXZvzomDkDxvpoChZbWhszZ8JoCvaAaVocM2epAqZgEMzR18RMnao+0wqDYf68LmbOFrO7+llsr26OmXMUjX6+BnPf1piZRgXJ4+qnPhSqYma6GPrRrbl9r5g5N4+2F8yFpZj5N3yyLRmfI2JmhnzoRw8hx46NmZlfMrbqmJiZlTNUEH4zMWZmi6GCfjDjTomZ86hAIzqEaI/OjJkfwGjm5PPbEDNzYOSjqqesjpm5ykMFPNKEG66PmXnyYU6pzabeGTPz5UNt+8FsvS9mzsdHFfQk2p+eipkLNHNTtK552Hk5Zi7ER+t6KMyo92Lmh/jYjqzq9bti5iJVQNXclpKLLGZ+RDRtvNwu0q4dYuZimGy2l4Q9u8XMJYpGPwPZ+o/7yoq/lAqyq3FJcvjeMXMZ0VS1bnLvD4mZUIBK+pgnGj88pi4v5Jm41duikTG1QF7ZwsLryJha6F50y80xnfWVK39RQQX67rsk/IOXuS+pxQpoeRmnnBRT9R6QMnTnXD0lppZ4wCk+fsn+tTHVoIAaQO7edtD0mFoqSrcuRsM+/kFMXSEq6aPFvySZ9KOY+rGXkfUVzr8sppZ5GfRFrqTqK9vGcgVULvpKnl4eU1d6QPoaykAVVsXUVQqYraUlac11MbXCvShDd/7aG2JqpXLpulGuf78lpla5F7kYqPQ3t8fUanlpoHikDK/fE1NXi9LdRbkeeSSmfiJKuagwKT4bU9d4LipkDMO+L8TUtRVqMGUc/ZXr6qdqmc2yXfv2xUL2ASD7yOJfZYa16t7xnYs//PnpTz/V9OjEtcMfGtRw3oNHX9Da2uzilTE3n5h/L6h4vLlXvw1jdn42YNRDIx4/aNQ/dh327Y/PxaOxCtYOLF5WCIXC5QVbwOcEvhoUbHHB6gu2pGANBVtasFsK/+TXmeOfnW8uWIGPEFsKRavafxUnFhaUzUaOKfJhAfCtcpFX1DGZJj0+BpRjpaEx+CbG2w4Yw2cJbMJfcRdlj1fAt8oWRNnJaGTswKkFNcgKUIq8DPttkZqSn3JS2tTKwuEOzN7E7OKaVgwwoB1KZBoUUmBJOWPCepglyK1SPA6zgxL6oiyMIdhJZUvbj7FkhctWlj7hwMKfsNqBS9qKk2dRIpPlRBcIpwPCSExOxyTUAIZy1HJ0QGEq/GWq+oVLgqh/FMnvkF/Dd5sxVr+CCTvRDKaql5EXVuP7IID28n6tYEZt9prCznfAuz95nkYRxnCyiWMUxxrChjQC6X9gYgLN2N+N3CLFLZgoSBbVnvEJPwuLIRpyQKL5CY0RCK8pJFQLsEGEctCW4zyOT9TMjwCv0/eVLkl2nQNLbkK+VVPMQDIaRia0Z7NdorgTPyluZa46k8aB8lnj6C+B1ySqBbTUDbCH1I1NIKavpIuJWQGZA1QL0A/rKXBDmXqB2uHMy09rrPEwKR6tsW3VzDY9IulvmAMLY8uZRZhcdhdJjyFg+xADi7QvCsMl9MSCGEgUj1MyCvsZk+4WpHUXJDHsAbUQqgnodX4D8BGDbYytFmZyp8tWljB5AEu2Y/E5Fo0FgrxFhcj0zjKLDMCP0dlIVS1gHbYOHqWkDTg/J8UtRHuVkxUuUZzpwGwcsploAvwAEym4ArzIvFq7tRWlWwe0S4kgEJ7AaSPyQyl6E4qKwyUuaeF2B16J/UU5MCcQ66Q1jVWArajGVmBSkyW7sP3PJhTvAfo3m22hjcObucjWlc1ObLZQ75IWvuvA81oNCnuISgY1+35g1kzhrcpmJYL5pvIU0Re6xJRlDzBbj/yxFCmgLwrJZdXUKnBEDcwtAFZuuNglir0cmDXVmC2ShUaiE0pkUl/GV2Bp2Ritr6NeVMYGEMocEzi6SzEL5jcskhUu6W+DA0/MBkYUAAfVw2iukpUuUeALyII9gkLRkzsxR5KOxMGXmfayowiV9MjHuzQqB41o+LHfbcdFQGsmuU3GDbnGelVAbXXmFXpjI2C1UOMwDmtyjXY4B3lSu9UrANhOVXgpJbMWwm0umV9WL8BXcbKOSAL8CEAh/DLAGqJfQHiYYwPHs1IwJxqAZIVLwk914PmStIwvgB+VTmBIW0CiAkW1gJ1l26J1HX7NiRmx7wb8nIY3IMcyMXYtQPM9xSUWHRyY3UHELrJoB1jLIdlL5QjMwuoR5JUowgBObuZYTn03U59mqwWk92AiEJ7gWIviRRR2Pfa/w0wL/ndSTHNgdgLKl1H4gnqGA5k0lelxFAuvCUYgfQnTa5DvSbEV8DcU/ThaM/42kTSMv13hEsUmB77x+IaTfgp4CyUyvZvoAva5+v0MkBBQt7l2XCwONMj5KBrj+UPQUxinyxxYch3yD1LcAigQm4atN3EdnC+w2gEJjnCQref9YcJwutwHxkFbjnEwHxDNt2TC5/msXk8T1pp8vkkBwpMwdzMR21GErjRDl7rZIrG40YGlG7H6lFQOtDxKRcxagLqzR6AEwmbA2crOZPlSmOcSRXcHZveScAEWXkFHlEhKMkbmEM60Jzio5hhPP92kOJuT32C/zCXOGhkUqikMzIsLmzBNYLTgtaCQ+BIM4JLodo3GQRtEdlEC7APVJ7C9yWwApkOaSfEO+aY0s9NUS6KYvEnArIzVxGa6FtjcBHMHfT3JiW2URHFpjUAmP9mEKaAlH4ASdNlx38MYoJupra7cfzdn919rw02tGoUesgAMen7/tZPKmQsyiwHQzVRPRn53DfvRhm63xEBioXuAFFczarJQWrlIEiPbltIm4pxaA3sTgOkK57gkYBcHZo/hVpLFJMA9HPiHI8r0CKA1ejyKqiqAinAG+HQ1uESxzoElTJv1x1nAfbTbtQB+TO1mbBxkxdm92pY0z6EHsQXsYI41HEpmV8Mcx8ks5BQpRlDh5SiQyeZckbyD4gXkFyjCvgwbaz0scInFfQ58q3CL9GPMcZFMNpXp7XYH+ALSLaRag3xZimsx3QZLMCTBah34ck5fkWIU5s+jQKYP54qUlCo7+RWKUAd7K8rlKG9EkXKS/IKDcQrXoAifAC7nkNwrV9hNjPFLyE6Msd0LYMZS1eFT+A0H2VVXW43FeqavD8c0jjVy2VbNtc6J5LAyczoI02FE5+ndQhsOxXhbpqcCHmD8FrlE8TMHFm5CvorCJ2YXFkhmSq9iLLC7aUrP8HYz4BkO3JBUN9WBvyrZBuUW0LzbaVRUAb42dCFk4CiAb1+z8WbCkhtckv02B7qFWKkdpnlmO4gqwh4QNyrHjQxYBbAfMq9QLQDKLsDedpUtuVXKERGwX9QQth3LtAV4lb+slCvgL3Rc8C0g2UcA9xbAUsCYFC2AFFmdQ8nioX5OqBagvdepFsAve1tczYnP9SgHZn/C/kJmg0c2C1UoJS9THkDSwNAJhPUw12G6VYpXGZSPUAxkxIyx5CrysQysRiSD+7ADC79H7sDF76DPcYJMlhNdgL2fNLs5IOrugH1p8nCkbne+qS8k1U9cEvVOB7pGzW6XYivgP6nqTdw6ECz5K4omMa8AaC/v1xiq5dh8qDxnOuDJl8NfH3tS16OcdOJoJEp4LgIsV0ph3eldNXB12etS3MYJQfKo9ksNrh4REq26sDdatW2n4Mc4EE2ScXjVgSX42HtYpJ9j+oUvQb1B49INgEU6gEMuyXEOzPiwkNxLVQL82AEPi0C4i2gOnqeKQ/B5E0UjG3fyAbn2ctnKSp0cWGMbLN5AkaiAZzk+49DDigA/8jwVgWQDtg5wTq7iULRwpAPuEzg/VsYUwA/wY6alAnxQ8tHJ3+OyE7KV8PRQp+Ujs8YlyagDYKnkXcQW4IcPZfDLwd04JwBfDJuQ/sT3KwCFaf6RhP+hAwsnI7XphkMBL6Gg4jQtEwzAj0KXVUoHZEVm1dqbXjo92xBpAWhZdVdHIP1zOaNagFUpncAWAn8XeRsrVP3aFSguc4liiQMLP0FeU4OvgB6s/eWLRWxnuaS7wQ6y6/WNahTPEWgBh2QVeQW8AFsx+kvgRYpqAS2NAHwnCz+i8tuxTx8oZ2a60h0k10I1QIX/xt4HqKkCLmEgj4HimYdDmrXVSIHv5F62tTqLY23KGchz5Rv/zXj+gZFKrkf7R06ucklzlAfIJuj/mCkrVWIPAHwk7+PxZhn5O6DWVXqDgyxhO0wd/KGcfSPJd0siaSOtgCwkVAvQjyt+eY2V9ieoQHowl+OtPKONkOJRZpJ3Rh77JVH0ogMpBnPxucUI6pALMosBCINQYMHVjwIX0wdGYiBREBTgWTIL0roLkhj2mm9DI2H9GR4QNhDjZ3TwghRs3HpvCwNJWcA/nEIqxiKsdMngPOlAS0Z7FBZVRH8CFyQrlOYB3NMzRnt1+ncy/IUFnG4HnEfKF5FPsioDTyxaprbKJflHOuBBiToW46IKrTNKZKgnugC1GxPRgQo8DyAciA3DYzvkdBpgIY4K6/eFex2YPY3ciSL9HeBgSkMSLVMk9xHnKRQaiXAPJx9y0DgSxWkO/H6bvChFB2LcjwJJHfaeHipDiqKzWIAdCnMXim+jSNYCiGGXI2ei0PuJvnz4e1ODFNyotB1x57J0jRSLUKxHIflorggsRL4ZWvgbCr2zaTZssUss7nbge3z6BRba0uxd6pDcXGYxNzmgZYEXyb8O09+jCL/g5EOUBEOiONmB2Wjk21L0B7zCgUwfyxV2LwfTHO6Q4gRO1pJuGcfPUWifDVdzPIrLUilex+JS2HdRno5Cq0IPhZK2Z66w6xmDF5BVmq17AKwKFoAkMcY74NETOaEaxVYmtwvHtRzX4WJlwIccyDC4zLrpSJbBRA+d8NkBcwjSHzsnAVgcHl2rJW10kD3SrEPhc8mVIcnkZl+AEkbZ/lnDrjeQ9a6rvvaIHOgOzQ+q8vLOd0CzZykjXAKQRjPHD+M7KrveO8yyg1Oh2mFs68qZJnmxArKk+S2SXS7VPOn1IIVJ1rhE8ZkDvyGm/7I7Y/ZwKaoCqNYe1mXiF6LuXPY4IFTrWxt3L8Y6uQmgqZ3pEot+DvzqsI5Y6HMv7xqZ1HoRCOdixXyHZVIcxsla0v3EJe0/HIHkAUwEwguc3IPZ76W4mZPtKJe6pMmpDigei7ek6I/iZSyQlEuPC8n3CIxA+gqmm1D8WYpPAX9HMQwXfRIK3ycIE5Isc4nFRgcWCGh/k8sOFO9yshO5UdEB9nf1KzCBgJ8jrZqRdGCYPO3AWAoXgZbLmEkDWPgP5INSPAjgEd4b7klcAZ4XCHODA0y6OXBpA3OFfcToHoxsVpBjAYp6USYb/S6iS8uvaEDKHUD/pwlaj2EQPai5BS6xuMuBpc9i9TG5HWhV0HsE1JRmhR9r/XnANLKHuwFaAYRDEm6wA09o9VioAuuCUrKe+ALUZlTZkeYWUZRAGIbNcA7dA2wyYCl2y12S5wEHXlzoRhQBFiimMLoC+OAoiQJfQBZMNwNFT+/nBEm6/BsR4+CXrYBd1EQKQJjSzFMKS94/CW3dKEC/TXx1b6ZygbZiFm2ysBtMr2pJFPvUCJidQZN/IZitArzUlMnLm/AFtOQDUII+G3HfxxjQqIeJ64jiTxf3AfS48b5LamMAAb6+G2Wh0UpxkfQYAnqYkIU/XcjFHzeIgSTovQ48i1sorVwkiZF9I/J1e1IN7K8ATGSY7xLF3g58L8y+ETEfHrSBo6ZMjwBao8eS95iBMKZMNQDZJ1onmtBEE4JCzyzZhALcxz6LAD/AlgrIirMzjELrybpHM8pp1dy4mqjnfDQHNnk/PK/CCPy2BtAHvxbQvQZbAT75WQEZmlDwtcj+0FQJa28VyRGugtVtR6/sAEsfRG6WQsvvC/p5nvKHlon8hQM2q7/C7CLI+8i1Mn0DUGKoH0GeV02q2wEMpEfXyIaDHfCVG7dLcdF37NAeJTJdpOiAsIzoAsa+yDtG/rl8K8xOFMx7UmBWwyQWANdzQnQkBW1yYOnrWOySiyp8k0Ml61uMN7EBRl2lWzDbiOINFOGXgA9RXOUSXy4uQHaHfgmFnrA0Ki6vIJiALciZoN1Apu/Rle5RGsRAMMk1vt4uwKqt/AiSTfsHOQiXYndLE0nHYzOlOdvDpzRjwjOxfU9gCBr/WivQVoD5C+2bcXrXgV/19iFRvJYnmiwchjyqCdPxgHQ04ODKbX4bM+rgAjK25VrTKjD+SZf4NgUIHWHex3FBDYrnAZq4f3dJjpMd+DcEu6iGQHsBfOnqptsCtKvqptsCUn1waPkSc4NLpo74AEtJyP2OhFRgT+GHTBrKRBNgT+MV7DUK05YvkP6akyc4tESSe/H+AKfVLslzjIMs8UPlrILQG8ZvJlyVAVMkwe5xYAnBeDJDQfSwP36SS8vZW7VuYvwoB5D+mYi2o/pLkA0pVAso9aA7gW184jCypyNR6PN541jaXeWSZDc60OcRCxoqW4/pATDJWj6aH4jvtS7xDQ4sTCtbMgSFTcCUzzCSoYd8AV5AuiYCWZFQLYAfgNr0W+3treBkLM07WMlxB8cGKZ4CvMBRwO8FFKGfA3+6yCxGA1aikPQYAs9UZxal6txlPf9bUIz1G7FQUCmURRaeVi6SY2vsPhUVfkBfddQcLgO0AdgVBDhV4EWAf5H8PAe1JQZCVK32+9aAZD/A2YAwDiCbxu/nIPD9iR8avjvxw/gD5qG1qD+Sqysg3ZZrTCtFNvq6zQ/NJ1SqODwhZSAv1a70x8uE5aV1KqBN358UfHEPYhbaM/0LXDLJLD4Aexz+O6g1oTGfufC3CPhbhoNfN1nyJra9mnFuRnFis15sJAn/PQf+PyCrluJFEg9sZg0hP2qi4M8AfjM4jCDsHaG+LEmwWx34oyF7CBbPAc5vyuQO7SECk2swvQvAFpDQBZLKaAuQ9envzTRunVEiA9UxJrvTju8wADuAXMORO2U7GbCUgVrukmgPOMjydS9niYPe93TNa6KSKzl0mathQPbvRG0Eip7ezwmSdNnuxndLneAPcOZ9LHTTs+cBFJ7e4BLFKQ58u7CJNYy+wIRmilhGRRWQTUwfIgnY3tTnu9vJZNdsEg5Jwucc+J0y1QLwCp7mBBm0uwlQm/FG9xpRtGoEkvuxeYzjBSnuQkGX+qc4kjzjHWTFPVGmFEDYDcbGo+HGk2KKRIEvQOPHbQeFotv++CNJZ8eQOlyI7gu6TTZDqKWwvQKWQ2nN66bLj24XVWeU7uUOcnez/wE=(/figma)--><strong>Meeting with adj</strong>uster</strong> &ndash; Element Exteriors will meet with adjuster, and settle the claim on your behalf. We will again provide you with results via email.\r\n  </li>\r\n  <li>\r\n    <!--(figmeta)eyJmaWxlS2V5IjoiZVQyanB1Y3NQU3JhR0JyVFFwQ0ZYS044IiwicGFzdGVJRCI6MTUwNzA2MjExMSwiZGF0YVR5cGUiOiJzY2VuZSJ9Cg==(/figmeta)--><!--(figma)ZmlnLWtpd2kBAAAAXxwAALVb+Z8kSVWPyKq+pmd3Z3aXU0RERETF2dlld0FEsrOyurK7qjI3M6t6ZkWK7Krs7typriorq3umV0REvG9FVFREvBCQ+5bbAw8OOQQRRA79P/x+I/Lq6ZHf3M9nO9578fIbES9evHgRUZN24jSN9uPwZBYLcduW63QHQWj6ocB/XbdhD6yW2d20A7CyF9h+hTeUtt1tgK4FzmbXbIOqB+HVtg1iSRGDwCbWstJVyINg2/EGvt12TX650nVDp3l1ELTcXrsx6Hmbvtng96sZOWi4XfJrOe/bTd8OWhCdCyy7aw8g9lqDh3q2fxXC9arQt702hefNG0mKLl8BLSiQ5nCIoUPk22Zj4HaVmlDMju+EbFF2p6PYO4jSGGoWqkKbPYZSx+0rUu4kk1Ey2fePxtTput2Hbd9FhXAbqp4I2rYXUWlDJBqu1evYXVpFWma3bwagjE3f7Xkgak3f7FCvvuG6bdvsDlzP9s3QcbsQLvVtK3R9UMu0JcqVtqNgV+122/ECkms+lDBJahbO+fZmr236A89tX91UIOtoqtuwGzBOqXc+tK+wS7cFbcei4PbgamfD5Yze4XTRWFdJL2yM48mog1EJcZdnBsEgbAFuk7MBf/E7ygdkw/S3bbZldHrt0NFzUGNX0ZONns+quuW23YJbajubrVB9sxzA1opSg8MXDbexaYNf1Z/k7BpmwW+bxD4XuM1woDDArbdMv1Fw5xtOs2n7th7BbfYVq90LtD1vb/UouyMww15h5AuqFRAX272O03UDJ2QTd3pRMlnoyVwJ3LbDCRZws4aD2URr7CokshCxVPbA7IKkCObmbEBWK2RQ6rhqFdWdjqlGtgQP23JALDuHWJ3BMBrH2uhYXr4dWsreTYfDk02nrRoJHTWTNXtvLx5mHa073S4WbdAyG+4OKkXDd72SlU0X/oEJ7DYGG+0e+2VsmNb2aVEtjG8sLLUMll3f2XT0Shc9D66JUrbdHUWgC6HuQwBHaA8s06Nz10tu0HR9Sy2dJYI24uF0Hi2S6QTf5AsELWNaYU7QEsN1tu3SyYzu0eFuPO9NkkWKb3yTwxCec8VuByAkeoTlT7sY1nSSLuaVScNkQi5Yr7orOybjgYE2MpPWAstUA6g3gdgY6C+WMkZpLweL+fRabI6T/Qk+KMAEVomjApd0e2FGGlrZimZAyceHoajZlsFDPdOnyDB9391RLsRB1DRrP9Rz2og5vrJ2XUNtTRM220GEUq1u2H2b1TJHNTam03EcTdxZnFu23utqz0Yf8VmAZQ9aBr2N0DcVbVxRDq8mWo2sNZ0nj04ni2iMz9t2k0oVw8EJ1NIytnoBorejZrT8uh/PFwl8ljLXQ1Xl0w03DN0OKKMzPUpj62ieTueYnIbdNBErUCEs3w3goo4PWtpXbfos5hWcgc1HNeWZGApihwXfAF/3VLxYQmE5bVDLfSyB6byTzOdEL3wL60/Nr1QEliPChN3dDDn5RiNKD/QqMywEU4hE6RpSrUTtSXWvuwmR2PJsljLoszC8RhNFzb4xm84XN3tfzXJhAnQ6dzGRC3achmpf5oKWnZu3HZ1Mjxab82SkQeraISvmLDtoaP+sld940WIRzyeogpbjKd9CwFKBS6rJOlpM/ThNHgV0YSLVHWWZoh+yoODQJ+M4iLNBweB+4GbhILRNzqu04BN6hrFPY1fuWgyftdDueK5vqj0azqxhYKVFXJjoTFQFKfOYiKaj4TU9P0VnW4hHD8NsqgcS20HowLygtbbyRqifMZu2lVaypkfoxDzTPWviXLewdE19tnWULpK9k2/1hWda9gALVCcX+rNAWdtQIQVCJBOB87A9CN1BFs5hkgmcFytXW6WIG/B424etB8zLwMuer0a6gYCNsma1XbX/1x0OJ6pAnHe7A3i0UhNmEzCD0OnYiFPgZcdFYjdQYzA0rStq+KrFLRZ0XVdg16DakuZUwrIMLQ+DoHMhl1NdXW34JlfEGuq27av5Z+fA9l2dXqyH82iSJmUfn4D4iSwjHCAmIZJme7FoOAG8om+DlE1kfygNpChIA5u+28HiVaGpVhHlsalekekotFSRFGFo2esFLS3LwFZKSY61Woo01FopKJDOMSvUsgxpvZTkSOdLkUa6rRQUSLfrjmIaoJSD3XFKmONdOCXVkBdPyQrUO1VLmTQDvasqyzHvrgo15GOqogLxsViajjVgHbjHYZtHem92sWJV/vx4O0qRHOv5RSYysHobjoUKQaCckUixKqzBXVBnSMFwPh2PG8lcLwdgZP71LZY9+qaXqPoWa2nBlRCPsPYWMertKx5Cm156FhC4ASpObvYQe6SR4lSAxkCvCDmeYhdTJLKJMXYSWZ+LNSH38cfYxZ9ahD91vdng4xvg5An+GD5E0C4F1/GndoA/dYUULKYzfDAkLUIhZ1O9GKBgdKLFPLkh5PLhpUvg5eGle1AYh5cuo6gd3kNh/fAeCpcO76Fw2YvmCKPOZBTjO2P/KBkJvwK6nudNqDyOxkcxvpFHKod6PGIRrNSNDmMha3vRYTI+gb5MGaFBGABZpMN5MluAq1G3H82TCJ8cHcbzZNhM9o/mMC1icpb+C0yho3ZI6bYb6hgIWjVz+tNgFg3hIKe+9bDZu5jPbFeRobmRZcy3AGhycjnAKgLyaRx0FI3tEcFRzW/1ayuapVjn5SfwXJVDSxSDnDE8G/ksu16DYFBwTKcsU4XaJYgw2E2QyxV8L7d7tVtIt/AXWRf2TBCqP4EyMian0HLg02odSCRwKjQ242ihDPw/0kMKjSphXfaUStYLw/ICymvsDUrVQZRL2WF0OXC6zExWXL/RRblqNn3WrzW6ahmf6/Y67NI6TkwmyvPYKzik2xq6vL2lyzuQlbO8YJoqUbto6fJO31LlXYHm7/b76kz3GC5MlI8NdtRx/XFWsMPy8Zgcyp9gWR32+4mB3le/reUElD+JOyLKb3f9Lvv3ZBoF5XdgZ+BUPqURqmT/O5ttk+N4amfT59b2XQF8DeXTtrFPovzuJnIZlE9v6fJ7WrrdZ4Sa/96HdPlMT5ffx2wW5fe3mxvkf8D1VPksP1TlD3r6+0vedpd2uqeN8IHyMkr2814/bJO/DyX5Z5sbfh/l/eZGn/wDKNnvB/sa5zl9dAjlczfaO5yfH0JJveehpN4Pm9stjuP51pbK0n/EaqqF8ALLU7xp9XzqbWCTJG8huLFsNDW+3cRJDWUT5WWUmyjvRdlCs2zPQUn8rZYeD1rbZH/aLXeLfoO8RqUkXQdbMEp3y3vgQZTelvcgcR7a8p5zCaW/5V26D2XQ3urwu7DtWtTvYT/gvPQ7doOH2R2U7MeVznaH8qvdtkpJHu72tkOUP4o8gv16IcoA5Y/1YXCUL/KCkPIBSspf7G/75CPfa7Hc9XsbnPdh0PGoPwp1P+KwqzLSPUwT52+/j2M+yoO+rk/6etyP9LeVv1zr+6GPcozyMsrDIEDkFWKCkvwU5b0oZyjvQ/njKJ+Nco7yfpQpygdQLlDSTkcon4PyOAgQs4W4jpJ4N1AS7wQl8R5FSbyfQEm8l6Ak3k+iJN5LURLvp1AS72UyCC4T8Kel1Vc9fDkJQv4MCWK+ggRBf5YEUX+OBGF/ngRxf4EEgX+RBJF/CYTq6i+TIPKvkCDyr5Ig8q+RIPKvkyDyb5Ag8m+SIPJvkSDyb5Mg8itBqD7/Dgkiv4oEkX+XBJF/jwSRf58EkV9Ngsh/QILIf0iCyH9EgsivAXEvkf+YBJFfS4LIf0KCyK8jQeQ/JUHkPyNB5D8nQeS/IEHkvyRB5NeDuI/If0WCyG8gQeQ3kiDym0gQ+a9JEPnNJIj8FhJEfisJIr+NBJHfDuLZRH4HCSK/kwSR30WCyO8mQeT3kCDye0kQ+X0kiPx+EkT+GxJE/gCI+4n8QRJE/hAJIn+YBJE/QoLIHyVB5I+RIPLfkiDy35Eg8t+TIPI/gHiAyB8nQeR/JEHkfyJB5H8mQeR/IUHkT5Ag8idJEPlTJIj8aRJE/lcQDxL5MySI/FkSRP4cCSJ/ngSR/40Ekb9AgshfJEHkfydB5C+RIPJ/gFAh6sskiPwVEkT+TxJE/ioJIv8XCSJ/jQSRv06CyN8gQeRvkiDyf8ubj/lIrRbYrsUlIfMUy2BO2YlmMyY50tibTw+Zli2m+GtsjKe7Qsrdk0WciprU9wvCqOG++YD8hBkZ8q9RtIiU7gqyr2SMo53FpNEcPYIDqJCrC7aNdC49iEbT6ylI4yDZP8Bp9gDpHRLGUbyIkjGoeowup8wlkDge47Qb434A9PIiPlS3Rbpq5TjZxeFsSHpVXXrqZrOnAmGc+/9tcojEaB5hbGtibXdOzAlaBndOdUYYF5WdbxdySEMgezamTCQXzLNrx0ma7CKpkqKOIrurPi+WUiTcqXhYLgN7ku5N54fihWIlUUa/IVYVER4gSZ6w58jbowlkODk4rIHgghYgrUPWialZERfBVy9nL4hz8ynOGVBBT9ZTVoA4v6fMZ7Gz2aw9Km6bcSxNVSNeIm6PD6ePJBZQPFzwwYgr8g4miB0YsgEHEMbStfhEwGH2IG0nk7gV0zKANyhpJPsxcGvI4MHptHIi6mR2tOISklVc+Wiw9eFBxNQ5nqdwMVlw6kOnweaNlLR7HM9xkxSHEYyJoCBrY3W9pG4x+jAxboXH6E2K7UUu7Y9PZgcp9hW5PCpudlPsKnJFf9ZHgxDBdqvsWjG6l0m5theNx7u4IGmiIhW78twBZnkO8Gsb0xto4BVSrrcqIiyVXdzcjFJxBWeZ+RgDyQ8+tY2sW8JYgfvpXLwv5PVktOARzGDdVRA1EoUl6+TMdIiTFLiVvWSeLqzcNOjzEtypyi9vcrzCWB5ODw8j9CRbpuW5qy+0GZFeYvXuYWTKcGjqLHg0Os5WwHKjMJ4wjDlOkhijlCWSoQ+cynRG7Vgx3XhxfTq/lndhAgePxmhspFrMO3J2PhmicFGIYUhaLxW+lMHJ4e50nMGnikG7iFyazkFSAhg4RnI1BfT2JkaDFQnD5rB59DMMNTNyBhlSCFziYOzonAL0470Y51cM3ljbS8bxNlwdbpmqStWygSbpOa0IwRHHUHbVA1QGnyLjkPU8lC6NE0ST+Qn7EE6Do10eX3ehRoFYSM7XbDrBNOuGVo4me2PelU6gU0VcTdJeXhWPEFLWdK+t/PtOlGL2MkMNc6lGlbOj3XGSHgCM7bK34TSMo8N22Ts2YtzcSPaAA79Sce5OUYlze3tpvMBs1ubRKDliUKyXAW8JRRHwlkPGOeWGzmRviglQaFtCjo4y38JC8BCwpqxoxMfJML/ezq9ZmIer+3Vp4WSkzoqGkuHmhSd08DX9oZ/HPZ5l9ceWtTNQe6+8qRFh1MkglcMUZ845m8cYmDOC9ZK9BAsCc4yvNOZrEMvpc4ghXrayQgLgPRA9UadpgWuq/E5Lki5qDHL5zVYN10MYR65Zz9hCeSkT5PrLHbPbU2eQlawDG4hQ+3PGHae8ZUUrxah5CYvnZH3fyhuz7ClIngHQYyi+xBnLaQzyt8ez6uZsFiNcqFVi7BZihfIXMGUpsnJ36UbYcpUNlRZuI8w+jvjqFkPg0i57PJXBjrpXMGxs1vNFgD0aTpsKYzU92tvDTRScWW11CuVZArdWRdIzF7X0eJ8roMtNETMFFkkPnfDNcElw7tGCgZW7D+qx+GA4hHh3gosmKVag0ZzOh3Gg3rewoq6lEK9mfelvZmDCcJqDrm1nd3dme8e8GoCQbbWz8L0D0WPBHl4WMuJzv4GwUSyO2uToMMCygjFSsSTq2VJCWpJqaUBXRPDdP8JKnGfcyjCz5eqMCxSPKfeJtU0EH0xCLWtEFlDF/uNhsWOWriflrwNWBZbxqW0Crw+IyCF7zLso7QXZYy4urnx3mxIje5iv2XjEVsf+Oo75uCEDtZQ95izrsKTwKrFUh/wsGsGdKgE0D79UgMkxMk4hxpRSkn2Ch7nyKgvflKE5u17diA/gYbAP8PBo11a3MhgCnjYGOy0bi6DltBsDt4lHL1bjpgw33fr3DdKcD4s2I7wXTvbNyT4MhbwSUazCGgkeROZ+HvBq3vhoP5lk384UAyugvzrtRkev6U56qs6Px9HRZHhwiw8OkVfCrUHCpdXcgKzxNxvYmSeoML6pNkVMqSrDaB/z9uzZAdILsSwMRWjh/TPYM7+BfZGoVVit8MCCE31OqNinRQ9OIiyZdbHEUoueUzrsckbqiufiKvqa2h5WNKXFP1RmvqsZqSuehy+LvWCtYHTlDw8RJhYgzilCC5+f0uX7yFtRatGPYJEXufL5gtGVLxjBleDo8B1sJfK2CqsVzEg9L3Jw6PbtJaerN8qAZU+YjnBwd5wRamXrEHEB9RdYalEjVhHCOh1OLp6VanWbXzqpq4MRNO88JdBKzbJ5V1sThr3rjFArbyJJqzrm3VVeq7QqKd9jclpXOfCQaH8ezQ7oJJiNNfHYm0RacauQ5tfla+JxN8u06jZXksPVorIxKD7+tESrtQ8TzFI7QQGVJ6DIOF3dSVUkzs4Na+KJVV6rdBcI5iF2v2toGyrfVuW1intQ/IQAkwEItV08UTzpVnL9iQcODZk4R07Ek8S3V1it8JCWWNFMPFk8uWB0pa959QOJp4jvKDldHbCLCqtVdEA8TTzlFmL9QVjU9POfMzxdfOcZoVbuUW4hGoi7xVNzWlf1yVYy+seK7zot0Wo7uzf/buOp4mk3y7TqleOs7dKAMOx3n5Vq9auI22OPfCpeKp9ecrr6YSjDUloEhe+p8lrlR7lCsmPSi8UzSk5Xv5Ce3cXCxvn0e3NaV/2YGioj78uleGbO6LoXxSrPTXHvJ78vo3XNANF3hI1J/XoDHiWeKb7/JpFWfLFe7UGesbxJyh84LdJ6EVs2VQBKsQLF/eJZpyVabXdc5BIpbu3kD1Z4rTHUhy0OAlej4lLJ6vqR2j+xu6yIezJSV8RlELGylOLyTSKtuMf52Yynh/FifoJrQXlvVaB19vUU5UJq3XdapPUOsPqzn0w8TyQFoysfUXwWP7CGr1V5rTJWIi8acTuGymGV1yoT7osI++pQN80ZXTfTBzhaB3fE4sdLVtfP93iR0kEYbiSpCvYIy+kZoVZezPVETZuIWlLg3qhgtcKxnvgN9FAbNf8e2tdVxy1IEerU8hUvEDeUcAv3MfwZx4Y4SXVOpHpZplGvlOLRJNVSTx/pCAvUnwBVfFA9N75khMfJ47yGA+ZJ+Ser6n2djmH3fylXTPZwaCELmU7aTNo5QLTxU6dq0f0bi6NoXNV4mboSylQw5uE8ZqjACbOq9dNVrRZ8AasIsaKq8vKqijvHHCPkSTwpVMTBGLt8PHo4nk9R9YpqVTd7ktXPwSM8PJytzLxL7OG66GxtExsIuy4O8EZRqUaIT8UjuFaqyIq8dIzXC7odhvB2KX9JIvJlx17mcViJPh4zZjhLqhNogO1wUVT8SllRuo1ai1ievyoRAJHMRGMmERjtr8npsbr4wN6sJ1GB/Hp2T9GIYXq8kqNlzOpvSN7bIInEpjudteM9zF6ZHWAt/eYpBZ/R9CaN3yo1NqaLxfTwFii/fbPOrYBeWSqVNQlzDDwxYzBcT79zs06Iree0yqtoLS4xjDCFLyLiRNgJuL5+V2rfhv/qKxCsX9hOef6rJAI8VLNZUZcRr5Z44yllISYANxOvroga5SXFH8g4Kn5H0sa1AeyMw0f5u5Aunn6GqtPB4XS64I0LPnutTCYHcCteso4DHYsxXa/JxYEKmGXF6/KKEGusFP9lLrZVeCkrXl9UqK2rrPirvIL7Ril+Qy6u9KfJH4KwG6h/n0zSogo2/SPwujKX/IlMSSk7vFviLUuxp/3uw/Iov0yCGapB6c/kGHsibJStwRfj6QtfwpKuPr/2cY0AB8/C0huzKQ3YRmU63y+xy1aqykD5XolHsCQ9HSPfLGNlNxrVTHGcJwH5W6AZTPeQBqFXGRTEb4W4O530ZiNs2RnE27JuwuXgH0OljVrhYcEPSxl2AwzhHRIXFnDEg2Q8QrcayTFCA6+T3llxLg8BL54f4+qeuGjiXQSaYBZRqczbhIFLEX9oty7eQ//X0SK7yHqtxKBTBVIchT8gYSIVOdAtfBtCXbTwQFc2HyaHMdIK+OgHqpqdCAz+VyvqgxJMXlNZDB+Soxgb1kTxOL1gwpCk4IOPVC6AdO6GXO6j8pY+t1Fowu8+JqPsJP4hifc/WOv01tVWOVA/c4wl7GQTjBTbBlg1uDdIPBJOj1VH8rCsKl4n8WiYVfAUvgBwroCp+nheV3bHKceMF1o8MJ7RMMtbsNdLPDyqLSHr2zreHxdwrx4mt32q1yt4kNQHf44ItpKfwCvcPoLdyJ24YVP/xCYVM/nJQr63d6riU5UJDA6mR+NRcIi9xFSPQnTTT8uU+YTOLp6PR03FlqeKLG3CHH5GV6FzKl8vKz6rK3bUM0VDfE6zOtUG/3llDgQVdQvj4yl0ptcaZpf3CF/IeRVvvggHzqIx1dfxPJqk1mX09Eu5XjzqZwZax1OpNhAnqrgu+ZiUXwYMug+3nAdHMy7lLEoxMpncLhl4mT98RXc3y7KwHjmoBh5aC4A0Q/g/AL4qD+A26n0H5sN77LX4JJwn+/tYwJ+S4mvof8CVvwlPmEH/6+WCrDhOCqeT35DHU6xQ+xij9w7wmkj7fLO8ia7o405I3/DEVIbPCUNXpHAnWSs+sVW1sZyUn4YQY23LiujUIsbNVVFRWcO10+Oq36KrS6WzldFiueiLqSDxjleqFUlNxU9DqGJfNUpJtRendtV6qVM2WOnFLV2ed7lZiFQwTd6X5hIdNFfpsuNbrv+1s3HkXNngmRi9npmsoWOvWNq2r264ps8LUNHrbnfdHVw48ieduGlUt/nyyoZ7BXfxNmjDC+5DUQt2nNBqDTz1w7j6djkRBm8N+QCL22EJGypp1tYnMJUtdFG7pmHo10aVdsLgRj+Jr9Ot8bAxjCbHUcotFvkYwhUe7oScYUcaYzzH0MNADMU3Yg6U90s1/dGmRqurfxZBKP0vI54hpK5XoO3pUBkM5jMq4gC7qDI630Wv3IxojZPhNYGHphECIR4n4ZX8Xlu2mBBpTDB66Gc7GgKgzgqMUBsDMVHPpZC1qaayFuTBdJHOpouMNdLr0Syjazd/rOKKUZ9qLtP6VgCz3OmdcjFldfUeXCS/qr146pe7mR/qZTjBiRIThhc6ndrX4cD7sXbQJc6Kmr3PwqEPlfE/j1vWNDcpHkRXp7to6BirBQ/ja6OYTtHVmOeQhGLhKhOniMASz/60Xm7WFGFX4ur0tBFShFt5G5qao7fr4nacqnB9lum0tC0wvjtOyb1bGAKf++LCIlfJ4ZWRvyLlxQCdQ7zEReFDRzFuCvgmgCWMkXSzyUaGj80GrxEUaFumnXgRjQhhyF28VSDgx2NuiPQH2LYDQ8N+wribvcE6klXTI3peU0RtUiIia5B1jjfnvyolniuBLY7lcootMxpnFl2JhkPAibpYTZmxBLG6T0LNWs6HbPZBcS7nLWwwmAQlfq5Yn8FqjIVL4rwis573+aMLsNh91AYKu+uGvehkPI1GENyRnrJXgo5+TcoLlYEUpvkG7pr3gNTH3oWhY7x3KnQn9WjgaDw+cY8WaTKK7clwDG+Y7ON8i3FIcZdS9GBCZ4QpuPt/ASMWAADFmXecFVWyx6vvBAYYGCRI0IELCLqIAUTinUuLOYJgQFx1EAbDovBA1HVRj8TBB4piTju6oCjsEg1IahVRcniygCuIcVkVBFFRMLxvVfcdz/vr/fPeZ/vzOdSv61dVp6rO6e4zlyBISZ4UL3v7z0/XrltxSccbh48aNLJPvxEDz+414pKLh59+Vv/zL+oqDaThpW3y8wKRlOQHBWcMGzTqpoqbb5HCoOhuEakp9aS+SCAWTFpKfqqgz8DrKtIdfrMoVsFloiRQhwaKO961ds2a3FDFbTI5WJo/oakEB2ouPk0DBgSsU3Da8OEjht1aMTh9+tCBN9yU/thNS19ekb7thqFD0yMrbh6cPu26ERUVmlV6cJLeyPStNwxMn8HdyBuuuzk9ZNiI9MD0LcNGDbp+aMXIkemK24dXjLih4uZBFSeSZg1JEq1dKe6CcSJVccZTZEkDS3qSRHfUkbqWeaOxIvWOlMaIsOk9kM3kaCmV5tJC0pTfSlpLG2kbBJJST3/k6T+0MJBj5Tjcq4Lf9R127bBbhkmvYUMHS4xPMNwu+H8tOTWATPyr6P/uyquuqm/FdaOGDhyRKyx326FodUAfcq0uSAUyVn5on6oMV2byJF8bU2OMyK4CKezNvhono4ekxsvKAXnKeHTvwgFSOIA+m3vsWQ+nu8T1lyBIjZFzBvpMABOmlRkru8/1mVTCpGDaf+IzeYV3ihslQV5qnOxM+0w+Pq6lBPkwC4f6TAFMlJKgAObBuT5TqExDCQph2h7ymRowjgxqUOng1j5TVDha5BcJimD6dfKZmvgIHaoJs6ncZ2pp1iUS1IL5aITP1MbH1ZegNsxlj/pMceJTDDPkRZ+pg0+4OM7twk99pm6SWx2YzHfGFMVMCT7SR30myN56PlNPfQ5LUBfmqqY+cwQ+4UoJSlITXF4Xn6mvDLlptNrn+kyDJFo9mDsu9pmG+EROgiNgav/BZxqpz34J6jNP75E+c+RvjDz0J59pnDBk4LaN9ZkmypBBA5izJ/tMUzKQorieDU/7TDMYrach82yd4zNHwbhmEjTC5/E3feZomCgdZ7B6i8+UJhkcCdNtp880x0cukqAxzHXf+kwLmLCFBE1SE93yPJ9J6z4YoFlPjC6v6TMt1YesYdyV9X2mVcI0TU0MrznKZ1rDRJH5RGe385ljYNSnIdHOP8Vn2sBoD5rhMzvjM201N+qpgU+ml88cm/SgUWqi3HKWzxxHNO3bUfgU9/GZ38HIMRIcDbPsCp9pp0yxBKUw06/1meNhQnKj0qhgqM+0h0kqDffe4TMnwCSVyjdjfeZEGEc0Kg37TfGZk5JKG+DzyYM+czI+uqvogbzwpM90SHrQnKx3/tlnOhJN9umzMNE1m+kzp6gP+7oF9WRm+0wn5nFHxvOMftlnTlUf5kkTbcEin+mMT9Q77vU/VvhMF5hcr6es95muyiS9HrnVZ7rBhHSHHkTv7fKZ7jDaA+qJHvuXz/TQ3KinMVkv3uMzGXx0x7MK0VkHfaYMxjFPjVSlXCI+k9VoVNoyVRkNS/lMTzrqBmmlleHgAp8JiaaVNoEpq+Uzp6nPAJunqnkdn+mVzNMiVVnevcRnTidavAqV8n4Dnzkj8WlGbt818pkzdR72DrmVz2ziM2cRTXMrhbmn1GfOhgmb6fpUSsdWPnMOjK5PK5gZbX3mXGXwqZ+qdP2O95nzNDdWoYRKB5/gM+fjo89CA3w+7+AzF8DomipzTmefuTBh6IF7qbvPXKTz0IOSlJ0ScureOOgkrVNj5Pa0z/TR1uBwTIoPfWOfuVh92B4lMLvn+ExfZYjWhI92/f8RrZ9GG6DbcJwcd5HPXKKJWQPGSfdhPnNpEq0hTP9XfeYyGNdMl2C8dAh85nIYXYISmFXH+Ex/GI3WBmbbOT5zheZWR4pq1kwF8fkrPmTaqbR9XsPiT0bveeqa1auWrug7veMbbSqHv37WbflS8EMtyZnnjms5jx1Hlc7ruf9gy65vdFp5Utdffuhy7oEb8agqhJUTU3cHLgjuCWQMpzkObYGMD2RCIBMDqQxkUiAvBL9ylTB+LZkRSMAZcE2QksK2t3PGk71ZkSOzKZFLc6A1gLlFynsgAeEkNJ17piRanwB3fE8YqKq8BCRxiOjuzEo0kUDR9gTIbLgidYspuZ8zGmfJnhKNy+YZcMUw32A2pixP3N8B6SUSPm8SxR0GRM5BZsqIqKDPMsDVZb+BsIbOUZZNQC9sviW+3Ebsmkw2w2SeRFsNiDuQFbcXiyrNYFU2lpVZygKQm9Cfd4hyLzYKojk4LCL+ChThbBTbGA8ytqFwAw1YctEyoiiQtDLXAraQ4DSTcTBALO/N6ooFEi3AbzXmoomuZTzOWIvCIqOwgPNyka3tlM0Vg1DLlpD8DJwB0OrcMLwpN3zGJJm/ZECihVlJ67okM8u7ui6SXybRJPwUyHwmcmXiNqliGYr9KJriFxDI9cOPQOFUk1hQD0Dcv7D6Bpd0ITcbMS9inzxK5uUANw7GQDFmunF01cM1ABY5mmqS6O0NiKxjWrWwhIpRIt0EgikgVWHTdWBlNKwCyXBzEbKBKv4AoNUW1no/y4BEi7CqrxbvoujBDZJoscLN4QYLW2pz2c6NxtiOwoKi0FnMQqeNcFFJHnIeOck94JOzPD8LsNIliX5JgPsL/rZs7FYuwMYeCVWa2CTu8g9dlPAx7Kwp3QyI7KAXo7WceoAilMjIZfFTMJGcFLi5MBORG1WxEmYfUY9Gaet3GVmzXFoXkicjt37/xGofLhHPt1uHEhlOIboCdw3AdcbkGkxcGaAdo5xRC4WMITwNlqdNEmSlAQl3Io/Fd5ewG+bAuP1o2pLVFuTtGXxfB1BeUq/QRXKj1VCjDIgMYJ7VKFxPbpYwujKeJayLPBA9j4koWIY9KxCtUcULmGiQOKpM0ObqNgp14RXo4ssCsrdHpz5+9EPnRmLxnAGJFmP1PVMZCFmudAqzamBL+haUArccMETLnQ6gKrnFJIqGBkReZsLcFnfJFicliXe2jNNcFGQYF1CP7ewh3Pwd+8kmcf6bAcvJtU6Sc0swDWHs1TTFJL4EA5gkOvNs1E6kW7C6I+CllCIOlUk5tVrq0ZcYkmk0yyQRzjdAF0h9JhbSnlQ6olQ5i9kVRG9oMED4PUxVmaRLtItfAFozVTeyOAGFu4tUutLW2Sbj6QCSZv6qY1GUHw17ZE8p1wz3ET06gIVuUdmflV2YyS6CHYFpuAHQFHOCIVFMNCByQ1bCYhT6aox+JqHTUbxNMAXRixoM4K5iaG+PRRGOB3xEIbNMkup6A+I+RNbDItoHOJlAmtAIgqU1xRFZOUnYWn0gdQ/wrCJzQPeJUdWAa00eDu41u2GeBYCnMhLOQ/ZiYl6fccPZ/0gsahng80rEempRBJjOUNmE1AzcjNVbyPtQuJbczGCwD8IZ5KoboxrwPaBggHuHMR3FZhTyJPY7MZtgEsX1BkT6odyCwmUxX8tAhkuzVNSVBV8KoyB6D9NHkLtVsRHwE4pSRr4uRV+m0dW71ySKJQYk3E6wQ7hE7JzwI5TIaAHRFbA3MT0ICAmor5OiDIwCbXLSRaGffwStwjiabEDCJ5CfqeIFQEBsCuaLFrdAblUwzQATdDcgcgrjeBjd364VjIEajDNhviKa6w8gfDKfvKFf9GRlaYgueg7Eb3eoaqAX1gPg2mkLAOUdKeWxMqnqoooVZbIrw65iRiSztTdgZxyz0OnVRaXFUCCtiIFFdDQKwcU1xoIYSBQryRaFPE4HzYJpzQVJDHlR3wjSk4Cap+PJCPdRutxJRBbIzTFJIz8xICHLEX6BxS5uIkZ4jEn2VHcDImcif8Qi6g2rzyuSx5SVA3AxTe5kqcDNxtbAW1RzLMx6VZCjvrvSJI9kPg4ZAKli+flmEw3AxUouwi8HQo2mINJoc1FoNL4T5uymmiT8IAN2xgqXZ1khABfgahqUA9aUpDv2qLsjmP05tX+OhuYAnxNqgaoGUPKK7g73H8xaodq7AQUAfQjk9wo2A+ygfSgB5WlKUqq8DSAfEP4OMATgzgSoTdVVCXAdAJpo1VEJCL+iPflKfc5c9QER7TeNTGMKtdHDDBeabzNxHPmZghUkqSZnEXWwF1BXAyL/xOx2HgLpTsGFKFXeTWoKwkqaqsDNhXkC042q2EaTvkbRmm4Le8QNANSkT7yakKzUmwbsRRvtw8XeG+u5QYZ2FgHwKWWa2gaIWgdwDLl2Q+pD7oYAxjLVwyaJ+jcDurIc61SxEfBfZLUDt1oEC39EsVSZrQDKS+oVVmwKNnt0nkEG4uPbdlU0Jq8V3NRlVBHFrfcAxz1SWYvJSm4Ww7yvipe4IUgSVZxuipCK5dcy0uD7yNZiwXl4DEgDKF2fUBKgRxtZp5PcCVCNvpe4MJ6dSbw+oVgDv4cqwlj+mo014eYciCeNX1p6luPC7im6kgNmp1Q10Iv3wxQ+5cezXAqik4kzk5dWJ1Xw0tJPOK9qlSiaUKMq2rLzzKITHVEXZBwD4NqgwCJqqQpcpDkKYiBREBRgs8QWTGsuSGLET2KcXZw4VwL0W2tUNeDabR/diHlLdEkAcipFzkdxLopwOuBqlPcgb0KhJzA3mlGfFG1ns3dsh8wio2dVMQ7FXBQqVyQK9xmKb5E/odBFirTl401iscCAuA3Iw1jo4yqfkofK5VlWeqkBHgIFm5mfRYw+ROGe5mYPSoIhUVxuIP6T5mNVNAdsZSCjtxOFvMzohlJfiq4fN9OZbjLjKRQyB+YhxgpcJqnifSzugv0U5TUoor2A02CR/N0fK+RJerAJWcjjw2lC9LFxE0wS4wID/HKF7JNBwWGAgwsnG8YTuEgWsIeBdG2zrFsxs7QluquLzz6YDshFanoJYCxmGl0f7KjKQPyW+SsKW0veMipZXFlkm7uUGmwHp9F+pZGvpgh6Hz5rksgHDUikcj5JKODCZ5UPFuAcAuwFsgRpZ6M5gK8Y0xgW/o8GbFXCXao4FfAeilaEj7IEA3BR7GTqy4E4yThbqdLXrjXF1gIQvYPTFhS24m0IRcZujEks5huQaB1WB5jDgG57+ckHOpnblIBwA+B6bdwCgK4T4ZCEa2vAJpQJWGgGnH1jOYH4CshNyLKYlMeRlALXHpuOjP3q1B8wCbspJplnkQFLjj9okixXqi+MNo0zq0oU+ALiYHYoLabCV7lBMp3oT1nhAe6zWUqixQbkY/LT2qQ8g1TwIJR+0XTFDFTxnuVCUzsBSRwiur5kZvV9lgMvZKW8CW4JJffp+0MPoZRPWoDoXdy1U3tV0YY8dSXoJZIds9AAex9//Tsm3JzVNSbiTx6w58PAa0sl3IFtk2U4L0Nx6TJ9JFUS/goDIi2zvJlUsZmJWy+LH6mvl5LwQYBbCtOFIDWXWdJIgs00ILI4y+82arEecOvSWO7rga+C/mWYzgewAUKqQJIZZQHiOsdjoYVLCUqkIzt6UodybCMA5ATm6oj0N0I0xSTRFhmI52uYjSd2+qaKXiPIV4z7GLYRrjAQn8htI9TJxhsByXTJL2kzUHwGGz4J+zk395vE/HQD8UP3vzx9wivCgKO74dfq3RtvFi98wCT5PWMgntB+SVPwWTY5O5fiZwFaMKMeYeTK2F6qTBJgmwEJ9+C3G4voEKaH+R7y8xi/teDCV18t+NqppKaLDJAMbi9nyRPAxc8qXTzg5hPNwAay4EAY7UBRxbne+sfBEMkPdHUNSFUBFh+gCDWBdYyDjAWEV8DFPKs8wJ+l5KYA5/B+hkZztBfAnxE4v53FFMAF+M9cewHWlKQ7skNXTB3lOLQK0PJcPOSB6ItsTFUDKUymkzUEvhj5ku6kqwH3orjbJIqJBsQ9jHykDF8F+vd1OBagW3iwSYppayA+wH6QQbGeQGMYKguZV4ElIFN7/AYsSaWqQXUhANluO6EznvaCALh5MPzRFW5SBV8o/QXDtWbNA5bXXUmVLK97wCQ74l0DOqFuEyz4c0fewQVJfUwFYO/HjOuG+c/M8B3lR3sBw5lyM/JdanKvACjS3oNWdWcDdkyMn2QytCcZybuCigDkLixSLTKweQDuRGw6Mfapk/Z9LI4aVr/GbEwFIquR+tBHOwEnkxqSaLEifIU4q1BoJ9xCbvYwKByJ4moD4jphuVkVtYjxKgokechH2lp3P0qbcqYBiV5HLlfFOsBh+rwBl3ZZKjlsgLl/hPmB7L5ETlfTDwBpCn4LOTxDQbMAtMWia58cuQNEduJ2Fy7604ariRIZjdPoADeZ6ApkIcwjMJq3nnPcfhTNydvW+BJqZklDoiNJaIkBid7H4gd10Qx3MDRl/cXfipgHo1XxU6aEi1HoA+teBOxBcb9JfPsbiM9K76HQfmlXTN5LMAUyJmFcW27UdDdV6TFFm+gIpnKmPpy2iJfB6ulGm+BGmUTRwkC8e9Jqoa/xlxmVjDKmUmAPhkuTYg64njo5QO3DMSYp7VUDtuPjAwHAfOSgB7gAtIALECdnv7i728GHy+jW8sTe7c2BKVBqr73nwnFcJqZ0SQ0k7vKmfdM1rr4oOJHwBc3Ee2OwpvkXgBZ9k0ksSg3YnwJSjIX+giLPMlTq4ViBuxErDrfxHunCzXSW42GTlPqmB8JFmChwm7hZiNmHqpjBDfW4SSZp4EADov/lE32kCt1gW7BAki6ljWW+t2AURFsxXYLiC1V8D/gZRXtc9Ic4/dVTt2A42SQWbDCAOALKT+qyD8Wn3OxHLtboAH4igFHQh4CHkJKhkwa0yasNCGtzB2iKGk8zIO555OuqeB3ATwhWcGPiKuD1TJhnDGDSwIBJaZ0o5Gu6ezJymQa5EKBR74jlRH03yItYWBoK9LQnD0B3pjoXGbCPtdO/PaN8bvjGVvFBrKqDoqoJtX9LqcjwTbJRwHsBUwXDYDDlbMBnVn1nUoF2p51mo9Fddzt3cDGvJsBFHzpRSitSUSBPs1kjOg5gY60wwNNETg2IKwET9EeJFP2ZTEH4RsKEv5LCp4x6ZBvxQRB+GAt5A4e58ID486rt5SIAIPpCI+3L/AZs9ytVDdKNiKlgFwcG/YhH1rQ+HBR68ZpiEiSzPmdADxvi7M+KuZieABNO5xfKE/F91CS+zoC468nrOBTSB9OWWCBdI/UFWALRsx6Ik4SqBlwActMr/quuFbS9+soB7NlQHW0THzRgf8NF/7Y/5kRbY1QOkK3cppn/CTwLx2gRkazmrxMQPgpVCeW+wdFCLc2BO5nyPCj+TmGoZnoGqeD8xEs25ta1IBuDZK74r0nOlvoNZQkBdnj+klD6HZUNAN5mEQ8fEsWVBixv6cuGNWD/6a615UA8RzMiKdAvg9Mjr/ZKV0AIh2TC9Qbs4xvpa8wy4D2h0mnqCshN+JNuO1H0tKBAPw/R24xNqpiPgqUIpzJsbS4wECf3TpZUAK42jFyARt9/mCJR4AvQE2r8471G5/d9k0wn03RTyVSKs/94UfAAYzZjnipWATYxAtw2oXClBuxlGlv0ADyAQqXFULCWNVKLdCZxmbs4jjF3MRYaVBU6i1rYtOqishfjvwE=(/figma)--><strong>Approved Claim</strong> &ndash; We will send Agreement documents via Docusign for a touchless experience.\r\n  </li>\r\n  <li>\r\n    <!--(figmeta)eyJmaWxlS2V5IjoiZVQyanB1Y3NQU3JhR0JyVFFwQ0ZYS044IiwicGFzdGVJRCI6MTQ5MjYxNDg4NSwiZGF0YVR5cGUiOiJzY2VuZSJ9Cg==(/figmeta)--><!--(figma)ZmlnLWtpd2kBAAAAXxwAALVb+Z8kSVWPyKq+pmd3Z3aXU0RERETF2dlld0FEsrOyurK7qjI3M6t6ZkWK7Krs7typriorq3umV0REvG9FVFREvBCQ+5bbAw8OOQQRRA79P/x+I/Lq6ZHf3M9nO9578fIbES9evHgRUZN24jSN9uPwZBYLcduW63QHQWj6ocB/XbdhD6yW2d20A7CyF9h+hTeUtt1tgK4FzmbXbIOqB+HVtg1iSRGDwCbWstJVyINg2/EGvt12TX650nVDp3l1ELTcXrsx6Hmbvtng96sZOWi4XfJrOe/bTd8OWhCdCyy7aw8g9lqDh3q2fxXC9arQt702hefNG0mKLl8BLSiQ5nCIoUPk22Zj4HaVmlDMju+EbFF2p6PYO4jSGGoWqkKbPYZSx+0rUu4kk1Ey2fePxtTput2Hbd9FhXAbqp4I2rYXUWlDJBqu1evYXVpFWma3bwagjE3f7Xkgak3f7FCvvuG6bdvsDlzP9s3QcbsQLvVtK3R9UMu0JcqVtqNgV+122/ECkms+lDBJahbO+fZmr236A89tX91UIOtoqtuwGzBOqXc+tK+wS7cFbcei4PbgamfD5Yze4XTRWFdJL2yM48mog1EJcZdnBsEgbAFuk7MBf/E7ygdkw/S3bbZldHrt0NFzUGNX0ZONns+quuW23YJbajubrVB9sxzA1opSg8MXDbexaYNf1Z/k7BpmwW+bxD4XuM1woDDArbdMv1Fw5xtOs2n7th7BbfYVq90LtD1vb/UouyMww15h5AuqFRAX272O03UDJ2QTd3pRMlnoyVwJ3LbDCRZws4aD2URr7CokshCxVPbA7IKkCObmbEBWK2RQ6rhqFdWdjqlGtgQP23JALDuHWJ3BMBrH2uhYXr4dWsreTYfDk02nrRoJHTWTNXtvLx5mHa073S4WbdAyG+4OKkXDd72SlU0X/oEJ7DYGG+0e+2VsmNb2aVEtjG8sLLUMll3f2XT0Shc9D66JUrbdHUWgC6HuQwBHaA8s06Nz10tu0HR9Sy2dJYI24uF0Hi2S6QTf5AsELWNaYU7QEsN1tu3SyYzu0eFuPO9NkkWKb3yTwxCec8VuByAkeoTlT7sY1nSSLuaVScNkQi5Yr7orOybjgYE2MpPWAstUA6g3gdgY6C+WMkZpLweL+fRabI6T/Qk+KMAEVomjApd0e2FGGlrZimZAyceHoajZlsFDPdOnyDB9391RLsRB1DRrP9Rz2og5vrJ2XUNtTRM220GEUq1u2H2b1TJHNTam03EcTdxZnFu23utqz0Yf8VmAZQ9aBr2N0DcVbVxRDq8mWo2sNZ0nj04ni2iMz9t2k0oVw8EJ1NIytnoBorejZrT8uh/PFwl8ljLXQ1Xl0w03DN0OKKMzPUpj62ieTueYnIbdNBErUCEs3w3goo4PWtpXbfos5hWcgc1HNeWZGApihwXfAF/3VLxYQmE5bVDLfSyB6byTzOdEL3wL60/Nr1QEliPChN3dDDn5RiNKD/QqMywEU4hE6RpSrUTtSXWvuwmR2PJsljLoszC8RhNFzb4xm84XN3tfzXJhAnQ6dzGRC3achmpf5oKWnZu3HZ1Mjxab82SkQeraISvmLDtoaP+sld940WIRzyeogpbjKd9CwFKBS6rJOlpM/ThNHgV0YSLVHWWZoh+yoODQJ+M4iLNBweB+4GbhILRNzqu04BN6hrFPY1fuWgyftdDueK5vqj0azqxhYKVFXJjoTFQFKfOYiKaj4TU9P0VnW4hHD8NsqgcS20HowLygtbbyRqifMZu2lVaypkfoxDzTPWviXLewdE19tnWULpK9k2/1hWda9gALVCcX+rNAWdtQIQVCJBOB87A9CN1BFs5hkgmcFytXW6WIG/B424etB8zLwMuer0a6gYCNsma1XbX/1x0OJ6pAnHe7A3i0UhNmEzCD0OnYiFPgZcdFYjdQYzA0rStq+KrFLRZ0XVdg16DakuZUwrIMLQ+DoHMhl1NdXW34JlfEGuq27av5Z+fA9l2dXqyH82iSJmUfn4D4iSwjHCAmIZJme7FoOAG8om+DlE1kfygNpChIA5u+28HiVaGpVhHlsalekekotFSRFGFo2esFLS3LwFZKSY61Woo01FopKJDOMSvUsgxpvZTkSOdLkUa6rRQUSLfrjmIaoJSD3XFKmONdOCXVkBdPyQrUO1VLmTQDvasqyzHvrgo15GOqogLxsViajjVgHbjHYZtHem92sWJV/vx4O0qRHOv5RSYysHobjoUKQaCckUixKqzBXVBnSMFwPh2PG8lcLwdgZP71LZY9+qaXqPoWa2nBlRCPsPYWMertKx5Cm156FhC4ASpObvYQe6SR4lSAxkCvCDmeYhdTJLKJMXYSWZ+LNSH38cfYxZ9ahD91vdng4xvg5An+GD5E0C4F1/GndoA/dYUULKYzfDAkLUIhZ1O9GKBgdKLFPLkh5PLhpUvg5eGle1AYh5cuo6gd3kNh/fAeCpcO76Fw2YvmCKPOZBTjO2P/KBkJvwK6nudNqDyOxkcxvpFHKod6PGIRrNSNDmMha3vRYTI+gb5MGaFBGABZpMN5MluAq1G3H82TCJ8cHcbzZNhM9o/mMC1icpb+C0yho3ZI6bYb6hgIWjVz+tNgFg3hIKe+9bDZu5jPbFeRobmRZcy3AGhycjnAKgLyaRx0FI3tEcFRzW/1ayuapVjn5SfwXJVDSxSDnDE8G/ksu16DYFBwTKcsU4XaJYgw2E2QyxV8L7d7tVtIt/AXWRf2TBCqP4EyMian0HLg02odSCRwKjQ242ihDPw/0kMKjSphXfaUStYLw/ICymvsDUrVQZRL2WF0OXC6zExWXL/RRblqNn3WrzW6ahmf6/Y67NI6TkwmyvPYKzik2xq6vL2lyzuQlbO8YJoqUbto6fJO31LlXYHm7/b76kz3GC5MlI8NdtRx/XFWsMPy8Zgcyp9gWR32+4mB3le/reUElD+JOyLKb3f9Lvv3ZBoF5XdgZ+BUPqURqmT/O5ttk+N4amfT59b2XQF8DeXTtrFPovzuJnIZlE9v6fJ7WrrdZ4Sa/96HdPlMT5ffx2wW5fe3mxvkf8D1VPksP1TlD3r6+0vedpd2uqeN8IHyMkr2814/bJO/DyX5Z5sbfh/l/eZGn/wDKNnvB/sa5zl9dAjlczfaO5yfH0JJveehpN4Pm9stjuP51pbK0n/EaqqF8ALLU7xp9XzqbWCTJG8huLFsNDW+3cRJDWUT5WWUmyjvRdlCs2zPQUn8rZYeD1rbZH/aLXeLfoO8RqUkXQdbMEp3y3vgQZTelvcgcR7a8p5zCaW/5V26D2XQ3urwu7DtWtTvYT/gvPQ7doOH2R2U7MeVznaH8qvdtkpJHu72tkOUP4o8gv16IcoA5Y/1YXCUL/KCkPIBSspf7G/75CPfa7Hc9XsbnPdh0PGoPwp1P+KwqzLSPUwT52+/j2M+yoO+rk/6etyP9LeVv1zr+6GPcozyMsrDIEDkFWKCkvwU5b0oZyjvQ/njKJ+Nco7yfpQpygdQLlDSTkcon4PyOAgQs4W4jpJ4N1AS7wQl8R5FSbyfQEm8l6Ak3k+iJN5LURLvp1AS72UyCC4T8Kel1Vc9fDkJQv4MCWK+ggRBf5YEUX+OBGF/ngRxf4EEgX+RBJF/CYTq6i+TIPKvkCDyr5Ig8q+RIPKvkyDyb5Ag8m+SIPJvkSDyb5Mg8itBqD7/Dgkiv4oEkX+XBJF/jwSRf58EkV9Ngsh/QILIf0iCyH9EgsivAXEvkf+YBJFfS4LIf0KCyK8jQeQ/JUHkPyNB5D8nQeS/IEHkvyRB5NeDuI/If0WCyG8gQeQ3kiDym0gQ+a9JEPnNJIj8FhJEfisJIr+NBJHfDuLZRH4HCSK/kwSR30WCyO8mQeT3kCDye0kQ+X0kiPx+EkT+GxJE/gCI+4n8QRJE/hAJIn+YBJE/QoLIHyVB5I+RIPLfkiDy35Eg8t+TIPI/gHiAyB8nQeR/JEHkfyJB5H8mQeR/IUHkT5Ag8idJEPlTJIj8aRJE/lcQDxL5MySI/FkSRP4cCSJ/ngSR/40Ekb9AgshfJEHkfydB5C+RIPJ/gFAh6sskiPwVEkT+TxJE/ioJIv8XCSJ/jQSRv06CyN8gQeRvkiDyf8ubj/lIrRbYrsUlIfMUy2BO2YlmMyY50tibTw+Zli2m+GtsjKe7Qsrdk0WciprU9wvCqOG++YD8hBkZ8q9RtIiU7gqyr2SMo53FpNEcPYIDqJCrC7aNdC49iEbT6ylI4yDZP8Bp9gDpHRLGUbyIkjGoeowup8wlkDge47Qb434A9PIiPlS3Rbpq5TjZxeFsSHpVXXrqZrOnAmGc+/9tcojEaB5hbGtibXdOzAlaBndOdUYYF5WdbxdySEMgezamTCQXzLNrx0ma7CKpkqKOIrurPi+WUiTcqXhYLgN7ku5N54fihWIlUUa/IVYVER4gSZ6w58jbowlkODk4rIHgghYgrUPWialZERfBVy9nL4hz8ynOGVBBT9ZTVoA4v6fMZ7Gz2aw9Km6bcSxNVSNeIm6PD6ePJBZQPFzwwYgr8g4miB0YsgEHEMbStfhEwGH2IG0nk7gV0zKANyhpJPsxcGvI4MHptHIi6mR2tOISklVc+Wiw9eFBxNQ5nqdwMVlw6kOnweaNlLR7HM9xkxSHEYyJoCBrY3W9pG4x+jAxboXH6E2K7UUu7Y9PZgcp9hW5PCpudlPsKnJFf9ZHgxDBdqvsWjG6l0m5theNx7u4IGmiIhW78twBZnkO8Gsb0xto4BVSrrcqIiyVXdzcjFJxBWeZ+RgDyQ8+tY2sW8JYgfvpXLwv5PVktOARzGDdVRA1EoUl6+TMdIiTFLiVvWSeLqzcNOjzEtypyi9vcrzCWB5ODw8j9CRbpuW5qy+0GZFeYvXuYWTKcGjqLHg0Os5WwHKjMJ4wjDlOkhijlCWSoQ+cynRG7Vgx3XhxfTq/lndhAgePxmhspFrMO3J2PhmicFGIYUhaLxW+lMHJ4e50nMGnikG7iFyazkFSAhg4RnI1BfT2JkaDFQnD5rB59DMMNTNyBhlSCFziYOzonAL0470Y51cM3ljbS8bxNlwdbpmqStWygSbpOa0IwRHHUHbVA1QGnyLjkPU8lC6NE0ST+Qn7EE6Do10eX3ehRoFYSM7XbDrBNOuGVo4me2PelU6gU0VcTdJeXhWPEFLWdK+t/PtOlGL2MkMNc6lGlbOj3XGSHgCM7bK34TSMo8N22Ts2YtzcSPaAA79Sce5OUYlze3tpvMBs1ubRKDliUKyXAW8JRRHwlkPGOeWGzmRviglQaFtCjo4y38JC8BCwpqxoxMfJML/ezq9ZmIer+3Vp4WSkzoqGkuHmhSd08DX9oZ/HPZ5l9ceWtTNQe6+8qRFh1MkglcMUZ845m8cYmDOC9ZK9BAsCc4yvNOZrEMvpc4ghXrayQgLgPRA9UadpgWuq/E5Lki5qDHL5zVYN10MYR65Zz9hCeSkT5PrLHbPbU2eQlawDG4hQ+3PGHae8ZUUrxah5CYvnZH3fyhuz7ClIngHQYyi+xBnLaQzyt8ez6uZsFiNcqFVi7BZihfIXMGUpsnJ36UbYcpUNlRZuI8w+jvjqFkPg0i57PJXBjrpXMGxs1vNFgD0aTpsKYzU92tvDTRScWW11CuVZArdWRdIzF7X0eJ8roMtNETMFFkkPnfDNcElw7tGCgZW7D+qx+GA4hHh3gosmKVag0ZzOh3Gg3rewoq6lEK9mfelvZmDCcJqDrm1nd3dme8e8GoCQbbWz8L0D0WPBHl4WMuJzv4GwUSyO2uToMMCygjFSsSTq2VJCWpJqaUBXRPDdP8JKnGfcyjCz5eqMCxSPKfeJtU0EH0xCLWtEFlDF/uNhsWOWriflrwNWBZbxqW0Crw+IyCF7zLso7QXZYy4urnx3mxIje5iv2XjEVsf+Oo75uCEDtZQ95izrsKTwKrFUh/wsGsGdKgE0D79UgMkxMk4hxpRSkn2Ch7nyKgvflKE5u17diA/gYbAP8PBo11a3MhgCnjYGOy0bi6DltBsDt4lHL1bjpgw33fr3DdKcD4s2I7wXTvbNyT4MhbwSUazCGgkeROZ+HvBq3vhoP5lk384UAyugvzrtRkev6U56qs6Px9HRZHhwiw8OkVfCrUHCpdXcgKzxNxvYmSeoML6pNkVMqSrDaB/z9uzZAdILsSwMRWjh/TPYM7+BfZGoVVit8MCCE31OqNinRQ9OIiyZdbHEUoueUzrsckbqiufiKvqa2h5WNKXFP1RmvqsZqSuehy+LvWCtYHTlDw8RJhYgzilCC5+f0uX7yFtRatGPYJEXufL5gtGVLxjBleDo8B1sJfK2CqsVzEg9L3Jw6PbtJaerN8qAZU+YjnBwd5wRamXrEHEB9RdYalEjVhHCOh1OLp6VanWbXzqpq4MRNO88JdBKzbJ5V1sThr3rjFArbyJJqzrm3VVeq7QqKd9jclpXOfCQaH8ezQ7oJJiNNfHYm0RacauQ5tfla+JxN8u06jZXksPVorIxKD7+tESrtQ8TzFI7QQGVJ6DIOF3dSVUkzs4Na+KJVV6rdBcI5iF2v2toGyrfVuW1intQ/IQAkwEItV08UTzpVnL9iQcODZk4R07Ek8S3V1it8JCWWNFMPFk8uWB0pa959QOJp4jvKDldHbCLCqtVdEA8TTzlFmL9QVjU9POfMzxdfOcZoVbuUW4hGoi7xVNzWlf1yVYy+seK7zot0Wo7uzf/buOp4mk3y7TqleOs7dKAMOx3n5Vq9auI22OPfCpeKp9ecrr6YSjDUloEhe+p8lrlR7lCsmPSi8UzSk5Xv5Ce3cXCxvn0e3NaV/2YGioj78uleGbO6LoXxSrPTXHvJ78vo3XNANF3hI1J/XoDHiWeKb7/JpFWfLFe7UGesbxJyh84LdJ6EVs2VQBKsQLF/eJZpyVabXdc5BIpbu3kD1Z4rTHUhy0OAlej4lLJ6vqR2j+xu6yIezJSV8RlELGylOLyTSKtuMf52Yynh/FifoJrQXlvVaB19vUU5UJq3XdapPUOsPqzn0w8TyQFoysfUXwWP7CGr1V5rTJWIi8acTuGymGV1yoT7osI++pQN80ZXTfTBzhaB3fE4sdLVtfP93iR0kEYbiSpCvYIy+kZoVZezPVETZuIWlLg3qhgtcKxnvgN9FAbNf8e2tdVxy1IEerU8hUvEDeUcAv3MfwZx4Y4SXVOpHpZplGvlOLRJNVSTx/pCAvUnwBVfFA9N75khMfJ47yGA+ZJ+Ser6n2djmH3fylXTPZwaCELmU7aTNo5QLTxU6dq0f0bi6NoXNV4mboSylQw5uE8ZqjACbOq9dNVrRZ8AasIsaKq8vKqijvHHCPkSTwpVMTBGLt8PHo4nk9R9YpqVTd7ktXPwSM8PJytzLxL7OG66GxtExsIuy4O8EZRqUaIT8UjuFaqyIq8dIzXC7odhvB2KX9JIvJlx17mcViJPh4zZjhLqhNogO1wUVT8SllRuo1ai1ievyoRAJHMRGMmERjtr8npsbr4wN6sJ1GB/Hp2T9GIYXq8kqNlzOpvSN7bIInEpjudteM9zF6ZHWAt/eYpBZ/R9CaN3yo1NqaLxfTwFii/fbPOrYBeWSqVNQlzDDwxYzBcT79zs06Iree0yqtoLS4xjDCFLyLiRNgJuL5+V2rfhv/qKxCsX9hOef6rJAI8VLNZUZcRr5Z44yllISYANxOvroga5SXFH8g4Kn5H0sa1AeyMw0f5u5Aunn6GqtPB4XS64I0LPnutTCYHcCteso4DHYsxXa/JxYEKmGXF6/KKEGusFP9lLrZVeCkrXl9UqK2rrPirvIL7Ril+Qy6u9KfJH4KwG6h/n0zSogo2/SPwujKX/IlMSSk7vFviLUuxp/3uw/Iov0yCGapB6c/kGHsibJStwRfj6QtfwpKuPr/2cY0AB8/C0huzKQ3YRmU63y+xy1aqykD5XolHsCQ9HSPfLGNlNxrVTHGcJwH5W6AZTPeQBqFXGRTEb4W4O530ZiNs2RnE27JuwuXgH0OljVrhYcEPSxl2AwzhHRIXFnDEg2Q8QrcayTFCA6+T3llxLg8BL54f4+qeuGjiXQSaYBZRqczbhIFLEX9oty7eQ//X0SK7yHqtxKBTBVIchT8gYSIVOdAtfBtCXbTwQFc2HyaHMdIK+OgHqpqdCAz+VyvqgxJMXlNZDB+Soxgb1kTxOL1gwpCk4IOPVC6AdO6GXO6j8pY+t1Fowu8+JqPsJP4hifc/WOv01tVWOVA/c4wl7GQTjBTbBlg1uDdIPBJOj1VH8rCsKl4n8WiYVfAUvgBwroCp+nheV3bHKceMF1o8MJ7RMMtbsNdLPDyqLSHr2zreHxdwrx4mt32q1yt4kNQHf44ItpKfwCvcPoLdyJ24YVP/xCYVM/nJQr63d6riU5UJDA6mR+NRcIi9xFSPQnTTT8uU+YTOLp6PR03FlqeKLG3CHH5GV6FzKl8vKz6rK3bUM0VDfE6zOtUG/3llDgQVdQvj4yl0ptcaZpf3CF/IeRVvvggHzqIx1dfxPJqk1mX09Eu5XjzqZwZax1OpNhAnqrgu+ZiUXwYMug+3nAdHMy7lLEoxMpncLhl4mT98RXc3y7KwHjmoBh5aC4A0Q/g/AL4qD+A26n0H5sN77LX4JJwn+/tYwJ+S4mvof8CVvwlPmEH/6+WCrDhOCqeT35DHU6xQ+xij9w7wmkj7fLO8ia7o405I3/DEVIbPCUNXpHAnWSs+sVW1sZyUn4YQY23LiujUIsbNVVFRWcO10+Oq36KrS6WzldFiueiLqSDxjleqFUlNxU9DqGJfNUpJtRendtV6qVM2WOnFLV2ed7lZiFQwTd6X5hIdNFfpsuNbrv+1s3HkXNngmRi9npmsoWOvWNq2r264ps8LUNHrbnfdHVw48ieduGlUt/nyyoZ7BXfxNmjDC+5DUQt2nNBqDTz1w7j6djkRBm8N+QCL22EJGypp1tYnMJUtdFG7pmHo10aVdsLgRj+Jr9Ot8bAxjCbHUcotFvkYwhUe7oScYUcaYzzH0MNADMU3Yg6U90s1/dGmRqurfxZBKP0vI54hpK5XoO3pUBkM5jMq4gC7qDI630Wv3IxojZPhNYGHphECIR4n4ZX8Xlu2mBBpTDB66Gc7GgKgzgqMUBsDMVHPpZC1qaayFuTBdJHOpouMNdLr0Syjazd/rOKKUZ9qLtP6VgCz3OmdcjFldfUeXCS/qr146pe7mR/qZTjBiRIThhc6ndrX4cD7sXbQJc6Kmr3PwqEPlfE/j1vWNDcpHkRXp7to6BirBQ/ja6OYTtHVmOeQhGLhKhOniMASz/60Xm7WFGFX4ur0tBFShFt5G5qao7fr4nacqnB9lum0tC0wvjtOyb1bGAKf++LCIlfJ4ZWRvyLlxQCdQ7zEReFDRzFuCvgmgCWMkXSzyUaGj80GrxEUaFumnXgRjQhhyF28VSDgx2NuiPQH2LYDQ8N+wribvcE6klXTI3peU0RtUiIia5B1jjfnvyolniuBLY7lcootMxpnFl2JhkPAibpYTZmxBLG6T0LNWs6HbPZBcS7nLWwwmAQlfq5Yn8FqjIVL4rwis573+aMLsNh91AYKu+uGvehkPI1GENyRnrJXgo5+TcoLlYEUpvkG7pr3gNTH3oWhY7x3KnQn9WjgaDw+cY8WaTKK7clwDG+Y7ON8i3FIcZdS9GBCZ4QpuPt/AVMYAADNmYmbFdW1xfe9QAPKJChDK3BBIahIgKeC2t2UGE1MjCJiNDiEFlrBIBBo4qyHsUFBnHFOo6DGARHQiAIWihM4gNGnGEWcEuMIMSpKTN5v7bq3OfwFL/f7ir1qrz2dXeecOl3kcnlrZC3W7Xhi3u6taob1P3fC5JGThpw0sfqngycOO3HCUcec+ovjB1o72/PkHo0b5czy1jjX5CfjR04+r2ZcrZXlml1uZs2tjbU1y5kHs27WON9kSPU5NYV+Oy1aSPBz0Tonh3bC/S97cf360iXF+TYnt6rxzE6W+6r5yiMVMEfAlk2OHTeptnrs2OraMePHFd4P1xVOmDyxMHJizfmF0dWTCmfV1IwrTKw5qHZi9ZhxNaMK1eNG7dSPwXXi5JG16GvHF2qrf1tTqLmgdmLNeTWFCRNrRlZPVsxJhVGTJ44Zd06hdnQNkSaMrR6JwbhaTMaPrJk0iSiF8RNH1UxUjPPIUstVqC5Mqj67pnDu+LMmjamt6cN4m1pxxLvPsnDcdLP6bOhzbWU7H/1sS2e3tFbegr2mmbVpbx0QSacpkOW2j3W2LtbVCvSxu+1rPaxnLmd5ecZXI/3Ds8jZj6wX7vW5/YeOP2t87XgbPH7sKMvwQY4PyB1LA/77e5e/K8eYdv6a/Vf+GjU0emjNOZPHVk8s9bp026/ZOsbRuPT0m+RzNs22987PSqoqGlljPaumU822NLGyYayZ6XbJ2XCP9WokJqKHldEPLh6+B8h82+B2qYUDLJfLT7EllTGTK7vM0i6swvxUe/6VmMnDJE0t1yg/zbZMiplGRLPhlmsMs6tPY3xCW8s1yU+3l/vGTBN8QuuM+WJYzJQVmcYwrS6MmabFaI1gtq+JmWb4qIIymM++jJnmMIrWND/DynaLmd0UrZt6MMMu3KW23WHUg2Yw838VMy3KLjH7t+Waw8w8x5lmGdMSHxuS+fS8PmZayWeH5XaDabwoZlrLZ4TldodZ++eYaQOTlFuuBcyx38XMHhrPcOWZaQc0i5m2xTwtYW5uEzPtiGYtFG2m1XSPmT2L0VrlZ4YbDoqZvfBJ6FtrfG4fFDPtYdKQVdDn1zHToVhBG5jbq2OmIz5Wbrk9YE6pjZlOMKG95dpSweszY6Ycxpp5nnDGTTGzdzFPO5gX62NmH3ySrj4e+3BZzHQWw3hgwqfPxEyXIrMnPl+9ETNdYQJVq4JHPomZQrECOhr2+ypmuu3sqJ3875jpTjTl2Stfl/TZ5cntK59yy7XP19l7LWJmPzHHK09dOqFtzPQQM1wdrQubO8RMT/Koox3w6dwtZn6kqrdppHWW9IiZXvIpV9V1yYI+MbM/jKruiM+iATFzAExaUHfqQuWRMXOg8tAdarPJR8dMb3xUGxUky4+PmYPEUAF5wl6nxkwfmGIeW1wdMz8u5mmDz0c1MdMXHyMaFYTB42OmH4wqaEt3plwQM/1hsvlWlx49JWb+p5inHVVfOiNmDsYnm2911nxezBwihr7BpC1uiplDiww9CG0WxMwAmEDVquB398XMwGIFPNPkj4tj5jAx2TMN65fGzOHFaBpp75UxcwSMRsp8S7eujZkKzapsvoWwLmYqxQzXXlWXHLUhZqqIlpRr36kLCzfFzCAY7TvkCVe8HzOJopGH7iTlH8fMkfioO8wD67ItZgbDFOdBePT7mDlKPaA75LEvdllzPynm6ZSfVb9/PmaOJprtp2iz6vNNY+aYhmizRnRpHjM/LUbbg3ftX3ePmZ8RTbOqPD9ry4w2MXOsGM6frfKzwpN7xszPYTRSKhhxZKeY+UWxAnwKZ+wdM8cVffbOz7J3u8bML1UbPlQd2u8XM8eLoeoW5NncM2ZOEDPc84T79o+ZIcU8++DTu0/MnAiTpu5TX39IzAyFkQ/jCd0Pj5mTiuPpnPeTSkk9TA4snhb5qXZBv5g5uaGwqRY+jJlfyYckLXmYl0yNmVNgNNn2yE+3cc1i5lQYPZzdYUYPjZlfw2jqtoeZeHvMDFcFNK0DzNYXYuY0DYYF1wkm/2nMnE40Tak987y094mZM2ACedrCvHxkzJwJo6WoY8PmUTHzG+WhaR1hVk6OmRH4aCHo2NDltpiphknIo2PDXWti5iyNZ7jGM8MWvxkzI5WH8ajqAX+PmVFEC+WW68Kr7MymMVMDoyenF+Pk8pg5W9Gouj3Mh91j5hxVQEd1OGjcJ2ZGE83Io1fm6iRmxsDoaSvPM7s8uXOLefQCPvi0mPmt8gzPotWcHTNji9E64zP2gpg5Twzj6YrP9CtjZpzy0B0OLuH562JmPD6aVTpu/fTumJkAo5moCto9FjO/g1EF+xCtfF3MTITJlhXHk7/FzCQY+fjx5LuYqYUJ5ep1XTq8LGYmqwf0WlvlJ7vHzO81HvrWma2ye5uYOZ9o6gFbf/pgp5i5QNGGa8bX2TFdY+ZCfDTj2fpte6+YuUiM96DONu+yti+G0Xj0Wnrv8Ji5BEZrQcyio2Lm0iLDeNIx/EW0k7msOB69GBcMiZnLxfDk9GJ8eljMhBzh1DiF2+/MmJqSkxfxGGty+lkxNVVeGiwNSlqNjalpuWKHeGmFu38XU9PlpcWqRgy6OKZmiFInCJgOnh5TM0sBqTA0uSKm6koV8tSt8qqYmuVePHYVf+cuk3W2cql4AibDdtnprigF3IcyrlwQU1fKS7OSY1RSuySm5ojS9KfxYdmKmJrrAbPOp6+viqmr3Ks8K37AczE1r1Q8udJnX4ypq90ry2Vl/xtT10S5kl5vxdS17kUuhhxmfxBT17kXQyaXrflbTF3vXuTCK7FtMXVDyUvzc8DXMXWjvDRBCZju+CGm5otSwAKvxdsbxdRNPuSRmhuzwgW7LOCb5aW5wct0xPe7xdQtpTK6cTpo3zKmbnXq75oAs9IurWPqNgXUBGgH9W27mLpdlFZ+W17pqzrG1B2iNK4OUF07x9QfPBed58CR9t1lV6j3cfEoGVf99m4xtUABNa7uDPminjF1p3u1tGbNm+dz2ecQ809P/t2qd6M9W3xwyee3/WbdC6vWDl3Yf02PWRMeP+b8xtZk+25WMh9a/HpS8nhn784PD9r2bbeBaw5+9scD/719wLFfnYtHfRms9clfngu53JScTeXjCt9QcjYjZzNzVpezWTmbnbN7cv/h15rrP60X5SzHJ5n1ubyV7ftjPrmEEVV8XuKzit1QiSyBQwflM6oB8FuBs4WKKj6foLUjAV9WNTK7uMrS5oMsWeyykSWbHFjyBRbfY1GfG2T2XpVtQaaLq/IO+BH6CQ9dBA9i62BtlYWHcX5ZinuI9iY3V7tEMdKB2dHI1UQT4AcYSukl4EUWq7VHGlF6spiwexFBwPpyLeAahMKuhzmem3HI4VIcXGlhCgpk8mRRkXyAYiNyB4qwH9kZZJjqEotHHVj6GillkX6FOS6SycoqirnfAb6AdD2pFiBfl2I+pltgCYYk2AgHZsdh8YYUAzF/BQUyfaqoSEmpspOHUIQa2HtRzkV5J4qUm+R2LjoabkQR/gmYwiW5d1Fhd1V6ydaqkqCPAAorLVUdhZVYHOnAQgvkiAosltDicq7RXAvksqXC7BtuJHtX0fsemPYmuv2INE24FON9mZ4OWEH/prtEcbMDC3ch30ThD2Y7FkielL3oM24UN730MAE8TEB9BMImkopqAFRA5QJNuSZw/ZPY4WLAWxR6lUuy3+LAEmV/rzKfgeQIGJkwahvvEsVi/KS4l2Jbk8aB8ln9ETuB1ySqATTUDbD1moThMWKaUc8ywG0VljDRbbDq0SRQkuEusdjNgdkDZG8ji2aAhVySHRmkg3FYPY28CkXoxs0iLiZBsoiy1MkGkC7HRCA8x7UQxaso7FbsN2M20yWK0Q7MTkLp07MK8xe5kMmqKoY2kDGughHw2XMj8mMpNgD+haIzV2Mti6GkYVnYFS5RrHTgu4TvDuk3gPdQItNlRBew7zXebwEJAQ3/ZhUwAlrgxS4a/bwQ9ALG6RwHltyC/EiKewA5YjNg60RcB78XuM4BCQ53YPY/XAfChP6MsjuMg6ZcR8N8RrRwKoDwxXymzdOGgFWOXUL/G0DCM3eqAfBbo6lcvEEruxLIZgtUA9AP6+FwB6hlgBH9GfpNlVY/QIq1law3Nh8qRFJdbwcWBldlFipXLpIeQ8C6EwOLdB8UhkvogAUxkCieZXQo7GY67hakdRckMez5vIpqDDubDgnYUoIG3DZKsRrFNhSdqqyQwz+cRCo96atdYvGcAwt/x+ofuBTKuNmAeTOyzKf/IwBhOoyDFph9wTWV/ifsl1oM6dUuid7bgdlLpJWFF9QCJTLMJJgApRqTpB9jVFgBq+DmeGQ7KX4LeB07hX1dUe53YOkKrNrK4nkUR3CDJFqmCA9xg0WyFoW7bOJGMTah8KAolMUtlDbFRZI6qEjTJ+zB2+LOKgq9k3wlQHjmIVQDgLK52jsK3WjmfcQTCGPoW0dkJyla08DreUw/kNkYRvI2gO4kS1yimOHA7GdIWWhr9nf9GnL6ZjKBm3NQjkXeQ26BZI0YQPo1zJMwrfUgG5N7X3Ifw7gOQpFOZ2ADKVWDHIgi/MWB7wVbZFGgwhG4qOREMXwM3xAHSZZ8Bu5TcxLmSKrEAkkOu+1Ea4tT2Ew4oigPEoupDnzVuIXtU5W5lFPvM4QVICy+ADuF6wSu1igMX5vHGJe4ZBREB1hCOtsdiy3MQpmrjvRugjlYU2X3+mpeh9mv8LOHAPQ2THaJoqsDXv80rCCL2YBHuGZxVRJIwJd7KBC+BMIgkgrIPlF5s3FO/uTA0uexaIezgPtog2wA/ADrSyArTofBnKWLuPmI2MmtPLC/cjPPJYUd5UCbnllKbAceYA6llkCWhMIc6C2THf1OwJuWJNe4pIN3OMgSNsPUwUdV9p72jjCPm2ka0b0OLH0c+aQULwF2kOcVSjmAMmyHAyJ+B7OdUj5FLpTp24ACc/Zp5IQKirgfQLM9urof+jow24zbZbjoLRWao0QyU4kOCHOILmDLYW6EeVWKDTDbUHRhiL6JDctGlBAdSUErHVj6Fhbb5aIK3+FSyQ8T3QfxMIxGla7H7AkUb6MIfwR8jmKeS3xPdWDWj+s1FHrnqysuryCYgE0tMqEnNzL9mFGFUwA0MRBM8i9qsb/avAkDHZj9jRFegLkdjmkZSsnLiSyQzCKyQFgCcwumG6R4k258iWJfijDGHIYDGHOY65KRPeXAwrvIrbhondvL3CCTuUQXsFoAC0mAqC0B+zGIw5B6QYezARSe3uCSqIsd6MTNU5ViA+DPVEV7GT+t/Q7FKjFvABhecbzG5JqLjfd0pAOtM+3CKDpQ11puWnHVEyW8HIFwFyY63aTPcsOTsrekuI8bghSjWtAyShix/aeSMthxfCWMOLwIrB2UVktSOqLwpwnvJiW5FCCNzhT8MH6gouj1AYN1cDpUM4z5GyjTJK+WQJa0+NdXd+r0QY4AwCQLXKL41oGlkkuJJMCPtC/EYBnOCcBbuxLpJ76HAJ9x0U0kw7/Qgc+xRH+QhEMAr6FQAWkVwQD8qJjtgV8R6MjjVAlQrT2ll5dvSDr4Gn3mD7NsAY/Ss7wLwDO081xi0dlB9uhbYKETCH9tZLI95QiEc7H6HDlHigHcLCTdDS4Z/lMRSFZgIsBBxZLlmL0rxSJuvkA52yWDrHZA8Vi8J0UXFK9jgaRcxjiNfE/DCKRvYLoSxSdSfAP4AUVvXHTwDWcQhAeSzHGJBXMLYIGA9i+5bEXxITfbkE8oOsB+0HgFhhDwe6RV0EkHhsk6B8ZUuAg0V8Y8NICFu5GPS/E4gGXvA+5AXIFkGiDc4QCTdg5cssozhX1Jd/siVyvILwGKelEmP9YzDCkRW2MuYIcQYymKY1EkCwFnopyCPA+Fn7Iu4WrL4HyX4WEm12FxP5UtkGI6iiUoJHVKEggfofgnUg3SglHHbIZLLJY58L+E0x1YaI7ah9Qh+WQVQ13lgIcr8Cr5H8T0XRThdm4+R0kwJIpTHGSHu/el6AJ4gwuZPlNU+J/Eh6F8QIqTuFlIujlct6HQwgnXc63FZbYUb2FxGeyHKH+DImU+6S9gSZ+6Dm6lBxuRZXQ6XQ5gtnNmlSTGcQ74Oxs5pALFBh5MG675XLfgYlWAz7mQvBOYFi3I0pPooRU+W2H6If1v7GEAJqtH1yab1jvIdvwHUfizZMeX5OFavd4j1piZO52AAkHRP8XKj9mvAFTdH1zif4oDC12RF1VSzN4An6zaERpAaUdoAKleHA2vljtcUh/xAZaSMNGqVAX2An7IZJYGKzBdB8V0E4Wp7QLpY9w8x6X3eMJj80lxnUvy/NxBlljHTQE/O/tM53gVMEUSbLkDSwhGL1EQPRyIn+TsquJW3JmA2qBDAa2nOBMTKk8WuCTytw58K07/3/bkrMisWv+7Qws/rcPerq/YCVgovGygGgCUveNDPYq4vRQFQBTo6yOQfoKDqAZgZSpPYD2FnIi8jzaqP3YFistdoiABwMINyBuZOQ70jlB6zSkb5ZJu9HSQnWDerkDxMoGmckmWkVfAC7Crj9gJvEhRDaBhIIDsr3LOmSRVt26DLgF3ENUA9GNlzK20woF6uoC0L3PzXv4qP1iKtQxlIIrvXaLoSDel6MmqcouDaZJckFkMQOiBAou0mxS4WBcUxECiICjAs2QWpHUXJDGKy1UbgRaCQPocMV5H4btcDyIzB8NUl1gsdWDpS1h9RZscaE3av2KgPoSNRZC8AhitR7YMwHMwwiEJR+UAT2gzsVAF1gal5EziC1CbUWULuumbCiD0xqY/1zY5nQpgyem4hSTPCgdeXGhHFAFODpjCaBnwvUsSBb6ALJjWvqKnf+IGSTrb5B06lGDeIQCnc//MkWyUgr1PL9ywLw8lR4fCafjToXCNS9b/8w40qyzxpvLdwuiyJJOYRgFIlTHhMMx/IMPXDCT9AjCBlK8in6/A4lGAGnatS/If6sAPgzYDF1VorVEig3cQQO3GVN2NCjwPIPTBhgnke5RpcU3DUWG1z2sHBGQnBvU43QzoS2lIomWK5FHivIBCnQjLufmci4EjUZzpwMLBWKq1Smu0VpI6smOxnQG4qIo66aBVlYDmjSYpvyLwuSWqBNL5GIdhuD8isLoqW2zpN0Wg6cB7G8Bf9PygXsRdoJjUzqcAfdpN78csXVF01F8vDpL5UHpphH+UHFeVwKVE+DkUNXNJs7ACKfCLopdtKJ3Um1RloJjL/uiTqnNJ25VYep3ZadBMFat3SZPfdKB5w59tWKTfY7qDqdaMCdUIC/3pIAtWtyRP7ngH/HWNmxojwI//NxkQgbCUaA5eoYp++LyDop4Pdb4a9nbJd5ZWDqy+CRZvo0hUwEtc33ItI7wAP/IwEfhlIHkYWwc4J/O4FE0bJ4Dvgjjr84oAP8CVPOES8KYUu5PtUAxVM4bxA/SnYPIpjpqo9gqA+Z/e4RLFaQ6y19nQSgoUGLKaiLzOGgChocqJJGClJ6DXo3ePcEgSvuzAvyCwGlGognXcIIOesgC1Ga/GTUTR2hBI/oTNM1wbpViKgoHrIx+SPMc5yIp7ropSAEFfjew4NKy8FFMkCnwBalj2MVnR7UD8kaSzq3S41pdubjAHaMvxLVUFWw+KYATpVJf4L3fA9MR/K7lZnFkbAlt3A/DDo4PHVlnyDrYdV+O8GsXJq7UHSBL+1w7MulVxbJfiVRLvuzo7b365iuZ+CwirYAYQpPlqbUuSBLvXgf9xY8/Jgm7b71dlcusR+AqcWonpUgCPNWEUSCpjWIBsnL7xMXDf+JCB6uiJJopmjYAdRK7+SO1m2vX9BTHXJdFWOMjy7VmVJabjPO/HCPIZ11VcenQaMCD77P+qFC2rsjcGknR+Siq+8YnDYYBfEWjrcqoB8PNTkv7k4ocdgFcFYGvFTuBPRVQDKOzFoxTYwpq17pRwKIowhLU6mId9rUvKv9OB1rsFZbUlmOqbarKQj5998J3vEt/gwMJoxtELhQ3BlH1FMuwlX4AXkC6IQFYkVAPgB6A2/W7UAtbTcgcBu2gV2QBh+Gq+G1ZIkm3DEwK4rrJw4moCCDQVM30lawOmY4Ukiu6VAmZnkeJrgtm1gNdWZXKK5hygIR+AEviYpyMPxoB6naNuIYofrB4F6KT1qUtqa0NtKPQnXL0sdNxIcZH0GAI6R8mCFqHAxU9axEAS9BEHnsUtlFYuksSw6/yxX43V4EpYgWu4HuB6WIoXABu5cgTeiCJ0duDfCDKLIwDXoJD0GAIvVmQWhYqiy5InshhLnsBCQaVQFll4WrlIDub6Pw==(/figma)--><strong>Installation</strong> &ndash; Our crew has been re-trained and has been instructed to take extreme precautions during the replacement process in order to maintain a safe jobsite.\r\n  </li>\r\n  <li>\r\n    <!--(figmeta)eyJmaWxlS2V5IjoiZVQyanB1Y3NQU3JhR0JyVFFwQ0ZYS044IiwicGFzdGVJRCI6MTE5OTY1OTA2OCwiZGF0YVR5cGUiOiJzY2VuZSJ9Cg==(/figmeta)--><!--(figma)ZmlnLWtpd2kBAAAAXxwAALVb+Z8kSVWPyKq+pmd3Z3aXU0RERETF2dlld0FEsrOyurK7qjI3M6t6ZkWK7Krs7typriorq3umV0REvG9FVFREvBCQ+5bbAw8OOQQRRA79P/x+I/Lq6ZHf3M9nO9578fIbES9evHgRUZN24jSN9uPwZBYLcduW63QHQWj6ocB/XbdhD6yW2d20A7CyF9h+hTeUtt1tgK4FzmbXbIOqB+HVtg1iSRGDwCbWstJVyINg2/EGvt12TX650nVDp3l1ELTcXrsx6Hmbvtng96sZOWi4XfJrOe/bTd8OWhCdCyy7aw8g9lqDh3q2fxXC9arQt702hefNG0mKLl8BLSiQ5nCIoUPk22Zj4HaVmlDMju+EbFF2p6PYO4jSGGoWqkKbPYZSx+0rUu4kk1Ey2fePxtTput2Hbd9FhXAbqp4I2rYXUWlDJBqu1evYXVpFWma3bwagjE3f7Xkgak3f7FCvvuG6bdvsDlzP9s3QcbsQLvVtK3R9UMu0JcqVtqNgV+122/ECkms+lDBJahbO+fZmr236A89tX91UIOtoqtuwGzBOqXc+tK+wS7cFbcei4PbgamfD5Yze4XTRWFdJL2yM48mog1EJcZdnBsEgbAFuk7MBf/E7ygdkw/S3bbZldHrt0NFzUGNX0ZONns+quuW23YJbajubrVB9sxzA1opSg8MXDbexaYNf1Z/k7BpmwW+bxD4XuM1woDDArbdMv1Fw5xtOs2n7th7BbfYVq90LtD1vb/UouyMww15h5AuqFRAX272O03UDJ2QTd3pRMlnoyVwJ3LbDCRZws4aD2URr7CokshCxVPbA7IKkCObmbEBWK2RQ6rhqFdWdjqlGtgQP23JALDuHWJ3BMBrH2uhYXr4dWsreTYfDk02nrRoJHTWTNXtvLx5mHa073S4WbdAyG+4OKkXDd72SlU0X/oEJ7DYGG+0e+2VsmNb2aVEtjG8sLLUMll3f2XT0Shc9D66JUrbdHUWgC6HuQwBHaA8s06Nz10tu0HR9Sy2dJYI24uF0Hi2S6QTf5AsELWNaYU7QEsN1tu3SyYzu0eFuPO9NkkWKb3yTwxCec8VuByAkeoTlT7sY1nSSLuaVScNkQi5Yr7orOybjgYE2MpPWAstUA6g3gdgY6C+WMkZpLweL+fRabI6T/Qk+KMAEVomjApd0e2FGGlrZimZAyceHoajZlsFDPdOnyDB9391RLsRB1DRrP9Rz2og5vrJ2XUNtTRM220GEUq1u2H2b1TJHNTam03EcTdxZnFu23utqz0Yf8VmAZQ9aBr2N0DcVbVxRDq8mWo2sNZ0nj04ni2iMz9t2k0oVw8EJ1NIytnoBorejZrT8uh/PFwl8ljLXQ1Xl0w03DN0OKKMzPUpj62ieTueYnIbdNBErUCEs3w3goo4PWtpXbfos5hWcgc1HNeWZGApihwXfAF/3VLxYQmE5bVDLfSyB6byTzOdEL3wL60/Nr1QEliPChN3dDDn5RiNKD/QqMywEU4hE6RpSrUTtSXWvuwmR2PJsljLoszC8RhNFzb4xm84XN3tfzXJhAnQ6dzGRC3achmpf5oKWnZu3HZ1Mjxab82SkQeraISvmLDtoaP+sld940WIRzyeogpbjKd9CwFKBS6rJOlpM/ThNHgV0YSLVHWWZoh+yoODQJ+M4iLNBweB+4GbhILRNzqu04BN6hrFPY1fuWgyftdDueK5vqj0azqxhYKVFXJjoTFQFKfOYiKaj4TU9P0VnW4hHD8NsqgcS20HowLygtbbyRqifMZu2lVaypkfoxDzTPWviXLewdE19tnWULpK9k2/1hWda9gALVCcX+rNAWdtQIQVCJBOB87A9CN1BFs5hkgmcFytXW6WIG/B424etB8zLwMuer0a6gYCNsma1XbX/1x0OJ6pAnHe7A3i0UhNmEzCD0OnYiFPgZcdFYjdQYzA0rStq+KrFLRZ0XVdg16DakuZUwrIMLQ+DoHMhl1NdXW34JlfEGuq27av5Z+fA9l2dXqyH82iSJmUfn4D4iSwjHCAmIZJme7FoOAG8om+DlE1kfygNpChIA5u+28HiVaGpVhHlsalekekotFSRFGFo2esFLS3LwFZKSY61Woo01FopKJDOMSvUsgxpvZTkSOdLkUa6rRQUSLfrjmIaoJSD3XFKmONdOCXVkBdPyQrUO1VLmTQDvasqyzHvrgo15GOqogLxsViajjVgHbjHYZtHem92sWJV/vx4O0qRHOv5RSYysHobjoUKQaCckUixKqzBXVBnSMFwPh2PG8lcLwdgZP71LZY9+qaXqPoWa2nBlRCPsPYWMertKx5Cm156FhC4ASpObvYQe6SR4lSAxkCvCDmeYhdTJLKJMXYSWZ+LNSH38cfYxZ9ahD91vdng4xvg5An+GD5E0C4F1/GndoA/dYUULKYzfDAkLUIhZ1O9GKBgdKLFPLkh5PLhpUvg5eGle1AYh5cuo6gd3kNh/fAeCpcO76Fw2YvmCKPOZBTjO2P/KBkJvwK6nudNqDyOxkcxvpFHKod6PGIRrNSNDmMha3vRYTI+gb5MGaFBGABZpMN5MluAq1G3H82TCJ8cHcbzZNhM9o/mMC1icpb+C0yho3ZI6bYb6hgIWjVz+tNgFg3hIKe+9bDZu5jPbFeRobmRZcy3AGhycjnAKgLyaRx0FI3tEcFRzW/1ayuapVjn5SfwXJVDSxSDnDE8G/ksu16DYFBwTKcsU4XaJYgw2E2QyxV8L7d7tVtIt/AXWRf2TBCqP4EyMian0HLg02odSCRwKjQ242ihDPw/0kMKjSphXfaUStYLw/ICymvsDUrVQZRL2WF0OXC6zExWXL/RRblqNn3WrzW6ahmf6/Y67NI6TkwmyvPYKzik2xq6vL2lyzuQlbO8YJoqUbto6fJO31LlXYHm7/b76kz3GC5MlI8NdtRx/XFWsMPy8Zgcyp9gWR32+4mB3le/reUElD+JOyLKb3f9Lvv3ZBoF5XdgZ+BUPqURqmT/O5ttk+N4amfT59b2XQF8DeXTtrFPovzuJnIZlE9v6fJ7WrrdZ4Sa/96HdPlMT5ffx2wW5fe3mxvkf8D1VPksP1TlD3r6+0vedpd2uqeN8IHyMkr2814/bJO/DyX5Z5sbfh/l/eZGn/wDKNnvB/sa5zl9dAjlczfaO5yfH0JJveehpN4Pm9stjuP51pbK0n/EaqqF8ALLU7xp9XzqbWCTJG8huLFsNDW+3cRJDWUT5WWUmyjvRdlCs2zPQUn8rZYeD1rbZH/aLXeLfoO8RqUkXQdbMEp3y3vgQZTelvcgcR7a8p5zCaW/5V26D2XQ3urwu7DtWtTvYT/gvPQ7doOH2R2U7MeVznaH8qvdtkpJHu72tkOUP4o8gv16IcoA5Y/1YXCUL/KCkPIBSspf7G/75CPfa7Hc9XsbnPdh0PGoPwp1P+KwqzLSPUwT52+/j2M+yoO+rk/6etyP9LeVv1zr+6GPcozyMsrDIEDkFWKCkvwU5b0oZyjvQ/njKJ+Nco7yfpQpygdQLlDSTkcon4PyOAgQs4W4jpJ4N1AS7wQl8R5FSbyfQEm8l6Ak3k+iJN5LURLvp1AS72UyCC4T8Kel1Vc9fDkJQv4MCWK+ggRBf5YEUX+OBGF/ngRxf4EEgX+RBJF/CYTq6i+TIPKvkCDyr5Ig8q+RIPKvkyDyb5Ag8m+SIPJvkSDyb5Mg8itBqD7/Dgkiv4oEkX+XBJF/jwSRf58EkV9Ngsh/QILIf0iCyH9EgsivAXEvkf+YBJFfS4LIf0KCyK8jQeQ/JUHkPyNB5D8nQeS/IEHkvyRB5NeDuI/If0WCyG8gQeQ3kiDym0gQ+a9JEPnNJIj8FhJEfisJIr+NBJHfDuLZRH4HCSK/kwSR30WCyO8mQeT3kCDye0kQ+X0kiPx+EkT+GxJE/gCI+4n8QRJE/hAJIn+YBJE/QoLIHyVB5I+RIPLfkiDy35Eg8t+TIPI/gHiAyB8nQeR/JEHkfyJB5H8mQeR/IUHkT5Ag8idJEPlTJIj8aRJE/lcQDxL5MySI/FkSRP4cCSJ/ngSR/40Ekb9AgshfJEHkfydB5C+RIPJ/gFAh6sskiPwVEkT+TxJE/ioJIv8XCSJ/jQSRv06CyN8gQeRvkiDyf8ubj/lIrRbYrsUlIfMUy2BO2YlmMyY50tibTw+Zli2m+GtsjKe7Qsrdk0WciprU9wvCqOG++YD8hBkZ8q9RtIiU7gqyr2SMo53FpNEcPYIDqJCrC7aNdC49iEbT6ylI4yDZP8Bp9gDpHRLGUbyIkjGoeowup8wlkDge47Qb434A9PIiPlS3Rbpq5TjZxeFsSHpVXXrqZrOnAmGc+/9tcojEaB5hbGtibXdOzAlaBndOdUYYF5WdbxdySEMgezamTCQXzLNrx0ma7CKpkqKOIrurPi+WUiTcqXhYLgN7ku5N54fihWIlUUa/IVYVER4gSZ6w58jbowlkODk4rIHgghYgrUPWialZERfBVy9nL4hz8ynOGVBBT9ZTVoA4v6fMZ7Gz2aw9Km6bcSxNVSNeIm6PD6ePJBZQPFzwwYgr8g4miB0YsgEHEMbStfhEwGH2IG0nk7gV0zKANyhpJPsxcGvI4MHptHIi6mR2tOISklVc+Wiw9eFBxNQ5nqdwMVlw6kOnweaNlLR7HM9xkxSHEYyJoCBrY3W9pG4x+jAxboXH6E2K7UUu7Y9PZgcp9hW5PCpudlPsKnJFf9ZHgxDBdqvsWjG6l0m5theNx7u4IGmiIhW78twBZnkO8Gsb0xto4BVSrrcqIiyVXdzcjFJxBWeZ+RgDyQ8+tY2sW8JYgfvpXLwv5PVktOARzGDdVRA1EoUl6+TMdIiTFLiVvWSeLqzcNOjzEtypyi9vcrzCWB5ODw8j9CRbpuW5qy+0GZFeYvXuYWTKcGjqLHg0Os5WwHKjMJ4wjDlOkhijlCWSoQ+cynRG7Vgx3XhxfTq/lndhAgePxmhspFrMO3J2PhmicFGIYUhaLxW+lMHJ4e50nMGnikG7iFyazkFSAhg4RnI1BfT2JkaDFQnD5rB59DMMNTNyBhlSCFziYOzonAL0470Y51cM3ljbS8bxNlwdbpmqStWygSbpOa0IwRHHUHbVA1QGnyLjkPU8lC6NE0ST+Qn7EE6Do10eX3ehRoFYSM7XbDrBNOuGVo4me2PelU6gU0VcTdJeXhWPEFLWdK+t/PtOlGL2MkMNc6lGlbOj3XGSHgCM7bK34TSMo8N22Ts2YtzcSPaAA79Sce5OUYlze3tpvMBs1ubRKDliUKyXAW8JRRHwlkPGOeWGzmRviglQaFtCjo4y38JC8BCwpqxoxMfJML/ezq9ZmIer+3Vp4WSkzoqGkuHmhSd08DX9oZ/HPZ5l9ceWtTNQe6+8qRFh1MkglcMUZ845m8cYmDOC9ZK9BAsCc4yvNOZrEMvpc4ghXrayQgLgPRA9UadpgWuq/E5Lki5qDHL5zVYN10MYR65Zz9hCeSkT5PrLHbPbU2eQlawDG4hQ+3PGHae8ZUUrxah5CYvnZH3fyhuz7ClIngHQYyi+xBnLaQzyt8ez6uZsFiNcqFVi7BZihfIXMGUpsnJ36UbYcpUNlRZuI8w+jvjqFkPg0i57PJXBjrpXMGxs1vNFgD0aTpsKYzU92tvDTRScWW11CuVZArdWRdIzF7X0eJ8roMtNETMFFkkPnfDNcElw7tGCgZW7D+qx+GA4hHh3gosmKVag0ZzOh3Gg3rewoq6lEK9mfelvZmDCcJqDrm1nd3dme8e8GoCQbbWz8L0D0WPBHl4WMuJzv4GwUSyO2uToMMCygjFSsSTq2VJCWpJqaUBXRPDdP8JKnGfcyjCz5eqMCxSPKfeJtU0EH0xCLWtEFlDF/uNhsWOWriflrwNWBZbxqW0Crw+IyCF7zLso7QXZYy4urnx3mxIje5iv2XjEVsf+Oo75uCEDtZQ95izrsKTwKrFUh/wsGsGdKgE0D79UgMkxMk4hxpRSkn2Ch7nyKgvflKE5u17diA/gYbAP8PBo11a3MhgCnjYGOy0bi6DltBsDt4lHL1bjpgw33fr3DdKcD4s2I7wXTvbNyT4MhbwSUazCGgkeROZ+HvBq3vhoP5lk384UAyugvzrtRkev6U56qs6Px9HRZHhwiw8OkVfCrUHCpdXcgKzxNxvYmSeoML6pNkVMqSrDaB/z9uzZAdILsSwMRWjh/TPYM7+BfZGoVVit8MCCE31OqNinRQ9OIiyZdbHEUoueUzrsckbqiufiKvqa2h5WNKXFP1RmvqsZqSuehy+LvWCtYHTlDw8RJhYgzilCC5+f0uX7yFtRatGPYJEXufL5gtGVLxjBleDo8B1sJfK2CqsVzEg9L3Jw6PbtJaerN8qAZU+YjnBwd5wRamXrEHEB9RdYalEjVhHCOh1OLp6VanWbXzqpq4MRNO88JdBKzbJ5V1sThr3rjFArbyJJqzrm3VVeq7QqKd9jclpXOfCQaH8ezQ7oJJiNNfHYm0RacauQ5tfla+JxN8u06jZXksPVorIxKD7+tESrtQ8TzFI7QQGVJ6DIOF3dSVUkzs4Na+KJVV6rdBcI5iF2v2toGyrfVuW1intQ/IQAkwEItV08UTzpVnL9iQcODZk4R07Ek8S3V1it8JCWWNFMPFk8uWB0pa959QOJp4jvKDldHbCLCqtVdEA8TTzlFmL9QVjU9POfMzxdfOcZoVbuUW4hGoi7xVNzWlf1yVYy+seK7zot0Wo7uzf/buOp4mk3y7TqleOs7dKAMOx3n5Vq9auI22OPfCpeKp9ecrr6YSjDUloEhe+p8lrlR7lCsmPSi8UzSk5Xv5Ce3cXCxvn0e3NaV/2YGioj78uleGbO6LoXxSrPTXHvJ78vo3XNANF3hI1J/XoDHiWeKb7/JpFWfLFe7UGesbxJyh84LdJ6EVs2VQBKsQLF/eJZpyVabXdc5BIpbu3kD1Z4rTHUhy0OAlej4lLJ6vqR2j+xu6yIezJSV8RlELGylOLyTSKtuMf52Yynh/FifoJrQXlvVaB19vUU5UJq3XdapPUOsPqzn0w8TyQFoysfUXwWP7CGr1V5rTJWIi8acTuGymGV1yoT7osI++pQN80ZXTfTBzhaB3fE4sdLVtfP93iR0kEYbiSpCvYIy+kZoVZezPVETZuIWlLg3qhgtcKxnvgN9FAbNf8e2tdVxy1IEerU8hUvEDeUcAv3MfwZx4Y4SXVOpHpZplGvlOLRJNVSTx/pCAvUnwBVfFA9N75khMfJ47yGA+ZJ+Ser6n2djmH3fylXTPZwaCELmU7aTNo5QLTxU6dq0f0bi6NoXNV4mboSylQw5uE8ZqjACbOq9dNVrRZ8AasIsaKq8vKqijvHHCPkSTwpVMTBGLt8PHo4nk9R9YpqVTd7ktXPwSM8PJytzLxL7OG66GxtExsIuy4O8EZRqUaIT8UjuFaqyIq8dIzXC7odhvB2KX9JIvJlx17mcViJPh4zZjhLqhNogO1wUVT8SllRuo1ai1ievyoRAJHMRGMmERjtr8npsbr4wN6sJ1GB/Hp2T9GIYXq8kqNlzOpvSN7bIInEpjudteM9zF6ZHWAt/eYpBZ/R9CaN3yo1NqaLxfTwFii/fbPOrYBeWSqVNQlzDDwxYzBcT79zs06Iree0yqtoLS4xjDCFLyLiRNgJuL5+V2rfhv/qKxCsX9hOef6rJAI8VLNZUZcRr5Z44yllISYANxOvroga5SXFH8g4Kn5H0sa1AeyMw0f5u5Aunn6GqtPB4XS64I0LPnutTCYHcCteso4DHYsxXa/JxYEKmGXF6/KKEGusFP9lLrZVeCkrXl9UqK2rrPirvIL7Ril+Qy6u9KfJH4KwG6h/n0zSogo2/SPwujKX/IlMSSk7vFviLUuxp/3uw/Iov0yCGapB6c/kGHsibJStwRfj6QtfwpKuPr/2cY0AB8/C0huzKQ3YRmU63y+xy1aqykD5XolHsCQ9HSPfLGNlNxrVTHGcJwH5W6AZTPeQBqFXGRTEb4W4O530ZiNs2RnE27JuwuXgH0OljVrhYcEPSxl2AwzhHRIXFnDEg2Q8QrcayTFCA6+T3llxLg8BL54f4+qeuGjiXQSaYBZRqczbhIFLEX9oty7eQ//X0SK7yHqtxKBTBVIchT8gYSIVOdAtfBtCXbTwQFc2HyaHMdIK+OgHqpqdCAz+VyvqgxJMXlNZDB+Soxgb1kTxOL1gwpCk4IOPVC6AdO6GXO6j8pY+t1Fowu8+JqPsJP4hifc/WOv01tVWOVA/c4wl7GQTjBTbBlg1uDdIPBJOj1VH8rCsKl4n8WiYVfAUvgBwroCp+nheV3bHKceMF1o8MJ7RMMtbsNdLPDyqLSHr2zreHxdwrx4mt32q1yt4kNQHf44ItpKfwCvcPoLdyJ24YVP/xCYVM/nJQr63d6riU5UJDA6mR+NRcIi9xFSPQnTTT8uU+YTOLp6PR03FlqeKLG3CHH5GV6FzKl8vKz6rK3bUM0VDfE6zOtUG/3llDgQVdQvj4yl0ptcaZpf3CF/IeRVvvggHzqIx1dfxPJqk1mX09Eu5XjzqZwZax1OpNhAnqrgu+ZiUXwYMug+3nAdHMy7lLEoxMpncLhl4mT98RXc3y7KwHjmoBh5aC4A0Q/g/AL4qD+A26n0H5sN77LX4JJwn+/tYwJ+S4mvof8CVvwlPmEH/6+WCrDhOCqeT35DHU6xQ+xij9w7wmkj7fLO8ia7o405I3/DEVIbPCUNXpHAnWSs+sVW1sZyUn4YQY23LiujUIsbNVVFRWcO10+Oq36KrS6WzldFiueiLqSDxjleqFUlNxU9DqGJfNUpJtRendtV6qVM2WOnFLV2ed7lZiFQwTd6X5hIdNFfpsuNbrv+1s3HkXNngmRi9npmsoWOvWNq2r264ps8LUNHrbnfdHVw48ieduGlUt/nyyoZ7BXfxNmjDC+5DUQt2nNBqDTz1w7j6djkRBm8N+QCL22EJGypp1tYnMJUtdFG7pmHo10aVdsLgRj+Jr9Ot8bAxjCbHUcotFvkYwhUe7oScYUcaYzzH0MNADMU3Yg6U90s1/dGmRqurfxZBKP0vI54hpK5XoO3pUBkM5jMq4gC7qDI630Wv3IxojZPhNYGHphECIR4n4ZX8Xlu2mBBpTDB66Gc7GgKgzgqMUBsDMVHPpZC1qaayFuTBdJHOpouMNdLr0Syjazd/rOKKUZ9qLtP6VgCz3OmdcjFldfUeXCS/qr146pe7mR/qZTjBiRIThhc6ndrX4cD7sXbQJc6Kmr3PwqEPlfE/j1vWNDcpHkRXp7to6BirBQ/ja6OYTtHVmOeQhGLhKhOniMASz/60Xm7WFGFX4ur0tBFShFt5G5qao7fr4nacqnB9lum0tC0wvjtOyb1bGAKf++LCIlfJ4ZWRvyLlxQCdQ7zEReFDRzFuCvgmgCWMkXSzyUaGj80GrxEUaFumnXgRjQhhyF28VSDgx2NuiPQH2LYDQ8N+wribvcE6klXTI3peU0RtUiIia5B1jjfnvyolniuBLY7lcootMxpnFl2JhkPAibpYTZmxBLG6T0LNWs6HbPZBcS7nLWwwmAQlfq5Yn8FqjIVL4rwis573+aMLsNh91AYKu+uGvehkPI1GENyRnrJXgo5+TcoLlYEUpvkG7pr3gNTH3oWhY7x3KnQn9WjgaDw+cY8WaTKK7clwDG+Y7ON8i3FIcZdS9GBCZ4QpuPt/AeYVAAC9mWeYFVW2hledbroJTU6SDyKYWhQGBaX7UII4V0VEFAMmUqMoyQbjRdwSGxXFrGO4jcIVxQCICey2UAQBJY0IOIKYZgzECyMoOt53rarTbn7Nv6nnKdZX61tpr71r1z5NEKQkRwoO7bj7UPU6JRd3vn7sTUPH9buodPCfe5ZefOHYXmdfdl7fbtJQGg1on5sTiKQkN6h21pihN40qGT1e8oLqd4pIDaknDUQCsWDSVnJT1foNvrYk3ekPiwIVXCbqBurQUHHniR+tWZO9VXGL3BtU5E5rJsH+GhVnasCAgLWr9Ro5ZtyI0demv3IPpS8tSd8yYuTI9LibhowaMT49GDg0oYcltY1Ljx9jxNjBpeNHlIzrWOU0dMzIkSVDx6eHjxg9WOnb1Dw9vHTMqPTQwaWlI0pK0zePGJweNXjEyI7Uny/JCGqVieszRaQ8HspMeaehjWaGRI/Xljo2pMaTReo1kaaIsNldkM2lpbSS1tJG0vTlaGkn7aVDEEhKPf07R/+ht4EcK8fhXh4c33/MkDHjx0jPMSOHSYxPMnxC0CsZ7H+2F6lxlGhXzf/clZPK9uH8kmEjbhqV7UTy1KnG6kAka9K/5NqbRg4uzdpkHzvVVKPc7PxVSwUyWQ4VpsqiHzrlSK52O3+SyI5qkjeAVTxFJgxPTZM+7+co49ED8sZJXimTZ+6xZz2cJopcIEGQmiR7h/pMkHeHuLq8FTBjD/hMCh/XVoKc1GTJfdhncmDCfAlyU5Raz2dyk2jVYNJdfKYaPlFrCfJgrnQ+kwcTHiNBPkydtT6TnzdB5F8SVIfZuceYmjFTHR/ppz5T5dFjfKaG+hyWoAbM+FN9piY+4QoJasIsG+sztZShao22/mGfKUii1YJ5Za7P1MYnchIUwKzf4jN11GefBLVhLv/eZ+p6zFc/+0y9hMlPTXOnVvOZ+spQQR2YObV9pgEVSHUJ6sIUtvGZhjBhcwnqsUL2dPKZRsq0kaA+Pnm9faYxTBTpeKa5zUN8polWQG0NiNbyBp9pqrPdN666+80+c5T6UHVDmBcn+kwz8rgm2oNpcvwDPtNcfcgD40Y94TMtEoY8smi2z7RUhjyNYNq+6DOtyCMFFk12LfWZ1upDtMbk6bTcZ9qoDytRe/3IZp9JK0OvtTutjpjTtkm0JuQZss9njsbHMQtNU9PDBimfaQejs5Cfmi7P1PKZYzQa4zkqNd1tqusz7fGJ0lr1dBndzGc6wGjVjWDS7XzmWGXoQV2YvEKfOQ4mpLb61HbtEW/J8TC6DmqmpkcXnOUzJ8DoW9KE2i4632dOhHFEa4DP4kt8pjBZIXXwOetKnzkJH+0oPXDVS3ymY9IDokk4wmdOTqLRg3DuaJ85RaPRA6KFl97qM52SaA2p7b4JPtMZn3glTpe1U33mT+rDnMKEe2f4TJeEIY9rcJ/PnKoMeZoR7dwHfeY08uhsawWbnvSZrjBaQXN8Gs/1mW460oFxD3rO95nTlaEHBUTbsMBnztAKqI2ZkwOLfaY7eXTmmIXoYIXPFMHoLLSAWbrCZ4o1T20badh1jc9kNA8jrYHP6HU+04Nooe2wVL3dZ0JlqIBoUe9/+MyZSbRa5LnjR5/piU+8w+JzyGd6qQ8jZX7kul995qwqpizdW3ymd8Lkp8rCS1I+c7YyVNAoVSalqP5g/kwF+v40hvm2us/8lzKsN/JIZW2fOUejkQcmva6uz5ybMDWpYEd9nzmPaNodKkgPaeIzfWC0ggYwm5r7zPk6P6wDxiNPt/KZvpqH8bTk7PDWEd+FC4jmWugbXFY+6hifuVCZ5rpGy8LWx/tMf2VYo4xnR8VJPnOR5mE8WsG6k33mYmUO67tg55SsegCh4hdhktzayWcugdEkrZiYWSf4zKU6zG90o5osw+b7zGX4xBvVFPmJM9MfzOUw2s4mMI0e8ZmBMDrMBjCtd/jMFZrH2jlV+ub5zJXJYFrDFDb1mavUZ6i+vhwBOvrM1coM1IUzVTr19plrqEAXTn2Yn2/wmUEwOh6t4MnnfWZwUkEjmNve8pkh+OjyaAhT/3OfGQqjHW2emibTxWeGJbXBuIICnylJGD5y8uARIx2uFTDVNfH5tI3PXEse7TXRZPsRc3pdEo2Pthta7DMjNBrjaQOz8YjuXI+P7LUK3LmX+MwN6kMFHCjk/qt9ZiQV6Eg1T+0bfWaU+pBHDzsTbvOZ0fhor4nmzn/MZ8bAaDQqkI9e8JmxGo0KOFC4eot85saEaYHPgCU+U8p42ESr16iRE8Tn/fiXkv20KsxpVPD1hF1PXbN6VcXy/nM6L2tfNnbJ2bfkSrVDNSVrnv15kPXY1qLVwh77DrbttqzLipO7/etQ13P2X49HeV6VR/KjI+twTZMDn/5t8Zx9J939/bCyl9JPLn5syFwcvsuHlY6pOwMXBHcFMomfG/yqCGRqINMCmR5IWSAzAnk++J2rLvfvdecGEvAjZU2Qkrz0+hS/QtJteogrzeSItOoh8kuxDKqBHF6cI9GPGZH0OxLNN5kj7jwDIj8Vi8zDQgqLxXVGqXJ+JmUgWqbBAOFPMOXFkq7bA8UPgHakOj0j0Uko3MSMuG49JHrJZJwOIGnylx+LYlBL2CY9ZJBWuJfo0X4s9mr0fRnZgZnsIFh9TMN1gGaYEwyJYroBkREZCQtQyFkofqOgXig+IJiC6AUNBnBXcQ+HPRZFOBXwJQOZb5JS1xoQ9wWyHhbRXsApBNKCSgmW1hJLM3Ky8AOwHyRzJzKBNlWBsAdAqSrA9aHOgOSSawZhFcgiGEeuDaqoRMFYpVlG0gGjcBdRNAMPZ5nEYqUBcd9j9X+4pPN4WI95dQb/GKUNArgpMAYKMNvNPYlhhWsATGc0yyTRCw2IfExatbCCClAi3TSCKaBUCcR1YugaVoEU8dAX2VAVNwA2YadhN2mU+QYkehurBmrxIYruPCCJFivcqzxgES5HYS5bedAYW1FYUBSaxSw0bYSLSuqQ13MoKnyFh8awCnSCZDZ3DxTyMExfHkYjB6qiC0O6CwUyfDdRhF+j2IA8jMIdQwZt7SSTWLxhQKJPqEEtov2Y46IyfCeT0ndAAb6AaA2pZiM3qeIxTFmtIcGQBBtkQKQPFptV0Q3zdSiQ0XuJIiKllh2+isKVwM5DORPlsygiHsKnuZeieBSFOwC4i1tli0Qhz9H6T5B1dC5eBzDFkdZhc36mgXhlDCrCYgFz3pz7Ou7Z6rKjKH7jVRZmWATtMS0kOm+LuGrcGuMrNb0S8Db9m2ISxRMGxD2H3ILCJuYQFkhmSpaxH2XfBiLri5IFYX7yolQBvbAeCHeCzgdgUGeW+ePFUt5VFcuLKZIZy2d7KELhCg2I65mJLdxlGXNRaTEUyNHEwCJqiUJwcU2xIAYSxQrKRyFP0EazIK25IIkhb+sQXBEBrU56Ee7R5vw3EVktOlIkQ99qQMLdWPyCRXlAkC+pEBm9kkkZ4GIdLaWqKvAytgaWU9JCnNeq4nmibeFhlkkUQw2I9EZWEk0BF6A/BWeBFZlUK/P0pZGaaPUtVOBW4rQUuUsVzQhFxe4OkwxhvgGrRP6pOTAnUErCXAaWBTKLdWTg4goJD2H71woU3wFaV4qsYRinV7J8X86IDKjUnUUlQ7jQgOWVYhSyjEraV4pM1xFUUnhORiRNMP2MyCqiTzaJabkBli/yHlVEgJYoVN5bRK0KziiGeR6gS36CSRQtDIhUFItMUQvtRB2UyND2PQW278mfUE/JYANwGe5+3I1UMRrmUxbJLJOMb6EBS+xaahQAN9XD6FyFD5hEgS8gDvY+Co0evoI5knQk1k+Lq89KeVYjPUueLGD3pDNQVQBK3rBleSPxSlR7J6AaQO4m4JUKNgJOY8bcLwkYlGbGlBrUHpALCI8HDAe43gC1Kb8qAa4TQBdVeYsEhDt5yXKV+ju5GgCiHYlGHiKF2uhexoXmQFEcR36jQQqSUuVv+kkM1UGnxnUzIPIPzG6lqcyguDyUKu+kNAVhmbYM4BbA/AXT9arYQpP2oGhHc4Xly8Zvy9fNNMmSfM+Afdj5pjNlv2K+lgdkOJPoCmQ8QGoZIGptwDHUqivwWypywwGTSfWISaK+YkA/K3zIVLEe8Feq2oZbTYKFP6OoUGYzgOEl4xVmbCY29vINNcCLwK2fQGlKXct5qMNdThS31gPssJTyESYreFgK85kqXuSBIElUcbooQkYsvxdTBucxe2kHnZEAaQil8xNKAthKOA9okjsAqrEDnwJ5qSjx+prBGrgSqjrG8nIm1oQbsyBOGm/47gTsLMRTdCULzE6pKqAXr9xMjo4nMl0KolOIM48Nv4sq2PD1yKjHViSKoxijKjqw8syiCx1RF2QcA+Dao8AiaqsKXKQ1CmIgURAUYFliC9KaC5IY8ZsYVxcXzpUAPdsZVQW4vtNd1kXkratTApBTGeQiFOegCOcArkZ5F3IUCikCTOBuQIm2slk7tkLmU9FsVUxBsQCFyuWJwn2L4gDyVxQ6SZG2fKpJLF4zYEeM6DAW+rrKN9Sh8t0MM11hgJdAwUbyM4nRFyjc0zzsQkkwJIpLDcSHuK9U0RqwmRsZfZAo7KxxOsqXVHERD3NIdy/3UyjkVZiHuZfjMkMVn2ExEfYblNegiHYDzoRFSpNEIU/Sgw3IPF6faDGA18ZNM0mMPgY4wCD7FaFYz6zU436M+y+4SAawixvpOmSYtwKydCC6q4PPXphOSDu8XAyYjJlG1xc7KjcQ7zIvo7C5ZJdRyeTKPF3cshrlJbA6Qi3G3WQSRRsD9r5IWi1mAF7nLuMu1mIA8epP04gscD20PIDah5NMMoFvGpDoQywa4qzAfOSgB7gAa7IgLk7KdZcVPtHhFGIrcNqHH2EnEVvWAbTS/zFJ9ksNiGuDvL2YQC0AFvFeaq8Ctu6PhsoC21arNt5nTNJJ4gPsN1+4GwutQFbhhwzLMkRTMEU/fNFWCtMFoiB6i4eV3BtRhK/jvROnh0yS51wDceJlmbgC1wxGzseMZjlMkQRbbEBCgjHrKIjuTsRP5YyMvGAdakVA7aSO2+lQ5ApMqFzKTeK3xYCEuwj0HRbRL5geZrvh91aUg4VuqmrBZqKSuvsa4H/zcHudMhVwcQLs6gG3iGgG6FbI9zbahqKcI6eOUfjuIvnFV8cA/9+IxecoQi3gY+6D3K8RXgEXeVZ5IFyIrQGcw/u5NZrrZYATLs4fZDAFcAHuYX6zwJqSdEe26bJXRzkOrQK0bPkPeyD6IRNTVUDyknSyhsAXIl9kGmwnvBvFnSZRTDcg7hHko6w8AyKMczKANSnDTDKYDgbi88HnRSjWEmgSt8o88iqwAmRW9z+AFalUFagaCEDe0/3bXhzNKisArkiPaWSmwPA5AFlllEksaAvAtm0pwEJ/KfBTKpa6kSlw12PFRuTuVUVXHubQHB3bHMqK3vNA+DYmCtwGHhZj9oUq5vKwG+UMk3RqsAGREIsvVdEaxSYskJTL0CaT730YBdFmTN9B8YMqfgL8hqIQl1zWqP5FRNdoeK9JLJYaEEdA+VVd9qL4hod9yKUaHcBxDkZBPwKyEPma0UkDunRWGxCWy+2gmWqsb+RMjP8XuUQVSwAc92zATYmrgLkmzDMGMGlowCSnu1ghe+juKchKDXI+QKPeHssv9W12LHJGzpTNMyDREuS7qvgYcJgFsI6cJ5BKDhugyz/DHCLyj8g5avo5IE3k95Fji0g1H8B0W3Sdf6dFoJDtuE3ERbphXgMlMpqi0QHO5h0gTCgLW6KNqlgPo+1rzQgD2u4upru0PSQ6koLeMSDRZ1gcUhetcBu3lryQ6DYIfbl1VNEazJai+ByFewGwC8X9JvG9zED8zfsEBcdT64rJuwmmQCYljOvAg5p+x6jsk0ATHcFUbtUWy2kMRDdrBRRhP5vDDarYwlD3EaMdW6ON7ApSMBD3gElG9qEBfS91N8WCv2XJSlyQbAMUAwj1g6XAnY75b2T4J8VEuu7HkpJzi3xYhAV/ObFJeNAk+U8zEH98p+KiFUpdlEg+8cwKgNqFhVKTCiwPwHXEpgu3fiXkasBkHDWsLaXXDcQrex+KaDuAFaCSaLEifIM4q1BoJ9xiHmi6DhyJ4moD4rpgqatA08qbKJDUkfyJoRUPukHpScDtVDP8tGHhbJNUd9CARCoXZXh1AFz4kJwrAa/hHALshwnrKdyOQo8r4U7uh7gt/G0GbKLDHao4FfAJiqMJH2UIBuCidfrtz4K4yLhauc82z5AWay8U6DTrnwNF9yz9W5JVPMkkZS02wItAHv2jLw3RQET81QN2uDPwVoWE27A9qhLnShQDKrXvKgl/uQGRthk2IlVsJHG7yvg8uKeCgg8CXAVMV4LUqNSloJJg8wzYxicr1WIt4OaKWO7tjq+Cy4oxXQRgbYWMAkllDAsQj9MWGwO3xYZ0VEdPajMcXWMK5CRydUbqCtKXUo8m0UyTRHvbQJyvUSZOzMeZtfUWQZii8D5unTMdMCD+u4EuJY0evckDknTJwS9jVcACIt4wrZMVSCoK1/Y7RoLEYpEBiT7Gan+GJaVAT3ei3a8COvluQwJ0B+Lvh4R7DaB9IByScB0MWEKZhoVWwN/UY2lvIYDahCoLrGRsAK4Qm87cfofcTJPkeduAFecaEkUBX2pMYawhVR3CFxAHsw4VMELtEJJ0cYc4uOkDHQZY737EQl940bExgugZkyiuMBC/DP2LaYOCfpUMhZehCsRLtzmRFEgbCtXzpL5c2l8hHJKEaw3YByfSV8QqWM0D0unRWAG1Cb/ktxJF51FB+CY2H3DrHhMuQrGTexa3Dtv1MRAXtzJDKQBXC0b6oGEHizBFosAXoCtMZCcKjS4n4o8knf7/Eh2ai/Jb/MMnyfl3Hu43iX8vA5ZB/s02IexlBhxvaLhHvS/Am/GHD5hk/HFn4oTVMTXwbUYe0jJkFiF7UqSBB7hf4l6oilWADdwB5htQ6JYEsDNObNEd8AAKlRZDwUdFsUW6KHFZsDSOsWApFhpUFZpFLSytuqjsWSz36OqR1TzYOAF8zgC3Fv0BbMBKVYGoAQNVMOh4Jvkokp2GwvVhNfZE8YhJFAsNxGeQ7vi6T2iz/l+Zfob4bzU+tyYxvdlA/CcZtdC/cNtf+JD8IiEvwAoIH/dAXCRUFeACUJterLn9iSpa7oHYH6oK6DXbZugWaswnmFuS0LIzAW4ids9XUFwfbAZW8jFi2Q2sxIRjg1yu4Dg0/bMgX8E0gG7Q8o0Be3FlF1FcB8DKCnFdkWdVYNoHEOlOfUq26zuyXb+FjPmZ+LeLHje50ALige/NzhcgdoCqAunG2lHADn6NydF0y+arXzw90YMmWbrPGtBfcuJsq1yAqU5POIe/+3fE9zGT+DoD4q7LSHgcCumHKb8YVbrG6guwAqLZHoiLhKoCXABq0+tcRuduRXm4mGl5N3F0u7NgJpTa6zGTC8cp2fFuT8abuIv8Pw==(/figma)--><strong>Closing</strong> &ndash; We will submit all closing documents to all parties. We will collect final payment from carrier via mail.\r\n  </li>\r\n</ul>\r\n\r\n<p>\r\n  <!--(figmeta)eyJmaWxlS2V5IjoiZVQyanB1Y3NQU3JhR0JyVFFwQ0ZYS044IiwicGFzdGVJRCI6NjcyNDg0MzkyLCJkYXRhVHlwZSI6InNjZW5lIn0K(/figmeta)--><!--(figma)ZmlnLWtpd2kBAAAAXxwAALVb+Z8kSVWPyKq+pmd3Z3aXU0RERETF2dlld0FEsrOyurK7qjI3M6t6ZkWK7Krs7typriorq3umV0REvG9FVFREvBCQ+5bbAw8OOQQRRA79P/x+I/Lq6ZHf3M9nO9578fIbES9evHgRUZN24jSN9uPwZBYLcduW63QHQWj6ocB/XbdhD6yW2d20A7CyF9h+hTeUtt1tgK4FzmbXbIOqB+HVtg1iSRGDwCbWstJVyINg2/EGvt12TX650nVDp3l1ELTcXrsx6Hmbvtng96sZOWi4XfJrOe/bTd8OWhCdCyy7aw8g9lqDh3q2fxXC9arQt702hefNG0mKLl8BLSiQ5nCIoUPk22Zj4HaVmlDMju+EbFF2p6PYO4jSGGoWqkKbPYZSx+0rUu4kk1Ey2fePxtTput2Hbd9FhXAbqp4I2rYXUWlDJBqu1evYXVpFWma3bwagjE3f7Xkgak3f7FCvvuG6bdvsDlzP9s3QcbsQLvVtK3R9UMu0JcqVtqNgV+122/ECkms+lDBJahbO+fZmr236A89tX91UIOtoqtuwGzBOqXc+tK+wS7cFbcei4PbgamfD5Yze4XTRWFdJL2yM48mog1EJcZdnBsEgbAFuk7MBf/E7ygdkw/S3bbZldHrt0NFzUGNX0ZONns+quuW23YJbajubrVB9sxzA1opSg8MXDbexaYNf1Z/k7BpmwW+bxD4XuM1woDDArbdMv1Fw5xtOs2n7th7BbfYVq90LtD1vb/UouyMww15h5AuqFRAX272O03UDJ2QTd3pRMlnoyVwJ3LbDCRZws4aD2URr7CokshCxVPbA7IKkCObmbEBWK2RQ6rhqFdWdjqlGtgQP23JALDuHWJ3BMBrH2uhYXr4dWsreTYfDk02nrRoJHTWTNXtvLx5mHa073S4WbdAyG+4OKkXDd72SlU0X/oEJ7DYGG+0e+2VsmNb2aVEtjG8sLLUMll3f2XT0Shc9D66JUrbdHUWgC6HuQwBHaA8s06Nz10tu0HR9Sy2dJYI24uF0Hi2S6QTf5AsELWNaYU7QEsN1tu3SyYzu0eFuPO9NkkWKb3yTwxCec8VuByAkeoTlT7sY1nSSLuaVScNkQi5Yr7orOybjgYE2MpPWAstUA6g3gdgY6C+WMkZpLweL+fRabI6T/Qk+KMAEVomjApd0e2FGGlrZimZAyceHoajZlsFDPdOnyDB9391RLsRB1DRrP9Rz2og5vrJ2XUNtTRM220GEUq1u2H2b1TJHNTam03EcTdxZnFu23utqz0Yf8VmAZQ9aBr2N0DcVbVxRDq8mWo2sNZ0nj04ni2iMz9t2k0oVw8EJ1NIytnoBorejZrT8uh/PFwl8ljLXQ1Xl0w03DN0OKKMzPUpj62ieTueYnIbdNBErUCEs3w3goo4PWtpXbfos5hWcgc1HNeWZGApihwXfAF/3VLxYQmE5bVDLfSyB6byTzOdEL3wL60/Nr1QEliPChN3dDDn5RiNKD/QqMywEU4hE6RpSrUTtSXWvuwmR2PJsljLoszC8RhNFzb4xm84XN3tfzXJhAnQ6dzGRC3achmpf5oKWnZu3HZ1Mjxab82SkQeraISvmLDtoaP+sld940WIRzyeogpbjKd9CwFKBS6rJOlpM/ThNHgV0YSLVHWWZoh+yoODQJ+M4iLNBweB+4GbhILRNzqu04BN6hrFPY1fuWgyftdDueK5vqj0azqxhYKVFXJjoTFQFKfOYiKaj4TU9P0VnW4hHD8NsqgcS20HowLygtbbyRqifMZu2lVaypkfoxDzTPWviXLewdE19tnWULpK9k2/1hWda9gALVCcX+rNAWdtQIQVCJBOB87A9CN1BFs5hkgmcFytXW6WIG/B424etB8zLwMuer0a6gYCNsma1XbX/1x0OJ6pAnHe7A3i0UhNmEzCD0OnYiFPgZcdFYjdQYzA0rStq+KrFLRZ0XVdg16DakuZUwrIMLQ+DoHMhl1NdXW34JlfEGuq27av5Z+fA9l2dXqyH82iSJmUfn4D4iSwjHCAmIZJme7FoOAG8om+DlE1kfygNpChIA5u+28HiVaGpVhHlsalekekotFSRFGFo2esFLS3LwFZKSY61Woo01FopKJDOMSvUsgxpvZTkSOdLkUa6rRQUSLfrjmIaoJSD3XFKmONdOCXVkBdPyQrUO1VLmTQDvasqyzHvrgo15GOqogLxsViajjVgHbjHYZtHem92sWJV/vx4O0qRHOv5RSYysHobjoUKQaCckUixKqzBXVBnSMFwPh2PG8lcLwdgZP71LZY9+qaXqPoWa2nBlRCPsPYWMertKx5Cm156FhC4ASpObvYQe6SR4lSAxkCvCDmeYhdTJLKJMXYSWZ+LNSH38cfYxZ9ahD91vdng4xvg5An+GD5E0C4F1/GndoA/dYUULKYzfDAkLUIhZ1O9GKBgdKLFPLkh5PLhpUvg5eGle1AYh5cuo6gd3kNh/fAeCpcO76Fw2YvmCKPOZBTjO2P/KBkJvwK6nudNqDyOxkcxvpFHKod6PGIRrNSNDmMha3vRYTI+gb5MGaFBGABZpMN5MluAq1G3H82TCJ8cHcbzZNhM9o/mMC1icpb+C0yho3ZI6bYb6hgIWjVz+tNgFg3hIKe+9bDZu5jPbFeRobmRZcy3AGhycjnAKgLyaRx0FI3tEcFRzW/1ayuapVjn5SfwXJVDSxSDnDE8G/ksu16DYFBwTKcsU4XaJYgw2E2QyxV8L7d7tVtIt/AXWRf2TBCqP4EyMian0HLg02odSCRwKjQ242ihDPw/0kMKjSphXfaUStYLw/ICymvsDUrVQZRL2WF0OXC6zExWXL/RRblqNn3WrzW6ahmf6/Y67NI6TkwmyvPYKzik2xq6vL2lyzuQlbO8YJoqUbto6fJO31LlXYHm7/b76kz3GC5MlI8NdtRx/XFWsMPy8Zgcyp9gWR32+4mB3le/reUElD+JOyLKb3f9Lvv3ZBoF5XdgZ+BUPqURqmT/O5ttk+N4amfT59b2XQF8DeXTtrFPovzuJnIZlE9v6fJ7WrrdZ4Sa/96HdPlMT5ffx2wW5fe3mxvkf8D1VPksP1TlD3r6+0vedpd2uqeN8IHyMkr2814/bJO/DyX5Z5sbfh/l/eZGn/wDKNnvB/sa5zl9dAjlczfaO5yfH0JJveehpN4Pm9stjuP51pbK0n/EaqqF8ALLU7xp9XzqbWCTJG8huLFsNDW+3cRJDWUT5WWUmyjvRdlCs2zPQUn8rZYeD1rbZH/aLXeLfoO8RqUkXQdbMEp3y3vgQZTelvcgcR7a8p5zCaW/5V26D2XQ3urwu7DtWtTvYT/gvPQ7doOH2R2U7MeVznaH8qvdtkpJHu72tkOUP4o8gv16IcoA5Y/1YXCUL/KCkPIBSspf7G/75CPfa7Hc9XsbnPdh0PGoPwp1P+KwqzLSPUwT52+/j2M+yoO+rk/6etyP9LeVv1zr+6GPcozyMsrDIEDkFWKCkvwU5b0oZyjvQ/njKJ+Nco7yfpQpygdQLlDSTkcon4PyOAgQs4W4jpJ4N1AS7wQl8R5FSbyfQEm8l6Ak3k+iJN5LURLvp1AS72UyCC4T8Kel1Vc9fDkJQv4MCWK+ggRBf5YEUX+OBGF/ngRxf4EEgX+RBJF/CYTq6i+TIPKvkCDyr5Ig8q+RIPKvkyDyb5Ag8m+SIPJvkSDyb5Mg8itBqD7/Dgkiv4oEkX+XBJF/jwSRf58EkV9Ngsh/QILIf0iCyH9EgsivAXEvkf+YBJFfS4LIf0KCyK8jQeQ/JUHkPyNB5D8nQeS/IEHkvyRB5NeDuI/If0WCyG8gQeQ3kiDym0gQ+a9JEPnNJIj8FhJEfisJIr+NBJHfDuLZRH4HCSK/kwSR30WCyO8mQeT3kCDye0kQ+X0kiPx+EkT+GxJE/gCI+4n8QRJE/hAJIn+YBJE/QoLIHyVB5I+RIPLfkiDy35Eg8t+TIPI/gHiAyB8nQeR/JEHkfyJB5H8mQeR/IUHkT5Ag8idJEPlTJIj8aRJE/lcQDxL5MySI/FkSRP4cCSJ/ngSR/40Ekb9AgshfJEHkfydB5C+RIPJ/gFAh6sskiPwVEkT+TxJE/ioJIv8XCSJ/jQSRv06CyN8gQeRvkiDyf8ubj/lIrRbYrsUlIfMUy2BO2YlmMyY50tibTw+Zli2m+GtsjKe7Qsrdk0WciprU9wvCqOG++YD8hBkZ8q9RtIiU7gqyr2SMo53FpNEcPYIDqJCrC7aNdC49iEbT6ylI4yDZP8Bp9gDpHRLGUbyIkjGoeowup8wlkDge47Qb434A9PIiPlS3Rbpq5TjZxeFsSHpVXXrqZrOnAmGc+/9tcojEaB5hbGtibXdOzAlaBndOdUYYF5WdbxdySEMgezamTCQXzLNrx0ma7CKpkqKOIrurPi+WUiTcqXhYLgN7ku5N54fihWIlUUa/IVYVER4gSZ6w58jbowlkODk4rIHgghYgrUPWialZERfBVy9nL4hz8ynOGVBBT9ZTVoA4v6fMZ7Gz2aw9Km6bcSxNVSNeIm6PD6ePJBZQPFzwwYgr8g4miB0YsgEHEMbStfhEwGH2IG0nk7gV0zKANyhpJPsxcGvI4MHptHIi6mR2tOISklVc+Wiw9eFBxNQ5nqdwMVlw6kOnweaNlLR7HM9xkxSHEYyJoCBrY3W9pG4x+jAxboXH6E2K7UUu7Y9PZgcp9hW5PCpudlPsKnJFf9ZHgxDBdqvsWjG6l0m5theNx7u4IGmiIhW78twBZnkO8Gsb0xto4BVSrrcqIiyVXdzcjFJxBWeZ+RgDyQ8+tY2sW8JYgfvpXLwv5PVktOARzGDdVRA1EoUl6+TMdIiTFLiVvWSeLqzcNOjzEtypyi9vcrzCWB5ODw8j9CRbpuW5qy+0GZFeYvXuYWTKcGjqLHg0Os5WwHKjMJ4wjDlOkhijlCWSoQ+cynRG7Vgx3XhxfTq/lndhAgePxmhspFrMO3J2PhmicFGIYUhaLxW+lMHJ4e50nMGnikG7iFyazkFSAhg4RnI1BfT2JkaDFQnD5rB59DMMNTNyBhlSCFziYOzonAL0470Y51cM3ljbS8bxNlwdbpmqStWygSbpOa0IwRHHUHbVA1QGnyLjkPU8lC6NE0ST+Qn7EE6Do10eX3ehRoFYSM7XbDrBNOuGVo4me2PelU6gU0VcTdJeXhWPEFLWdK+t/PtOlGL2MkMNc6lGlbOj3XGSHgCM7bK34TSMo8N22Ts2YtzcSPaAA79Sce5OUYlze3tpvMBs1ubRKDliUKyXAW8JRRHwlkPGOeWGzmRviglQaFtCjo4y38JC8BCwpqxoxMfJML/ezq9ZmIer+3Vp4WSkzoqGkuHmhSd08DX9oZ/HPZ5l9ceWtTNQe6+8qRFh1MkglcMUZ845m8cYmDOC9ZK9BAsCc4yvNOZrEMvpc4ghXrayQgLgPRA9UadpgWuq/E5Lki5qDHL5zVYN10MYR65Zz9hCeSkT5PrLHbPbU2eQlawDG4hQ+3PGHae8ZUUrxah5CYvnZH3fyhuz7ClIngHQYyi+xBnLaQzyt8ez6uZsFiNcqFVi7BZihfIXMGUpsnJ36UbYcpUNlRZuI8w+jvjqFkPg0i57PJXBjrpXMGxs1vNFgD0aTpsKYzU92tvDTRScWW11CuVZArdWRdIzF7X0eJ8roMtNETMFFkkPnfDNcElw7tGCgZW7D+qx+GA4hHh3gosmKVag0ZzOh3Gg3rewoq6lEK9mfelvZmDCcJqDrm1nd3dme8e8GoCQbbWz8L0D0WPBHl4WMuJzv4GwUSyO2uToMMCygjFSsSTq2VJCWpJqaUBXRPDdP8JKnGfcyjCz5eqMCxSPKfeJtU0EH0xCLWtEFlDF/uNhsWOWriflrwNWBZbxqW0Crw+IyCF7zLso7QXZYy4urnx3mxIje5iv2XjEVsf+Oo75uCEDtZQ95izrsKTwKrFUh/wsGsGdKgE0D79UgMkxMk4hxpRSkn2Ch7nyKgvflKE5u17diA/gYbAP8PBo11a3MhgCnjYGOy0bi6DltBsDt4lHL1bjpgw33fr3DdKcD4s2I7wXTvbNyT4MhbwSUazCGgkeROZ+HvBq3vhoP5lk384UAyugvzrtRkev6U56qs6Px9HRZHhwiw8OkVfCrUHCpdXcgKzxNxvYmSeoML6pNkVMqSrDaB/z9uzZAdILsSwMRWjh/TPYM7+BfZGoVVit8MCCE31OqNinRQ9OIiyZdbHEUoueUzrsckbqiufiKvqa2h5WNKXFP1RmvqsZqSuehy+LvWCtYHTlDw8RJhYgzilCC5+f0uX7yFtRatGPYJEXufL5gtGVLxjBleDo8B1sJfK2CqsVzEg9L3Jw6PbtJaerN8qAZU+YjnBwd5wRamXrEHEB9RdYalEjVhHCOh1OLp6VanWbXzqpq4MRNO88JdBKzbJ5V1sThr3rjFArbyJJqzrm3VVeq7QqKd9jclpXOfCQaH8ezQ7oJJiNNfHYm0RacauQ5tfla+JxN8u06jZXksPVorIxKD7+tESrtQ8TzFI7QQGVJ6DIOF3dSVUkzs4Na+KJVV6rdBcI5iF2v2toGyrfVuW1intQ/IQAkwEItV08UTzpVnL9iQcODZk4R07Ek8S3V1it8JCWWNFMPFk8uWB0pa959QOJp4jvKDldHbCLCqtVdEA8TTzlFmL9QVjU9POfMzxdfOcZoVbuUW4hGoi7xVNzWlf1yVYy+seK7zot0Wo7uzf/buOp4mk3y7TqleOs7dKAMOx3n5Vq9auI22OPfCpeKp9ecrr6YSjDUloEhe+p8lrlR7lCsmPSi8UzSk5Xv5Ce3cXCxvn0e3NaV/2YGioj78uleGbO6LoXxSrPTXHvJ78vo3XNANF3hI1J/XoDHiWeKb7/JpFWfLFe7UGesbxJyh84LdJ6EVs2VQBKsQLF/eJZpyVabXdc5BIpbu3kD1Z4rTHUhy0OAlej4lLJ6vqR2j+xu6yIezJSV8RlELGylOLyTSKtuMf52Yynh/FifoJrQXlvVaB19vUU5UJq3XdapPUOsPqzn0w8TyQFoysfUXwWP7CGr1V5rTJWIi8acTuGymGV1yoT7osI++pQN80ZXTfTBzhaB3fE4sdLVtfP93iR0kEYbiSpCvYIy+kZoVZezPVETZuIWlLg3qhgtcKxnvgN9FAbNf8e2tdVxy1IEerU8hUvEDeUcAv3MfwZx4Y4SXVOpHpZplGvlOLRJNVSTx/pCAvUnwBVfFA9N75khMfJ47yGA+ZJ+Ser6n2djmH3fylXTPZwaCELmU7aTNo5QLTxU6dq0f0bi6NoXNV4mboSylQw5uE8ZqjACbOq9dNVrRZ8AasIsaKq8vKqijvHHCPkSTwpVMTBGLt8PHo4nk9R9YpqVTd7ktXPwSM8PJytzLxL7OG66GxtExsIuy4O8EZRqUaIT8UjuFaqyIq8dIzXC7odhvB2KX9JIvJlx17mcViJPh4zZjhLqhNogO1wUVT8SllRuo1ai1ievyoRAJHMRGMmERjtr8npsbr4wN6sJ1GB/Hp2T9GIYXq8kqNlzOpvSN7bIInEpjudteM9zF6ZHWAt/eYpBZ/R9CaN3yo1NqaLxfTwFii/fbPOrYBeWSqVNQlzDDwxYzBcT79zs06Iree0yqtoLS4xjDCFLyLiRNgJuL5+V2rfhv/qKxCsX9hOef6rJAI8VLNZUZcRr5Z44yllISYANxOvroga5SXFH8g4Kn5H0sa1AeyMw0f5u5Aunn6GqtPB4XS64I0LPnutTCYHcCteso4DHYsxXa/JxYEKmGXF6/KKEGusFP9lLrZVeCkrXl9UqK2rrPirvIL7Ril+Qy6u9KfJH4KwG6h/n0zSogo2/SPwujKX/IlMSSk7vFviLUuxp/3uw/Iov0yCGapB6c/kGHsibJStwRfj6QtfwpKuPr/2cY0AB8/C0huzKQ3YRmU63y+xy1aqykD5XolHsCQ9HSPfLGNlNxrVTHGcJwH5W6AZTPeQBqFXGRTEb4W4O530ZiNs2RnE27JuwuXgH0OljVrhYcEPSxl2AwzhHRIXFnDEg2Q8QrcayTFCA6+T3llxLg8BL54f4+qeuGjiXQSaYBZRqczbhIFLEX9oty7eQ//X0SK7yHqtxKBTBVIchT8gYSIVOdAtfBtCXbTwQFc2HyaHMdIK+OgHqpqdCAz+VyvqgxJMXlNZDB+Soxgb1kTxOL1gwpCk4IOPVC6AdO6GXO6j8pY+t1Fowu8+JqPsJP4hifc/WOv01tVWOVA/c4wl7GQTjBTbBlg1uDdIPBJOj1VH8rCsKl4n8WiYVfAUvgBwroCp+nheV3bHKceMF1o8MJ7RMMtbsNdLPDyqLSHr2zreHxdwrx4mt32q1yt4kNQHf44ItpKfwCvcPoLdyJ24YVP/xCYVM/nJQr63d6riU5UJDA6mR+NRcIi9xFSPQnTTT8uU+YTOLp6PR03FlqeKLG3CHH5GV6FzKl8vKz6rK3bUM0VDfE6zOtUG/3llDgQVdQvj4yl0ptcaZpf3CF/IeRVvvggHzqIx1dfxPJqk1mX09Eu5XjzqZwZax1OpNhAnqrgu+ZiUXwYMug+3nAdHMy7lLEoxMpncLhl4mT98RXc3y7KwHjmoBh5aC4A0Q/g/AL4qD+A26n0H5sN77LX4JJwn+/tYwJ+S4mvof8CVvwlPmEH/6+WCrDhOCqeT35DHU6xQ+xij9w7wmkj7fLO8ia7o405I3/DEVIbPCUNXpHAnWSs+sVW1sZyUn4YQY23LiujUIsbNVVFRWcO10+Oq36KrS6WzldFiueiLqSDxjleqFUlNxU9DqGJfNUpJtRendtV6qVM2WOnFLV2ed7lZiFQwTd6X5hIdNFfpsuNbrv+1s3HkXNngmRi9npmsoWOvWNq2r264ps8LUNHrbnfdHVw48ieduGlUt/nyyoZ7BXfxNmjDC+5DUQt2nNBqDTz1w7j6djkRBm8N+QCL22EJGypp1tYnMJUtdFG7pmHo10aVdsLgRj+Jr9Ot8bAxjCbHUcotFvkYwhUe7oScYUcaYzzH0MNADMU3Yg6U90s1/dGmRqurfxZBKP0vI54hpK5XoO3pUBkM5jMq4gC7qDI630Wv3IxojZPhNYGHphECIR4n4ZX8Xlu2mBBpTDB66Gc7GgKgzgqMUBsDMVHPpZC1qaayFuTBdJHOpouMNdLr0Syjazd/rOKKUZ9qLtP6VgCz3OmdcjFldfUeXCS/qr146pe7mR/qZTjBiRIThhc6ndrX4cD7sXbQJc6Kmr3PwqEPlfE/j1vWNDcpHkRXp7to6BirBQ/ja6OYTtHVmOeQhGLhKhOniMASz/60Xm7WFGFX4ur0tBFShFt5G5qao7fr4nacqnB9lum0tC0wvjtOyb1bGAKf++LCIlfJ4ZWRvyLlxQCdQ7zEReFDRzFuCvgmgCWMkXSzyUaGj80GrxEUaFumnXgRjQhhyF28VSDgx2NuiPQH2LYDQ8N+wribvcE6klXTI3peU0RtUiIia5B1jjfnvyolniuBLY7lcootMxpnFl2JhkPAibpYTZmxBLG6T0LNWs6HbPZBcS7nLWwwmAQlfq5Yn8FqjIVL4rwis573+aMLsNh91AYKu+uGvehkPI1GENyRnrJXgo5+TcoLlYEUpvkG7pr3gNTH3oWhY7x3KnQn9WjgaDw+cY8WaTKK7clwDG+Y7ON8i3FIcZdS9GBCZ4QpuPt/AQITAADNmHmUFfWVx2+9XuiGbvZF9gcIQVAERKCl+1HiNioSVNza0YDQuCQsQVDjRPxJ001jQCFGmLhNqzgiuLC5IHZbrqjIajwKEcWIMx5FhHEiRNSZz71V7/FzlpMzf8w5eaer77fu926/+1uq3guClORJybZVK24raF41bvB102dNvH7shTMmnDVqxrjzp5925qXnjhkubaTtRb3z8wORlOQHBadPmzhrStXUmVIYFN0qIsXSUlqLBGLBpIfkpwrGTri6Kj3oqEWJCj4mWgTq0Ebx4Nlvb9qUvVRxoywIGvJrO0pwKPi0UAMGPSW/tGDcTZqviSTxmtWKlFeL1P8ocKk0t1raSju4lu2lAyLseBtUJzXoIl2DbtJd0hTZU3pJb+kTBJKaffv8+dlLzfL0HwMN5CfSlwj1wXEXTLtq2sxpckHV1bN+MWGGxLcnZG/7BYOGTr8pHWvTWW1+tsYCksyRVYdTtW73KXmSbzopbMMf2Y2KtS3RzhbXXYIgNUduGuQzQcKkUtX/hUnBhDB5MG3f8Jm8wlvEHZEgPzVX5vzEZ/ILfy0CUwCTOdtnCjTaCAkKYUru95lCGDlWgiYw933uM01gtILCVI3c0tlnimDUpwjmjFE+U6y1jYl9dl3iM00Tn3yYh2b7TLNc1TXi7vSZEny06mKYq9f7TKkyLSRoCnPDbp9prgxVN2NedgQ+00KZThKUpGrl7rY+01IrOChBKT47u/hMK3xcewma43PpiT7TWkdaKUWFxUEQLxHJLhFJsdSO178Bwa2BC4LbWCmBVAcyN5CaQGoDmRdIXSDzA1ahPBzkPcI2WxnI44GunDyRJ4KgalDZ4KqyIUOHTxhaVjV88pBJA8smlA2/6qTJg6smDx501ZBhk6rKBk2cVCWpk4cNPWXISSJPBvJWwI79uvjVUzVKwJ4tLTg7feOEqTPTrOCZ10yY+vP0r6bNSk+eNiM9cdrU66+dVDXj2qlXp8/4RZVu/fQZN81EMW3G9WaB5Yz09TOnzZiSnlGlcsLMa6dNTU+tqpp0/YAfbds6kcuqWf7xtl0o09vYzp0v0XI2r50L/33r6r6V/2Hfqqd/5em//9u+/f8ac352oLr3q+Xw8am6cOvp8YqobzJHZA9b/RL+ghYp42NKDwAWC8soP3WbTGcQR5lAl94RCVqm5kjfzj6jB0DkdFFWS5dKn8mD0WitYFru95l8ZVjiRWzm1qN8pkArYGPqobFoqs8UJhWoz+hFPtMk8dFD44YNPpM9AHQzV6M6yhTnotXIBCb9KNM0idYapr6/zzTTaFRdCtP2fJ/RAyAeaY20usFn9ABw+LSBWXKvz+gB4Fj9Wltpo8+0SGprC/PFFp9pqbXt1ZHWyD/u9xk9AHSkHCeyqqnPtIYJqSCfQ2NGV59pk+RpB/Nxb59pq3kmap5at3aQz7QjmubhoHEdzvCZ9upTaXnk/rE+0yHJ0x6mhHV5lDlGo5VYHnn/Op/pqAx5WsGUz/aZTjCukwQdqOCHRT7TGUaKJDgGpvYhn+miFXBwdiTaphU+0xWfKK1Hd6181+Az3WD06NaR5m3zme7JSMkj8//oM+kkD1W7zZ/4TA+iadVN8Vn0jc/0hAl5EOSn5kXvoDrK9NJo9K1Tal7YrNhnjsWHk4hHxLxoXWuf6a0+VFCcmifvtfeZPvjoeDrjs6u7z/wEJorMJ3xlgM/0hVGfVkTbOMxnjoPR8RTh0/dUn+mn3WH/MB557kyf6a+1xeNxX53jM8cTTceTh8/vx/nMCRoNH/JI0RU+M0AZ8lB1tPQqnzmRaFp1c/Lc+3OfGag+lTpz88Irf+kzg7Q2+laIj5vlM4OJpitRow2+1WdOSqJ1INqf5/rMEPVhJdKDcP1CnzlZ8zCedlR9YLHPDNVoE62CaOdSnxmm0eIKot886DPD1YcKyOPGPOozZUmetvStdqXPnKI+ey1P+Mu1PjMiydMMpleDz5TDhJ2sAjf3dZ+p0GiVVkF41ts+k0kqoDvR7B/tn5FE0+4wp9GonT4TajTmlNpk+Yc+c6r6UBsVSOVnPjNKfahA13WX/T5zGj66rrW2gu995vSktuapuvEP/OgJeEYSrThV567L85kziaarqgM++5r4zFkw8Xjqxo8p8Zm/02g2njoJWvjM2epj46mTXW185hz1oYLSVN2eRT/awefio08Z8riBnX1mtPqQ5xgqONzVZ87Tkdq6rnPFaZ8ZQzStoBXMn471mZ/CuE7at7r0Xcf5zFiNRt/w2fNkf585P/HRvv1soM9cAKN9gxn/8RCfuTBhOvJ6MrHMZ8bB6KlMr92JGZ+5CEZ73QVm8SifuVh7UCpFxf/bi25e292du64eefBQj+EvDXn9xOE/HB529tfX5UtBfSGsDEj9tXfgR+1b4SO8A/P+uilISWHXcySQ8JkMb368EEfzPJDuNDIlsqKCF88s6KbgqYzsGQpQrxzQT00esaJ38FStAtcTEG4ykCfh3dj1HCnuOhStUbh+KPJQpDMSbc7kiVQC9nM9wLUfRbjFgLjPMxKqhcM8WokC6aYkCvm2QsLPiDW5Ik+iNwHpFyRcYpKgpxsgE3IBFjK3glXIjcrbMwwJEN5HMAXjhcgdGFonrXAKqU5GsckbFUACkaWU9AZObrYBcRcT8nlVDKDoldx0h1iSIb6CGhgFbiDXWbBfaynTATVkX2IS36cNSLgR+TGKcCfm3fBHyrXEMHAPl1qsRiG4aP6kIKlPUV1EW8K5sAqkFOYLLKoJKFsBtEN7jERxuQHmCHlBRSoGYxupewFzngVhE4bvOhFJgY3kAPHdJQy2mByEQ5JwiwEREjJ1KLSCt7hBuroMPQRQm7DwGIubj42C8FlsXuParoo1KPZxLeLah8KNNhAXtzFDKQDXDEZGo6mukAhTJAp8AeIIJvtQaHTpjz+SdPxIEoj7BzKtJE60HkKHFH2VgHAplBbq/g0/3Q7SkAW3EOEcKJGsZlk5UsG5iZdsK4/jSEEmBkkuss63uXkK/V1YuiEe4IPLcjqeA7rg3ENQQ+mr7DEgjvUpfVGkWwE6jTTpfqARBj5g5TYZKeErKNz3uKwgN0p3P3nSHXGJRiRA80Q/YGIgLorytBj3PNayzAAzyFIDWBzZjEJojPuIG5WaWkG6JVtzN7IjxekuTLPXo4cJq6eARs0BDbZTWyFDmTddAArcaiL+npWmC0DepwEHMe1FoICI7nIKYF25xSZJwVoHSPQ5kb/ExRUyKC0V6eZlSAVgocWMK8P8ezL8mRXBwmTvkXIH8o1yLJ4BsAnktybJP9SAyCfUoTtTK5QWKJGulugKqF3oWFMqsDwA3f3CGOWAOl0JqMZRw+raDNmsANsQchBF9CFgIKUhiRYrwmeI8yYK7YRbx82XXAwcieJKA9bJcIcqmhLjWRRI6ohPAMlPBq/AlcB+gdUcUmZPAPknk/hfYoDfx5A3cwJIZ4CuCt34fBIQ6vT1hMqCyE6ASgDz4B4wyQiID5CIhKGeAFqBMByVoW0RBRTKXthJYTZsQPQcNzqBOijtlG54YVEiyXOOgTjxS5m4AtcRRs7DbD7TgimSYOsMxKeozoNGd/3xUzk/I7t5BIo7DbavDgUQ6kYNf+cB1lVM5YAUkszAJrpxPnIFsXU65HYUt5pEMc+AuLuRS2inAZ4/ElYDaLRMMknlfQywQJEflKPYQqA5XCoLyavACpBFI44CK1KpHMgNBCB/1AUQajc0iRtuQORfMbuJAuUUitOMKm/VkAAmJmFWwdyD6TZVsA31YJRe9EGY3NxsLzTJmF42YOeBrYfoO8y3cIMMFxJdgcwESDMDRC0FHMtUlCE/pSI3GcC2iLRTtk+eNCDhi8iVqtgGeIeqduPWlGDhX1A0KPMegOEl4xUmdiE2ulNkogGRCq6dquhAXa9y05yrnihuiwfcw5i4tzF5nZsNMLtUsYIbgiRR5Q59zZGQRum6VaAnkbxLbbbYe+NPP6I5JqlvnQHtpz4yqXxHJp43R2NyQMaWk0vBcw0S7sb2mEacG1Fc1KhHg0rCX2ZApEeGn8dVsYPEvRp5/CO/aqDLhwCuAWYYQYob9bRSSbDlBkR0aBvVgkHLDQ2xPDACXwWXVmC6BkAzQ0aBpDKGBYjHWYOFDtzOQ6SjOnpSynDsxAHICeQajNRDTi4FsB+jhSaJtt5AnK9tJk7M85rV8xxB9nHdwaXbXgcMEDmJSw8GjR49yw2SdLJc97KdpxcTWZ4CUKebZRJFdwPxQZ5WC837NFcdV0WG3IB4GtJEzAI3klwK1N7aoIWHmhiFTrlrg7MC85FDHuAD2JQFcXFyorA2+4FNeR/pc8BOVKVygM/LttLeshvqfh3gysW9gpyktTwM0JFNMYlFVwPxPinBQioBD3KpbM94FOjrt3yJXKCKYdwso6F3m2Q8L3sgXI+JAredG13HH6niEW72o2TWkXRpggGKx+JjVXRD8S4WSMpljNXkewVGQfQepi+g+FwV3wC+R3E8LvlsF3cFQdgu4QKTWLBaAeIIKN+pywEUe7k5iNyg0QHyvY5XwVgCfouUcjppQDB5y4AwATeDFqrxXQbE/TPyeVU8D+CMtAF3IK4CjmzCPGAAkzYGTHIkxgr5iu4ORDZqkPMAGvXmWNbo6tSOyaeYh/dS8r9wc6dJzE8zYM8yiTSVAqtYn7hZEC+sNMkVuB6Ar9T7p3jTmnCxSaaGQgFxwiJMDXyaiZfeCLBFfDYbWoG9ZSqVA3yclh0SSf6jghOr18g48/hTEiBtoDREqK+jCqJGPDfrCG4BqMa2vwJ5vDzx+iQ7lL+HKsJYnmAoqgl3ZEGcVNZrBa5ronWM3e1jyPq0jTAJHzRJDw4ZkEjlmgyFAPjg86YP1uIcAsJt3LyA/BCFnhbhPq67uCz8rwzYK1G4RxUnA/6AgnmJ/soEJdUmpWMX2UNoPIAC/8Yqjk8apbKAauN5lysAN+PJEueLThaYJ0uaTwLU06gsiJZi7Mbh/rSCxoz2gwF+kwC3EOp+pQJmWeNEb+OuIEkqD1oFN3LTRO2eTzxlXwL067Y82kAnRmNT2Uhr2G2VjZjw3UEuU9AXzQVZ0ERBLUAfgbLXAMdjhkOQKK4PYGODuGHI0xswHQ3Q70gyMLtq9yTzm1QVvz3qScEHLSD6PAM4UH4UxA5QOZBup3MP2NOPsWu/9WudG8v7+igWw29NsoUfMiBuDcmsr6swPQEmXMZ3uwH4LjWJrzMg7pqMhPqVUMZi2gMLpGunvgArIGLx5UBcJFQO8AFQm34+1rdHdydaexNbbkAiZkJeVMVmwBEGtpUk/TTAEQOU/heYwwT5ArlMTT8ApCv06OfrVjkFrgTwhLLo+shyAw2IfIjbbFxkOObFKJHRXI0OcAuIrkDWwSyBsReBbTAHUXTLSGhfEccxJDZWSHQkBb1gQKJdWBxWF61wN5eWvJroNojVMDqqaBNmG1B8gMI9BvgSxZ0m8b3UgMggrj+g4DXUumLydoIpkDkJYwtLTT9jVLo5tYmOYCo/0ye7i7BqoeYA0V2rU342Cp1pPejkNuQUFFIO+DVXa1LZizqPeD0CeDfWKUUxF8UqFCpfTRSOk1/+HfkdCj2OtRlSYxKLtQbEbUUewSLch/le6lD5IgOKGgzQSAU7yP8Eph+hYBPHzSAYEgUjBIiMQP5JFd0A73Eho9cShTzNVYbycVVcyM0y0i3gug+Fnm3ud1yv4jJfFbuwmA27F+XPUES8ZbhTYZH2QmPgXnqwHVlIp6N1ABaUvvQiiTHaAD+VIMeWo2DZSEuupVz34CIZwJdcSGaNJVdClj5Ed83xOQAzCLleTccBmD+LrrsjqjcQf2l6AoXN5fsokEyuvKRnBbuDfaVb7D6CZYHtR6VyQD+cLAs5LPrrBAGigczY8gqpH6KKVwk8HMW3JlEcQxZV9OHQMIshNEddkHEMgOuNAguOBhS48EOuxUCiICjAssQWpDUXJDGSnxO0OTYngGgjMd5FYTPfm8i6jOaYxGKNAf1Jl1856acBO8q+84H2wW1PQLgVcI02cC1A54twSMJROcASco6joAJpiVJlLfEVUJtQJTMXzqUoBe54bAZz+V9B9AmEJM96A1aca0MUBbxjYwpjW+AOkyjwBcTB7OQpYYTPcoMknf2gKIfByzMMiY7ngNxfQeQimpkDOlp5jNJzwF68eG/IgdwPZTngthJQU+QAKeQxm5mu3NgK4puO02/gcjnlMQFSb5JV+r4B/ZmM8wiL6FtMj7BEKIifY3HhfU4tWAAqOQvGGOAVEzd9mCvgk5I9wzzg1hDNAPMXDsJnN4p6nnDWsM4m+WmyuQGpL8DiAxShFrCZ6xDXWsIr4EOeNz0Q6tFsAOfwTi6N5k4zYA9R91oGUwAfwG9oZxZYU5LuyF26D2UR9Cgm38Birse5VqviTcB2roBI21E4/AD2vSS2GAFYjEKlxVDwdnlskS5PXFZtiGOs2oCFBlWFZlELS6suKkdx/Sc=(/figma)-->I want to thank you for considering Element Exteriors for your storm restoration needs.\r\n</p>\r\n	2024-01-23	2024-01-24	f		Learn more about COVID-19	2024-01-23 18:31:24.314977+00	Christian@elementext.com	Christian Oiler 	720.668.6567 	CEO 
\.


--
-- Name: offers_offer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.offers_offer_id_seq', 1, false);


--
-- Data for Name: rating_ratingvote; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.rating_ratingvote (id, ip, rating, date) FROM stdin;
1	62.76.123.230	3	2019-03-06 10:30:51.07+00
2	23.237.16.27	5	2019-03-07 08:58:50.036+00
3	65.74.159.43	5	2019-03-11 05:26:21.247+00
4	198.52.38.5	5	2019-03-12 10:16:36.237+00
5	73.95.14.222	5	2019-03-15 15:25:57.33+00
6	71.237.66.191	5	2019-03-15 23:05:24.877+00
7	174.255.3.43	2	2019-03-16 00:10:25.517+00
8	62.76.123.230	5	2019-04-18 13:58:52.839+00
9	198.52.38.4	5	2019-04-22 12:00:13.047+00
10	62.76.123.230	5	2019-04-22 13:05:06.979+00
11	62.76.123.230	5	2019-04-23 08:36:12.501+00
12	198.52.38.4	5	2019-04-23 12:01:18.792+00
13	74.141.171.46	5	2019-04-23 19:11:09.808+00
14	174.209.24.235	5	2019-04-26 16:27:40.521093+00
15	73.95.14.222	5	2019-04-26 16:27:50.112552+00
16	73.243.249.3	5	2019-04-26 16:29:18.95434+00
17	104.6.39.88	5	2019-04-26 16:29:41.373745+00
18	68.80.145.232	5	2019-04-26 18:10:49.531455+00
19	104.143.209.100	5	2019-04-29 10:23:15.035603+00
20	37.120.138.40	5	2019-05-15 15:27:36.082715+00
21	77.111.247.74	5	2019-05-16 07:25:49.570739+00
22	116.202.16.229	5	2019-05-16 07:58:28.719305+00
23	176.113.72.110	5	2019-05-16 10:56:54.378403+00
24	185.165.168.229	5	2019-05-16 13:25:05.84505+00
25	73.95.14.222	5	2019-05-21 17:53:28.484179+00
26	104.236.213.230	5	2019-05-30 10:32:22.587166+00
27	104.143.209.100	5	2019-05-30 10:37:00.03885+00
28	66.206.12.98	5	2019-05-30 12:37:15.363715+00
29	54.36.162.10	5	2019-05-31 10:50:52.189509+00
30	104.143.209.100	5	2019-05-31 10:56:33.303676+00
31	104.143.209.101	5	2019-05-31 10:57:18.46185+00
32	104.143.209.101	5	2019-06-06 19:35:49.029837+00
33	104.143.209.99	5	2019-07-02 09:10:44.158509+00
34	73.34.24.202	5	2019-07-18 04:14:05.620044+00
35	104.236.205.233	5	2019-08-05 05:15:17.232494+00
36	23.227.142.218	5	2019-08-19 10:00:17.256728+00
37	104.236.74.212	5	2019-09-06 05:21:17.290676+00
38	162.243.127.7	5	2019-09-06 05:28:29.027698+00
39	104.131.188.187	5	2019-09-10 12:22:19.587532+00
40	23.227.142.218	5	2019-09-10 12:23:08.970455+00
41	104.236.195.72	5	2019-09-10 12:23:30.83804+00
42	185.232.20.202	5	2019-10-02 11:59:31.028778+00
43	92.38.148.53	5	2019-10-02 14:14:08.85173+00
44	67.166.14.238	5	2019-10-08 05:38:29.670216+00
45	104.236.70.228	5	2019-10-10 13:41:39.517402+00
46	107.170.127.117	5	2019-10-12 15:21:40.487498+00
47	104.131.176.234	5	2019-11-14 05:56:14.953638+00
48	107.173.59.132	5	2019-11-25 16:09:53.574032+00
49	73.217.85.95	5	2019-12-10 17:06:34.674307+00
50	23.227.142.218	5	2019-12-18 06:15:45.631026+00
51	31.13.189.123	5	2019-12-18 10:19:50.102077+00
52	96.9.247.204	5	2019-12-19 07:06:13.105319+00
53	107.170.166.118	5	2019-12-30 19:00:10.70918+00
54	174.209.4.41	5	2020-05-02 21:20:27.426961+00
55	73.34.22.161	5	2020-05-03 01:37:56.853111+00
56	73.34.24.202	5	2020-05-23 21:01:54.11722+00
57	37.120.138.174	5	2020-07-22 11:17:00.665059+00
58	174.51.114.236	5	2021-02-23 01:28:59.216415+00
59	65.119.35.98	5	2021-06-01 20:55:13.926237+00
60	74.139.98.205	5	2022-03-07 18:22:38.443481+00
61	71.218.46.134	1	2022-06-22 22:29:57.598006+00
62	50.89.139.228	5	2022-06-28 20:37:28.638823+00
\.


--
-- Name: rating_ratingvote_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.rating_ratingvote_id_seq', 62, true);


--
-- Data for Name: seo_counter; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.seo_counter (id, label, "position", content, sort_order) FROM stdin;
1	Universal Analytics head	head	<!-- Google Tag Manager -->\n<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':\nnew Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],\nj=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=\n'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);\n})(window,document,'script','dataLayer','GTM-P5ZCGKR');</script>\n<!-- End Google Tag Manager -->	0
2	Universal Analytics body	body_top	<!-- Google Tag Manager (noscript) -->\n<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-P5ZCGKR"\nheight="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>\n<!-- End Google Tag Manager (noscript) -->	1
3	HTML Tag	head	<meta name="google-site-verification" content="caLSBoXpGO29Y4o_E80yMpgxldtJmMKe8hoqJ-ZI_NI" />	2
\.


--
-- Name: seo_counter_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.seo_counter_id_seq', 3, true);


--
-- Data for Name: seo_redirect; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.seo_redirect (id, old_path, new_path, permanent, note, created, last_usage) FROM stdin;
\.


--
-- Name: seo_redirect_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.seo_redirect_id_seq', 1, true);


--
-- Data for Name: seo_seoconfig; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.seo_seoconfig (id, title, keywords, description) FROM stdin;
1			
\.


--
-- Name: seo_seoconfig_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.seo_seoconfig_id_seq', 1, true);


--
-- Data for Name: seo_seodata; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.seo_seodata (id, object_id, title, keywords, description, canonical, noindex, og_title, og_image, og_description, content_type_id) FROM stdin;
14	27	Superior Roof Replacement Service in Denver, CO	roof replacement, roof replacement service, roof replacement contractors, roof replacement company, roof replacement near me, element exteriors, englewood, denver	When you need an expert roof replacement service provider in Denver, CO, hire the professional team at Element Exteriors. We have the local expertise you need		f				33
6	2	Choose Element Exteriors for commercial roofing in Denver	Commercial Roofing, Сommercial Roofing Contractor, Commercial Roofing Systems, Commercial Roofers, Denver, Centennial, Thornton, Parker,  Castlerock, Colorado	Element Exteriors specializes in commercial roofing. We are a local contractor that deals with major roofing systems. Call 303-747-3706 and get a free estimate		f				33
1	1	Call Element Exteriors for Your Home Improvements in Denver	Element Exteriors, Home Improvements Company, Roofing Company, Englewood, Denver, Centennial, Thornton, Parker,  Castlerock, Colorado	Our roofing company, Element Exteriors, provides residential and commercial roof repair and re-roofing in Denver. We also work with gutter, siding, and windows.		f				25
7	4	Top-Notch New Roof Construction in Denver	Element Exteriors, New Roof Construction, Roof installation, Roofing Construction Company, Roof Construction Services, Denver, Centennial, Thornton, Parker, Castlerock, Colorado	If you need new roof construction, Element Exteriors should be your first choice. Our highly trained professionals work on residential projects in Denver		f				33
5	6	Denver Professional Painting Contractor | Element Exteriors	Residential Painting Contractors, Commercial Painting Contractors, Painting Services, Painters, Englewood, Denver, Centennial, Thornton, Parker,  Castlerock, Colorado	Element Exteriors is a professional commercial and residential painting contractor. Call 303-747-3706 today to get a free estimate		f				33
19	22	Top-Quality Metal Roofing Contractors in Denver, CO	metal roofing contractors, metal roofing company, metal roofing installation, metal roofing repair, metal roofing contractors near me, element exteriors, denver	If you’ve been searching for experienced metal roofing contractors, look no further than Element Exteriors, LLC. We’ve been serving the community for more than 25 years and are experts in the installation and repair of residential roofs in Denver, CO, and surrounding areas		f				33
12	1	Denver Licensed Contractor	Element Exteriors, licensed contractor	We work for homeowners of Colorado		f				22
13	1	We help with insurance claims | Element Exteriors	Element Exteriors, insurance claims	Element Exteriors can help you with the insurance claim and the whole insurance process		f				19
9	26	Denver Professional Roofing Contractors | Element Exteriors	Roofing Contractors, Professional Roofing Contractors, Licensed Roofing Contractors, Roofing Contractors In My Area, Denver, Centennial, Thornton, Parker,  Castlerock, Colorado\n	Element Exteriors is a local roofing contractor. We use the best materials for residential jobs. We offer a 10-year workmanship and materials warranty		f				33
8	16	Get Emergency Roof Repair from Professionals in Denver, CO	Element Exteriors, Emergency Roof Repair, Emergency Roofing Service, 24-hour emergency roof repair, Denver, Centennial, Thornton, Parker, Castlerock, Colorado	Element Exteriors offers 24-hour emergency roof repair. If your roof has been damaged by bad weather you need to get help quickly, call us 303-747-3706		f				33
10	1	Element Exteriors - Denver Roofing Company	Element Exteriors, Roofing company, Denver, Englewood, Centennial, Thornton, Parker,  Castlerock, Colorado	We are professionals who have helped many homeowners of Colorado to get a roof over their heads. On this page, you can learn about Element Exteriors more		f				8
11	1	Contact our Roofing company	Element Exteriors, Denver	Contact Element Exteriors to solve all roofing problems		f				11
2	1	Call Residential Roofing Contractor in Denver, CO	Residential Roofing Services, Residential Roofing, Roofing Contractor, Residential Roof Types, Residential Roofing Companies, Denver, Centennial, Thornton, Parker, Castlerock, Colorado	Element Exteriors specializes in residential roofing. We are a local contractor that deals with all major roof types. Call 303-747-3706 to get a free estimate		f				33
3	7	Experienced Gutter Contractors in Denver | Element Exteriors	gutter contractor, seamless gutter services, Gutter Installation, Gutter Replacement, Gutter Cleaning, Gutter Services Near Me, Englewood, Denver, Centennial, Thornton, Parker, Castlerock, Colorado	Element Exteriors is a local gutter contractor offering residential and commercial gutter services. Call us 303-747-3706 today to get free estimate		f				33
15	28	Reliable & Honest Roof Repair Services in Denver, CO	roof repair, roof leak repair, hail damage roof repair, storm damage roof repair, roof repair near me, element exteriors, englewood, denver	Element Exteriors is a trusted roof repair company in Denver, CO. We’re skilled contractors with a professional team and lots of local experience		f				33
16	29	High-Quality Roof Maintenance Services in Denver, CO	roof maintenance, roof maintenance company, roof maintenance services, element exteriors, englewood, denver	When you need roof maintenance in and around Denver, CO, contact Element Exteriors. We are professional roofers with several years of local experience		f				33
17	20	Expert Asphalt Roof Installation and Repair in Denver	asphalt roofing, asphalt roof shingles, asphalt roofing installation, asphalt roof repair, element exteriors, englewood, denver	Element Exteriors offers asphalt roof installation, repair, and replacement in Denver, CO. We are roofing experts and we hire only licensed professionals		f				33
18	21	Let Element Exteriors Install Your Roof Tiles in Denver, CO	roof tiles, types of roof tiles, concrete roof tiles, tile roof installation, element exteriors, englewood, denver	Element Exteriors has been expertly installing roof tiles for Denver, CO homeowners for many years. We are professional roofers with lots of local knowledge		f				33
4	1	Roofing Services in Denver, CO | Element Exteriors	Element Exteriors, Home Improvements Services, Roofing Services, Englewood, Denver, Centennial, Thornton, Parker,  Castlerock, Colorado	Element Exteriors specializes in roofing services. If you need residential or commercial roofing services, call 303-747-3706 and request a free estimate.		f				32
20	31	Top-Notch Exterior Painting Company in Denver, CO	exterior painting, exterior painting services, exterior house painters, exterior painting cost, exterior painters near me	Element Exteriors offers world-class exterior painting services in Denver, CO. We use weather-resistant materials and perform paint restoration		f				33
21	32	Hire a Professional Interior Painting Company in Denver, CO	interior painting, interior painting services, interior house painters, interior painting cost, interior painters near me	We offer professional interior painting services in Denver, CO and other cities in Colorado. Contact us today to schedule an inspection and get a free estimate		f				33
22	25	Quality EPDM Roofing Installation in Denver, CO	epdm roofing, epdm roofing installation, epdm roofing costs, epdm roofing installers near me, element exteriors, denver	If you are looking for EPDM roofing installation in Denver, CO, it is best to hire professional contractors. We are your local roofing company for the job		f				33
23	23	Benefits of Using TPO Roofing in Denver, CO	tpo roofing, tpo roofing installation, tpo roofing cost, tpo roofing installers near me, element exteriors, denver	TPO roofing is one of the most affordable commercial roofing solutions. Element Exteriors installs TPO on commercial roofs throughout Denver, CO		f				33
24	1	Element Exteriors | Our Projects		Look at the projects that our professional roofing contractors have completed		f				39
25	33	Professional Roof Installation Services in Denver, CO, Area	roof installation, residential roof installation, commercial roof installation, new roof installation, roof installation cost	Discover the benefits of the new roof installation services provided by Element Exteriors to home and business owners in Denver, CO, and surrounding areas		f				33
26	34	The Best Local Roofers for Special Projects in Denver, CO	roofers, local roofers, roofers near me, specialty roof types	Few local roofers can match the experience and reputation of Element Exteriors when it comes to specialty roofing projects in Denver, CO and nearby areas		f				33
27	35	Professional Roof Inspection Services in Denver, CO	roof inspection, roof inspection service, roof inspection near me	Find out more about the professional roof inspection services provided by the licensed and experienced contractors at Element Exteriors to Denver, CO, homeowners		f				33
28	37	Professional Cedar Shake Roof Services in Denver, CO	cedar shake roof, cedar shake roof installation, cedar shake roof repair	Find out more about cedar shake roof installation and repair services and the licensed contractors providing them in Denver, CO, and the surrounding area		f				33
29	36	The Best Slate Roofing Installation Services in Denver, CO	slate roofing, slate roof tiles, slate roof specialists	Find out more about slate roofing and Denver, CO, licensed contractors providing professional insurance-approved installation and repair services		f				33
30	24	Professional PVC Roofing Services in Denver, CO, Area	pvc roofing, pvc roofing installation, pvc roofing contractors	Learn more about PVC roofing and the contractors installing it with best results in Denver, Centennial, Englewood, Thornton, Castle Rock, and Parker, CO, area		f				33
31	38	Modified Bitumen Roof Installation Services in Denver, CO	modified bitumen roof, modified bitumen roof installation, modified bitumen roof contractors	Discover the benefits of a modified bitumen roof and the best installation services in Denver, Englewood, Centennial, Thornton, Parker, and Castle Rock, CO		f				33
\.


--
-- Name: seo_seodata_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.seo_seodata_id_seq', 31, true);


--
-- Data for Name: services_service; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.services_service (id, title, slug, description, text, sort_order, updated, background, header, icon, level, lft, parent_id, rght, tree_id, visible) FROM stdin;
16	Emergency roof repair	emergency-roof-repair	Do you need emergency roof repair in Denver, CO? Contact Element Exteriors today so our highly experienced contractors can help you. We are available 24/7 to help you avoid further damage to your home. We work on both residential and commercial buildings.	<p>\r\n  You rely on your roof to protect your home so if something goes wrong, you&rsquo;ll need emergency roof repair. A tree may fall on the roof or high winds may destroy it, leaving you, your family and your possession exposed to the elements. Once your roof is compromised, water can get inside. Urgent <a href="/services/">roofing services</a> is one of our specialties at Element Exteriors.\r\n</p>\r\n\r\n<p>\r\n  Severe weather is usually the culprit but a fire can trigger the need for emergency roof repair. Rodents may also chew through the wood. A quick patch and a tarp may help at first but you&rsquo;ll need to call the top professionals. Whether you have a flat or sloped roof, we can help.\r\n</p>\r\n\r\n<p class="page-images single-image">\r\n  <img alt="Emergency roof repair" data-crop="" data-description="R2V0JTIwcHJvZmVzc2lvbmFsJTIwaGVscCUyMHdpdGglMjB5b3VyJTIwZW1lcmdlbmN5JTIwc2l0dWF0aW9u" data-id="7" data-source="/media/page_photos/0000/photo_7.jpg?_=1562150597" height="576" sizes="100vw" src="/media/page_photos/0000/photo_7.normal.jpg" srcset="/media/page_photos/0000/photo_7.wide.jpg?_=1562150597 1024w, /media/page_photos/0000/photo_7.normal.jpg?_=1562150597 800w, /media/page_photos/0000/photo_7.mobile.jpg?_=1562150597 480w" title="professional roofers working with crane" width="1024" />\r\n</p>\r\n\r\n<h2>Signs You Need Emergency Roofing Service from a Contractor</h2>\r\n\r\n<p>\r\n  At Element Exteriors, we are available 24/7 and you can call us whenever you need our emergency roofing service. A small leak during a storm, suddenly sagging ceilings or a piece of your roof missing are all signs that you need to take action and seek out our <a href="/denver-residential-roofing/">residential roofing services</a>.\r\n</p>\r\n\r\n<p>\r\n  &nbsp;If you put off a site visit, you could find yourself facing a much more serious problem later. Repairs or roof replacement will cost a lot more then, so it&rsquo;s best to schedule residential emergency roof repair as soon as possible.\r\n</p>\r\n\r\n<blockquote><p>\r\n  Take advantage of our 24-hour emergency roof repair whenever you have problems with your roof, drain or flashing.\r\n</p>\r\n</blockquote>\r\n\r\n<p class="page-images single-image">\r\n  <img alt="Emergency roof repair service" data-crop="" data-id="8" data-source="/media/page_photos/0000/photo_8.jpg?_=1562150618" height="576" sizes="100vw" src="/media/page_photos/0000/photo_8.normal.jpg" srcset="/media/page_photos/0000/photo_8.wide.jpg?_=1562150618 1024w, /media/page_photos/0000/photo_8.normal.jpg?_=1562150618 800w, /media/page_photos/0000/photo_8.mobile.jpg?_=1562150618 480w" title="Two men repairing a roof" width="1024" />\r\n</p>\r\n\r\n<h2>I Need Emergency Roof Repair Near Me in Denver, CO. What Do I Do?</h2>\r\n\r\n<p>\r\n  When you begin to think &ldquo;I need emergency roof repair near me&rdquo;, you don&#39;t have a lot of time to act. Element Exteriors is the preferred provider of commercial and residential roofing repairs and you&rsquo;ll be in good hands with us.&nbsp;\r\n</p>\r\n\r\n<p>\r\n  <strong>We are located in Englewood, CO and we serve Denver, CO; Centennial, CO; Thornton, CO; Parker, CO; and Castlerock, CO.</strong> Whatever the cause of the damage to your roof, we will repair it expertly and efficiently. Most jobs are completed within one day, and you don&rsquo;t even have to pay money upfront. We also have experience working with insurance companies. Contact us if you&rsquo;ve been frantically searching for <a href="https://elementext.com/">roofing companies</a> offering &ldquo;emergency roof repair near me&rdquo;.\r\n</p>\r\n	3	2019-10-28 05:21:10.569758+00	./background_16.jpg	We Provide Emergency Roof Repair in Denver, CO	commercial	1	6	26	7	1	t
33	Roof Installation	roof-installation	Element Exteriors has been providing roof installation services for years to home and business owners in Englewood, Denver, Centennial, Parker, Thornton, and Castle Rock, CO, and we have wide experience dealing with insurance companies	<p>\r\n  Are you planning a new roof installation and you are looking for <a href="https://elementext.com/denver-roofing-contractors/">roofing contractors</a> who will do a good job fast and without overcharging you? You have already found them. Our team of licensed roofers is famous among homeowners, business owners, and insurance companies in the Denver area.&nbsp;\r\n</p>\r\n\r\n<p>\r\n  Everyone knows that we work fast, deliver quality, keep the roof installation cost minimum, and provide extensive warranties. We can help you choose the best materials and build a solid and durable structure that will withstand even the harshest Colorado weather. Upon completing the roof installation, we will clean the place so well that you won&rsquo;t even know we worked there.&nbsp;\r\n</p>\r\n\r\n<p class="page-images single-image">\r\n  <img alt="" data-crop="" data-id="29" data-source="/media/page_photos/0000/photo_29.jpg?_=1575965267" height="576" sizes="100vw" src="/media/page_photos/0000/photo_29.normal.jpg" srcset="/media/page_photos/0000/photo_29.wide.jpg?_=1575965268 1024w, /media/page_photos/0000/photo_29.normal.jpg?_=1575965268 800w, /media/page_photos/0000/photo_29.mobile.jpg?_=1575965267 480w" width="1024" />\r\n</p>\r\n\r\n<h2>Trust Us with Your Residential Roof Installation Project</h2>\r\n\r\n<p>\r\n  Hundreds of homeowners in Englewood, Denver, Centennial, Parker, Thornton, and Castle Rock, CO, trusted us with their residential roof installation projects and never regretted it. Any of them can vouch for our professionalism and commitment to quality and client satisfaction.&nbsp;\r\n</p>\r\n\r\n<p>\r\n  Our experience covers everything from asphalt shingles to metal roof installation services. We have even handled residential flat roof installation projects with excellent results. Since we do not ask for upfront payments and we offer ten years warranty on both materials and labor, our residential roof installation service is literally risk-free.&nbsp;&nbsp;\r\n</p>\r\n\r\n<h2>We Also Offer Commercial Roof Installation</h2>\r\n\r\n<p>\r\n  You want what&rsquo;s best for your business and we know it. That is why we provide commercial roof installation services at excellent prices and backed by extensive warranties. We also adapt to our clients&rsquo; schedules and needs, keeping activity disruptions minimum and finishing the works fast and without issues.&nbsp;\r\n</p>\r\n\r\n<p>\r\n  When you work with Element Exteriors, you get professionalism, promptitude, and solutions for all your needs and desires. You get help protecting your assets, your business reputation, and your finances. Finally, you get the peace of mind that comes with reliable, long-lasting commercial roof installation.&nbsp;\r\n</p>\r\n\r\n<h2>New Roof Installation in Denver, CO, and the Surrounding Areas</h2>\r\n\r\n<p>\r\n  Are you still not sure how to approach your new roof installation project or whom to hire? Before you check out any other roofing companies, schedule a free inspection with <a href="https://elementext.com/">Element Exteriors</a>.&nbsp;\r\n</p>\r\n\r\n<p>\r\n  Someone can come to your home or office within 24 hours, review the details of your project, propose solutions, and give you a cost estimate. If you like what you hear, we shake hands and install your new roof. If not, you are free to keep looking.&nbsp;\r\n</p>\r\n\r\n<p>\r\n  We are pretty sure that, once you get a taste of how we work, you will not even consider hiring someone else for your new roof installation. But please, put our word to the test by calling 303-747-3706 or filling in the online form and scheduling your free inspection!\r\n</p>\r\n	19	2019-12-18 10:21:12.201208+00		Friendly and Reliable Roof Installation Services in Denver, CO	residential	1	10	26	11	1	t
35	Roof Inspection	roof-inspection	The roof inspection service provided by Element Exteriors is the best solution for homeowners in Englewood, Denver, Centennial, Thornton, Parker, and Castlerock, CO, wanting to file an insurance claim or assess their roof’s condition after a storm	<p>\r\n  When was the last time you requested a roof inspection from licensed <a href="https://elementext.com/denver-roofing-contractors/">roofing contractors</a>? A small fissure or a displaced shingle, left unattended, can escalate and cause huge damage when you least expect it. It is therefore in your best interest to have your roof checked regularly by a professional roof inspection company.&nbsp;&nbsp;\r\n</p>\r\n\r\n<p>\r\n  The National Roofing Contractors Association recommends homeowners to have a roof inspection every spring, every fall, and after any major storm or hail. If the damage is found, it can be repaired. If the roof is in good condition, the homeowner will gain peace of mind.&nbsp;\r\n</p>\r\n\r\n<p>\r\n  You too should schedule a roof inspection, as soon as possible, preferably with a licensed and experienced roof inspection company like Element Exteriors.&nbsp;\r\n</p>\r\n\r\n<p class="page-images single-image">\r\n  <img alt="" data-crop="" data-id="31" data-source="/media/page_photos/0000/photo_31.jpg?_=1577694454" height="576" sizes="100vw" src="/media/page_photos/0000/photo_31.normal.jpg" srcset="/media/page_photos/0000/photo_31.wide.jpg?_=1577694454 1024w, /media/page_photos/0000/photo_31.normal.jpg?_=1577694454 800w, /media/page_photos/0000/photo_31.mobile.jpg?_=1577694454 480w" width="1024" />\r\n</p>\r\n\r\n<h2>Why Choose Our Roof Inspection Service?</h2>\r\n\r\n<p>\r\n  We are a team of highly skilled, insurance-approved contractors with an excellent reputation among Colorado homeowners. With our roof inspection service, you can be sure your roof will be carefully checked not only from the top but also from the ground. If there is any sign of damage, we will find it and, if you allow us, repair it.&nbsp;\r\n</p>\r\n\r\n<blockquote><p>\r\n  Our roof inspection reports are clear, accurate, backed up by warranty, and accepted by all local insurance companies. Moreover, we always schedule our roof inspection service according to the client&rsquo;s schedule and preferences, to avoid disrupting their routine.&nbsp;\r\n</p>\r\n</blockquote>\r\n\r\n<h2>Your Search for &ldquo;Roof Inspection near Me&rdquo; in Denver, CO, Area Ends Here</h2>\r\n\r\n<p>\r\n  Are you tired of searching for &ldquo;roof inspection near me&rdquo; online and not sure what to choose? At Element Exteriors, you will find a licensed roof inspector ready to check every inch of your roof and report even the smallest damage.&nbsp;\r\n</p>\r\n\r\n<p>\r\n  Whether you live in Englewood, Denver, Centennial, Thornton, Parker, or Castlerock, CO, our specialist will come to your home at a time of your convenience, and perform a detailed roof inspection. Call us today at 303-747-3706 and make the appointment!\r\n</p>\r\n\r\n<p>\r\n  We promise that you will never again need to look for &ldquo;roof inspection near me&rdquo;, as you will already be working with the best licensed roof inspector from one of the best <a href="https://elementext.com/">roofing companies</a> in your area.\r\n</p>\r\n	21	2019-12-30 08:27:44.072137+00		Finding the Best Contractors for Your Roof Inspection in Denver, CO	residential	1	12	26	13	1	t
34	Specialty Roof Types	specialty-roof-types	At Element Exteriors, you will find a team of licensed professional roofers able to successfully complete even the most challenging roofing projects, familiar with the most unusual materials and able to work in the most difficult conditions	<p>\r\n  Are you looking for roofers able to install less common, specialty roof types? At Element Exteriors you will find a team of highly-trained, licensed roofers, with extensive experience in installing all types of <a href="https://elementext.com/denver-residential-roofing/">residential roofing</a> in Englewood, Denver, Centennial, Castle Rock, Thornton, and Parker, CO.&nbsp;\r\n</p>\r\n\r\n<p class="page-images single-image">\r\n  <img alt="" data-crop="" data-id="30" data-source="/media/page_photos/0000/photo_30.jpg?_=1575965307" height="576" sizes="100vw" src="/media/page_photos/0000/photo_30.normal.jpg" srcset="/media/page_photos/0000/photo_30.wide.jpg?_=1575965307 1024w, /media/page_photos/0000/photo_30.normal.jpg?_=1575965307 800w, /media/page_photos/0000/photo_30.mobile.jpg?_=1575965307 480w" width="1024" />\r\n</p>\r\n\r\n<h2>Why Hire Our Team of Local Roofers for Your Denver, CO, Project?</h2>\r\n\r\n<p>\r\n  Our team of local roofers has installed and repaired all types of structures &ndash; from flat, gable, and cross-gabled to gambrel, hip, cross-hipped, and lean-to roofs. They have also worked with most, if not all the materials available on the market: solar tiles, asphalt shingles, metal, stone-coated steel, slate, rubber slate, tiles, you name it.&nbsp;\r\n</p>\r\n\r\n<p>\r\n  No matter the type of roof you want installed or the materials you plan to use, when you hire our team of local roofers, you have the guarantee of a job well-done. We work fast and efficiently, causing no or minimum disruptions, leaving the site clean, and providing extended warranty for materials and labor.&nbsp;\r\n</p>\r\n\r\n<p>\r\n  Your specialty roofing project could not be in better hands. The best proof of that is the fact that we do not request for upfront payments. We also provide free inspections within 24 hours from being scheduled, and no-strings-attached cost estimates. Otherwise put, you have no reason not to check if we are the local roofers you are looking for.&nbsp;\r\n</p>\r\n\r\n<h2>Your Searches for &bdquo;Roofers Near Me&rdquo; in Denver, CO, End with Element Exteriors&nbsp;</h2>\r\n\r\n<p>\r\n  Most of our contracts begin with an online search for &ldquo;roofers near me&rdquo; or &ldquo;roofers in my area&rdquo;. Once home and business owners learn how we work, they do not even consider getting in touch with other roofing companies. They are all impressed with our reputation, professionalism, and commitment to client satisfaction.&nbsp;\r\n</p>\r\n\r\n<p>\r\n  You too can benefit from our skills and expertise. Call us at 303-747-3706 or use the online form to leave us a message! We&rsquo;ll set a date and time for the free inspection, and discuss how we can turn your specialty roofing project into reality! You will surely begin to understand why all searches for &ldquo;roofers near me&rdquo; in Denver area end with <a href="https://elementext.com/">Element Exteriors</a>!\r\n</p>\r\n	20	2019-12-18 10:21:47.133107+00		The Best Roofers for Specialty Roof Types in Denver, CO, Area	commercial	1	8	1	9	2	t
36	Slate Roofing	slate-roofing	Element Exteriors is a licensed, experienced, and reputed contractor providing slate roofing installation and repair services to homeowners in Denver, Englewood, Centennial, Parker, Thornton, and Castle Rock, CO	<p>\r\n  Are you thinking of installing a slate roof over your home? Slate roof tiles are among the best <a href="https://elementext.com/denver-residential-roofing/">residential roofing</a> materials. Here are the most important benefits a slate roof system brings about:&nbsp;\r\n</p>\r\n\r\n<ul>\r\n  <li>\r\n    Durability &ndash; Slate roof tiles can last up to a century\r\n  </li>\r\n  <li>\r\n    Low-maintenance &ndash; No need to worry about coating or expensive repair work\r\n  </li>\r\n  <li>\r\n    Able to withstand harsh weather &ndash; Not even hail and storms will damage your roof\r\n  </li>\r\n  <li>\r\n    Great looks &ndash; A slate roof will look good on both modern and classic buildings\r\n  </li>\r\n</ul>\r\n\r\n<p>\r\n  The list could continue but keep in mind that, in order to enjoy these benefits and more, you need to have your new roof installed by professionals like Element Exteriors.&nbsp;\r\n</p>\r\n\r\n<p class="page-images single-image">\r\n  <img alt="" data-crop="" data-id="32" data-source="/media/page_photos/0000/photo_32.jpg?_=1577694497" height="576" sizes="100vw" src="/media/page_photos/0000/photo_32.normal.jpg" srcset="/media/page_photos/0000/photo_32.wide.jpg?_=1577694498 1024w, /media/page_photos/0000/photo_32.normal.jpg?_=1577694498 800w, /media/page_photos/0000/photo_32.mobile.jpg?_=1577694498 480w" width="1024" />\r\n</p>\r\n\r\n<h2>Why Choose Our Slate Roof Installation Services?</h2>\r\n\r\n<p>\r\n  Element Exteriors has completed hundreds of slate roof installation projects in Colorado, not only in Englewood and Denver, but also in Parker, Centennial, Thornton, and Castle Rock. We can help you choose the best materials for your slate roof installation project, estimate costs, and complete the work fast and without interfering with your routine.&nbsp;\r\n</p>\r\n\r\n<blockquote><p>\r\n  Since we offer a 10 years warranty on materials and workmanship, you will not have to worry about slate roof repair works. Even if some small slate roof repair becomes necessary during the warranty period, we will perform it free of charge. With our slate roof installation services, your peace of mind is guaranteed.&nbsp;\r\n</p>\r\n</blockquote>\r\n\r\n<h2>Get a Cost Estimate from the Best Slate Roofing Contractors in Denver, CO, Area</h2>\r\n\r\n<p>\r\n  Element Exteriors is one of the most experienced and best-reputed slate roofing contractors in Colorado. Whether you live in Denver, Englewood, Centennial, Parker, Thornton, or Castle Rock, CO, you too can benefit from a free inspection and cost estimate.&nbsp;\r\n</p>\r\n\r\n<p>\r\n  All you have to do is call us at 303-747-3706 and let us know when would be the best time for our slate roof specialists to come to your home for the inspection. They will get there on time, perform the inspection, and assess the costs.&nbsp;\r\n</p>\r\n\r\n<p>\r\n  The experience will also help you assess what choosing us as your slate roofing contractors means. You will be working not only with the best slate roof specialists in the area, but with professionals committed to provide quality services and ensure your satisfaction. We promise that, once you get a glimpse of how we work, you will not want to contact other r<a href="https://elementext.com/">oofing companies</a>.\r\n</p>\r\n	22	2019-12-30 08:28:24.042036+00		Why Install a Slate Roof on Your Denver, CO, Home? 	commercial	1	10	1	11	2	t
37	Cedar Shake Roof	cedar-shake-roof	Element Exteriors has been providing professional cedar shake roof installation and repair services to homeowners all throughout Englewood, Denver, Centennial, Parker, Castle Rock, and Thornton, CO, for years	<p>\r\n  Are you considering a cedar shake roof for your home? Many homeowners in Colorado opt for this <a href="https://elementext.com/denver-residential-roofing/">residential roofing</a> material, and for all the right reasons. Few materials can match the beautiful, natural look of a cedar shake roof, and there are many other benefits at stake:&nbsp;\r\n</p>\r\n\r\n<ul>\r\n  <li>\r\n    Low weight compared to other roofing materials\r\n  </li>\r\n  <li>\r\n    Energy efficient\r\n  </li>\r\n  <li>\r\n    Low maintenance requirements\r\n  </li>\r\n  <li>\r\n    25+ year lifespan, etc.\r\n  </li>\r\n</ul>\r\n\r\n<p>\r\n  Of course, your ability to enjoy these benefits will depend on the experience and professionalism of the contractor installing your cedar shake roof. For best results, you should work with a licensed, experienced, and reputed contractor like Element Exteriors.&nbsp;\r\n</p>\r\n\r\n<p class="page-images single-image">\r\n  <img alt="" data-crop="" data-id="33" data-source="/media/page_photos/0000/photo_33.jpg?_=1577694525" height="576" sizes="100vw" src="/media/page_photos/0000/photo_33.normal.jpg" srcset="/media/page_photos/0000/photo_33.wide.jpg?_=1577694525 1024w, /media/page_photos/0000/photo_33.normal.jpg?_=1577694525 800w, /media/page_photos/0000/photo_33.mobile.jpg?_=1577694525 480w" width="1024" />\r\n</p>\r\n\r\n<h2>Why Trust Us with Your Cedar Shake Roof Installation Project?</h2>\r\n\r\n<p>\r\n  Our company has successfully completed many cedar shake roof installation projects. We have also honored quite a few cedar shake roof repair requests. We know all about this roofing material, from where to supply it to how to install it and maintain it in order to ensure the longest lifespan.&nbsp;\r\n</p>\r\n\r\n<p>\r\n  We also offer extended warranties, usually of ten years on both materials and labor. This means that we will handle any cedar shake roof installation issue or cedar shake roof repair needed during the warranty period free of charge.\r\n</p>\r\n\r\n<p>\r\n  But you do not have to take our word for granted and hire us just based on our claims. Hundreds of Colorado homeowners and most insurance companies can testify to our professionalism.&nbsp;\r\n</p>\r\n\r\n<blockquote><p>\r\n  Moreover, we provide free inspections and cost estimates, so you can assess how we work and how much we charge for cedar shake roof installation without obligations. If you like what you see and hear you can hire us. If not, you will at least have comparison terms when reviewing other roofing companies.&nbsp;\r\n</p>\r\n</blockquote>\r\n\r\n<h2>Schedule an Inspection with the Best Cedar Shake Roof Contractors in Denver, CO, Area</h2>\r\n\r\n<p>\r\n  Whether you live in Englewood, Denver, Centennial, Parker, Castle Rock, or Thornton, CO, if you want the best cedar shake roof contractors for your project, look no further than Element Exteriors. Call us today at 303-747-3706, and our cedar shake roof specialists will come to your home to assess your needs and prepare a free estimate.\r\n</p>\r\n\r\n<p>\r\n  You will have a chance to ask questions, receive advice, and see for yourself why Colorado homeowners refer to us as one of the most reliable <a href="https://elementext.com/">roofing companies</a> in the area and why they like working with our cedar shake roof specialists. We promise you will not even consider consulting other cedar shake roofing contractors after that.\r\n</p>\r\n	23	2019-12-30 08:28:49.834526+00		Why Choose a Cedar Shake Roof for Your Denver, CO, Home?	commercial	1	12	1	13	2	t
25	EPDM Roofing	epdm-roofing	EPDM rubber is one of the most popular roofing materials because it offers numerous benefits. Our EPDM roofing installation and repair services in Denver, CO and neighboring areas are unbeatable, so contact us today	<p>\r\n  If you are asking yourself &ldquo;what is EPDM roofing?&rdquo;, here&rsquo;s a quick answer. EPDM, also called rubber roofing, is a synthetic material that is incredibly durable and inexpensive roofing material. It is widely used in <a href="https://elementext.com/denver-commercial-roofing/">commercial roofing</a>. When installed correctly, EPDM roofing can last up to 20 years.\r\n</p>\r\n\r\n<p>\r\n  Compared to other conventional roofing options, EPDM has many advantages. It is:\r\n</p>\r\n\r\n<ul>\r\n  <li>\r\n    Cost-effective. EPDM costs as little as $0.80 per square foot, so it is one of the most affordable roofing materials.\r\n  </li>\r\n  <li>\r\n    Ease of installation. EPDM weighs very little, which means that you don&rsquo;t have to spend time reinforcing the roof.&nbsp;\r\n  </li>\r\n  <li>\r\n    Durable. Built using rolls of resilient rubber sheeting, EPDM roofing is strong and long-lasting.\r\n  </li>\r\n  <li>\r\n    UV-resistant. EPDM can withstand the sun&rsquo;s ultraviolet rays.\r\n  </li>\r\n</ul>\r\n\r\n<p class="page-images single-image">\r\n  <img alt="" data-crop="" data-id="25" data-source="/media/page_photos/0000/photo_25.jpg?_=1574681708" height="576" sizes="100vw" src="/media/page_photos/0000/photo_25.normal.jpg" srcset="/media/page_photos/0000/photo_25.wide.jpg?_=1574681708 1024w, /media/page_photos/0000/photo_25.normal.jpg?_=1574681708 800w, /media/page_photos/0000/photo_25.mobile.jpg?_=1574681708 480w" width="1024" />\r\n</p>\r\n\r\n<h2>Costs and Factors Involved in EPDM Roofing Installation</h2>\r\n\r\n<p>\r\n  EPDM roofing installation is not an easy process, so it&rsquo;s best to hire a qualified professional to do the job. The professional will assess the condition of your existing roof and roof structure, the size of the roof, the choice between fasteners and adhesives and other aspects of installation and provide you with a preliminary quote. Our specialists are experts in EPDM roofing installation, repairs, and maintenance.\r\n</p>\r\n\r\n<p>\r\n  At the end of the day, EPDM roofing costs vary from one building to another. They depend on the type of roof that was previously installed, work required to dismantle the current roofing, the type of roof structure, and the insulation layers.\r\n</p>\r\n\r\n<h2>How Can I Find EPDM Roofing Installers Near Me?</h2>\r\n\r\n<p>\r\n  If you live in Denver, CO and are looking for &ldquo;reliable EPDM roofing installers near me,&rdquo; look no further. We are one of the leading <a href="https://elementext.com/">roofing companies</a> in Colorado. We also serve Centennial, CO; Thornton, CO; Castlerock, CO; and Parker, CO. Call us today at 303-747-3706 and get a free estimate on your EPDM roofing.\r\n</p>\r\n	10	2019-11-25 11:35:11.783017+00		Why Choose EPDM Roofing in Denver, CO	construction	1	2	2	3	3	t
38	Modified Bitumen Roof	modified-bitumen-roof	Element Exteriors has been providing modified bitumen roof installation services to home and business owners in Denver area for a long time, showing professionalism, experience, and commitment to quality and client satisfaction	<p>\r\n  Are you thinking of installing a modified bitumen roof over your flat or low-slope structure? This asphalt-based material is one of the most popular <a href="https://elementext.com/denver-commercial-roofing/">commercial roofing</a> solutions in Colorado. It is more versatile and brings about more benefits than other types of membrane roofing.\r\n</p>\r\n\r\n<p>\r\n  Here are the main benefits associated with modified bitumen roof systems:&nbsp;&nbsp;\r\n</p>\r\n\r\n<ul>\r\n  <li>\r\n    Resistance to tear and weather damage\r\n  </li>\r\n  <li>\r\n    Waterproof\r\n  </li>\r\n  <li>\r\n    Energy efficient\r\n  </li>\r\n  <li>\r\n    Flexible and able to withstand high-temperature fluctuations\r\n  </li>\r\n  <li>\r\n    Easy to maintain and repair\r\n  </li>\r\n</ul>\r\n\r\n<p>\r\n  While some business owners complain about disadvantages like the black color attracting sun rays or a short lifespan, those are usually the result of poor installation services. This is why it is important to work with experienced and licensed contractors, who know how to install a modified bitumen roof.&nbsp;\r\n</p>\r\n\r\n<h2>Modified Bitumen Roof Installation Services &ndash; What to Look for</h2>\r\n\r\n<p>\r\n  A modified bitumen roof can be coated in a light color to decrease its vulnerability to UV rays. It can consist of several layers, and can be installed using heat, adhesives, or auto-adhesive membrane. With several installation methods available and without professional workmanship, mistakes, and faults can easily appear.&nbsp;\r\n</p>\r\n\r\n<p>\r\n  At Element Exteriors, we have long years of experience in modified bitumen roof installation. Our specialists can recommend the best materials and the best installation method for your roof. They will take into account your needs, your budget, and the specifics of your structure.&nbsp;\r\n</p>\r\n\r\n<blockquote><p>\r\n  With our modified bitumen roof installation services, you will have a solid, durable roof protecting your building and assets in no time, and you will be able to enjoy all the above benefits and more.&nbsp;\r\n</p>\r\n</blockquote>\r\n\r\n<h2>Contact the Best Modified Bitumen Roof Contractors in Denver, CO, Area</h2>\r\n\r\n<p>\r\n  Whether you want to find out more about various roofing solutions, obtain cost estimates, or schedule the installation, we can help. Element Exteriors is not only one of the best modified bitumen roof contractors but one of the best <a href="https://elementext.com/">roofing companies</a> in Englewood, Centennial, Thornton, Parker, and Castle Rock, CO.&nbsp;\r\n</p>\r\n\r\n<p>\r\n  We will gladly answer your questions, help you assess costs, and install your roof. All you have to do is call our office at (303) 747-3706 or fill in the contact form on our website. We promise you will not want to get in touch with other modified bitumen roof contractors once you get a taste of how we work!\r\n</p>\r\n	24	2020-01-10 06:22:54.711041+00		Modified Bitumen Roof Solutions for Denver, CO, Buildings	construction	1	8	2	9	3	t
21	Tile Roof	tile-roofs	Roof tiles are popular among Denver homeowners. Whether you need installation or repair services, we can help. Our roofers are skilled in working with a wide variety of materials and consistently provide excellent service	<p>\r\n  Roof tiles are one of the more popular choices for <a href="https://elementext.com/denver-residential-roofing/">residential roofing</a> in Denver, CO. They are usually made from locally sourced materials, like clay or slate, and offer good protection from rain, as well as other bad weather. We have many years of experience in working with a variety of materials and deliver superior workmanship on a consistent basis. If you want to get roof tiles for your home or need information on all the options available, we&rsquo;d be more than happy to assist you.\r\n</p>\r\n\r\n<p class="page-images single-image">\r\n  <img alt="Man installing roof tiles" data-crop="" data-description="Q2FsbCUyMEVsZW1lbnQlMjBFeHRlcmlvcnMlMjB0byUyMGdldCUyMGElMjBiZWF1dGlmdWwlMjByb29m" data-id="12" data-source="/media/page_photos/0000/photo_12.jpg?_=1572242477" height="576" sizes="100vw" src="/media/page_photos/0000/photo_12.normal.jpg" srcset="/media/page_photos/0000/photo_12.wide.jpg?_=1572242477 1024w, /media/page_photos/0000/photo_12.normal.jpg?_=1572242477 800w, /media/page_photos/0000/photo_12.mobile.jpg?_=1572242477 480w" title="Roof tiles installed by worker" width="1024" />\r\n</p>\r\n\r\n<h2>Types of Roof Tiles: Know Your Options</h2>\r\n\r\n<p>\r\n  It is important to know the strengths and weaknesses of the various types of roof tiles before you decide to purchase a particular kind. Your roof affects both the aesthetics and the comfort of your home, so you need to choose carefully. If you&rsquo;re feeling a little overwhelmed by all the different types of roof tiles out there, here&rsquo;s a simple guide.\r\n</p>\r\n\r\n<div class="columns">\r\n  <div class="column column-left">\r\n    <p>\r\n      Plain roof tiles are beautiful and can be overlapped to protect the interior from water.\r\n    </p>\r\n\r\n    <p>\r\n      Low pitch roof tiles are ideal for roofs that are pitched between 10&deg; and&nbsp; 20&deg;. They are great for home extensions that restrict the use of standard tiles.\r\n    </p>\r\n\r\n    <p>\r\n      Interlocking roof tiles can be made from concrete, clay, or slate. They are easy to install and competitively priced.&nbsp;\r\n    </p>\r\n  </div>\r\n\r\n  <div class="column column-right">\r\n    <p>\r\n      Concrete roof tiles are highly durable and can be made to look like clay or slate. They are low maintenance and fire-resistant. However, they are heavy, so your roof needs to be able to handle the weight.\r\n    </p>\r\n\r\n    <p>\r\n      Clay roof tiles are aesthetically pleasing, eco-friendly, and don&rsquo;t require significant maintenance. However, they are prone to breakage. Because of that, they are best suited for roofs with moderate to high slopes.\r\n    </p>\r\n  </div>\r\n</div>\r\n\r\n<h2>Tile Roof Installation in Denver, CO and Neighboring Areas</h2>\r\n\r\n<p>\r\n  If you are thinking about getting a tile roof installation in Denver or surrounding areas, choose Element Exteriors over the other <a href="https://elementext.com/">roofing companies</a> out there. We offer high-quality work and excellent customer service.&nbsp; Element Exteriors is located in Englewood, CO and serves Denver, Centennial, Thornton, Parker, and Castlerock, CO. Call us today at 303-747-3706 to get a free estimate for a tile roof installation or tile roof repair.\r\n</p>\r\n	7	2019-10-28 06:10:54.255418+00		Roof Tiles Installed by Experts in Denver, CO	commercial	1	4	1	5	2	t
2	Commercial Roofing	denver-commercial-roofing	With extensive experience in Commercial Roofing, our company focuses on top performance and quality customer service. We offer a free estimate, fast job completion, and a warranty to ensure your roofing system will last for many years.	<p>\r\n  Element Exteriors specializes in Commercial Roofing to help commercial and industrial property owners solve their roofing problems by offering installation, replacement, and maintenance. Our roofing services include storm and hail damage repair, reroofing, emergency roof repair, and more. Most of our jobs are complete in 1-3 days after your initial call because we understand that a faulty, damaged roof on your warehouse or office demands quick, high-quality repair. Our specialists are well-trained, fully-equipped, and experienced to perform the job in a timely and professional manner. When it comes to Commercial Roofing in Denver, CO, leave your roof issues to the experts at Element Exteriors.\r\n</p>\r\n\r\n<p class="page-images single-image">\r\n  <img alt="Commercial roofing services performed by experts" data-crop="" data-id="20" data-source="/media/page_photos/0000/photo_20.jpg?_=1572256920" height="576" sizes="100vw" src="/media/page_photos/0000/photo_20.normal.jpg" srcset="/media/page_photos/0000/photo_20.wide.jpg?_=1572256920 1024w, /media/page_photos/0000/photo_20.normal.jpg?_=1572256920 800w, /media/page_photos/0000/photo_20.mobile.jpg?_=1572256920 480w" title="Team of roofers working on a commercial project" width="1024" />\r\n</p>\r\n\r\n<h2>Сommercial Roofing Contractor</h2>\r\n\r\n<p>\r\n  Element Exteriors is a licensed Commercial Roofing Contractor in the Denver Metro area. Based in Englewood, CO, we understand the necessities of local businesses and strive to provide services at an unmatched level. Having a long history in business allows us to find the most cost-effective solution to match your roofing repair needs. Whether your roof has leaks, blow-offs, or ponding water, our team of professionals can fix it. We are fully insured against damages to the property and injuries that may occur on the job site. If you are looking for a local Commercial Roofing Contractor, Element Exteriors is your best choice.\r\n</p>\r\n\r\n<blockquote><p>\r\n  We are experienced in many types of Commercial Roofing Systems, materials, and installation techniques, and we offer durable products to protect your property for decades.\r\n</p>\r\n</blockquote>\r\n\r\n<h2>Types of Commercial Roofing Systems We Handle</h2>\r\n\r\n<p>\r\n  If you are a property owner who needs a new roof or wants to build a new structure, you likely vacillate between various types of Commercial Roofing Systems and materials. Element Exteriors can help you choose an energy-efficient solution that fits your needs and budget. We are experienced in many types of Commercial Roofing Systems, materials, and installation techniques, and we offer durable products to protect your property for decades. Whether you need metal roofing for your sloped roof or EPDM roofing for your flat roof, our experts are trained and certified to accomplish this job for you.\r\n</p>\r\n\r\n<h2>Commercial Roofers Near Me in the Denver Metro Area</h2>\r\n\r\n<p>\r\n  If you are searching &quot;Commercial Roofers near me,&quot; choose Element Exteriors, a reliable roofing company in the Denver Metro area. With trained staff, professional equipment, and quality materials, we aim to deliver work of the highest level. In addition, we offer a 10-year warranty on labor and materials, so we will come back and fix any problem, if needed. Our service area includes Englewood, Denver, Centennial, Thornton, Parker, and Castlerock. If you need Commercial Roofing Services like installation, repair, and maintenance, call 303-747-3706 today for a free estimate.\r\n</p>\r\n	9	2019-10-28 10:03:27.026747+00	./background_2.jpg	Commercial Roofing in Denver, CO	construction	0	1	\N	10	3	t
7	Gutters	denver-gutter-contractors	Unlike many gutter contractors in Denver, Element Exteriors specializes in both residential and commercial gutter systems. We are a local company aimed at providing the best service to protect your property from damage and leaks; we give you the peace of mind you deserve.	<p>\r\n  Based in Englewood, CO, Element Exteriors is a Local Gutter Contractor dedicated to providing affordable seamless gutter services: installation, replacement, and modifications. Gutter systems are designed to protect your home, its foundation, and surroundings from damage during rain and storms; they keep rainwater away from your home. If your gutter system doesn&#39;t function properly, the structure of your property becomes exposed to water damage. To protect your home from weathering, call Element Exteriors, a professional Gutter Contractor in the Denver Metro area. Our <a href="/services/">Home Improvement Services</a> encompass residential and commercial gutter systems.\r\n</p>\r\n\r\n<p class="page-images single-image">\r\n  <img alt="Gutter installation performed by professional contractor" data-crop="" data-description="RWxlbWVudCUyMEV4dGVyaW9ycyUyMHdpbGwlMjBoYW5kbGUlMjBhbGwlMjB5b3VyJTIwZ3V0dGVyJTIwcHJvYmxlbXM=" data-id="21" data-source="/media/page_photos/0000/photo_21.jpg?_=1572257137" height="576" sizes="100vw" src="/media/page_photos/0000/photo_21.normal.jpg" srcset="/media/page_photos/0000/photo_21.wide.jpg?_=1572257137 1024w, /media/page_photos/0000/photo_21.normal.jpg?_=1572257137 800w, /media/page_photos/0000/photo_21.mobile.jpg?_=1572257137 480w" title="Man installing gutters" width="1024" />\r\n</p>\r\n\r\n<h2>Gutter Installation Services from Experts</h2>\r\n\r\n<p>\r\n  Our company is experienced in commercial and residential Gutter Installation Services and offers high-quality products to fit your needs and budget. Our experienced technicians are trained, certified, and insured to provide seamless Gutter Installation Services and bring you comfort knowing that your new gutter system will last for decades.\r\n</p>\r\n\r\n<h2>Gutter Replacement Services at Element Exteriors</h2>\r\n\r\n<p>\r\n  Living at the foot of the Rocky Mountains, sudden changes in weather can be a challenge for you and your property. If you experience water damage to your home, you may need a Gutter Replacement Service as soon as possible. Element Exteriors specializes in seamless Gutter Replacement Services, offering you high-quality work and advanced residential and commercial gutter systems.\r\n</p>\r\n\r\n<h2>Seamless Gutter Cleaning Services</h2>\r\n\r\n<p>\r\n  Professional Gutter Cleaning Services are vital for keeping your system free from clogs and debris. A clogged gutter system can&#39;t transport water away from the building. Eventually, it can cause substantial damage to your property. &nbsp;Element Exteriors offers residential and commercial Gutter Cleaning Services to ensure optimal performance of your system. Our skilled specialists will clean your system so that it performs at its best.\r\n</p>\r\n\r\n<h2>Finding the Best Gutter Services Near Me in Denver, CO</h2>\r\n\r\n<p>\r\n  If you are looking for &ldquo;Gutter Services near me&rdquo; in the Denver Metro area, look no further than Element Exteriors. With extensive experience in the industry and all the necessary equipment, our team of professionals can handle any job in a timely manner. We proudly serve the communities of Englewood, Denver, Centennial, Thornton, Parker, and Castlerock, CO. We also offer a 10-year warranty. Call us today at 303-747-3706 to get a free estimate.\r\n</p>\r\n	14	2019-10-28 10:07:42.205602+00	./background_7.jpg	Professional Gutter Contractor in Denver, CO	paintings	0	1	\N	2	5	t
31	Exterior Painting	exterior-painting	Treat your home to a makeover with our exterior painting services. We offer same-day inspections on all exterior paint jobs. Our exterior house painters provide free estimates within 48 hours, and we complete most jobs in one day	<p>\r\n  A quick and easy way to give your house a fresh look is to have the exterior painted. Exterior painting removes stains, covers chips and cracks, and produces an excellent finish. Hiring the right <a href="https://elementext.com/denver-painting-contractors/">painting contractors</a> to get the job done properly will result in your home&rsquo;s value increasing.\r\n</p>\r\n\r\n<p>\r\n  Unlike painting the interior walls or ceilings, exterior painting requires more effort and skilled expertise. A qualified contractor in Denver, CO will come with the right equipment to complete the work quickly and efficiently. Save yourself time by leaving everything to the professionals.\r\n</p>\r\n\r\n<p class="page-images single-image">\r\n  <img alt="" data-crop="" data-id="27" data-source="/media/page_photos/0000/photo_27.jpg?_=1574681769" height="576" sizes="100vw" src="/media/page_photos/0000/photo_27.normal.jpg" srcset="/media/page_photos/0000/photo_27.wide.jpg?_=1574681769 1024w, /media/page_photos/0000/photo_27.normal.jpg?_=1574681769 800w, /media/page_photos/0000/photo_27.mobile.jpg?_=1574681769 480w" width="1024" />\r\n</p>\r\n\r\n<h2>Why Choose Our Exterior House Painters?</h2>\r\n\r\n<p>\r\n  It is important to hire qualified exterior house painters when you are looking to spruce up your home&rsquo;s curb appeal. This is where Elements Exteriors comes in. We are Colorado&rsquo;s top painting contractor with a stellar reputation for unmatched quality and professionalism. We carefully choose our painting materials by considering the Colorado weather. This allows us to ensure that the finished result achieved by our exterior house painters is able to withstand the elements.\r\n</p>\r\n\r\n<p>\r\n  When performing a paint job, we use tarps to make sure your driveway and other areas aren&rsquo;t damaged. We also work with a wide range of insurance companies. If your insurance covers home restoration, we can start the repair and restoration process quickly.\r\n</p>\r\n\r\n<p>\r\n  Any exterior painting cost depends on a number of factors. These include the size and location of your home, its architectural style, and the type of siding, among other aspects. We do not ask for any upfront costs and provide accurate estimates. If you are concerned about pricing, let us know so that we can provide you with a quote.\r\n</p>\r\n\r\n<h2>I am Searching for Exterior Painters Near Me&nbsp;</h2>\r\n\r\n<p>\r\n  If you are looking to restore your home&rsquo;s exterior and have been looking for &ldquo;exterior painters near me,&rdquo; look no further. We are the premier <a href="https://elementext.com/">home improvement company</a> in Colorado. We serve Denver, CO; Thornton, CO; Castlerock, CO; Parker, CO; and Centennial, CO.\r\n</p>\r\n\r\n<p>\r\n  No matter the size of your home, the type of paint job you want, or your budget, you can rely on us. Simply give us a call today at 303-747-3706 to get a free estimate.\r\n</p>\r\n	17	2019-11-25 11:36:24.046816+00		Hiring an Exterior Painting Contractor in Denver, CO	residential	1	2	6	3	7	t
23	TPO Roofing	tpo-roofing	TPO roofing installation requires specialized skills, so it is always a good idea to hire a professional roofing company with years of experience to get the job done quickly, efficiently, and for a minimal cost	<p>\r\n  TPO, or thermoplastic polyolefin, is becoming an increasingly popular choice of roofing material for commercial buildings. TPO roofing is preferred because of the overwhelming cost benefits it offers. As a <a href="https://elementext.com/denver-commercial-roofing/">commercial roofing</a> material, TPO costs less than EPDM or any other rubber roofing option.\r\n</p>\r\n\r\n<p>\r\n  TPO is resistant to corrosion, mildew, algae, and sunlight, which makes it able to withstand rain, snow, and other elements. Unlike other rubber materials, like EPDM, TPO also reflects sunlight very well.\r\n</p>\r\n\r\n<p>\r\n  Typically, TPO roofing costs around $5.50 and $9.50 per square feet. For a 1,200 square foot roof, the average cost is between $6,600 and $11,400. Ultimately, the actual TPO roofing cost depends on the method of installation required and roof size.\r\n</p>\r\n\r\n<p class="page-images single-image">\r\n  <img alt="" data-crop="" data-id="26" data-source="/media/page_photos/0000/photo_26.jpg?_=1574681748" height="576" sizes="100vw" src="/media/page_photos/0000/photo_26.normal.jpg" srcset="/media/page_photos/0000/photo_26.wide.jpg?_=1574681749 1024w, /media/page_photos/0000/photo_26.normal.jpg?_=1574681749 800w, /media/page_photos/0000/photo_26.mobile.jpg?_=1574681749 480w" width="1024" />\r\n</p>\r\n\r\n<h2>Why Hire Professionals for TPO Roofing Installation</h2>\r\n\r\n<p>\r\n  TPO is a type of roofing that consists of sheets of rubber or other synthetic materials. Because TPO roofing installation requires a certain degree of skill and expertise, it is best to leave it to an expert contractor.\r\n</p>\r\n\r\n<p>\r\n  TPO is very sturdy, so you can have it installed in any way. It can be directly fastened to the roof structure, installed with adhesives, or heat-welded to eliminate seams and prevent leaks. TPO roofing installation doesn&rsquo;t have to be complicated!\r\n</p>\r\n\r\n<blockquote><p>\r\n  At Element Exteriors, our technicians are licensed and have extensive experience in commercial roofing. We have the resources to install TPO on roofs of any size and type. We can also achieve a perfect finish using the right tools and techniques.&nbsp;\r\n</p>\r\n</blockquote>\r\n\r\n<h2>I Am Searching for TPO Roofing Installers Near Me&nbsp;</h2>\r\n\r\n<p>\r\n  If you live in Denver, CO and have been looking for &ldquo;TPO roofing installers near me,&rdquo; your search is over because we are one of the most reliable <a href="https://elementext.com/">roofing companies</a> in town. We also operate in Thornton, CO; Parker, CO; Castlerock, CO; and Centennial, CO. Contact us today at 303-747-3706 to get a free estimate.\r\n</p>\r\n	12	2019-11-25 11:35:52.84098+00		Superior TPO Roofing Installation in Denver, CO	construction	1	6	2	7	3	t
20	Asphalt Roofing	asphalt-roofing	We’ll install, repair or replace your asphalt roof quickly and expertly using high-quality materials. We only hire the best residential roofing professionals who are licensed and highly trained. Element Exteriors is trusted among homeowners in the local community	<p>\r\n  The asphalt roof is becoming more and more popular among homeowners. Asphalt shingle roofs are easy to install and they are durable, low maintenance, and cost-effective. The material is also recyclable. When you choose a residential asphalt roof, you help the environment and support the green building movement. Torn-off shingles can be used in asphalt or aggregate for road works so you won&rsquo;t have to send them to the landfill when it&rsquo;s time to get rid of them. Element Exteriors has several years of experience working with asphalt shingles and we guarantee a high quality of work on any <a href="https://elementext.com/denver-residential-roofing/">residential roofing</a> project.\r\n</p>\r\n\r\n<p class="page-images single-image">\r\n  <img alt="Asphalt roof shingles" data-crop="" data-id="11" data-source="/media/page_photos/0000/photo_11.jpg?_=1572242048" height="576" sizes="100vw" src="/media/page_photos/0000/photo_11.normal.jpg" srcset="/media/page_photos/0000/photo_11.wide.jpg?_=1572242048 1024w, /media/page_photos/0000/photo_11.normal.jpg?_=1572242048 800w, /media/page_photos/0000/photo_11.mobile.jpg?_=1572242048 480w" title="Asphalt roof installation" width="1024" />\r\n</p>\r\n\r\n<h2>We Work with Different Types of Asphalt Roof Shingles&nbsp;</h2>\r\n\r\n<p>\r\n  Asphalt roof shingles are available in a wide variety of colors and textures and they can be made to resemble wood, slate and other materials. They are widely available and you will always find multiple options from which you can choose. Whether you have a roof with a low slope or steep slope, there are solutions that will work well.&nbsp;\r\n</p>\r\n\r\n<p>\r\n  Since asphalt roof shingles are lightweight, no additional structure is needed to support them. There is also no need for ice stops and the material is resistant to fire. If you&rsquo;re not sure which type of shingles you should get for your home, contact us. Our experts will listen to your needs and tell you which option will work best for your project.\r\n</p>\r\n\r\n<h2>Asphalt Roofing Installation, Repair, and Replacement Done Right</h2>\r\n\r\n<p>\r\n  Element Exteriors offers professional asphalt roofing installation as well as repairs and replacement. We do the job quickly and efficiently and deliver reliable results. We&rsquo;re so confident in our work that we don&rsquo;t ask you to pay upfront and we offer a ten-year labor and material warranty. Our specialists only use high-quality products when we do asphalt roofing installation or asphalt roof repair.\r\n</p>\r\n\r\n<h2>Choose Us for Expert Asphalt Roof Services in Denver</h2>\r\n\r\n<p>\r\n  Residential roof installation is best left to the professional <a href="http://www.elementext.com/">roofing companies</a>. Our company has a long history of delivering excellent service to the local market, and we have a solid reputation among homeowners in Colorado. If you need an asphalt roof installation or other services in Denver, Centennial, Thornton, Parker, Castlerock or Englewood, CO, call us today at 303-747-3706 to get a free estimate.\r\n</p>\r\n	6	2019-10-28 05:59:36.450258+00	./background_20.jpg	Get an Asphalt Roof Installed by Professionals in Denver	commercial	1	2	1	3	2	t
1	Residential Roofing	denver-residential-roofing	Element Exteriors delivers Residential Roofing Services designed to meet all your home improvement needs. We install, repair, and maintain all roof types, as well as provide a free estimate and 10-year labor and materials warranty.	<p>\r\n  When it comes to Residential Roofing Services, you must think twice before choosing the right contractor. Your roofing system performs multiple functions; providing protection is one of them. Acting like an enormous umbrella, your roof preserves you, your family, and your belongings from harmful weather elements such as heat, cold, wind, rain, and more. That is why hiring a professional roofing company that can deliver high-quality work and durable materials is a must. Element Exteriors specializes in <a href="/services/">Roofing Services</a> and offers a superior product that stands the test of time. We provide Residential Roofing Services in the Denver Metro area, which includes new roof construction, residential Re-Roofs, and repairs.\r\n</p>\r\n\r\n<blockquote><p>\r\n  We finish most jobs in one day, including cleanup, so you don&#39;t have to wait weeks for completion.\r\n</p>\r\n</blockquote>\r\n\r\n<p class="page-images single-image">\r\n  <img alt="Residential roofing services performed by professionals" data-crop="" data-description="SGlyZSUyMEVsZW1lbnQlMjBFeHRlcmlvcnMlMjB0byUyMGdldCUyMHRoZSUyMGJlc3QlMjByZXNpZGVudGlhbCUyMHJvb2ZpbmclMjBzZXJ2aWNlcyUyMGluJTIwRGVudmVy" data-id="19" data-source="/media/page_photos/0000/photo_19.jpg?_=1572256534" height="576" sizes="100vw" src="/media/page_photos/0000/photo_19.normal.jpg" srcset="/media/page_photos/0000/photo_19.wide.jpg?_=1572256534 1024w, /media/page_photos/0000/photo_19.normal.jpg?_=1572256534 800w, /media/page_photos/0000/photo_19.mobile.jpg?_=1572256534 480w" title="Team of roofers working on a residential project" width="1024" />\r\n</p>\r\n\r\n<h2>Local Residential Roofing Contractor</h2>\r\n\r\n<p>\r\n  Element Exteriors is a Denver Residential Roofing Contractor committed to delivering services to restore the protective function and integrity of your roof. Whether you have a roof leak, broken gutters, or blown off shingles, our certified specialists can fix any problem you encounter as quickly as possible. <strong>Our services include roof replacement and repair after a severe storm that brings heavy wind, rain, and hail. </strong>We finish most jobs in one day, including cleanup, so you don&#39;t have to wait weeks for completion. Moreover, you only pay after the job is done, and you are satisfied with the results. To ensure that your investment is safe, we offer a 10-year warranty on labor and materials. If you are looking for a dependable Residential Roofing Contractor, Element Exteriors is your best local choice.\r\n</p>\r\n\r\n<h2>Residential Roof Types We Can Service</h2>\r\n\r\n<p>\r\n  At Element Exteriors, we work with major Residential Roof Types to meet your repair and maintenance needs. Each roofing material requires specific maintenance and installation, and our experts have the necessary experience and knowledge to complete the job in a prompt and professional manner. We mostly deal with asphalt Residential Roof Types, because of their lifespan, appearance, and affordability. We also handle metal and tile roofing systems, which last longer than the most expensive asphalt shingles. Generally, these materials can boost the curb appeal and value of your home.\r\n</p>\r\n\r\n<h2>Residential Roofing Companies Near Me in the Denver Metro Area</h2>\r\n\r\n<p>\r\n  If you are searching for &nbsp;&quot;Residential Roofing Companies near me,&quot; &nbsp;look no further than Element Exteriors. Headquartered in Englewood, CO, our <a href="/">Roofing Company</a> is committed to serving the roofing needs of residents in Denver, Centennial, Thornton, Parker, Castlerock, and the surrounding area. Contact us today at 303-747-3706 to get a free estimate.\r\n</p>\r\n	5	2019-10-28 10:01:06.500718+00	./background_1_thLHsWG.jpg	Residential Roofing Services in Denver, CO	commercial	0	1	\N	14	2	t
29	Roof Maintenance	roof-maintenance	Ongoing roof maintenance is crucial if you want to prolong the lifespan of your roof. Our local roofing professionals work on all types of roofs and ensure they remain in excellent condition. We’ll help you save money in the long run	<p>\r\n  Preventing a problem is always better than trying to fix it. If you want your roof to stand the test of time, it&rsquo;s vital to get regular roof maintenance work done by professional <a href="https://elementext.com/denver-roofing-contractors/">roofing contractors</a>. While it will come at a cost upfront, doing this can save you money down the road. You won&rsquo;t have to pay for expensive emergency repairs or even replace the roof completely. When you entrust your roof maintenance to our team of professionals, you can rest assured that your roof will stand even the harshest weather.\r\n</p>\r\n\r\n<p class="page-images single-image">\r\n  <img alt="Roof maintenance service performed by professional" data-crop="" data-description="Um9vZiUyMG1haW50ZW5hbmNlJTIwd2lsbCUyMGhlbHAlMjB5b3UlMjBzYXZlJTIwbW9uZXk=" data-id="13" data-source="/media/page_photos/0000/photo_13.jpg?_=1572243164" height="576" sizes="100vw" src="/media/page_photos/0000/photo_13.normal.jpg" srcset="/media/page_photos/0000/photo_13.wide.jpg?_=1572243164 1024w, /media/page_photos/0000/photo_13.normal.jpg?_=1572243164 800w, /media/page_photos/0000/photo_13.mobile.jpg?_=1572243164 480w" title="Professional roof maintenance" width="1024" />\r\n</p>\r\n\r\n<h2>Hire the Best Roof Maintenance Company in Denver</h2>\r\n\r\n<p>\r\n  Our local roof maintenance company has been providing high-quality services to Denver homeowners for many years. Our preventative work helps them avoid serious problems and unplanned expenses in the future. We use premium products and highly-trained installers, so we know that our work will stand the test of time. As a local roofing business, we are happy to serve our community.\r\n</p>\r\n\r\n<p>\r\n  When you choose our company to handle your roofing needs, you&rsquo;ll see why we&rsquo;re so highly respected. We work quickly, efficiently, and always leave the job site clean and tidy. We won&rsquo;t park in your driver or disrupt you and your family unnecessarily. When you need a different kind of roof maintenance company, let us be your first choice. No job is too big or small for our team to handle.&nbsp;&nbsp;&nbsp;\r\n</p>\r\n\r\n<h2>Roof Maintenance Services in Denver, CO and Neighboring Areas</h2>\r\n\r\n<p>\r\n  Element Exteriors is the best choice for homeowners who are looking at <a href="https://elementext.com/">roofing companies</a> for roof maintenance services in Denver, Centennial, Thornton, Parker, and Castlerock, CO. Your roof is a very important part of your home, and you need it to be in excellent condition. Let true professionals do the job. Call us today at 303-747-3706 to get a free estimate for roof maintenance services. We&rsquo;ll carry out an inspection within 24 hours, and the estimate will be ready within one to two days.\r\n</p>\r\n	1	2019-10-28 06:20:50.700194+00		Local Roof Maintenance Specialists in Denver, CO	residential	1	2	26	3	1	t
28	Roof Repair	roof-repair	Do you need high-quality roof repair from a local contractor? Reach out to Element Exteriors and learn why we’re trusted by homeowners in the Denver area. We have a highly trained team of roofing specialists who use only the best materials	<p>\r\n  As soon as your roof begins to show signs of damage, you need to act quickly. If you don&rsquo;t seek roof repair immediately, small issues can become big problems that are costly to fix. You may even end up needing a completely new roof. Since your roof is so important for the comfort and safety of you and your family, you need to ensure you hire experienced <a href="https://elementext.com/denver-roofing-contractors/">roofing contractors</a> who have a track record of doing high-quality work. Regardless of how your roof was damaged, we can provide the roof repair services you need. Our roofing specialists are licensed and have experience in fixing leaks of any complexity.\r\n</p>\r\n\r\n<p class="page-images single-image">\r\n  <img alt="Roof repaired by professional roofing contractor" data-crop="" data-description="RWxlbWVudCUyMEV4dGVyaW9ycyUyMG9mZmVycyUyMGV4Y2VsbGVudCUyMHJvb2YlMjByZXBhaXIlMjBzZXJ2aWNlcw==" data-id="17" data-source="/media/page_photos/0000/photo_17.jpg?_=1572244087" height="576" sizes="100vw" src="/media/page_photos/0000/photo_17.normal.jpg" srcset="/media/page_photos/0000/photo_17.wide.jpg?_=1572244087 1024w, /media/page_photos/0000/photo_17.normal.jpg?_=1572244087 800w, /media/page_photos/0000/photo_17.mobile.jpg?_=1572244087 480w" title="Man repairing a roof" width="1024" />\r\n</p>\r\n\r\n<h2>We&rsquo;re Experts in Roof Leak Repair</h2>\r\n\r\n<p>\r\n  We can handle any roof leak repair project no matter how big or small. Whether your leak developed because of hail, a storm, or aging, we guarantee high-quality work done in record time. We&rsquo;ll have the job completed in just one day, and we&rsquo;ll leave the worksite in pristine condition. We treat your property as if it were our own, so we use tarps generously and clean up any dirt and debris. In addition, our roofers are experienced and love what they do. They&rsquo;ll work hard to ensure the roof leak repair job is done right the first time. Whether you need hail damage roof repair or storm damage roof repair, we&rsquo;re here to help.\r\n</p>\r\n\r\n<h2>Looking for &ldquo;Roof Repair Near Me&rdquo; in Denver, CO and Neighboring Areas?</h2>\r\n\r\n<p>\r\n  If you&rsquo;ve been searching online for &ldquo;roof repair near me,&rdquo; there&rsquo;s no need to review pages and pages of <a href="https://elementext.com/">roofing companies</a>. Many homeowners have relied on Element Exteriors over the years, and all were satisfied with the work we delivered. If you need to file an insurance claim, we can help with that. We never ask for payment upfront and offer a 10-year labor and materials warranty. Call us today at 303-747-3706 to get a free estimate. End your search for &ldquo;roof repair near me&rdquo; now!\r\n</p>\r\n	4	2019-10-28 06:30:28.690654+00		We Offer Professional Roof Repair Services in Denver, CO	residential	1	8	26	9	1	t
22	Metal Roof	metal-roofs	We are the preferred metal roofing contractors for homeowners in Denver and nearby areas thanks to our high quality work and excellent service	<p>\r\n  Metal roofs are becoming increasingly popular. If you&rsquo;re one of the many homeowners looking for metal roofing contractors who offer <a href="https://elementext.com/denver-residential-roofing/">residential roofing</a>, choose Element Exteriors. Metal roofs offer numerous benefits, including longevity, durability, safety, and energy efficiency. As professional metal roofing contractors will tell you, these roofs can last for up to 70 years. Some can even withstand winds of up to 140 miles per hour.&nbsp;\r\n</p>\r\n\r\n<p>\r\n  Since your roof is a vital part of your property&rsquo;s structure, you should choose the best metal roofing company. If you&rsquo;ve been searching for reputable metal roofing contractors, Element Exteriors, LLC is the company you need.\r\n</p>\r\n\r\n<p class="page-images single-image">\r\n  <img alt="" data-crop="" data-id="24" data-source="/media/page_photos/0000/photo_24.jpg?_=1574424524" height="576" sizes="100vw" src="/media/page_photos/0000/photo_24.normal.jpg" srcset="/media/page_photos/0000/photo_24.wide.jpg?_=1574424525 1024w, /media/page_photos/0000/photo_24.normal.jpg?_=1574424525 800w, /media/page_photos/0000/photo_24.mobile.jpg?_=1574424524 480w" width="1024" />\r\n</p>\r\n\r\n<h2>Choose Element Exteriors for Premium Metal Roofing Installation</h2>\r\n\r\n<p>\r\n  We offer top-quality metal roofing installation in Denver and surrounding areas. Since metal roofs reflect heat, they can reduce cooling costs by up to 25 percent. The material is also recyclable and can be repurposed. If you want to know more about the benefits of metal roofing installation, reach out to our specialists today.\r\n</p>\r\n\r\n<p>\r\n  Although quality metal roofing installation usually guarantees the long-term span of your roof, even the finest roofing materials get damaged. That&rsquo;s why we also offer metal roofing repair. Thanks to our experience with metal roofs, we can diagnose any problem quickly and fix it using the best materials.\r\n</p>\r\n\r\n<blockquote><p>\r\n  Whether you need metal roofing repair to fix damage caused by a storm or want to update the look of your home, we&rsquo;ll work with you throughout the entire process. No matter how big or small the project, we will provide the repair services you need.\r\n</p>\r\n</blockquote>\r\n\r\n<h2>I Need Metal Roofing Contractors Near Me in Denver, CO and Neighboring Areas</h2>\r\n\r\n<p>\r\n  If you are looking for <a href="https://elementext.com/">roofing companies</a> that work with metal roofs in Denver or nearby areas, you may be googling &ldquo;metal roofing contractors near me.&rdquo;&nbsp; There&rsquo;s no need to continue poring over search results when you can simply contact Element Exteriors, LLC today at 303-552-4467 to get a free estimate. Our service area covers Denver, CO; Centennial, CO; Thornton, CO; Parker, CO; and Castle Rock, CO. End your search for &ldquo;metal roofing contractors near me&rdquo; now!\r\n</p>\r\n	8	2019-11-22 12:08:50.080996+00		We are Expert Metal Roofing Contractors in Denver, CO	commercial	1	6	1	7	2	t
4	New Roof Construction	denver-roof-construction	We’re a roofing company with a difference. Hire us for your new roof construction and benefit from the best materials and workmanship. If your property is in Denver or the surrounding areas, we will work closely with you to deliver the perfect roofing solution.	<p>\r\n  Element Exteriors is a full-service roofing company and we offer new roof construction for both residential and commercial buildings. We work closely with each client to determine the best roofing material for their project. When you choose Element Exteriors, we also fix other aspects of the house. We don&rsquo;t just focus on <a href="/services/">roofing services</a>.\r\n</p>\r\n\r\n<p>\r\n  You should always choose highly trained professionals for new roof construction. The quality of the work determines how long your roof will last and if you will need costly repairs in short order. If we&rsquo;re working on your home, you can choose from asphalt, tile or metal roofs as well as specialty materials. For buildings, we offer TPO, PVC, EPDM and modified bitumen roofs.\r\n</p>\r\n\r\n<p class="page-images single-image">\r\n  <img alt="New roof construction for residential building" data-crop="" data-id="9" data-source="/media/page_photos/0000/photo_9.jpg?_=1562150698" height="576" sizes="100vw" src="/media/page_photos/0000/photo_9.normal.jpg" srcset="/media/page_photos/0000/photo_9.wide.jpg?_=1562150699 1024w, /media/page_photos/0000/photo_9.normal.jpg?_=1562150698 800w, /media/page_photos/0000/photo_9.mobile.jpg?_=1562150698 480w" title="Professional roofer checking new roof construction " width="1024" />\r\n</p>\r\n\r\n<h2>Roof Installation is a Specialized Field</h2>\r\n\r\n<p>\r\n  Roof installation can be a time-consuming process and it requires careful planning. The exact process to <a href="/denver-residential-roofing/">residential roofing</a> will vary depending on the project, but the basic steps are similar:\r\n</p>\r\n\r\n<ol>\r\n  <li>\r\n    The contractor will secure your property so no one gets hurt and nothing gets damaged during construction.\r\n  </li>\r\n  <li>\r\n    Any existing shingles or other roofing will be removed so the contract can check the underlying structure for damage. If the old shingles aren&rsquo;t removed you could face expensive repairs later.\r\n  </li>\r\n  <li>\r\n    The skeleton of the roof will be repaired if necessary or installed if it is a completely new roof.\r\n  </li>\r\n  <li>\r\n    The final step is to install the shingles or other roofing material. Your roof installation is complete!\r\n  </li>\r\n</ol>\r\n\r\n<h2>We Are a Roofing Construction Company With a Difference</h2>\r\n\r\n<p>\r\n  When you choose us as your roofing construction company, you&rsquo;ll enjoy exceptional service. Roofing costs vary but you can be sure we will provide you with a cost-effective solution. That&rsquo;s why we are the roofing construction company of choice in the area.\r\n</p>\r\n\r\n<blockquote><p>\r\n  In 2019, homeowners in Denver paid between $4,982.00 and $6,367.00 to install shingle roofs with an average cost of $5,674.00.\r\n</p>\r\n</blockquote>\r\n\r\n<p>\r\n  The materials you use and the labor costs involved can have a significant impact on the cost of your residential roofing project. To get a clearer idea of how much your new roof will cost, reach out to us for an estimate.\r\n</p>\r\n\r\n<p class="page-images single-image">\r\n  <img data-crop="" data-description="QXNrJTIwZm9yJTIwYSUyMGZyZWUlMjBlc3RpbWF0ZSUyMHRvJTIwdGFrZSUyMGElMjB3ZWxsLWNvbnNpZGVyZWQlMjBkZWNpc2lvbg==" data-id="10" data-source="/media/page_photos/0000/photo_10.jpg?_=1562150711" height="576" sizes="100vw" src="/media/page_photos/0000/photo_10.normal.jpg" srcset="/media/page_photos/0000/photo_10.wide.jpg?_=1562150712 1024w, /media/page_photos/0000/photo_10.normal.jpg?_=1562150711 800w, /media/page_photos/0000/photo_10.mobile.jpg?_=1562150711 480w" title="Man estimating new roof construction" width="1024" />\r\n</p>\r\n\r\n<h2>I&rsquo;m Looking for Roof Construction Services Near Me in Denver&nbsp;</h2>\r\n\r\n<p>\r\n  At this point, you may be asking &ldquo;how can I get professional roof construction near me?&rdquo;.&nbsp;<strong>Contact us at 303-747-3706 to arrange a site visit and get an estimate for your roof or roof deck. </strong>You don&rsquo;t even have to pay upfront. You only pay when we have completed the roof installation to your satisfaction. We have experience working with all major insurance companies.\r\n</p>\r\n\r\n<p>\r\n  &nbsp;We serve Englewood, CO; Denver, CO; Centennial, CO; Thornton, CO; Parker, CO; and Castlerock, CO. As one of the best <a href="http://www.elementext.com/">roofing companies</a> in the area, we offer unparalleled roof construction services.&nbsp;\r\n</p>\r\n	13	2019-10-28 05:37:54.35341+00	./background_4.jpg	Choose Element Exteriors for Your New Roof Construction in Denver \n	gutters	0	1	\N	2	4	t
27	Roof Replacement	roof-replacement	Element Exteriors offers a superior roof replacement service in Denver, CO and surrounding areas. We guarantee high-quality work and are respected in the local community. When we work on your roof, you get a 10-year labor and materials warranty	<p>\r\n  Whatever the reason why you need a roof replacement service, Element Exteriors is here to help. Perhaps your roof was severely damaged in a storm, or it has fallen into disrepair due to age. With Colorado&rsquo;s unpredictable weather, serious roof damage isn&rsquo;t uncommon. When the time comes to change your roof, let us handle your roof replacement service. We are local <a href="https://elementext.com/denver-roofing-contractors/">roofing contractors</a> who have helped many homeowners in Denver change their roofs, and we&rsquo;re happy to serve our community.\r\n</p>\r\n\r\n<p class="page-images single-image">\r\n  <img alt="Roof replacement by professional contractor" data-crop="" data-id="16" data-source="/media/page_photos/0000/photo_16.jpg?_=1572243969" height="576" sizes="100vw" src="/media/page_photos/0000/photo_16.normal.jpg" srcset="/media/page_photos/0000/photo_16.wide.jpg?_=1572243969 1024w, /media/page_photos/0000/photo_16.normal.jpg?_=1572243969 800w, /media/page_photos/0000/photo_16.mobile.jpg?_=1572243969 480w" title="Man replacing a roof" width="1024" />\r\n</p>\r\n\r\n<h2>We&rsquo;re the Best Roof Replacement Contractors</h2>\r\n\r\n<p>\r\n  When choosing roof replacement contractors, you need to look for professionals with a proven track record and a solid reputation. We can guarantee that you will get a reliable roof that will protect you during all types of weather. Our workers are experts in the roofing process, and they&rsquo;re always ready to go the extra mile to satisfy clients. Your roof is simply too important to hand it over to a roof replacement company that will cut corners or leave the job unfinished.\r\n</p>\r\n\r\n<p>\r\n  When you hire Element Exteriors, you can be sure that your roof replacement contractors will pay attention to detail. We take cleanliness seriously, and we always leave the worksite in excellent condition. We won&rsquo;t park in your driveway or disrupt your normal daily activities unnecessarily.&nbsp; Furthermore, we complete most jobs in one day and offer a 10-year labor and materials warranty.\r\n</p>\r\n\r\n<blockquote><p>\r\n  We&rsquo;re so confident in our work that we never charge an upfront fee, and we&rsquo;ll return if there&rsquo;s something we need to fix.\r\n</p>\r\n</blockquote>\r\n\r\n<h2>I Need Roof Replacement Near Me in Denver, CO and Surrounding Areas</h2>\r\n\r\n<p>\r\n  You can finally stop searching for &ldquo;roof replacement near me&rdquo; or other <a href="https://elementext.com/">roofing companies</a> now that you&rsquo;ve found Element Exteriors. We can handle all your roofing problems with the greatest efficiency. We&#39;re located in Englewood, CO and serve Denver, Centennial, Thornton, Parker, and Castlerock, CO. Call us today at 303-747-3706 to get a free estimate and end your search for &ldquo;roof replacement near me.&rdquo;\r\n</p>\r\n	2	2019-10-28 06:27:52.924699+00		Professional Roof Replacement Service in Denver, CO	residential	1	4	26	5	1	t
26	Roofing Contactors	denver-roofing-contractors	Element Exteriors are the roofing contractors of choice for residential and commercial projects. We construct and repair roofs and do ongoing maintenance. We offer the best customer service and only assign licensed workers for the job. We’re professional in every way.	<p>\r\n  Element Exteriors is the leading roofing company in Denver, Colorado. We are roofing contractors known for offering exceptional customer service and excellent products. We promise to deliver high-quality work using the best materials, no matter the scale or complexity of your residential project. We&rsquo;re so confident in our work as roofing contractors that you only pay after the job is completed, and you are satisfied.<strong> We offer a full range of <a href="/services/">roofing services</a> including:</strong>\r\n</p>\r\n\r\n<ul>\r\n  <li>\r\n    New roof construction\r\n  </li>\r\n  <li>\r\n    Roof replacement and maintenance\r\n  </li>\r\n  <li>\r\n    Roof repair after storm damage\r\n  </li>\r\n  <li>\r\n    Gutter services\r\n  </li>\r\n</ul>\r\n\r\n<p>\r\n  Element Exteriors works with the most popular roofing materials including:\r\n</p>\r\n\r\n<div class="columns">\r\n  <div class="column column-left">\r\n    <p>\r\n      Asphalt roofing\r\n    </p>\r\n\r\n    <p>\r\n      Tile roofs\r\n    </p>\r\n\r\n    <p>\r\n      Metal roofs\r\n    </p>\r\n\r\n    <p>\r\n      Specialty roofs\r\n    </p>\r\n  </div>\r\n\r\n  <div class="column column-right">\r\n    <p>\r\n      TPO roofing\r\n    </p>\r\n\r\n    <p>\r\n      PVC roofing\r\n    </p>\r\n\r\n    <p>\r\n      EPDM roofing\r\n    </p>\r\n\r\n    <p>\r\n      Modified bitumen roof\r\n    </p>\r\n  </div>\r\n</div>\r\n\r\n<p>\r\n  We also do interior and exterior painting.&nbsp;\r\n</p>\r\n\r\n<p class="page-images single-image">\r\n  <img alt="New roof installation by Denver Roofing contractor" data-crop="" data-description="SGlyZSUyMHRoZSUyMGJlc3QlMjByb29maW5nJTIwY29udHJhY3RvciUyMGluJTIwRGVudmVy" data-id="4" data-source="/media/page_photos/0000/photo_4.jpg?_=1562150443" height="576" sizes="100vw" src="/media/page_photos/0000/photo_4.normal.jpg" srcset="/media/page_photos/0000/photo_4.wide.jpg?_=1562150443 1024w, /media/page_photos/0000/photo_4.normal.jpg?_=1562150443 800w, /media/page_photos/0000/photo_4.mobile.jpg?_=1562150443 480w" title="Man installing new roof" width="1024" />\r\n</p>\r\n\r\n<h2>Benefit from Having Licensed Roofing Contractors on the Job</h2>\r\n\r\n<p>\r\n  Our licensed roofing contractors are true professionals. Most jobs are completed in just one day, so you don&rsquo;t have to wait weeks or even months for repairs or installations. Also, our <a href="/denver-residential-roofing/">residential roofing</a> company won&rsquo;t leave your premises until we&rsquo;ve cleaned up. Our CEO or general manager inspects most job sites to ensure the work has been completed properly.&nbsp;\r\n</p>\r\n\r\n<p>\r\n  Additionally, a third-party licensed inspector provides a final inspection for all commercial jobs. That&rsquo;s why we can offer a 10-year labor and material warranty. If anything goes wrong with your roof because of faulty workmanship, our licensed roofing contractors will fix the problem at no extra cost.\r\n</p>\r\n\r\n<p>\r\n  We are also highly experienced in dealing with insurance companies regarding storm restoration and weather-related insurance claims.&nbsp;\r\n</p>\r\n\r\n<p class="page-images single-image">\r\n  <img alt="New roof installation" data-crop="" data-id="6" data-source="/media/page_photos/0000/photo_6.jpg?_=1562150509" height="576" sizes="100vw" src="/media/page_photos/0000/photo_6.normal.jpg" srcset="/media/page_photos/0000/photo_6.wide.jpg?_=1562150509 1024w, /media/page_photos/0000/photo_6.normal.jpg?_=1562150509 800w, /media/page_photos/0000/photo_6.mobile.jpg?_=1562150509 480w" title="Man working on a roof" width="1024" />\r\n</p>\r\n\r\n<h2>I&rsquo;m Looking for Roofing Contractors in My Area Near Denver&nbsp;</h2>\r\n\r\n<p>\r\n  If you need roofing services, you may be asking &ldquo;where can I find roofing contractors in my area?&rdquo; Element Exteriors is based in Englewood, CO, but we also serve Denver, CO; Centennial, CO; Thornton, CO; Parker, CO; and Castlerock, CO. We are not like your average residential and commercial <a href="https://elementext.com/">roofing companies</a>. When you call us or send a message through our website, an inspection will be arranged within 24 hours. Your estimate will be ready in one to two days after the onsite visit. Don&rsquo;t look any further for &ldquo;roofing contractors in my area.&rdquo; Simply call us to learn how we can help you.\r\n</p>\r\n	0	2019-10-28 05:09:28.178465+00	./background_26_AEjT65a.jpg	We’re Colorado’s First Choice for Roofing Contractors in Denver	residential	0	1	\N	14	1	t
24	PVC roofing	pvc-roofing	PVC roofing installation holds no secrets for  licensed, experienced, and dedicated roofing contractors like Element Exteriors, reputed professionals who have been serving the home and business owners in Denver area for years	<p>\r\n  Are you looking for solutions to cover your commercial building? Then PVC roofing could be a worthwhile option. PVC has become one of the most popular <a href="https://elementext.com/denver-commercial-roofing/">commercial roofing</a> alternatives in Colorado, and for all the right reasons.&nbsp;\r\n</p>\r\n\r\n<p>\r\n  As you may already know, PVC stands for polyvinyl chloride, a type of thermoplastic that withstands temperature fluctuations, humidity, and punctures. The PVC roofing material is basically a membrane or a panel that has all the above properties and brings about several valuable benefits:&nbsp;\r\n</p>\r\n\r\n<div class="columns">\r\n  <div class="column column-left">\r\n    <p>\r\n      Durability\r\n    </p>\r\n\r\n    <p>\r\n      Watertight\r\n    </p>\r\n\r\n    <p>\r\n      Long lifespan\r\n    </p>\r\n\r\n    <p>\r\n      Low maintenance\r\n    </p>\r\n  </div>\r\n\r\n  <div class="column column-right">\r\n    <p>\r\n      Environmentally friendly\r\n    </p>\r\n\r\n    <p>\r\n      Resistance to chemicals\r\n    </p>\r\n\r\n    <p>\r\n      Resistance to fire\r\n    </p>\r\n\r\n    <p>\r\n      Resistance to&nbsp;temperature fluctuations\r\n    </p>\r\n  </div>\r\n</div>\r\n\r\n<p>\r\n  The key to enjoying all these benefits and more is to work with licensed and experienced PVC roofing contractors. Any mistakes performed during the installation process could affect the roof&rsquo;s lifespan and performance, so it is vital that you work with professionals like Element Exteriors.&nbsp;\r\n</p>\r\n\r\n<h2>Why Choose Our PVC Roofing Installation Services?&nbsp;</h2>\r\n\r\n<p>\r\n  The PVC roofing installation process is anything but simple. It requires careful preparation of the support layer, accurate measurements and cuts, inspired choice of tools and materials, knowhow, skills, and attention to detail. At Element Exteriors, we have all that and more.&nbsp;\r\n</p>\r\n\r\n<p>\r\n  Our roofing specialists have long years of working with PVC and have handled numerous commercial projects of various sizes and complexities. We have the skills, knowledge, experience, and equipment required to successfully complete your PVC roofing installation project.&nbsp;\r\n</p>\r\n\r\n<blockquote><p>\r\n  With our one-decade warranty on both materials and labor, you can rest assured that your new roof will look and perform flawlessly for years to come.\r\n</p>\r\n</blockquote>\r\n\r\n<h2>Contact the Best PVC Roofing Contractors in Denver, CO, Area</h2>\r\n\r\n<p>\r\n  The best way to assess if PVC is the right solution for your roof and what costs using it would imply is to contact PVC <a href="/">roofing contractors</a>. Having served home and business owners in Denver, Centennial, Englewood, Thornton, Castle Rock, and Parker, CO, for years, our company is one of the best roofing companies in the area and your best option. Contact us online or by calling (303) 747-3706 to benefit from our professional PVC roofing contractors&rsquo; advice!\r\n</p>\r\n	11	2020-01-10 06:10:37.821051+00		PVC Roofing Solutions for Denver, CO, Commercial Buildings	construction	1	4	2	5	3	t
5	Windows & Doors	denver-doors-windows-contractors		<p>\r\n  Windows are more than just panes of glass. They have the power to transform the way you live. They are paramount to maintaining your homes energy efficiency. Our Denver window installer is the best in the business, offering quality installation of your new windows at a great price.\r\n</p>\r\n	15	2019-10-23 05:58:55.566259+00		Windows & Doors - Element Exteriors	windows	0	1	\N	2	6	f
32	Interior Painting	interior-painting	Hiring professional interior house painters offers a variety of benefits. These include a better finish, less mess, no hassle, and a job done well. Let us handle the stress and provide you with top-notch interior painting	<p>\r\n  If your home&rsquo;s indoor paint is chipped, faded, or simply boring, it&rsquo;s time for an upgrade. A fresh coat of paint can liven up your interior spaces. It also gives the indoors an all-new look and feel. Sure, you can take the do-it-yourself approach to interior painting. However, if you want a perfect paint job, it&rsquo;s best to contact professional <a href="https://elementext.com/denver-painting-contractors/">painting contractors</a>.\r\n</p>\r\n\r\n<p>\r\n  Element Exteriors is one of the best interior painting companies in Denver, CO. We also service Centennial, CO; Parker, CO; Castlerock, CO; and Thornton, CO. Here are some of the features that make stand out from other contractors:\r\n</p>\r\n\r\n<ul>\r\n  <li>\r\n    Quick Turnaround. We offer free inspection within 24 hours and a preliminary complimentary quote within 48 hours. We also complete most paint jobs in a day.\r\n  </li>\r\n  <li>\r\n    Inspection Resources. If you&rsquo;ve already hired another company to do the inspection, we can provide them with materials.&nbsp;\r\n  </li>\r\n  <li>\r\n    Familiar with Insurance Claims. We work with most insurance companies. If your home has paint or structural damage caused by a storm, we can help make your case insurance inspectors.\r\n  </li>\r\n</ul>\r\n\r\n<p class="page-images single-image">\r\n  <img alt="" data-crop="" data-id="28" data-source="/media/page_photos/0000/photo_28.jpg?_=1574681813" height="576" sizes="100vw" src="/media/page_photos/0000/photo_28.normal.jpg" srcset="/media/page_photos/0000/photo_28.wide.jpg?_=1574681813 1024w, /media/page_photos/0000/photo_28.normal.jpg?_=1574681813 800w, /media/page_photos/0000/photo_28.mobile.jpg?_=1574681813 480w" width="1024" />\r\n</p>\r\n\r\n<h2>Why Choose Our Interior House Painters</h2>\r\n\r\n<blockquote><p>\r\n  When you hire our interior house painters, you will receive a perfect, professional job. We always use tarps so that the paint doesn&rsquo;t leave any mess in your home. Best of all, our interior house painters use only the highest-quality materials. We specifically choose paints and materials that can best withstand Colorado weather.\r\n</p>\r\n</blockquote>\r\n\r\n<p>\r\n  We also take pride in offering incredibly affordable services. Actual interior painting costs may vary from project to project depending on the home size, style, location, and other factors. However, you can be sure that our prices are the best, considering the final product we deliver.&nbsp;\r\n</p>\r\n\r\n<h2>I Need to Find Interior Painters Near Me&nbsp;</h2>\r\n\r\n<p>\r\n  If you live in Denver, CO or surrounding areas and are tired of endless searches for &ldquo;quality interior painters near me,&rdquo; we are the ones to contact. We are the leading <a href="https://elementext.com/">home improvement company</a> in Colorado offering interior painting services in Denver, CO; Thornton, CO; Parker, CO; Centennial, CO; and Castlerock, CO. Give us a call today at 303-747-3706 to get a free estimate.\r\n</p>\r\n	18	2019-11-25 11:36:58.35074+00		Benefits of Professional Interior Painting Services in Denver, CO	residential	1	4	6	5	7	t
6	Painting	denver-painting-contractors	We are your local painting contractor that can handle all your painting needs as quickly as possible. Our professional services cover exterior, interior, and commercial painting. We only use high-quality products to ensure the durability of the paint job.\n	<p>\r\n  If painting a house sounds like a headache for you, hiring a Professional Painting Contractor can be the relief you need. Element Exteriors is a Local Painting Contractor serving residents and businesses in the Denver Metro area. We excel in Commercial and Residential Painting, and our testimonials are the best proof. Our <a href="/services/">home improvement services</a> are designed to make your renovation project smooth and hassle-free.\r\n</p>\r\n\r\n<p class="page-images single-image">\r\n  <img alt="Work performed by painting contractor" data-crop="" data-id="22" data-source="/media/page_photos/0000/photo_22.jpg?_=1572257291" height="576" sizes="100vw" src="/media/page_photos/0000/photo_22.normal.jpg" srcset="/media/page_photos/0000/photo_22.wide.jpg?_=1572257291 1024w, /media/page_photos/0000/photo_22.normal.jpg?_=1572257291 800w, /media/page_photos/0000/photo_22.mobile.jpg?_=1572257291 480w" title="Man painting exterior part of a house" width="1024" />\r\n</p>\r\n\r\n<h2>What to Expect From Our Residential Painting Services</h2>\r\n\r\n<p>\r\n  Element Exteriors is dedicated to providing Residential Painting Services, including interior painting, exterior painting, and staining, at an unmatched level. We offer our customers superior Painting Service - from preparation to cleanup - to deliver an effortless and seamless painting experience. Moreover, our CEO or GM will be on the job site to oversee your project from start to finish, and they are always ready to answer any questions or concerns you may have.\r\n</p>\r\n\r\n<h2>Professional House Painters and Commercial Painting Contractor</h2>\r\n\r\n<p>\r\n  If you are planning a home renovation, or want to sell your property for a peak price, leave this job to the professional house painters of Element Exteriors. Many homeowners can paint their houses themselves. However, experts with the know-how, experience, and equipment, can accomplish the project in a timely and professional manner. Not only are we trained house painters, but we are also a Commercial Painting Contractor, so we can provide all of the labor needed and quality work to enhance your business space. Element Exteriors can take care of all your residential or Commercial Painting needs.\r\n</p>\r\n\r\n<h2>Residential Painters Near Me in Denver, CO</h2>\r\n\r\n<p>\r\n  If you are searching &quot;Painters near me&quot; in Denver, CO, look no further than Element Exteriors. We are fully licensed, trained, and insured. Our company only offers top-notch products and professional equipment to ensure the best results; we&rsquo;ll complete the job in the shortest possible time. Our services are available all along the i25 corridor from North Denver to Colorado Springs. Contact us today at 303-747-3706 for a free estimate.\r\n</p>\r\n	16	2019-10-28 10:10:20.055309+00	./background_6.jpg	Commercial and Residential Painting Contractors in the Denver Metro Area	residential	0	1	\N	6	7	t
\.


--
-- Name: services_service_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.services_service_id_seq', 38, true);


--
-- Data for Name: services_servicesblock; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.services_servicesblock (attachableblock_ptr_id, header) FROM stdin;
11	
\.


--
-- Data for Name: services_servicesconfig; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.services_servicesconfig (id, header, updated, background, description, text, title, visible) FROM stdin;
1	Quality Roofing Services in Denver, CO	2019-10-28 13:17:35.064053+00	./background_1_SOs9wim.jpg	Element Exteriors specializes in exterior storm damage repair and offers superior one-stop roofing services. Whatever the damage is, our experienced specialists will restore the integrity of your roof in no time to give you peace of mind.	<p>\r\n  &nbsp;\r\n</p>\r\n\r\n<p>\r\n  Severe hail storms and violent weather in Colorado increase the demand for exterior repair and roofing services. Blown off shingles, crashed gutters, and leaks are common roof problems in the Denver Metro area that should be addressed by licensed specialists. Moreover, exterior home improvements call for big investments; therefore, hiring experts can guarantee quality work and a long-lasting product to give you peace of mind. If you&rsquo;ve encountered roofing damage, call in the professionals of Element Exteriors. We will meticulously inspect every inch of your roofing system to give you the best solution. Our <a href="/">Roofing Company</a> provides repair and maintenance for residential and commercial properties. Whether you have a leaky roof, damaged or missing shingles, rotted wood, or major structural damage, you can always rely on our professional roofing services.\r\n</p>\r\n\r\n<p class="page-images single-image">\r\n  <img alt="Roofing services performed by expert" data-crop="" data-description="RWxlbWVudCUyMEV4dGVyaW9ycyUyMHdpbGwlMjBoZWxwJTIwd2l0aCUyMGFsbCUyMHlvdXIlMjByb29maW5nJTIwcHJvYmxlbXM=" data-id="18" data-source="/media/page_photos/0000/photo_18.jpg?_=1572256078" height="576" sizes="100vw" src="/media/page_photos/0000/photo_18.normal.jpg" srcset="/media/page_photos/0000/photo_18.wide.jpg?_=1572256078 1024w, /media/page_photos/0000/photo_18.normal.jpg?_=1572256078 800w, /media/page_photos/0000/photo_18.mobile.jpg?_=1572256078 480w" title="Man installing a roof for a residential building" width="1024" />\r\n</p>\r\n\r\n<h2>Professional Roofing Services: One-day Repair and Re-Roofing</h2>\r\n\r\n<p>\r\n  One of the most common signs that you need professional roofing services is a roof leak. Element Exteriors is a local roofing company that specializes in residential roof repair and maintenance. We are trained and can get your roof repaired in one day. We use tarps to keep your yard clean. Furthermore, we don&rsquo;t request upfront payment for your exterior home improvement; you pay after the job is finished, and you are satisfied with the results. We also offer 10-year labor and material warranty, so we can come back and fix any problems, if needed. We work with major types of roofing that include:\r\n</p>\r\n\r\n<div class="columns">\r\n  <div class="column column-left">\r\n    <p>\r\n      Asphalt\r\n    </p>\r\n\r\n    <p>\r\n      Tile\r\n    </p>\r\n\r\n    <p>\r\n      Metal\r\n    </p>\r\n\r\n    <p>\r\n      Specialty\r\n    </p>\r\n  </div>\r\n\r\n  <div class="column column-right">\r\n    <p>\r\n      TPO\r\n    </p>\r\n\r\n    <p>\r\n      PVC\r\n    </p>\r\n\r\n    <p>\r\n      EPDM\r\n    </p>\r\n\r\n    <p>\r\n      Modified bitumen\r\n    </p>\r\n  </div>\r\n</div>\r\n\r\n<p>\r\n  Element Exteriors provides professional residential and commercial roofing services at affordable prices. We offer new roof construction, roof replacement and maintenance, roof repair after damages, interior and exterior painting, and gutters services.\r\n</p>\r\n\r\n<h2>What Are the Best Roofing Services Near Me?</h2>\r\n\r\n<p>\r\n  When searching &ldquo;residential roofing services near me&rdquo; in Denver, CO, look no further than Element Exteriors. We offer one-day job completion, job site cleanup, high-quality materials, and warranties. We can also walk you through the insurance claims process to get you the loss statement. Our service area includes Englewood, Denver, Centennial, Thornton, Parker, and Castlerock, CO. We will carry out your home improvement project in a professional and timely manner. Call us today at 303-747-3706 to get a free estimate.\r\n</p>\r\n\r\n<p>\r\n  <br />\r\n  &nbsp;\r\n</p>\r\n	Services	t
\.


--
-- Name: services_servicesconfig_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.services_servicesconfig_id_seq', 1, true);


--
-- Data for Name: social_networks_feedpost; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.social_networks_feedpost (id, network, text, url, scheduled, object_id, created, posted, content_type_id) FROM stdin;
\.


--
-- Name: social_networks_feedpost_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.social_networks_feedpost_id_seq', 1, false);


--
-- Data for Name: social_networks_socialconfig; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.social_networks_socialconfig (id, google_apikey, twitter_client_id, twitter_client_secret, twitter_access_token, twitter_access_token_secret, facebook_access_token, linkedin_access_token, instagram_client_id, instagram_client_secret, instagram_access_token, updated, linkedin_client_secret, linkedin_client_id, facebook_client_id, facebook_client_secret) FROM stdin;
1	AIzaSyCxRpeT6jnFIfeCwlZPK7YQaEixHC_h2g8										2020-05-01 22:53:47.269984+00				
\.


--
-- Name: social_networks_socialconfig_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.social_networks_socialconfig_id_seq', 1, true);


--
-- Data for Name: social_networks_sociallinks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.social_networks_sociallinks (id, social_facebook, social_twitter, social_google, updated, social_instagram, social_linkedin, social_yelp, social_youtube) FROM stdin;
1	https://www.facebook.com/ElementExteriorsinc/			2019-04-25 11:21:30.445+00		https://www.linkedin.com/company/element-exteriors/	https://www.yelp.com/biz/element-exteriors-englewood	
\.


--
-- Name: social_networks_sociallinks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.social_networks_sociallinks_id_seq', 1, true);


--
-- Data for Name: testimonials_testimonial; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.testimonials_testimonial (id, rating, author, text, visible, sort_order) FROM stdin;
1	5	Diane Weston - Denver, CO	Job Well Done! Very clean.\nThey showed up bright and early as promised. I think everything went well. The roof looks good and really adds a nice touch of curb appeal. Thanks to Element Exteriors for a job well done!	t	0
2	5	Chan Yang - Lakewood, CO	Great Job. A+ \nWe wanted to submit this review because we put a lot of trust in Element Exteriors and they did an amazing job. From start to finish, the people at Element were excellent.	t	1
3	5	Bob Kraft - Wheat Ridge, CO	Roof looks great!\nJob well done. Quick and clean, not much more you can ask for.	t	2
4	5	Jason Slaughter - Denver, CO	Very pleasant experience!\nA friend referred me to Element after they had some work done after the storm. Very pleasant experience. Our roof & siding look great!	t	3
5	5	Jack Davis - Denver, CO	Really Nice Job, Looks Great!\nThe Roofing and siding work is perfect and the guys had to work through some very hot days last Summer to get it done. They were fast and Efficient. If we would need any further work, I will use them again.	t	4
6	5	Bradley Johnson - Wheat Ridge, CO	Highly recommend. \nTravis & Kyle were excellent to work with...service doesn't get any better. We had a re-roof, new gutters and new skylight. All done in a very professional manner and quality results. I would highly recommend Element Exteriors.	t	5
7	5	Shannon Davis	Christian and Travis are awesome to work with. The recent storms somehow blew snow into our attic dormer. Travis came out on a Saturday to conduct an inspection of the roof condition and locate the issue. Above that, he let me know that I had mild hail damage which didn't warrant repair, just knowing about. Definitely recommend this crew as both Christian and Travis treat you like family.	t	6
\.


--
-- Name: testimonials_testimonial_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.testimonials_testimonial_id_seq', 7, true);


--
-- Data for Name: testimonials_testimonialsblock; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.testimonials_testimonialsblock (attachableblock_ptr_id, header) FROM stdin;
4	Testimonials
\.


--
-- Data for Name: users_customuser; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users_customuser (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined, avatar, avatar_crop) FROM stdin;
2	pbkdf2_sha256$20000$DRo0lRvwHfnh$32/57X/KypuxciWJrzMSJRTFtdQebZdQr2OTzvV3er0=	2019-12-30 06:22:21.522707+00	t	seo				t	t	2019-04-26 07:26:40.176402+00		
3	pbkdf2_sha256$20000$pFU60lwGnjUj$hek+g8TD9zMEQ+YR2deKc2j9jNPwW7FzVo6zAygMEi0=	2020-01-22 21:26:29.197978+00	f	elementext				t	t	2019-04-26 07:27:03.125186+00		
1	pbkdf2_sha256$20000$0jTDA0s5hMWd$kI/+NW7vBU6g0oc5rA2UX3WS+AGe8sh/N03GYtzhOx0=	2024-01-23 18:30:06.260817+00	t	dladmin				t	t	2019-02-13 12:28:07.075+00		
\.


--
-- Data for Name: users_customuser_groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users_customuser_groups (id, customuser_id, group_id) FROM stdin;
1	3	1
\.


--
-- Name: users_customuser_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_customuser_groups_id_seq', 1, true);


--
-- Name: users_customuser_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_customuser_id_seq', 3, true);


--
-- Data for Name: users_customuser_user_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users_customuser_user_permissions (id, customuser_id, permission_id) FROM stdin;
\.


--
-- Name: users_customuser_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_customuser_user_permissions_id_seq', 1, false);


--
-- Data for Name: work_galleryimageservice; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.work_galleryimageservice (galleryitembase_ptr_id, image, image_crop, image_alt) FROM stdin;
1	0000/0001.jpg		
2	0000/0002.jpg		
3	0000/0003.jpg		
4	0000/0004.jpg		
5	0000/0005.jpg		
6	0000/0006.jpg		
7	0000/0007.jpg		
8	0000/0008.jpg		
\.


--
-- Data for Name: work_galleryservice; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.work_galleryservice (id) FROM stdin;
1
\.


--
-- Name: work_galleryservice_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.work_galleryservice_id_seq', 1, true);


--
-- Data for Name: work_workpageconfig; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.work_workpageconfig (id, title, header, description, background, visible, updated, text, gallery_id) FROM stdin;
1	Our Work	Our Work – Element Exteriors	We put the same emphasis on quality work and customer satisfaction in our jobs. 	./background_1_IRK0ReL.jpg	f	2019-12-06 06:51:50.489653+00	<p>\r\n  At Element Exteriors, we are proud of the work we have done.\r\n</p>\r\n	1
\.


--
-- Name: work_workpageconfig_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.work_workpageconfig_id_seq', 1, true);


--
-- Name: about_aboutblock about_aboutblock_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.about_aboutblock
    ADD CONSTRAINT about_aboutblock_pkey PRIMARY KEY (attachableblock_ptr_id);


--
-- Name: about_aboutpageconfig about_aboutpageconfig_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.about_aboutpageconfig
    ADD CONSTRAINT about_aboutpageconfig_pkey PRIMARY KEY (id);


--
-- Name: attachable_blocks_attachableblock attachable_blocks_attachableblock_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attachable_blocks_attachableblock
    ADD CONSTRAINT attachable_blocks_attachableblock_pkey PRIMARY KEY (id);


--
-- Name: attachable_blocks_attachablereference attachable_blocks_attachablereference_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attachable_blocks_attachablereference
    ADD CONSTRAINT attachable_blocks_attachablereference_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_key UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission auth_permission_content_type_id_codename_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_key UNIQUE (content_type_id, codename);


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: ckeditor_pagefile ckeditor_pagefile_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ckeditor_pagefile
    ADD CONSTRAINT ckeditor_pagefile_pkey PRIMARY KEY (id);


--
-- Name: ckeditor_pagephoto ckeditor_pagephoto_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ckeditor_pagephoto
    ADD CONSTRAINT ckeditor_pagephoto_pkey PRIMARY KEY (id);


--
-- Name: ckeditor_simplephoto ckeditor_simplephoto_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ckeditor_simplephoto
    ADD CONSTRAINT ckeditor_simplephoto_pkey PRIMARY KEY (id);


--
-- Name: config_config config_config_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_config
    ADD CONSTRAINT config_config_pkey PRIMARY KEY (id);


--
-- Name: contacts_address contacts_address_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contacts_address
    ADD CONSTRAINT contacts_address_pkey PRIMARY KEY (id);


--
-- Name: contacts_contactblock contacts_contactblock_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contacts_contactblock
    ADD CONSTRAINT contacts_contactblock_pkey PRIMARY KEY (attachableblock_ptr_id);


--
-- Name: contacts_contactsconfig contacts_contactsconfig_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contacts_contactsconfig
    ADD CONSTRAINT contacts_contactsconfig_pkey PRIMARY KEY (id);


--
-- Name: contacts_estimateblock contacts_estimateblock_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contacts_estimateblock
    ADD CONSTRAINT contacts_estimateblock_pkey PRIMARY KEY (attachableblock_ptr_id);


--
-- Name: contacts_message contacts_message_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contacts_message
    ADD CONSTRAINT contacts_message_pkey PRIMARY KEY (id);


--
-- Name: contacts_notificationreceiver contacts_notificationreceiver_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contacts_notificationreceiver
    ADD CONSTRAINT contacts_notificationreceiver_pkey PRIMARY KEY (id);


--
-- Name: contacts_openinghours contacts_openinghours_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contacts_openinghours
    ADD CONSTRAINT contacts_openinghours_pkey PRIMARY KEY (id);


--
-- Name: contacts_phonenumber contacts_phonenumber_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contacts_phonenumber
    ADD CONSTRAINT contacts_phonenumber_pkey PRIMARY KEY (id);


--
-- Name: django_admin_log django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type django_content_type_app_label_74e2904cd5190364_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_74e2904cd5190364_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_cron_cronjoblog django_cron_cronjoblog_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_cron_cronjoblog
    ADD CONSTRAINT django_cron_cronjoblog_pkey PRIMARY KEY (id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: django_site django_site_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_site
    ADD CONSTRAINT django_site_pkey PRIMARY KEY (id);


--
-- Name: gallery_galleryitembase gallery_galleryitembase_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gallery_galleryitembase
    ADD CONSTRAINT gallery_galleryitembase_pkey PRIMARY KEY (id);


--
-- Name: google_maps_mapandaddress google_maps_mapandaddress_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.google_maps_mapandaddress
    ADD CONSTRAINT google_maps_mapandaddress_pkey PRIMARY KEY (id);


--
-- Name: insurance_insuranceblock insurance_insuranceblock_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.insurance_insuranceblock
    ADD CONSTRAINT insurance_insuranceblock_pkey PRIMARY KEY (attachableblock_ptr_id);


--
-- Name: insurance_insurancepageconfig insurance_insurancepageconfig_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.insurance_insurancepageconfig
    ADD CONSTRAINT insurance_insurancepageconfig_pkey PRIMARY KEY (id);


--
-- Name: insurance_insurancestep insurance_insurancestep_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.insurance_insurancestep
    ADD CONSTRAINT insurance_insurancestep_pkey PRIMARY KEY (id);


--
-- Name: licenses_license licenses_license_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.licenses_license
    ADD CONSTRAINT licenses_license_pkey PRIMARY KEY (id);


--
-- Name: licenses_license licenses_license_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.licenses_license
    ADD CONSTRAINT licenses_license_slug_key UNIQUE (slug);


--
-- Name: licenses_licensesblock licenses_licensesblock_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.licenses_licensesblock
    ADD CONSTRAINT licenses_licensesblock_pkey PRIMARY KEY (attachableblock_ptr_id);


--
-- Name: licenses_licensespageconfig licenses_licensespageconfig_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.licenses_licensespageconfig
    ADD CONSTRAINT licenses_licensespageconfig_pkey PRIMARY KEY (id);


--
-- Name: main_advantage main_advantage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.main_advantage
    ADD CONSTRAINT main_advantage_pkey PRIMARY KEY (id);


--
-- Name: main_advantagesblock main_advantagesblock_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.main_advantagesblock
    ADD CONSTRAINT main_advantagesblock_pkey PRIMARY KEY (attachableblock_ptr_id);


--
-- Name: main_mainpageconfig main_mainpageconfig_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.main_mainpageconfig
    ADD CONSTRAINT main_mainpageconfig_pkey PRIMARY KEY (id);


--
-- Name: main_member main_member_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.main_member
    ADD CONSTRAINT main_member_pkey PRIMARY KEY (id);


--
-- Name: main_membersblock main_membersblock_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.main_membersblock
    ADD CONSTRAINT main_membersblock_pkey PRIMARY KEY (attachableblock_ptr_id);


--
-- Name: main_recoveryblock main_recoveryblock_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.main_recoveryblock
    ADD CONSTRAINT main_recoveryblock_pkey PRIMARY KEY (attachableblock_ptr_id);


--
-- Name: main_step main_step_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.main_step
    ADD CONSTRAINT main_step_pkey PRIMARY KEY (id);


--
-- Name: main_stepsblock main_stepsblock_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.main_stepsblock
    ADD CONSTRAINT main_stepsblock_pkey PRIMARY KEY (attachableblock_ptr_id);


--
-- Name: offers_offer offers_offer_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offers_offer
    ADD CONSTRAINT offers_offer_pkey PRIMARY KEY (id);


--
-- Name: rating_ratingvote rating_ratingvote_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rating_ratingvote
    ADD CONSTRAINT rating_ratingvote_pkey PRIMARY KEY (id);


--
-- Name: seo_counter seo_counter_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.seo_counter
    ADD CONSTRAINT seo_counter_pkey PRIMARY KEY (id);


--
-- Name: seo_redirect seo_redirect_old_path_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.seo_redirect
    ADD CONSTRAINT seo_redirect_old_path_key UNIQUE (old_path);


--
-- Name: seo_redirect seo_redirect_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.seo_redirect
    ADD CONSTRAINT seo_redirect_pkey PRIMARY KEY (id);


--
-- Name: seo_seoconfig seo_seoconfig_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.seo_seoconfig
    ADD CONSTRAINT seo_seoconfig_pkey PRIMARY KEY (id);


--
-- Name: seo_seodata seo_seodata_content_type_id_2396d7d1068dd7f0_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.seo_seodata
    ADD CONSTRAINT seo_seodata_content_type_id_2396d7d1068dd7f0_uniq UNIQUE (content_type_id, object_id);


--
-- Name: seo_seodata seo_seodata_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.seo_seodata
    ADD CONSTRAINT seo_seodata_pkey PRIMARY KEY (id);


--
-- Name: services_service services_service_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.services_service
    ADD CONSTRAINT services_service_pkey PRIMARY KEY (id);


--
-- Name: services_service services_service_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.services_service
    ADD CONSTRAINT services_service_slug_key UNIQUE (slug);


--
-- Name: services_servicesblock services_servicesblock_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.services_servicesblock
    ADD CONSTRAINT services_servicesblock_pkey PRIMARY KEY (attachableblock_ptr_id);


--
-- Name: services_servicesconfig services_servicesconfig_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.services_servicesconfig
    ADD CONSTRAINT services_servicesconfig_pkey PRIMARY KEY (id);


--
-- Name: social_networks_feedpost social_networks_feedpost_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_networks_feedpost
    ADD CONSTRAINT social_networks_feedpost_pkey PRIMARY KEY (id);


--
-- Name: social_networks_socialconfig social_networks_socialconfig_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_networks_socialconfig
    ADD CONSTRAINT social_networks_socialconfig_pkey PRIMARY KEY (id);


--
-- Name: social_networks_sociallinks social_networks_sociallinks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_networks_sociallinks
    ADD CONSTRAINT social_networks_sociallinks_pkey PRIMARY KEY (id);


--
-- Name: testimonials_testimonial testimonials_testimonial_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.testimonials_testimonial
    ADD CONSTRAINT testimonials_testimonial_pkey PRIMARY KEY (id);


--
-- Name: testimonials_testimonialsblock testimonials_testimonialsblock_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.testimonials_testimonialsblock
    ADD CONSTRAINT testimonials_testimonialsblock_pkey PRIMARY KEY (attachableblock_ptr_id);


--
-- Name: users_customuser_groups users_customuser_groups_customuser_id_group_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_customuser_groups
    ADD CONSTRAINT users_customuser_groups_customuser_id_group_id_key UNIQUE (customuser_id, group_id);


--
-- Name: users_customuser_groups users_customuser_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_customuser_groups
    ADD CONSTRAINT users_customuser_groups_pkey PRIMARY KEY (id);


--
-- Name: users_customuser users_customuser_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_customuser
    ADD CONSTRAINT users_customuser_pkey PRIMARY KEY (id);


--
-- Name: users_customuser_user_permissions users_customuser_user_permissio_customuser_id_permission_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_customuser_user_permissions
    ADD CONSTRAINT users_customuser_user_permissio_customuser_id_permission_id_key UNIQUE (customuser_id, permission_id);


--
-- Name: users_customuser_user_permissions users_customuser_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_customuser_user_permissions
    ADD CONSTRAINT users_customuser_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: users_customuser users_customuser_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_customuser
    ADD CONSTRAINT users_customuser_username_key UNIQUE (username);


--
-- Name: work_galleryimageservice work_galleryimageservice_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_galleryimageservice
    ADD CONSTRAINT work_galleryimageservice_pkey PRIMARY KEY (galleryitembase_ptr_id);


--
-- Name: work_galleryservice work_galleryservice_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_galleryservice
    ADD CONSTRAINT work_galleryservice_pkey PRIMARY KEY (id);


--
-- Name: work_workpageconfig work_workpageconfig_gallery_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_workpageconfig
    ADD CONSTRAINT work_workpageconfig_gallery_id_key UNIQUE (gallery_id);


--
-- Name: work_workpageconfig work_workpageconfig_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_workpageconfig
    ADD CONSTRAINT work_workpageconfig_pkey PRIMARY KEY (id);


--
-- Name: attachable_blocks_attachab_content_type_id_133e4c66372971eb_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX attachable_blocks_attachab_content_type_id_133e4c66372971eb_idx ON public.attachable_blocks_attachablereference USING btree (content_type_id, object_id, set_name);


--
-- Name: attachable_blocks_attachableblock_59e355a7; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX attachable_blocks_attachableblock_59e355a7 ON public.attachable_blocks_attachableblock USING btree (content_type_id);


--
-- Name: attachable_blocks_attachablereference_417f1b1c; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX attachable_blocks_attachablereference_417f1b1c ON public.attachable_blocks_attachablereference USING btree (content_type_id);


--
-- Name: attachable_blocks_attachablereference_6781f319; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX attachable_blocks_attachablereference_6781f319 ON public.attachable_blocks_attachablereference USING btree (block_ct_id);


--
-- Name: attachable_blocks_attachablereference_7e53bca2; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX attachable_blocks_attachablereference_7e53bca2 ON public.attachable_blocks_attachablereference USING btree (block_id);


--
-- Name: auth_group_name_1ca95c3c2952df84_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_group_name_1ca95c3c2952df84_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_0e939a4f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_group_permissions_0e939a4f ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_8373b171; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_group_permissions_8373b171 ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_417f1b1c; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_permission_417f1b1c ON public.auth_permission USING btree (content_type_id);


--
-- Name: ckeditor_pagefile_51afcc4f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ckeditor_pagefile_51afcc4f ON public.ckeditor_pagefile USING btree (instance_id);


--
-- Name: ckeditor_pagephoto_51afcc4f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ckeditor_pagephoto_51afcc4f ON public.ckeditor_pagephoto USING btree (instance_id);


--
-- Name: ckeditor_simplephoto_51afcc4f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ckeditor_simplephoto_51afcc4f ON public.ckeditor_simplephoto USING btree (instance_id);


--
-- Name: contacts_notificationreceiver_d1738a90; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX contacts_notificationreceiver_d1738a90 ON public.contacts_notificationreceiver USING btree (config_id);


--
-- Name: contacts_openinghours_ea8e5d12; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX contacts_openinghours_ea8e5d12 ON public.contacts_openinghours USING btree (address_id);


--
-- Name: contacts_phonenumber_ea8e5d12; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX contacts_phonenumber_ea8e5d12 ON public.contacts_phonenumber USING btree (address_id);


--
-- Name: django_admin_log_417f1b1c; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX django_admin_log_417f1b1c ON public.django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_e8701ad4; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX django_admin_log_e8701ad4 ON public.django_admin_log USING btree (user_id);


--
-- Name: django_cron_cronjoblog_305d2889; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX django_cron_cronjoblog_305d2889 ON public.django_cron_cronjoblog USING btree (end_time);


--
-- Name: django_cron_cronjoblog_a05e4b70; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX django_cron_cronjoblog_a05e4b70 ON public.django_cron_cronjoblog USING btree (ran_at_time);


--
-- Name: django_cron_cronjoblog_c1336794; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX django_cron_cronjoblog_c1336794 ON public.django_cron_cronjoblog USING btree (code);


--
-- Name: django_cron_cronjoblog_c4d98dbd; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX django_cron_cronjoblog_c4d98dbd ON public.django_cron_cronjoblog USING btree (start_time);


--
-- Name: django_cron_cronjoblog_code_1b8ed02562e58802_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX django_cron_cronjoblog_code_1b8ed02562e58802_like ON public.django_cron_cronjoblog USING btree (code varchar_pattern_ops);


--
-- Name: django_cron_cronjoblog_code_2da7bed23889c78d_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX django_cron_cronjoblog_code_2da7bed23889c78d_idx ON public.django_cron_cronjoblog USING btree (code, is_success, ran_at_time);


--
-- Name: django_cron_cronjoblog_code_5c9a52c0ef66323d_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX django_cron_cronjoblog_code_5c9a52c0ef66323d_idx ON public.django_cron_cronjoblog USING btree (code, start_time);


--
-- Name: django_cron_cronjoblog_code_66245b3d703e80cc_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX django_cron_cronjoblog_code_66245b3d703e80cc_idx ON public.django_cron_cronjoblog USING btree (code, start_time, ran_at_time);


--
-- Name: django_session_de54fa62; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX django_session_de54fa62 ON public.django_session USING btree (expire_date);


--
-- Name: django_session_session_key_6e9840798fb21c3e_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX django_session_session_key_6e9840798fb21c3e_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: gallery_galleryitembase_417f1b1c; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX gallery_galleryitembase_417f1b1c ON public.gallery_galleryitembase USING btree (content_type_id);


--
-- Name: gallery_galleryitembase_7a31d283; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX gallery_galleryitembase_7a31d283 ON public.gallery_galleryitembase USING btree (self_type_id);


--
-- Name: gallery_galleryitembase_content_type_id_49d14060cbad362a_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX gallery_galleryitembase_content_type_id_49d14060cbad362a_idx ON public.gallery_galleryitembase USING btree (content_type_id, object_id);


--
-- Name: google_maps_mapandaddress_884d9804; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX google_maps_mapandaddress_884d9804 ON public.google_maps_mapandaddress USING btree (address);


--
-- Name: google_maps_mapandaddress_address_79a358e7830dd109_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX google_maps_mapandaddress_address_79a358e7830dd109_like ON public.google_maps_mapandaddress USING btree (address varchar_pattern_ops);


--
-- Name: insurance_insurancestep_d1738a90; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX insurance_insurancestep_d1738a90 ON public.insurance_insurancestep USING btree (config_id);


--
-- Name: licenses_license_slug_59fdb1bb908d37df_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX licenses_license_slug_59fdb1bb908d37df_like ON public.licenses_license USING btree (slug varchar_pattern_ops);


--
-- Name: main_advantage_d1738a90; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX main_advantage_d1738a90 ON public.main_advantage USING btree (config_id);


--
-- Name: main_member_d1738a90; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX main_member_d1738a90 ON public.main_member USING btree (config_id);


--
-- Name: main_step_d1738a90; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX main_step_d1738a90 ON public.main_step USING btree (config_id);


--
-- Name: rating_ratingvote_5fc73231; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX rating_ratingvote_5fc73231 ON public.rating_ratingvote USING btree (date);


--
-- Name: seo_counter_position_761cc6a2a88811e_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX seo_counter_position_761cc6a2a88811e_like ON public.seo_counter USING btree ("position" varchar_pattern_ops);


--
-- Name: seo_counter_position_761cc6a2a88811e_uniq; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX seo_counter_position_761cc6a2a88811e_uniq ON public.seo_counter USING btree ("position");


--
-- Name: seo_redirect_old_path_755dd1f5fa85912b_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX seo_redirect_old_path_755dd1f5fa85912b_like ON public.seo_redirect USING btree (old_path varchar_pattern_ops);


--
-- Name: seo_seodata_417f1b1c; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX seo_seodata_417f1b1c ON public.seo_seodata USING btree (content_type_id);


--
-- Name: services_service_3cfbd988; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX services_service_3cfbd988 ON public.services_service USING btree (rght);


--
-- Name: services_service_656442a0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX services_service_656442a0 ON public.services_service USING btree (tree_id);


--
-- Name: services_service_6be37982; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX services_service_6be37982 ON public.services_service USING btree (parent_id);


--
-- Name: services_service_c9e9a848; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX services_service_c9e9a848 ON public.services_service USING btree (level);


--
-- Name: services_service_caf7cc51; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX services_service_caf7cc51 ON public.services_service USING btree (lft);


--
-- Name: services_service_slug_37cc2120422b7d6e_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX services_service_slug_37cc2120422b7d6e_like ON public.services_service USING btree (slug varchar_pattern_ops);


--
-- Name: social_networks_feedpost_417f1b1c; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX social_networks_feedpost_417f1b1c ON public.social_networks_feedpost USING btree (content_type_id);


--
-- Name: social_networks_feedpost_network_30fe5e3a2e7d1bcc_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX social_networks_feedpost_network_30fe5e3a2e7d1bcc_idx ON public.social_networks_feedpost USING btree (network, content_type_id, object_id);


--
-- Name: users_customuser_groups_0e939a4f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_customuser_groups_0e939a4f ON public.users_customuser_groups USING btree (group_id);


--
-- Name: users_customuser_groups_721e74b0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_customuser_groups_721e74b0 ON public.users_customuser_groups USING btree (customuser_id);


--
-- Name: users_customuser_user_permissions_721e74b0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_customuser_user_permissions_721e74b0 ON public.users_customuser_user_permissions USING btree (customuser_id);


--
-- Name: users_customuser_user_permissions_8373b171; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_customuser_user_permissions_8373b171 ON public.users_customuser_user_permissions USING btree (permission_id);


--
-- Name: users_customuser_username_65e4845bf1dc9f12_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_customuser_username_65e4845bf1dc9f12_like ON public.users_customuser USING btree (username varchar_pattern_ops);


--
-- Name: contacts_estimateblock D115c916950b9daa52fb8c571be71c26; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contacts_estimateblock
    ADD CONSTRAINT "D115c916950b9daa52fb8c571be71c26" FOREIGN KEY (attachableblock_ptr_id) REFERENCES public.attachable_blocks_attachableblock(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: about_aboutblock D3c0ff6fa3dd5b1f495a1be710808ace; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.about_aboutblock
    ADD CONSTRAINT "D3c0ff6fa3dd5b1f495a1be710808ace" FOREIGN KEY (attachableblock_ptr_id) REFERENCES public.attachable_blocks_attachableblock(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: main_advantagesblock D3f086793690257349eaa3cbd7b262cc; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.main_advantagesblock
    ADD CONSTRAINT "D3f086793690257349eaa3cbd7b262cc" FOREIGN KEY (attachableblock_ptr_id) REFERENCES public.attachable_blocks_attachableblock(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: main_membersblock D5013d99139bfabb7b9d819e0b980057; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.main_membersblock
    ADD CONSTRAINT "D5013d99139bfabb7b9d819e0b980057" FOREIGN KEY (attachableblock_ptr_id) REFERENCES public.attachable_blocks_attachableblock(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: services_servicesblock add989b1dee17b6a56b095a28411c491; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.services_servicesblock
    ADD CONSTRAINT add989b1dee17b6a56b095a28411c491 FOREIGN KEY (attachableblock_ptr_id) REFERENCES public.attachable_blocks_attachableblock(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: attachable_blocks_attachablereference atta_content_type_id_2532464b5d87b6e1_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attachable_blocks_attachablereference
    ADD CONSTRAINT atta_content_type_id_2532464b5d87b6e1_fk_django_content_type_id FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: attachable_blocks_attachableblock atta_content_type_id_7688c006bdd88f83_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attachable_blocks_attachableblock
    ADD CONSTRAINT atta_content_type_id_7688c006bdd88f83_fk_django_content_type_id FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: attachable_blocks_attachablereference attachab_block_ct_id_46e76bf8c7bb56ba_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attachable_blocks_attachablereference
    ADD CONSTRAINT attachab_block_ct_id_46e76bf8c7bb56ba_fk_django_content_type_id FOREIGN KEY (block_ct_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth__content_type_id_b75b643c222a340_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth__content_type_id_b75b643c222a340_fk_django_content_type_id FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissio_group_id_100829fc0ccfcc00_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_group_id_100829fc0ccfcc00_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permission_id_7514b0de978f0c4d_fk_auth_permission_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permission_id_7514b0de978f0c4d_fk_auth_permission_id FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: insurance_insuranceblock c1932d8e3a930c526da6c25c62e8faf2; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.insurance_insuranceblock
    ADD CONSTRAINT c1932d8e3a930c526da6c25c62e8faf2 FOREIGN KEY (attachableblock_ptr_id) REFERENCES public.attachable_blocks_attachableblock(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: attachable_blocks_attachablereference c427484883477fc558eb37731a57c59b; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attachable_blocks_attachablereference
    ADD CONSTRAINT c427484883477fc558eb37731a57c59b FOREIGN KEY (block_id) REFERENCES public.attachable_blocks_attachableblock(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: main_step c9d028a73af3b1011dc5d2bb5a694048; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.main_step
    ADD CONSTRAINT c9d028a73af3b1011dc5d2bb5a694048 FOREIGN KEY (config_id) REFERENCES public.main_stepsblock(attachableblock_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: main_stepsblock cbdadc1dd8eda517d59c3dfe434056ef; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.main_stepsblock
    ADD CONSTRAINT cbdadc1dd8eda517d59c3dfe434056ef FOREIGN KEY (attachableblock_ptr_id) REFERENCES public.attachable_blocks_attachableblock(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: insurance_insurancestep config_id_6d46bb82bdd70729_fk_insurance_insurancepageconfig_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.insurance_insurancestep
    ADD CONSTRAINT config_id_6d46bb82bdd70729_fk_insurance_insurancepageconfig_id FOREIGN KEY (config_id) REFERENCES public.insurance_insurancepageconfig(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: contacts_notificationreceiver contac_config_id_18e42156b007cd01_fk_contacts_contactsconfig_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contacts_notificationreceiver
    ADD CONSTRAINT contac_config_id_18e42156b007cd01_fk_contacts_contactsconfig_id FOREIGN KEY (config_id) REFERENCES public.contacts_contactsconfig(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: contacts_openinghours contacts_open_address_id_3f016ccfcc85bcc_fk_contacts_address_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contacts_openinghours
    ADD CONSTRAINT contacts_open_address_id_3f016ccfcc85bcc_fk_contacts_address_id FOREIGN KEY (address_id) REFERENCES public.contacts_address(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: contacts_phonenumber contacts_pho_address_id_3c10f04fa41a0c72_fk_contacts_address_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contacts_phonenumber
    ADD CONSTRAINT contacts_pho_address_id_3c10f04fa41a0c72_fk_contacts_address_id FOREIGN KEY (address_id) REFERENCES public.contacts_address(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: licenses_licensesblock d79963a653caa98c9a92a90e431101eb; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.licenses_licensesblock
    ADD CONSTRAINT d79963a653caa98c9a92a90e431101eb FOREIGN KEY (attachableblock_ptr_id) REFERENCES public.attachable_blocks_attachableblock(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: contacts_contactblock dcd5380829af4d07ddbcda55f6cd297f; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contacts_contactblock
    ADD CONSTRAINT dcd5380829af4d07ddbcda55f6cd297f FOREIGN KEY (attachableblock_ptr_id) REFERENCES public.attachable_blocks_attachableblock(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: testimonials_testimonialsblock dec5b5c0f27e01b7dcc3f0c6e368d4f6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.testimonials_testimonialsblock
    ADD CONSTRAINT dec5b5c0f27e01b7dcc3f0c6e368d4f6 FOREIGN KEY (attachableblock_ptr_id) REFERENCES public.attachable_blocks_attachableblock(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: main_recoveryblock dfc7a8779a54dcfd9f2aed5c46352f29; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.main_recoveryblock
    ADD CONSTRAINT dfc7a8779a54dcfd9f2aed5c46352f29 FOREIGN KEY (attachableblock_ptr_id) REFERENCES public.attachable_blocks_attachableblock(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log djan_content_type_id_352f9f9b41484bdb_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT djan_content_type_id_352f9f9b41484bdb_fk_django_content_type_id FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_user_id_b4dd00ed8f0dbcb_fk_users_customuser_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_b4dd00ed8f0dbcb_fk_users_customuser_id FOREIGN KEY (user_id) REFERENCES public.users_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: work_galleryimageservice f5432954ac6c314f0ade8e55ee28b491; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_galleryimageservice
    ADD CONSTRAINT f5432954ac6c314f0ade8e55ee28b491 FOREIGN KEY (galleryitembase_ptr_id) REFERENCES public.gallery_galleryitembase(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gallery_galleryitembase gall_content_type_id_2ed98bd61adebf7a_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gallery_galleryitembase
    ADD CONSTRAINT gall_content_type_id_2ed98bd61adebf7a_fk_django_content_type_id FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gallery_galleryitembase gallery_self_type_id_2e631f1c6975205d_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gallery_galleryitembase
    ADD CONSTRAINT gallery_self_type_id_2e631f1c6975205d_fk_django_content_type_id FOREIGN KEY (self_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: main_advantage main_advan_config_id_7bc548702ac63217_fk_main_mainpageconfig_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.main_advantage
    ADD CONSTRAINT main_advan_config_id_7bc548702ac63217_fk_main_mainpageconfig_id FOREIGN KEY (config_id) REFERENCES public.main_mainpageconfig(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: main_member main_membe_config_id_5148b5111cb5f4b4_fk_main_mainpageconfig_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.main_member
    ADD CONSTRAINT main_membe_config_id_5148b5111cb5f4b4_fk_main_mainpageconfig_id FOREIGN KEY (config_id) REFERENCES public.main_mainpageconfig(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: seo_seodata seo__content_type_id_480d03fc5a739ad4_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.seo_seodata
    ADD CONSTRAINT seo__content_type_id_480d03fc5a739ad4_fk_django_content_type_id FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: services_service services_servi_parent_id_843161a8debc48e_fk_services_service_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.services_service
    ADD CONSTRAINT services_servi_parent_id_843161a8debc48e_fk_services_service_id FOREIGN KEY (parent_id) REFERENCES public.services_service(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: social_networks_feedpost soci_content_type_id_554d921f37b03957_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_networks_feedpost
    ADD CONSTRAINT soci_content_type_id_554d921f37b03957_fk_django_content_type_id FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_customuser_groups users_cus_customuser_id_4dad08f3a9937472_fk_users_customuser_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_customuser_groups
    ADD CONSTRAINT users_cus_customuser_id_4dad08f3a9937472_fk_users_customuser_id FOREIGN KEY (customuser_id) REFERENCES public.users_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_customuser_user_permissions users_cust_customuser_id_bbd8fc43171ddbc_fk_users_customuser_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_customuser_user_permissions
    ADD CONSTRAINT users_cust_customuser_id_bbd8fc43171ddbc_fk_users_customuser_id FOREIGN KEY (customuser_id) REFERENCES public.users_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_customuser_user_permissions users_cust_permission_id_37ec2413b891a846_fk_auth_permission_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_customuser_user_permissions
    ADD CONSTRAINT users_cust_permission_id_37ec2413b891a846_fk_auth_permission_id FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_customuser_groups users_customuser_grou_group_id_10ad1f8ac50bdf1_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_customuser_groups
    ADD CONSTRAINT users_customuser_grou_group_id_10ad1f8ac50bdf1_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: work_workpageconfig work_work_gallery_id_695db303692469f1_fk_work_galleryservice_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_workpageconfig
    ADD CONSTRAINT work_work_gallery_id_695db303692469f1_fk_work_galleryservice_id FOREIGN KEY (gallery_id) REFERENCES public.work_galleryservice(id) DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

